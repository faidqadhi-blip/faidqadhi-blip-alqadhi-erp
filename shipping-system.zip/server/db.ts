import { eq, and, sql, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users } from "../drizzle/schema";
import {
  clients, type InsertClient,
  shipments, type InsertShipment,
  invoices, type InsertInvoice,
  entries, type InsertEntry,
  salesTransfers, type InsertSalesTransfer,
  payments, type InsertPayment,
  transferLogs, type InsertTransferLog,
  settings, type InsertSetting,
  serviceInvoices, vouchers, accounts, journalEntries, journalEntryItems,
  dailyMovements, currencies, languages, fonts,
  templates, permissions, backups, services,
  customsDeclarations, customsEntries, clearanceCosts, clearanceReceipts, clearanceDisbursements,
  jobOrders, internalTransportOrders, fixedAssets, evaluations,
  modulePermissions, permissionAuditLog, type InsertPermissionAuditLog,
  suppliers, type InsertSupplier,
  employees, type InsertEmployee,
  custodyRecords, type InsertCustodyRecord,
  cashboxes, type InsertCashbox,
  permits, permitDeductions, quantityDeductions, quantityDeductionDetails,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ===== Users =====
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    textFields.forEach((field) => {
      const value = user[field];
      if (value === undefined) return;
      values[field] = value ?? null;
      updateSet[field] = value ?? null;
    });
    if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
    if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
    else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ===== Clients =====
export async function listClients() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(clients).orderBy(sql`${clients.id} DESC`);
}

export async function getClient(id: number) {
  const db = await getDb();
  if (!db) return null;
  const r = await db.select().from(clients).where(eq(clients.id, id)).limit(1);
  return r[0] || null;
}

export async function createClient(data: InsertClient) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(clients).values(data as any);
  return { id: Number(r[0].insertId) };
}

export async function updateClient(id: number, data: Partial<InsertClient>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(clients).set(data as any).where(eq(clients.id, id));
}

export async function deleteClient(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(clients).where(eq(clients.id, id));
}

// ===== Shipments =====
export async function listShipments(filter?: { status?: string; invoiceType?: string; limit?: number }) {
  const db = await getDb();
  if (!db) return [];
  if (filter?.status) {
    return await db.select().from(shipments).where(eq(shipments.status, filter.status as any)).orderBy(sql`${shipments.id} DESC`).limit(filter?.limit || 1000);
  }
  if (filter?.invoiceType) {
    return await db.select().from(shipments).where(eq(shipments.invoiceType, filter.invoiceType as any)).orderBy(sql`${shipments.id} DESC`).limit(filter?.limit || 1000);
  }
  return await db.select().from(shipments).orderBy(sql`${shipments.id} DESC`).limit(filter?.limit || 1000);
}

export async function getShipment(id: number) {
  const db = await getDb();
  if (!db) return null;
  const r = await db.select().from(shipments).where(eq(shipments.id, id)).limit(1);
  return r[0] || null;
}

export async function createShipment(data: InsertShipment) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(shipments).values(data as any);
  return { id: Number(r[0].insertId) };
}

export async function updateShipment(id: number, data: Partial<InsertShipment>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(shipments).set(data as any).where(eq(shipments.id, id));
}

export async function deleteShipment(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(shipments).where(eq(shipments.id, id));
}

// ===== Invoices =====
export async function listInvoices(filter?: { status?: string; clientId?: number; limit?: number }) {
  const db = await getDb();
  if (!db) return [];
  if (filter?.clientId) {
    return await db.select().from(invoices).where(eq(invoices.clientId, filter.clientId)).orderBy(sql`${invoices.id} DESC`).limit(filter?.limit || 1000);
  }
  return await db.select().from(invoices).orderBy(sql`${invoices.id} DESC`).limit(filter?.limit || 1000);
}

export async function getInvoice(id: number) {
  const db = await getDb();
  if (!db) return null;
  const r = await db.select().from(invoices).where(eq(invoices.id, id)).limit(1);
  return r[0] || null;
}

export async function createInvoice(data: InsertInvoice) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(invoices).values(data as any);
  return { id: Number(r[0].insertId) };
}

export async function updateInvoice(id: number, data: Partial<InsertInvoice>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(invoices).set(data as any).where(eq(invoices.id, id));
}

export async function getNextInvoiceNumber() {
  const db = await getDb();
  if (!db) return 1;
  const r = await db.select({ maxNum: sql<number>`MAX(${invoices.number})`.as('maxNum') }).from(invoices);
  const maxNum = r[0]?.maxNum;
  return maxNum ? Number(maxNum) + 1 : 1;
}

// ===== Entries =====
export async function listEntries(limit?: number) {
  const db = await getDb();
  if (!db) return [];
  let q: any = db.select().from(entries).orderBy(sql`${entries.id} DESC`);
  if (limit) q = q.limit(limit);
  return await q;
}

export async function transferShipmentsToEntries(shipmentIds: number[], performedBy: string) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  
  const shipmentsData = await db.select().from(shipments).where(sql`${shipments.id} IN (${shipmentIds.join(',')})`);
  
  let count = 0;
  for (const s of shipmentsData) {
    await db.insert(entries).values({
      shipmentId: s.id,
      clientId: s.clientId,
      invoiceType: s.invoiceType,
      entryDate: s.entryDate,
      releaseDate: s.releaseDate,
      driverName: s.driverName,
      routeFrom: s.routeFrom,
      routeTo: s.routeTo,
      goodsType: s.goodsType,
      customsPort: s.customsPort,
      unit: s.unit,
      quantity: s.quantity,
      quantityTons: s.quantityTons,
    });
    await db.update(shipments).set({ status: 'تم_الترحيل' }).where(eq(shipments.id, s.id));
    count++;
  }
  
  await db.insert(transferLogs).values({
    transferType: 'ترحيل شحنات إلى المدخلات',
    recordCount: count,
    status: 'تم بنجاح',
    performedBy,
  });
  
  return { count };
}

// ===== Sales Transfers =====
export async function transferInvoicesToSales(invoiceIds: number[], performedBy: string) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  
  const invData = await db.select().from(invoices).where(sql`${invoices.id} IN (${invoiceIds.join(',')})`);
  
  let count = 0;
  const now = new Date();
  for (const inv of invData) {
    await db.insert(salesTransfers).values({
      invoiceId: inv.id,
      invoiceType: inv.invoiceType,
      clientId: inv.clientId,
      totalAmount: inv.totalAmount,
      monthNum: now.getMonth() + 1,
      year: now.getFullYear(),
    });
    count++;
  }
  
  await db.insert(transferLogs).values({
    transferType: 'ترحيل فواتير إلى تقرير المبيعات',
    recordCount: count,
    status: 'تم بنجاح',
    performedBy,
  });
  
  return { count };
}

// ===== Payments =====
export async function listPayments(clientId?: number) {
  const db = await getDb();
  if (!db) return [];
  if (clientId) {
    return await db.select().from(payments).where(eq(payments.clientId, clientId)).orderBy(sql`${payments.id} DESC`);
  }
  return await db.select().from(payments).orderBy(sql`${payments.id} DESC`);
}

export async function createPayment(data: InsertPayment) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(payments).values(data as any);
  return { id: Number(r[0].insertId) };
}

export async function deletePayment(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(payments).where(eq(payments.id, id));
}

// ===== Transfer Logs =====
export async function listTransferLogs(limit?: number) {
  const db = await getDb();
  if (!db) return [];
  let q: any = db.select().from(transferLogs).orderBy(sql`${transferLogs.performedAt} DESC`);
  if (limit) q = q.limit(limit);
  return await q;
}

// ===== Settings =====
export async function getSetting(key: string) {
  const db = await getDb();
  if (!db) return null;
  const r = await db.select().from(settings).where(eq(settings.key, key)).limit(1);
  return r[0]?.value || null;
}

export async function getAllSettings() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(settings);
}

export async function saveSetting(key: string, value: string) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(settings).values({ key, value }).onDuplicateKeyUpdate({ set: { value } });
}

// ===== Dashboard Stats =====
export async function getDashboardStats() {
  const db = await getDb();
  if (!db) return { totalClients: 0, totalShipments: 0, totalInvoices: 0, totalRevenue: 0, pendingShipments: 0 };
  
  const [clientsCount] = await db.select({ count: sql<number>`COUNT(*)`.as('count') }).from(clients);
  const [shipmentsCount] = await db.select({ count: sql<number>`COUNT(*)`.as('count') }).from(shipments);
  const [invoicesCount] = await db.select({ count: sql<number>`COUNT(*)`.as('count') }).from(invoices);
  const [revenue] = await db.select({ total: sql<number>`COALESCE(SUM(${invoices.totalAmount}), 0)`.as('total') }).from(invoices);
  const [pending] = await db.select({ count: sql<number>`COUNT(*)`.as('count') }).from(shipments).where(eq(shipments.status, 'جديد' as any));
  
  return {
    totalClients: Number(clientsCount?.count || 0),
    totalShipments: Number(shipmentsCount?.count || 0),
    totalInvoices: Number(invoicesCount?.count || 0),
    totalRevenue: Number(revenue?.total || 0),
    pendingShipments: Number(pending?.count || 0),
  };
}

// ===== Reports =====
export async function getMonthlySalesReport(year: number, month: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(salesTransfers).where(
    sql`${salesTransfers.year} = ${year} AND ${salesTransfers.monthNum} = ${month}`
  );
}

export async function getRevenueReport() {
  const db = await getDb();
  if (!db) return [];
  return await db.execute(
    sql`SELECT MONTH(${invoices.createdAt}) as month, YEAR(${invoices.createdAt}) as year, COALESCE(SUM(${invoices.totalAmount}), 0) as totalAmount, COUNT(*) as count FROM ${invoices} GROUP BY MONTH(${invoices.createdAt}), YEAR(${invoices.createdAt}) ORDER BY YEAR(${invoices.createdAt}) DESC, MONTH(${invoices.createdAt}) DESC LIMIT 24`
  ).then(r => (r as any)[0]);
}

export async function getClientStatement(clientId: number) {
  const db = await getDb();
  if (!db) return { client: null, invoices: [], payments: [], totalInvoices: 0, totalPayments: 0, balance: 0 };
  
  const client = await getClient(clientId);
  if (!client) return { client: null, invoices: [], payments: [], totalInvoices: 0, totalPayments: 0, balance: 0 };
  
  const clientInvoices = await db.select().from(invoices).where(eq(invoices.clientId, clientId));
  const clientPayments = await db.select().from(payments).where(eq(payments.clientId, clientId));
  
  const totalInvoices = clientInvoices.reduce((sum, inv) => sum + Number(inv.totalAmount || 0), 0);
  const totalPayments = clientPayments.reduce((sum, p) => sum + Number(p.amount || 0), 0);
  
  return {
    client,
    invoices: clientInvoices,
    payments: clientPayments,
    totalInvoices,
    totalPayments,
    balance: totalInvoices - totalPayments,
  };
}

// ===== Service Invoices =====
export async function listServiceInvoices(filter?: { clientId?: number; limit?: number }) {
  const db = await getDb();
  if (!db) return [];
  if (filter?.clientId) {
    return await db.select().from(serviceInvoices).where(eq(serviceInvoices.clientId, filter.clientId)).orderBy(sql`${serviceInvoices.id} DESC`).limit(filter?.limit || 1000);
  }
  return await db.select().from(serviceInvoices).orderBy(sql`${serviceInvoices.id} DESC`).limit(filter?.limit || 1000);
}

export async function getServiceInvoice(id: number) {
  const db = await getDb();
  if (!db) return null;
  const r = await db.select().from(serviceInvoices).where(eq(serviceInvoices.id, id)).limit(1);
  return r[0] || null;
}

export async function getNextServiceInvoiceNumber() {
  const db = await getDb();
  if (!db) return 1;
  const r = await db.select({ maxNum: sql<number>`MAX(${serviceInvoices.number})`.as('maxNum') }).from(serviceInvoices);
  const maxNum = r[0]?.maxNum;
  return maxNum ? Number(maxNum) + 1 : 1;
}

export async function createServiceInvoice(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(serviceInvoices).values(data as any);
  return { id: Number(r[0].insertId) };
}

export async function updateServiceInvoice(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(serviceInvoices).set(data as any).where(eq(serviceInvoices.id, id));
}

export async function deleteServiceInvoice(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(serviceInvoices).where(eq(serviceInvoices.id, id));
}

// ===== Vouchers =====
export async function listVouchers(filter?: { voucherType?: string; limit?: number }) {
  const db = await getDb();
  if (!db) return [];
  if (filter?.voucherType) {
    return await db.select().from(vouchers).where(eq(vouchers.voucherType, filter.voucherType as any)).orderBy(sql`${vouchers.id} DESC`).limit(filter?.limit || 1000);
  }
  return await db.select().from(vouchers).orderBy(sql`${vouchers.id} DESC`).limit(filter?.limit || 1000);
}

export async function getVoucher(id: number) {
  const db = await getDb();
  if (!db) return null;
  const r = await db.select().from(vouchers).where(eq(vouchers.id, id)).limit(1);
  return r[0] || null;
}

export async function getNextVoucherNumber() {
  const db = await getDb();
  if (!db) return 1;
  const r = await db.select({ maxNum: sql<number>`MAX(${vouchers.number})`.as('maxNum') }).from(vouchers);
  const maxNum = r[0]?.maxNum;
  return maxNum ? Number(maxNum) + 1 : 1;
}

export async function createVoucher(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  
  // If cashboxId is provided, try to fill cashBox (string name) for legacy compatibility
  if (data.cashboxId && !data.cashBox) {
    const cb = await db.select().from(cashboxes).where(eq(cashboxes.id, data.cashboxId)).limit(1);
    if (cb[0]) {
      data.cashBox = cb[0].name;
    }
  }
  
  const r = await db.insert(vouchers).values(data as any);
  return { id: Number(r[0].insertId) };
}

export async function updateVoucher(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(vouchers).set(data as any).where(eq(vouchers.id, id));
}

export async function deleteVoucher(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(vouchers).where(eq(vouchers.id, id));
}

export async function postVoucherToLedger(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");

  const voucher = await getVoucher(id);
  if (!voucher) throw new Error("Voucher not found");
  if (voucher.status === "مرحل") throw new Error("Voucher already posted");

  // Load account mappings from settings
  const sysSettings = await db.select().from(settings);
  const getMapping = (key: string) => sysSettings.find(s => s.key === key)?.value;
  
  const receivableAccId = Number(getMapping("acc_receivable_id") || 2);
  const revenueAccId = Number(getMapping("acc_revenue_id") || 4); // Default to a revenue account
  const expenseAccId = Number(getMapping("acc_expense_id") || 3);
  
  // Find linked account for the cashbox
  let cashboxAccId = 1; // Default fallback
  if (voucher.cashboxId) {
    const cbRows = await db.select().from(cashboxes).where(eq(cashboxes.id, voucher.cashboxId)).limit(1);
    if (cbRows[0]?.linkedAccountId) {
      cashboxAccId = cbRows[0].linkedAccountId;
    }
  }

  // 1. Create Journal Entry
  const nextJE = await getNextJournalEntryNumber();
  const jeData = {
    entryNumber: nextJE,
    date: voucher.date || new Date().toISOString().split("T")[0],
    description: `ترحيل سند ${voucher.voucherType === "سند_قبض" ? "قبض" : "صرف"} رقم ${voucher.number}: ${voucher.description || ""}`,
    entryType: "قيد_يومي",
    items: [] as any[]
  };

  const amountStr = String(voucher.amount);
  
  if (voucher.voucherType === "سند_قبض") {
    // Debit Cash (from cashbox account), Credit Revenue
    jeData.items = [
      { accountId: cashboxAccId, debit: amountStr, credit: "0", description: voucher.description },
      { accountId: revenueAccId, debit: "0", credit: amountStr, description: voucher.description },
    ];
  } else {
    // Debit Expense/Supplier, Credit Cash (from cashbox account)
    jeData.items = [
      { accountId: expenseAccId, debit: amountStr, credit: "0", description: voucher.description },
      { accountId: cashboxAccId, debit: "0", credit: amountStr, description: voucher.description },
    ];
  }

  const { id: entryId } = await createJournalEntry(jeData);
  
  // 2. Post the Journal Entry (Update account balances)
  await postJournalEntry(entryId);

  // 3. Update Voucher Status
  await db.update(vouchers).set({ status: "مرحل" as any }).where(eq(vouchers.id, id));

  return { success: true, entryId };
}

// ===== Accounts (Chart of Accounts) =====
export async function listAccounts() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(accounts).orderBy(accounts.code);
}

export async function createAccount(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(accounts).values(data as any);
  return { id: Number(r[0].insertId) };
}

export async function updateAccount(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(accounts).set(data as any).where(eq(accounts.id, id));
}

export async function deleteAccount(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(accounts).where(eq(accounts.id, id));
}

// ===== Journal Entries =====
export async function listJournalEntries(filter?: { entryType?: string; limit?: number }) {
  const db = await getDb();
  if (!db) return [];
  if (filter?.entryType) {
    return await db.select().from(journalEntries).where(eq(journalEntries.entryType, filter.entryType as any)).orderBy(sql`${journalEntries.id} DESC`).limit(filter?.limit || 1000);
  }
  return await db.select().from(journalEntries).orderBy(sql`${journalEntries.id} DESC`).limit(filter?.limit || 1000);
}

export async function getJournalEntry(id: number) {
  const db = await getDb();
  if (!db) return null;
  const entry = await db.select().from(journalEntries).where(eq(journalEntries.id, id)).limit(1);
  if (!entry.length) return null;
  const items = await db.select().from(journalEntryItems).where(eq(journalEntryItems.entryId, id));
  return { ...entry[0], items };
}

export async function getNextJournalEntryNumber() {
  const db = await getDb();
  if (!db) return 1;
  const r = await db.select({ maxNum: sql<number>`MAX(${journalEntries.entryNumber})`.as('maxNum') }).from(journalEntries);
  const maxNum = r[0]?.maxNum;
  return maxNum ? Number(maxNum) + 1 : 1;
}

export async function createJournalEntry(data: { entryNumber: number; date?: string; description?: string; entryType: string; items: { accountId: number; debit: string; credit: string; description?: string }[] }) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const { items, ...entryData } = data;
  const r = await db.insert(journalEntries).values(entryData as any);
  const entryId = Number(r[0].insertId);
  for (const item of items) {
    await db.insert(journalEntryItems).values({ entryId, ...item });
  }
  return { id: entryId };
}

export async function postJournalEntry(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(journalEntries).set({ status: 'مرحل' as any }).where(eq(journalEntries.id, id));
  const items = await db.select().from(journalEntryItems).where(eq(journalEntryItems.entryId, id));
  for (const item of items) {
    if (Number(item.debit) > 0) {
      await db.update(accounts).set({ balance: sql`${accounts.balance} + ${item.debit}` }).where(eq(accounts.id, item.accountId));
    }
    if (Number(item.credit) > 0) {
      await db.update(accounts).set({ balance: sql`${accounts.balance} - ${item.credit}` }).where(eq(accounts.id, item.accountId));
    }
  }
}

export async function deleteJournalEntry(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(journalEntryItems).where(eq(journalEntryItems.entryId, id));
  await db.delete(journalEntries).where(eq(journalEntries.id, id));
}

// ===== Daily Movements =====
export async function listDailyMovements(filter?: { date?: string; type?: string; limit?: number }) {
  const db = await getDb();
  if (!db) return [];
  if (filter?.date) {
    return await db.select().from(dailyMovements).where(eq(dailyMovements.date, filter.date)).orderBy(sql`${dailyMovements.id} DESC`).limit(filter?.limit || 1000);
  }
  if (filter?.type) {
    return await db.select().from(dailyMovements).where(eq(dailyMovements.type, filter.type as any)).orderBy(sql`${dailyMovements.id} DESC`).limit(filter?.limit || 1000);
  }
  return await db.select().from(dailyMovements).orderBy(sql`${dailyMovements.id} DESC`).limit(filter?.limit || 1000);
}

export async function createDailyMovement(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(dailyMovements).values(data as any);
  return { id: Number(r[0].insertId) };
}

export async function deleteDailyMovement(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(dailyMovements).where(eq(dailyMovements.id, id));
}



// ===== Currencies =====
export async function listCurrencies() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(currencies);
}

export async function createCurrency(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(currencies).values(data as any);
  return { id: Number(r[0].insertId) };
}

export async function updateCurrency(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(currencies).set(data as any).where(eq(currencies.id, id));
}

export async function deleteCurrency(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(currencies).where(eq(currencies.id, id));
}

// ===== Languages =====
export async function listLanguages() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(languages);
}

export async function createLanguage(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(languages).values(data as any);
  return { id: Number(r[0].insertId) };
}

export async function deleteLanguage(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(languages).where(eq(languages.id, id));
}

// ===== Fonts =====
export async function listFonts() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(fonts);
}

export async function createFont(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(fonts).values(data as any);
  return { id: Number(r[0].insertId) };
}

export async function deleteFont(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(fonts).where(eq(fonts.id, id));
}

// ===== Templates =====
export async function listTemplates() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(templates).orderBy(templates.type);
}

export async function createTemplate(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(templates).values(data as any);
  return { id: Number(r[0].insertId) };
}

export async function updateTemplate(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(templates).set(data as any).where(eq(templates.id, id));
}

export async function deleteTemplate(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(templates).where(eq(templates.id, id));
}

// ===== Permissions =====
export async function listPermissions() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(permissions).orderBy(permissions.role);
}

export async function createPermission(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(permissions).values(data as any);
  return { id: Number(r[0].insertId) };
}

export async function updatePermission(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(permissions).set(data as any).where(eq(permissions.id, id));
}

export async function deletePermission(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(permissions).where(eq(permissions.id, id));
}

// ===== Backups =====
export async function listBackups() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(backups).orderBy(sql`${backups.id} DESC`).limit(50);
}

export async function createBackup(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(backups).values(data as any);
  return { id: Number(r[0].insertId) };
}

export async function deleteBackup(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(backups).where(eq(backups.id, id));
}

// ===== Services =====
export async function listServices() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(services).orderBy(services.code);
}

export async function createService(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(services).values(data as any);
  return { id: Number(r[0].insertId) };
}

export async function updateService(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(services).set(data as any).where(eq(services.id, id));
}

export async function deleteService(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(services).where(eq(services.id, id));
}

// ===== Customs Declarations (التخليص الجمركي) =====
export async function listDeclarations(input?: { status?: string; limit?: number }) {
  const db = await getDb();
  if (!db) return [];
  const q = db.select().from(customsDeclarations);
  if (input?.status && input.status !== "all") {
    return await q.where(eq(customsDeclarations.status, input.status as any)).orderBy(desc(customsDeclarations.id));
  }
  return await q.orderBy(desc(customsDeclarations.id));
}

export async function getDeclaration(id: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(customsDeclarations).where(eq(customsDeclarations.id, id)).limit(1);
  return rows[0] || null;
}

export async function nextDeclarationNumber() {
  const db = await getDb();
  if (!db) return 1;
  const rows = await db.select({ max: sql<number>`MAX(id)` }).from(customsDeclarations);
  return (rows[0]?.max || 0) + 1;
}

export async function createDeclaration(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  try {
    const r = await db.insert(customsDeclarations).values(data as any);
    const declarationId = Number(r[0].insertId);
    
    // If linked to a customs entry, update its status
    if (data.customsEntryId) {
      await db.update(customsEntries).set({ status: 'مرتبط_ببيان' as any }).where(eq(customsEntries.id, data.customsEntryId));
    }
    
    return { id: declarationId };
  } catch (e: any) {
    if (e.code === "ER_DUP_ENTRY") {
      throw new Error("رقم القيد أو رقم البيان موجود مسبقاً");
    }
    throw e;
  }
}

export async function updateDeclaration(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  try {
    await db.update(customsDeclarations).set(data as any).where(eq(customsDeclarations.id, id));
  } catch (e: any) {
    if (e.code === "ER_DUP_ENTRY") {
      throw new Error("رقم القيد أو رقم البيان موجود مسبقاً");
    }
    throw e;
  }
}

export async function deleteDeclaration(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  // Delete related records
  await db.delete(clearanceCosts).where(eq(clearanceCosts.declarationId, id));
  await db.delete(clearanceReceipts).where(eq(clearanceReceipts.declarationId, id));
  await db.delete(clearanceDisbursements).where(eq(clearanceDisbursements.declarationId, id));
  await db.delete(customsDeclarations).where(eq(customsDeclarations.id, id));
}

// ===== Clearance Costs =====
export async function listClearanceCosts(declarationId?: number) {
  const db = await getDb();
  if (!db) return [];
  if (declarationId) {
    return await db.select().from(clearanceCosts).where(eq(clearanceCosts.declarationId, declarationId));
  }
  return await db.select().from(clearanceCosts);
}

export async function createClearanceCost(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(clearanceCosts).values(data as any);
  return { id: Number(r[0].insertId) };
}

export async function updateClearanceCost(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(clearanceCosts).set(data as any).where(eq(clearanceCosts.id, id));
}

export async function deleteClearanceCost(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(clearanceCosts).where(eq(clearanceCosts.id, id));
}

export async function getClearanceSummary(declarationId: number) {
  const db = await getDb();
  if (!db) return null;
  // Get declaration
  const rows = await db.select().from(customsDeclarations).where(eq(customsDeclarations.id, declarationId)).limit(1);
  if (!rows[0]) return null;
  const decl = rows[0];
  // Get costs
  const costRows = await db.select().from(clearanceCosts).where(eq(clearanceCosts.declarationId, declarationId));
  const cost = costRows[0] || null;
  // Get receipts
  const receipts = await db.select().from(clearanceReceipts).where(eq(clearanceReceipts.declarationId, declarationId));
  // Get disbursements
  const disbursements = await db.select().from(clearanceDisbursements).where(eq(clearanceDisbursements.declarationId, declarationId));

  const totalCost = Number(cost?.netCost || cost?.totalCost || 0);
  const totalReceived = receipts.reduce((sum, r) => sum + Number(r.amount || 0), 0);
  const totalPaid = disbursements.reduce((sum, d) => sum + Number(d.amount || 0), 0);

  return {
    declaration: decl,
    cost,
    receipts,
    disbursements,
    totals: {
      totalCost,
      totalReceived,
      totalPaid,
      net: totalReceived - totalCost - totalPaid,
    },
  };
}

// ===== Clearance Receipts (مقبوضات) =====
export async function listClearanceReceipts(declarationId?: number) {
  const db = await getDb();
  if (!db) return [];
  if (declarationId) {
    return await db.select().from(clearanceReceipts).where(eq(clearanceReceipts.declarationId, declarationId));
  }
  return await db.select().from(clearanceReceipts);
}

export async function createClearanceReceipt(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(clearanceReceipts).values(data as any);
  const receiptId = Number(r[0].insertId);

  // Auto-create receipt voucher
  try {
    const declRows = await db.select().from(customsDeclarations).where(eq(customsDeclarations.id, data.declarationId)).limit(1);
    const decl = declRows[0];
    const nextNum = await getNextVoucherNumber();
    const voucherData = {
      number: nextNum,
      voucherType: "سند_قبض" as const,
      clientId: decl?.clientId ?? null,
      amount: data.amount,
      currency: data.currency ?? "SAR",
      date: data.paymentDate ?? new Date().toISOString().split("T")[0],
      paymentMethod: data.paymentMethod ?? null,
      cashboxId: data.cashboxId ?? null,
      sourceDeclarationId: data.declarationId,
      description: `سند قبض - بيان جمركي: ${decl?.declarationNumber ?? "N/A"} ${data.notes ? "- " + data.notes : ""}`,
      status: "معتمد" as const,
    };
    const rV = await db.insert(vouchers).values(voucherData as any);
    const vId = Number(rV[0].insertId);
    // Link voucher back to receipt
    await db.update(clearanceReceipts).set({ voucherId: vId }).where(eq(clearanceReceipts.id, receiptId));
  } catch (e) {
    console.error("[Auto-Voucher] Failed to create receipt voucher:", e);
  }

  return { id: receiptId };
}

export async function deleteClearanceReceipt(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(clearanceReceipts).where(eq(clearanceReceipts.id, id));
}

// ===== Clearance Disbursements (مدفوعات) =====
export async function listClearanceDisbursements(declarationId?: number) {
  const db = await getDb();
  if (!db) return [];
  if (declarationId) {
    return await db.select().from(clearanceDisbursements).where(eq(clearanceDisbursements.declarationId, declarationId));
  }
  return await db.select().from(clearanceDisbursements);
}

export async function createClearanceDisbursement(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(clearanceDisbursements).values(data as any);
  const disbursementId = Number(r[0].insertId);

  // Auto-create payment voucher
  try {
    const declRows = await db.select().from(customsDeclarations).where(eq(customsDeclarations.id, data.declarationId)).limit(1);
    const decl = declRows[0];
    const nextNum = await getNextVoucherNumber();
    const voucherData = {
      number: nextNum,
      voucherType: "سند_صرف" as const,
      clientId: null,
      amount: data.amount,
      currency: data.currency ?? "SAR",
      date: data.paymentDate ?? new Date().toISOString().split("T")[0],
      paymentMethod: data.paymentMethod ?? null,
      cashboxId: data.cashboxId ?? null,
      sourceDeclarationId: data.declarationId,
      description: `سند صرف - ${data.payee ?? "جهة غير محددة"} - بيان جمركي: ${decl?.declarationNumber ?? "N/A"} ${data.notes ? "- " + data.notes : ""}`,
      status: "معتمد" as const,
    };
    const rV = await db.insert(vouchers).values(voucherData as any);
    const vId = Number(rV[0].insertId);
    // Link voucher back to disbursement
    await db.update(clearanceDisbursements).set({ voucherId: vId }).where(eq(clearanceDisbursements.id, disbursementId));
  } catch (e) {
    console.error("[Auto-Voucher] Failed to create payment voucher:", e);
  }

  return { id: disbursementId };
}

export async function deleteClearanceDisbursement(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(clearanceDisbursements).where(eq(clearanceDisbursements.id, id));
}

// ===== Job Orders (أوامر العمل) =====
export async function listJobOrders() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(jobOrders);
}
export async function getJobOrderById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(jobOrders).where(eq(jobOrders.id, id)).limit(1);
  return rows[0];
}
export async function nextJobOrderNumber(): Promise<number> {
  const db = await getDb();
  if (!db) return 1;
  const rows = await db.select({ max: sql<number>`MAX(CAST(SUBSTRING(jobNumber, 4) AS UNSIGNED)) as max` }).from(jobOrders);
  return (rows[0]?.max ?? 0) + 1;
}
export async function createJobOrder(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const next = await nextJobOrderNumber();
  const jobNumber = `JO-${String(next).padStart(4, "0")}`;
  const r = await db.insert(jobOrders).values({ ...data, jobNumber } as any);
  return { id: Number(r[0].insertId), jobNumber };
}
export async function updateJobOrder(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(jobOrders).set(data).where(eq(jobOrders.id, id));
}
export async function deleteJobOrder(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(jobOrders).where(eq(jobOrders.id, id));
}

// ===== Internal Transport Orders =====
export async function listInternalTransportOrders(jobOrderId?: number) {
  const db = await getDb();
  if (!db) return [];
  if (jobOrderId) {
    return await db.select().from(internalTransportOrders).where(eq(internalTransportOrders.jobOrderId, jobOrderId));
  }
  return await db.select().from(internalTransportOrders);
}
export async function createInternalTransportOrder(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(internalTransportOrders).values(data as any);
  return { id: Number(r[0].insertId) };
}
export async function updateInternalTransportOrder(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(internalTransportOrders).set(data).where(eq(internalTransportOrders.id, id));
}
export async function deleteInternalTransportOrder(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(internalTransportOrders).where(eq(internalTransportOrders.id, id));
}

// ===== Fixed Assets =====
export async function listFixedAssets() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(fixedAssets);
}
export async function createFixedAsset(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(fixedAssets).values(data as any);
  return { id: Number(r[0].insertId) };
}
export async function updateFixedAsset(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(fixedAssets).set(data).where(eq(fixedAssets.id, id));
}
export async function deleteFixedAsset(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(fixedAssets).where(eq(fixedAssets.id, id));
}
export async function runDepreciation() {
  const db = await getDb();
  if (!db) return 0;
  const assets = await db.select().from(fixedAssets).where(eq(fixedAssets.status, "نشط"));
  let count = 0;
  for (const asset of assets) {
    const monthly = Number(asset.purchaseValue) / (Number(asset.usefulLifeYears) * 12);
    const newAccumulated = Number(asset.accumulatedDepreciation) + monthly;
    const newBookValue = Number(asset.purchaseValue) - newAccumulated;
    await db.update(fixedAssets).set({
      monthlyDepreciation: String(monthly),
      accumulatedDepreciation: String(newAccumulated),
      bookValue: String(newBookValue),
    }).where(eq(fixedAssets.id, asset.id));
    count++;
  }
  return count;
}

// ===== Evaluations =====
export async function listEvaluations(jobOrderId?: number) {
  const db = await getDb();
  if (!db) return [];
  if (jobOrderId) {
    return await db.select().from(evaluations).where(eq(evaluations.jobOrderId, jobOrderId));
  }
  return await db.select().from(evaluations);
}

export async function createEvaluation(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(evaluations).values(data as any);
  return { id: Number(r[0].insertId) };
}

// ===== Module Permissions (Access Control) =====
export async function listAllUsers() {
  const db = await getDb();
  if (!db) return [];
  return await db.select({ id: users.id, name: users.name, email: users.email, role: users.role }).from(users);
}

export async function listModulePermissions(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(modulePermissions).where(eq(modulePermissions.userId, userId));
}

export async function upsertModulePermission(userId: number, moduleId: string, canView: boolean) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const existing = await db.select().from(modulePermissions)
    .where(and(eq(modulePermissions.userId, userId), eq(modulePermissions.moduleId, moduleId)));
  if (existing.length > 0) {
    await db.update(modulePermissions).set({ canView }).where(eq(modulePermissions.id, existing[0].id));
  } else {
    await db.insert(modulePermissions).values({ userId, moduleId, canView });
  }
  return { success: true };
}

// ===== Permission Audit Log (سجل تغييرات الصلاحيات) =====
export async function logPermissionChange(data: InsertPermissionAuditLog) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(permissionAuditLog).values(data as any);
  return { id: Number(r[0].insertId) };
}

export async function logPermissionChangeAsync(data: InsertPermissionAuditLog) {
  // Fire-and-forget: log after the permission change without blocking the response
  logPermissionChange(data).catch(err => console.warn("[PermissionAudit] failed to log:", err));
}

export async function listPermissionAuditLogs(userId?: number, limit = 100) {
  const db = await getDb();
  if (!db) return [];
  const selectFields = {
    id: permissionAuditLog.id,
    userId: permissionAuditLog.userId,
    moduleId: permissionAuditLog.moduleId,
    action: permissionAuditLog.action,
    grantedBy: permissionAuditLog.grantedBy,
    createdAt: permissionAuditLog.createdAt,
    userName: users.name,
    grantedByName: sql<string>`(SELECT name FROM ${users} WHERE id = ${permissionAuditLog.grantedBy})`,
  };
  const base = db.select(selectFields).from(permissionAuditLog)
    .leftJoin(users, eq(users.id, permissionAuditLog.userId))
    .orderBy(desc(permissionAuditLog.id))
    .limit(limit);
  if (userId !== undefined) {
    return await base.where(eq(permissionAuditLog.userId, userId)) as any[];
  }
	  return await base as any[];
	}
	
	// ===== القيود الجمركية (Customs Entries) =====
	export async function createCustomsEntry(data: any) {
	  const db = await getDb();
	  if (!db) throw new Error("DB unavailable");
	  const r = await db.insert(customsEntries).values(data as any);
	  return { id: Number(r[0].insertId) };
	}
	
	export async function listCustomsEntries(limit = 1000) {
	  const db = await getDb();
	  if (!db) return [];
	  return await db.select().from(customsEntries).orderBy(desc(customsEntries.id)).limit(limit);
	}
	
	export async function getCustomsEntry(id: number) {
	  const db = await getDb();
	  if (!db) return null;
	  const r = await db.select().from(customsEntries).where(eq(customsEntries.id, id)).limit(1);
	  return r[0] || null;
	}
	
	export async function getCustomsEntryByNumber(entryNumber: string) {
	  const db = await getDb();
	  if (!db) return null;
	  const r = await db.select().from(customsEntries).where(eq(customsEntries.entryNumber, entryNumber)).limit(1);
	  return r[0] || null;
	}
	
	export async function updateCustomsEntry(id: number, data: any) {
	  const db = await getDb();
	  if (!db) throw new Error("DB unavailable");
	  await db.update(customsEntries).set(data).where(eq(customsEntries.id, id));
	  return { success: true };
	}
	
	export async function deleteCustomsEntry(id: number) {
	  const db = await getDb();
	  if (!db) throw new Error("DB unavailable");
	  await db.delete(customsEntries).where(eq(customsEntries.id, id));
	  return { success: true };
	}
	
	// ===== الموردين (Suppliers) =====
export async function createSupplier(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(suppliers).values(data as any);
  return { id: Number(r[0].insertId) };
}
export async function listSuppliers() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(suppliers).orderBy(sql`${suppliers.id} DESC`);
}
export async function updateSupplier(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(suppliers).set(data as any).where(eq(suppliers.id, id));
  return { success: true };
}
export async function deleteSupplier(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(suppliers).where(eq(suppliers.id, id));
  return { success: true };
}

// ===== الموظفين (Employees) =====
export async function createEmployee(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(employees).values(data as any);
  return { id: Number(r[0].insertId) };
}
export async function listEmployees() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(employees).orderBy(sql`${employees.id} DESC`);
}
export async function updateEmployee(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(employees).set(data as any).where(eq(employees.id, id));
  return { success: true };
}
export async function deleteEmployee(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(employees).where(eq(employees.id, id));
  return { success: true };
}

// ===== العهد والسلف (Custody) =====
export async function createCustodyRecord(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(custodyRecords).values(data as any);
  return { id: Number(r[0].insertId) };
}
export async function listCustodyRecords() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(custodyRecords).orderBy(sql`${custodyRecords.id} DESC`);
}
export async function updateCustodyRecord(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(custodyRecords).set(data as any).where(eq(custodyRecords.id, id));
  return { success: true };
}
export async function deleteCustodyRecord(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(custodyRecords).where(eq(custodyRecords.id, id));
  return { success: true };
}

// ===== الصناديق والبنوك (Cashboxes) =====
export async function createCashbox(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const r = await db.insert(cashboxes).values(data as any);
  return { id: Number(r[0].insertId) };
}
export async function listCashboxes() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(cashboxes).orderBy(sql`${cashboxes.id} DESC`);
}
export async function updateCashbox(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(cashboxes).set(data as any).where(eq(cashboxes.id, id));
  return { success: true };
}
export async function deleteCashbox(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(cashboxes).where(eq(cashboxes.id, id));
  return { success: true };
}

// ===== التراخيص (Permits) =====
export async function listPermits() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(permits).orderBy(sql`${permits.id} DESC`);
}

export async function createPermit(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  // Set initial remaining quantity equal to total quantity
  const permitData = { ...data, remainingQuantity: data.totalQuantity };
  const r = await db.insert(permits).values(permitData as any);
  return { id: Number(r[0].insertId) };
}

export async function updatePermit(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(permits).set(data as any).where(eq(permits.id, id));
}

export async function deletePermit(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(permits).where(eq(permits.id, id));
}

// ===== تخصيم التراخيص (Permit Deductions) =====
export async function listPermitDeductions(permitId?: number) {
  const db = await getDb();
  if (!db) return [];
  if (permitId) {
    return await db.select().from(permitDeductions).where(eq(permitDeductions.permitId, permitId)).orderBy(sql`${permitDeductions.id} DESC`);
  }
  return await db.select().from(permitDeductions).orderBy(sql`${permitDeductions.id} DESC`);
}

export async function createPermitDeduction(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  
  const permit = (await db.select().from(permits).where(eq(permits.id, data.permitId)).limit(1))[0];
  if (!permit) throw new Error("Permit not found");
  
  const deductedQty = Number(data.deductedQuantity);
  const currentRemaining = Number(permit.remainingQuantity);
  
  if (deductedQty > currentRemaining) {
    throw new Error("Deducted quantity exceeds permit remaining quantity");
  }
  
  const newRemaining = currentRemaining - deductedQty;
  
  // 1. Create deduction record
  const r = await db.insert(permitDeductions).values({
    ...data,
    remainingQuantity: newRemaining.toString()
  } as any);
  
  // 2. Update permit remaining quantity
  await db.update(permits).set({ remainingQuantity: newRemaining.toString() as any }).where(eq(permits.id, data.permitId));
  
  return { id: Number(r[0].insertId) };
}

// ===== تخصيم الكميات (Quantity Deductions) =====
export async function listQuantityDeductions() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(quantityDeductions).orderBy(sql`${quantityDeductions.id} DESC`);
}

export async function getQuantityDeduction(id: number) {
  const db = await getDb();
  if (!db) return null;
  const r = await db.select().from(quantityDeductions).where(eq(quantityDeductions.id, id)).limit(1);
  return r[0] || null;
}

export async function createQuantityDeduction(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  // Set initial remaining quantity equal to total quantity
  const deductionData = { ...data, remainingQuantity: data.totalQuantity };
  const r = await db.insert(quantityDeductions).values(deductionData as any);
  return { id: Number(r[0].insertId) };
}

export async function deleteQuantityDeduction(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  // Delete details first
  await db.delete(quantityDeductionDetails).where(eq(quantityDeductionDetails.quantityDeductionId, id));
  await db.delete(quantityDeductions).where(eq(quantityDeductions.id, id));
  return { success: true };
}

export async function listQuantityDeductionDetails(quantityDeductionId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(quantityDeductionDetails)
    .where(eq(quantityDeductionDetails.quantityDeductionId, quantityDeductionId))
    .orderBy(sql`${quantityDeductionDetails.id} DESC`);
}

export async function createQuantityDeductionDetail(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  
  const mainDeduction = (await db.select().from(quantityDeductions).where(eq(quantityDeductions.id, data.quantityDeductionId)).limit(1))[0];
  if (!mainDeduction) throw new Error("Main quantity deduction record not found");
  
  const deductedQty = Number(data.deductedQuantity);
  const currentRemaining = Number(mainDeduction.remainingQuantity);
  
  if (deductedQty > currentRemaining) {
    throw new Error("Deducted quantity exceeds remaining quantity");
  }
  
  const newRemaining = currentRemaining - deductedQty;
  
  // 1. Create detail record
  const r = await db.insert(quantityDeductionDetails).values({
    ...data,
    remainingQuantity: newRemaining.toString()
  } as any);
  
  // 2. Update main deduction remaining quantity
  await db.update(quantityDeductions).set({ remainingQuantity: newRemaining.toString() as any }).where(eq(quantityDeductions.id, data.quantityDeductionId));
  
  return { id: Number(r[0].insertId) };
}
