import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import { logPermissionChange, logPermissionChangeAsync, listPermissionAuditLogs } from "./db";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createCtx(role: "admin" | "user"): TrpcContext {
  const user: AuthenticatedUser = {
    id: 9901,
    openId: "permission-audit-test-user",
    email: "audit-test@example.com",
    name: "Audit Test User",
    loginMethod: "manus",
    role,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

const TEST_MODULE_ID = "sales-report";

describe("permission audit log", () => {
  it("writes an audit entry synchronously and reads it back", async () => {
    await logPermissionChange({
      userId: 9901,
      moduleId: TEST_MODULE_ID,
      action: "granted",
      grantedBy: 9901,
    });

    const logs = await listPermissionAuditLogs(9901, 10);
    const match = logs.find(
      (l: any) => l.userId === 9901 && l.moduleId === TEST_MODULE_ID && l.action === "granted",
    );
    expect(match).toBeTruthy();
    expect(match.grantedBy).toBe(9901);
  });

  it("writes audit entry asynchronously without throwing", async () => {
    await logPermissionChangeAsync({
      userId: 9901,
      moduleId: "client-statement",
      action: "revoked",
      grantedBy: 9901,
    });
    // Give the fire-and-forget promise a moment to settle
    await new Promise(r => setTimeout(r, 800));

    const logs = await listPermissionAuditLogs(9901, 10);
    const match = logs.find(
      (l: any) => l.userId === 9901 && l.moduleId === "client-statement" && l.action === "revoked",
    );
    expect(match).toBeTruthy();
  });

  it("setPermission writes an audit entry via the router", async () => {
    const adminCtx = createCtx("admin");
    const caller = appRouter.createCaller(adminCtx);

    await caller.moduleAccess.setPermission({ userId: 9901, moduleId: "vouchers", canView: true });

    await new Promise(r => setTimeout(r, 800));
    const logs = await listPermissionAuditLogs(9901, 10);
    const match = logs.find((l: any) => l.userId === 9901 && l.moduleId === "vouchers" && l.action === "granted");
    expect(match).toBeTruthy();
  });

  it("setPermissions writes one audit entry per module (granted/revoked)", async () => {
    const adminCtx = createCtx("admin");
    const caller = appRouter.createCaller(adminCtx);

    await caller.moduleAccess.setPermissions({
      userId: 9901,
      permissions: [
        { moduleId: "revenue", canView: true },
        { moduleId: "payments", canView: false },
      ],
    });

    await new Promise(r => setTimeout(r, 800));
    const logs = await listPermissionAuditLogs(9901, 10);
    const granted = logs.find((l: any) => l.userId === 9901 && l.moduleId === "revenue" && l.action === "granted");
    const revoked = logs.find((l: any) => l.userId === 9901 && l.moduleId === "payments" && l.action === "revoked");
    expect(granted).toBeTruthy();
    expect(revoked).toBeTruthy();
  });

  it("blocks non-admin from reading the audit log", async () => {
    const userCtx = createCtx("user");
    const caller = appRouter.createCaller(userCtx);

    await expect(caller.moduleAccess.auditLog()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("allows admin to read the audit log", async () => {
    const adminCtx = createCtx("admin");
    const caller = appRouter.createCaller(adminCtx);

    const logs = await caller.moduleAccess.auditLog();
    expect(Array.isArray(logs)).toBe(true);
  });
});
