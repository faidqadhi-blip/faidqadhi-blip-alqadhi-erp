import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAdminContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("shipping-system", () => {
  it("should have appRouter with all required routers", () => {
    expect(appRouter).toBeDefined();
    // Create caller and check all routers exist
    const caller = appRouter.createCaller(createAdminContext());
    expect((caller as any).clients).toBeDefined();
    expect((caller as any).shipments).toBeDefined();
    expect((caller as any).invoices).toBeDefined();
    expect((caller as any).transferLogs).toBeDefined();
    expect((caller as any).payments).toBeDefined();
    expect((caller as any).settings).toBeDefined();
    expect((caller as any).dashboard).toBeDefined();
    expect((caller as any).statements).toBeDefined();
  });

  it("should have clients router with CRUD operations", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    const clientRouter = (caller as any).clients;
    expect(typeof clientRouter.list).toBe("function");
    expect(typeof clientRouter.create).toBe("function");
    expect(typeof clientRouter.update).toBe("function");
    expect(typeof clientRouter.delete).toBe("function");
  });

  it("should have shipments router with CRUD operations", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    const shipmentsRouter = (caller as any).shipments;
    expect(typeof shipmentsRouter.list).toBe("function");
    expect(typeof shipmentsRouter.create).toBe("function");
    expect(typeof shipmentsRouter.update).toBe("function");
    expect(typeof shipmentsRouter.delete).toBe("function");
  });

  it("should have invoices router with create and list operations", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    const invoicesRouter = (caller as any).invoices;
    expect(typeof invoicesRouter.list).toBe("function");
    expect(typeof invoicesRouter.create).toBe("function");
    expect(typeof invoicesRouter.update).toBe("function");
    expect(typeof invoicesRouter.nextNumber).toBe("function");
  });

  it("should have dashboard stats procedure", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    const dashboardRouter = (caller as any).dashboard;
    expect(typeof dashboardRouter.stats).toBe("function");
  });

  it("should fetch dashboard stats successfully", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    const stats = await (caller as any).dashboard.stats();
    expect(stats).toBeDefined();
  });

  it("should fetch clients list", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    const clients = await (caller as any).clients.list();
    expect(clients).toBeDefined();
    expect(Array.isArray(clients)).toBe(true);
  });

  it("should fetch shipments list", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    const shipments = await (caller as any).shipments.list();
    expect(shipments).toBeDefined();
    expect(Array.isArray(shipments)).toBe(true);
  });

  it("should fetch invoices list", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    const invoices = await (caller as any).invoices.list();
    expect(invoices).toBeDefined();
    expect(Array.isArray(invoices)).toBe(true);
  });

  it("should fetch transfer logs", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    const logs = await (caller as any).transferLogs.list();
    expect(logs).toBeDefined();
    expect(Array.isArray(logs)).toBe(true);
  });

  it("should fetch all settings", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    const allSettings = await (caller as any).settings.getAll();
    expect(allSettings).toBeDefined();
    expect(Array.isArray(allSettings)).toBe(true);
  });

  it("should validate client creation input", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    // Should fail without required fields
    await expect((caller as any).clients.create({})).rejects.toThrow();
    // Should succeed with valid input
    const client = await (caller as any).clients.create({
      name: "Test Client",
      code: "TC001",
      phone: "0500000000",
      email: "test@client.com",
      address: "Test Address",
      notes: "Test notes",
    });
    expect(client).toBeDefined();
    // Clean up
    await (caller as any).clients.delete({ id: client.id });
  });

  it("should validate shipment creation input", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    // Should fail without required fields
    await expect((caller as any).shipments.create({})).rejects.toThrow();
    // Should succeed with valid input
    // Clean up any leftover from previous test runs
    const existingClients = await (caller as any).clients.list();
    for (const c of existingClients) {
      if (c.code === "RC001") await (caller as any).clients.delete({ id: c.id });
    }
    // First create a client to use as reference
    const client = await (caller as any).clients.create({
      name: "Ref Client",
      code: "RC001",
      phone: "0500000001",
      email: "ref@client.com",
      address: "Ref Address",
      notes: "Ref",
    });
    const shipment = await (caller as any).shipments.create({
      clientId: client.id,
      invoiceType: "تخليص_جمركي",
      entryDate: "2026-01-01",
      releaseDate: "2026-01-05",
      driverName: "Driver Test",
      routeFrom: "Jeddah",
      routeTo: "Riyadh",
      goodsType: "General",
      customsPort: "Jeddah Port",
      unit: "piece",
      quantity: "100",
      notes: "Test",
    });
    expect(shipment).toBeDefined();
    // Clean up
    await (caller as any).shipments.delete({ id: shipment.id });
    await (caller as any).clients.delete({ id: client.id });
  });

  it("should validate invoice creation input", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    // Should fail without required fields
    await expect((caller as any).invoices.create({})).rejects.toThrow();
  });

  it("should validate transfer logs input", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    const logs = await (caller as any).transferLogs.list({ limit: 10 });
    expect(Array.isArray(logs)).toBe(true);
  });

  it("should fetch statements for a client", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    // Should fail without clientId
    await expect((caller as any).statements.get({})).rejects.toThrow();
  });

  it("should fetch monthly sales report", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    const report = await (caller as any).sales.monthlyReport({ year: 2026, month: 1 });
    expect(report).toBeDefined();
  });

  it("should fetch revenue report", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    const report = await (caller as any).sales.revenue();
    expect(report).toBeDefined();
  });

  it("should fetch entries list", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    const entries = await (caller as any).entries.list();
    expect(entries).toBeDefined();
    expect(Array.isArray(entries)).toBe(true);
  });

  it("should fetch payments list", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    const payments = await (caller as any).payments.list();
    expect(payments).toBeDefined();
    expect(Array.isArray(payments)).toBe(true);
  });
});
