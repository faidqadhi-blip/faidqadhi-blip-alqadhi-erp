import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ===== Storage =====
  storage: router({
    getUploadUrl: protectedProcedure
      .input(z.object({
        filename: z.string(),
        contentType: z.string(),
      }))
      .mutation(async ({ input }) => {
        const { storagePut } = await import("./storage");
        // We use storagePut with null data to just get the presigned URL if needed, 
        // but storagePut in this template actually performs the upload if data is provided.
        // For client-side upload, we need a way to get a presigned URL.
        // Since the template's storagePut returns { key, url }, and the url is a proxy path,
        // we'll implement a dedicated getPresignedUrl if the platform supports it.
        // Given the environment, the most reliable way is to proxy the upload through the server.
        return { success: true }; 
      }),
    upload: protectedProcedure
      .input(z.object({
        filename: z.string(),
        contentType: z.string(),
        base64Data: z.string(), // Base64 encoded file data
      }))
      .mutation(async ({ input }) => {
        const { storagePut } = await import("./storage");
        const buffer = Buffer.from(input.base64Data, 'base64');
        const result = await storagePut(input.filename, buffer, input.contentType);
        return result; // returns { key, url }
      }),
  }),

  // ===== Clients =====
  clients: router({
    list: protectedProcedure.query(() => db.listClients()),
    get: protectedProcedure.input(z.object({ id: z.number() })).query(({ input }) => db.getClient(input.id)),
    create: protectedProcedure.input(z.object({
      code: z.string(), name: z.string(), phone: z.string().optional(),
      address: z.string().optional(), nationalId: z.string().optional(),
      commercialReg: z.string().optional(), taxNumber: z.string().optional(),
      notes: z.string().optional(),
    })).mutation(({ input }) => db.createClient(input)),
    update: protectedProcedure.input(z.object({
      id: z.number(),
      code: z.string(), name: z.string(), phone: z.string().optional(),
      address: z.string().optional(), nationalId: z.string().optional(),
      commercialReg: z.string().optional(), taxNumber: z.string().optional(),
      notes: z.string().optional(),
    })).mutation(({ input }) => {
      const { id, ...data } = input;
      return db.updateClient(id, data);
    }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteClient(input.id)),
  }),

  // ===== Shipments =====
  shipments: router({
    list: protectedProcedure.input(z.object({ status: z.string().optional(), invoiceType: z.string().optional(), limit: z.number().optional() }).optional()).query(({ input }) => db.listShipments(input)),
    get: protectedProcedure.input(z.object({ id: z.number() })).query(({ input }) => db.getShipment(input.id)),
    create: protectedProcedure.input(z.object({
      clientId: z.number(), invoiceType: z.enum(["تخليص_جمركي", "شحن_داخلي", "تعبئة_وتغليف"]),
      entryDate: z.string().optional(), releaseDate: z.string().optional(),
      driverName: z.string().optional(), routeFrom: z.string().optional(),
      routeTo: z.string().optional(), goodsType: z.string().optional(),
      customsPort: z.string().optional(), unit: z.string().optional(),
      quantity: z.string().optional(), quantityTons: z.string().optional(),
      invoiceNumber: z.number().optional(), agriLicense: z.string().optional(),
      paymentLicense: z.string().optional(),
    })).mutation(({ input }) => db.createShipment(input)),
    update: protectedProcedure.input(z.object({
      id: z.number(),
      clientId: z.number(), invoiceType: z.enum(["تخليص_جمركي", "شحن_داخلي", "تعبئة_وتغليف"]),
      entryDate: z.string().optional(), releaseDate: z.string().optional(),
      driverName: z.string().optional(), routeFrom: z.string().optional(),
      routeTo: z.string().optional(), goodsType: z.string().optional(),
      customsPort: z.string().optional(), unit: z.string().optional(),
      quantity: z.string().optional(), quantityTons: z.string().optional(),
      invoiceNumber: z.number().optional(), agriLicense: z.string().optional(),
      paymentLicense: z.string().optional(), status: z.enum(["جديد", "تم_الترحيل", "مكتمل", "ملغي"]).optional(),
    })).mutation(({ input }) => {
      const { id, ...data } = input;
      return db.updateShipment(id, data);
    }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteShipment(input.id)),
  }),

  // ===== Invoices =====
  invoices: router({
    list: protectedProcedure.input(z.object({ clientId: z.number().optional(), limit: z.number().optional() }).optional()).query(({ input }) => db.listInvoices(input)),
    get: protectedProcedure.input(z.object({ id: z.number() })).query(({ input }) => db.getInvoice(input.id)),
    nextNumber: protectedProcedure.query(() => db.getNextInvoiceNumber()),
    create: protectedProcedure.input(z.object({
      number: z.number(), invoiceType: z.enum(["تخليص_جمركي", "شحن_داخلي", "تعبئة_وتغليف"]),
      clientId: z.number(), shipmentId: z.number().optional(),
      date: z.string().optional(), totalAmount: z.string().optional(),
      items: z.string().optional(), notes: z.string().optional(),
      currency: z.string().optional(), paymentType: z.enum(["نقداً", "آجل", "حوالة"]).optional(),
      status: z.enum(["مسودة", "معتمدة", "مدفوعة_جزئياً", "مدفوعة", "ملغاة"]).optional(),
    })).mutation(({ input }) => db.createInvoice(input)),
    update: protectedProcedure.input(z.object({
      id: z.number(),
      number: z.number(), invoiceType: z.enum(["تخليص_جمركي", "شحن_داخلي", "تعبئة_وتغليف"]),
      clientId: z.number(), shipmentId: z.number().optional(),
      date: z.string().optional(), totalAmount: z.string().optional(),
      items: z.string().optional(), notes: z.string().optional(),
      currency: z.string().optional(),
      status: z.enum(["مسودة", "معتمدة", "مدفوعة_جزئياً", "مدفوعة", "ملغاة"]).optional(),
    })).mutation(({ input }) => {
      const { id, ...data } = input;
      return db.updateInvoice(id, data);
    }),
  }),

  // ===== Entries (Transfer) =====
  entries: router({
    list: protectedProcedure.input(z.object({ limit: z.number().optional() }).optional()).query(({ input }) => db.listEntries(input?.limit)),
    transferShipments: protectedProcedure.input(z.object({ shipmentIds: z.array(z.number()) })).mutation(({ input, ctx }) =>
      db.transferShipmentsToEntries(input.shipmentIds, ctx.user?.name || "مدير النظام")
    ),
  }),

  // ===== Sales Transfers =====
  sales: router({
    transferInvoices: protectedProcedure.input(z.object({ invoiceIds: z.array(z.number()) })).mutation(({ input, ctx }) =>
      db.transferInvoicesToSales(input.invoiceIds, ctx.user?.name || "مدير النظام")
    ),
    monthlyReport: protectedProcedure.input(z.object({ year: z.number(), month: z.number() })).query(({ input }) =>
      db.getMonthlySalesReport(input.year, input.month)
    ),
    revenue: protectedProcedure.query(() => db.getRevenueReport()),
  }),

  // ===== Payments =====
  payments: router({
    list: protectedProcedure.input(z.object({ clientId: z.number().optional() }).optional()).query(({ input }) => db.listPayments(input?.clientId)),
    create: protectedProcedure.input(z.object({
      invoiceId: z.number(), clientId: z.number(), amount: z.string(),
      paymentDate: z.string(), method: z.string().optional(), notes: z.string().optional(),
    })).mutation(({ input }) => db.createPayment(input)),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deletePayment(input.id)),
  }),

  // ===== Transfer Logs =====
  transferLogs: router({
    list: protectedProcedure.input(z.object({ limit: z.number().optional() }).optional()).query(({ input }) => db.listTransferLogs(input?.limit)),
  }),

  // ===== Settings =====
  settings: router({
    getAll: protectedProcedure.query(() => db.getAllSettings()),
    get: protectedProcedure.input(z.object({ key: z.string() })).query(({ input }) => db.getSetting(input.key)),
    save: protectedProcedure.input(z.object({ key: z.string(), value: z.string() })).mutation(({ input }) => db.saveSetting(input.key, input.value)),
  }),

  // ===== Dashboard =====
  dashboard: router({
    stats: protectedProcedure.query(() => db.getDashboardStats()),
  }),

  // ===== Client Statement =====
  statements: router({
    get: protectedProcedure.input(z.object({ clientId: z.number() })).query(({ input }) => db.getClientStatement(input.clientId)),
  }),

  // ===== Service Invoices =====
  serviceInvoices: router({
    list: protectedProcedure.input(z.object({ clientId: z.number().optional(), limit: z.number().optional() }).optional()).query(({ input }) => db.listServiceInvoices(input)),
    get: protectedProcedure.input(z.object({ id: z.number() })).query(({ input }) => db.getServiceInvoice(input.id)),
    nextNumber: protectedProcedure.query(() => db.getNextServiceInvoiceNumber()),
    create: protectedProcedure.input(z.object({
      number: z.number(), clientId: z.number(), serviceName: z.string(),
      serviceDescription: z.string().optional(), quantity: z.string().optional(),
      unitPrice: z.string().optional(), discount: z.string().optional(),
      taxRate: z.string().optional(), totalAmount: z.string().optional(),
      currency: z.string().optional(), date: z.string().optional(),
      status: z.string().optional(), paymentType: z.enum(["نقداً", "آجل", "حوالة"]).optional(), notes: z.string().optional(),
    })).mutation(({ input }) => db.createServiceInvoice(input)),
    update: protectedProcedure.input(z.object({
      id: z.number(),
      number: z.number().optional(), clientId: z.number().optional(), serviceName: z.string().optional(),
      serviceDescription: z.string().optional(), quantity: z.string().optional(),
      unitPrice: z.string().optional(), discount: z.string().optional(),
      taxRate: z.string().optional(), totalAmount: z.string().optional(),
      currency: z.string().optional(), date: z.string().optional(),
      status: z.string().optional(), notes: z.string().optional(),
    })).mutation(({ input }) => {
      const { id, ...data } = input;
      return db.updateServiceInvoice(id, data);
    }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteServiceInvoice(input.id)),
  }),

  // ===== Vouchers =====
  vouchers: router({
    list: protectedProcedure.input(z.object({ voucherType: z.string().optional(), limit: z.number().optional() }).optional()).query(({ input }) => db.listVouchers(input)),
    get: protectedProcedure.input(z.object({ id: z.number() })).query(({ input }) => db.getVoucher(input.id)),
    nextNumber: protectedProcedure.query(() => db.getNextVoucherNumber()),
    create: protectedProcedure.input(z.object({
      number: z.number(), voucherType: z.string(), clientId: z.number().optional(),
      amount: z.string(), currency: z.string().optional(), date: z.string().optional(),
      paymentMethod: z.string().optional(), cashBox: z.string().optional(),
      cashboxId: z.number().optional(),
      description: z.string().optional(), status: z.string().optional(),
      sourceDeclarationId: z.number().optional(),
    })).mutation(({ input }) => db.createVoucher(input)),
    update: protectedProcedure.input(z.object({
      id: z.number(),
      number: z.number().optional(), voucherType: z.string().optional(), clientId: z.number().optional(),
      amount: z.string().optional(), currency: z.string().optional(), date: z.string().optional(),
      paymentMethod: z.string().optional(), cashBox: z.string().optional(),
      cashboxId: z.number().optional(),
      description: z.string().optional(), status: z.string().optional(),
      sourceDeclarationId: z.number().optional(),
    })).mutation(({ input }) => {
      const { id, ...data } = input;
      return db.updateVoucher(id, data);
    }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteVoucher(input.id)),
    postToLedger: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.postVoucherToLedger(input.id)),
  }),

  // ===== Accounts =====
  accounts: router({
    list: protectedProcedure.query(() => db.listAccounts()),
    create: protectedProcedure.input(z.object({
      code: z.string(), name: z.string(), type: z.string(),
      parentId: z.number().optional(), balance: z.string().optional(),
      description: z.string().optional(),
    })).mutation(({ input }) => db.createAccount(input)),
    update: protectedProcedure.input(z.object({
      id: z.number(), code: z.string().optional(), name: z.string().optional(),
      type: z.string().optional(), parentId: z.number().optional(),
      balance: z.string().optional(), description: z.string().optional(),
    })).mutation(({ input }) => {
      const { id, ...data } = input;
      return db.updateAccount(id, data);
    }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteAccount(input.id)),
  }),

  // ===== Journal Entries =====
  journalEntries: router({
    list: protectedProcedure.input(z.object({ entryType: z.string().optional(), limit: z.number().optional() }).optional()).query(({ input }) => db.listJournalEntries(input)),
    get: protectedProcedure.input(z.object({ id: z.number() })).query(({ input }) => db.getJournalEntry(input.id)),
    nextNumber: protectedProcedure.query(() => db.getNextJournalEntryNumber()),
    create: protectedProcedure.input(z.object({
      entryNumber: z.number(), date: z.string().optional(), description: z.string().optional(),
      entryType: z.string(), items: z.array(z.object({
        accountId: z.number(), debit: z.string(), credit: z.string(), description: z.string().optional(),
      })),
    })).mutation(({ input }) => db.createJournalEntry(input)),
    post: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.postJournalEntry(input.id)),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteJournalEntry(input.id)),
  }),

  // ===== Daily Movements =====
  dailyMovements: router({
    list: protectedProcedure.input(z.object({ date: z.string().optional(), type: z.string().optional(), limit: z.number().optional() }).optional()).query(({ input }) => db.listDailyMovements(input)),
    create: protectedProcedure.input(z.object({
      date: z.string().optional(), type: z.string(), accountId: z.number(),
      amount: z.string(), currency: z.string().optional(), description: z.string().optional(),
      reference: z.string().optional(),
    })).mutation(({ input }) => db.createDailyMovement(input)),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteDailyMovement(input.id)),
  }),



  // ===== Currencies =====
  currencies: router({
    list: protectedProcedure.query(() => db.listCurrencies()),
    create: protectedProcedure.input(z.object({ code: z.string(), name: z.string(), symbol: z.string().optional(), exchangeRate: z.string().optional(), isDefault: z.string().optional() })).mutation(({ input }) => db.createCurrency(input)),
    update: protectedProcedure.input(z.object({ id: z.number(), code: z.string().optional(), name: z.string().optional(), symbol: z.string().optional(), exchangeRate: z.string().optional(), isDefault: z.string().optional() })).mutation(({ input }) => {
      const { id, ...data } = input;
      return db.updateCurrency(id, data);
    }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteCurrency(input.id)),
  }),

  // ===== Languages =====
  languages: router({
    list: protectedProcedure.query(() => db.listLanguages()),
    create: protectedProcedure.input(z.object({ code: z.string(), name: z.string(), isDefault: z.number().optional() })).mutation(({ input }) => db.createLanguage(input)),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteLanguage(input.id)),
  }),

  // ===== Fonts =====
  fonts: router({
    list: protectedProcedure.query(() => db.listFonts()),
    create: protectedProcedure.input(z.object({ name: z.string(), fontFamily: z.string(), isDefault: z.number().optional() })).mutation(({ input }) => db.createFont(input)),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteFont(input.id)),
  }),

  // ===== Templates =====
  templates: router({
    list: protectedProcedure.query(() => db.listTemplates()),
    create: protectedProcedure.input(z.object({
      name: z.string(), type: z.string(), header: z.string().optional(),
      body: z.string().optional(), footer: z.string().optional(), isActive: z.number().optional(),
    })).mutation(({ input }) => db.createTemplate(input)),
    update: protectedProcedure.input(z.object({
      id: z.number(), name: z.string().optional(), type: z.string().optional(),
      header: z.string().optional(), body: z.string().optional(), footer: z.string().optional(),
      isActive: z.number().optional(),
    })).mutation(({ input }) => {
      const { id, ...data } = input;
      return db.updateTemplate(id, data);
    }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteTemplate(input.id)),
  }),

  // ===== Permissions =====
  permissions: router({
    list: protectedProcedure.query(() => db.listPermissions()),
    create: protectedProcedure.input(z.object({
      role: z.string(), module: z.string(), canView: z.number().optional(),
      canCreate: z.number().optional(), canEdit: z.number().optional(), canDelete: z.number().optional(),
    })).mutation(({ input }) => db.createPermission(input)),
    update: protectedProcedure.input(z.object({
      id: z.number(), role: z.string().optional(), module: z.string().optional(),
      canView: z.number().optional(), canCreate: z.number().optional(),
      canEdit: z.number().optional(), canDelete: z.number().optional(),
    })).mutation(({ input }) => {
      const { id, ...data } = input;
      return db.updatePermission(id, data);
    }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deletePermission(input.id)),
  }),

  // ===== Backups =====
  backups: router({
    list: protectedProcedure.query(() => db.listBackups()),
    create: protectedProcedure.input(z.object({ name: z.string(), createdBy: z.string().optional() })).mutation(({ input }) => db.createBackup(input)),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteBackup(input.id)),
  }),

  // ===== Services =====
  services: router({
    list: protectedProcedure.query(() => db.listServices()),
    create: protectedProcedure.input(z.object({
      code: z.string(), name: z.string(), description: z.string().optional(),
      price: z.string().optional(), category: z.string().optional(), isActive: z.number().optional(),
    })).mutation(({ input }) => db.createService(input)),
    update: protectedProcedure.input(z.object({
      id: z.number(), code: z.string().optional(), name: z.string().optional(),
      description: z.string().optional(), price: z.string().optional(),
      category: z.string().optional(), isActive: z.number().optional(),
    })).mutation(({ input }) => {
      const { id, ...data } = input;
      return db.updateService(id, data);
    }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteService(input.id)),
  }),

  // ===== Customs Declarations (البيانات الجمركية) =====
  declarations: router({
    list: protectedProcedure.input(z.object({ status: z.string().optional() }).optional()).query(({ input }) => db.listDeclarations(input)),
    get: protectedProcedure.input(z.object({ id: z.number() })).query(({ input }) => db.getDeclaration(input.id)),
    nextNumber: protectedProcedure.query(() => db.nextDeclarationNumber()),
    create: protectedProcedure.input(z.object({
      entryNumber: z.string(), customsEntryId: z.number().optional(), declarationNumber: z.string(),
      shipmentId: z.number().optional(), clientId: z.number(),
      goodsType: z.string().optional(), customsPort: z.string().optional(),
      declarationDate: z.string().optional(), plateNumber: z.string().optional(),
      driverName: z.string().optional(), declarationFee: z.string().optional(),
      currency: z.string().optional(), status: z.string().optional(), notes: z.string().optional(),
      attachmentUrl: z.string().optional(), attachmentKey: z.string().optional(),
    })).mutation(({ input }) => db.createDeclaration(input)),
    update: protectedProcedure.input(z.object({
      id: z.number(),
      entryNumber: z.string().optional(), customsEntryId: z.number().optional(), declarationNumber: z.string().optional(),
      shipmentId: z.number().optional(), clientId: z.number().optional(),
      goodsType: z.string().optional(), customsPort: z.string().optional(),
      declarationDate: z.string().optional(), plateNumber: z.string().optional(),
      driverName: z.string().optional(), declarationFee: z.string().optional(),
      currency: z.string().optional(), status: z.string().optional(), notes: z.string().optional(),
      attachmentUrl: z.string().optional(), attachmentKey: z.string().optional(),
      releaseAttachmentUrl: z.string().optional(), releaseAttachmentKey: z.string().optional(),
    })).mutation(({ input }) => {
      const { id, ...data } = input;
      return db.updateDeclaration(id, data);
    }),
    delete: protectedProcedure.input(z.number()).mutation(({ input }) => db.deleteDeclaration(input)),
    // ===== إذن الإفراج =====
    issueReleasePermit: protectedProcedure.input(z.object({
      id: z.number(),
      releaseDate: z.string().optional(),
      releasedBy: z.string().optional(),
      releaseNotes: z.string().optional(),
      status: z.string().optional(),
      releaseAttachmentUrl: z.string().optional(),
      releaseAttachmentKey: z.string().optional(),
    })).mutation(({ input }) => {
      const { id, ...data } = input;
      return db.updateDeclaration(id, data);
    }),
  }),

  // ===== Clearance Costs (تكاليف التخليص) =====
  clearanceCosts: router({
    list: protectedProcedure.input(z.object({ declarationId: z.number().optional() }).optional()).query(({ input }) => db.listClearanceCosts(input?.declarationId)),
    create: protectedProcedure.input(z.object({
      declarationId: z.number(),
      declarationFee: z.string().optional(), inspectionFee: z.string().optional(),
      penalties: z.string().optional(), weightDifferences: z.string().optional(),
      otherGovtFees: z.string().optional(), transport: z.string().optional(),
      fuel: z.string().optional(), driverCost: z.string().optional(),
      maintenance: z.string().optional(), otherExpenses: z.string().optional(),
      pettyCash: z.string().optional(), totalCost: z.string().optional(),
      discount: z.string().optional(), netCost: z.string().optional(),
      notes: z.string().optional(),
    })).mutation(({ input }) => db.createClearanceCost(input)),
    update: protectedProcedure.input(z.object({
      id: z.number(),
      declarationFee: z.string().optional(), inspectionFee: z.string().optional(),
      penalties: z.string().optional(), weightDifferences: z.string().optional(),
      otherGovtFees: z.string().optional(), transport: z.string().optional(),
      fuel: z.string().optional(), driverCost: z.string().optional(),
      maintenance: z.string().optional(), otherExpenses: z.string().optional(),
      pettyCash: z.string().optional(), totalCost: z.string().optional(),
      discount: z.string().optional(), netCost: z.string().optional(),
      isApproved: z.boolean().optional(), notes: z.string().optional(),
    })).mutation(({ input }) => {
      const { id, ...data } = input;
      return db.updateClearanceCost(id, data);
    }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteClearanceCost(input.id)),
    summary: protectedProcedure.input(z.object({ declarationId: z.number() })).query(({ input }) => db.getClearanceSummary(input.declarationId)),
  }),

  // ===== Clearance Receipts (المقبوضات) =====
  clearanceReceipts: router({
    list: protectedProcedure.input(z.object({ declarationId: z.number().optional() }).optional()).query(({ input }) => db.listClearanceReceipts(input?.declarationId)),
    create: protectedProcedure.input(z.object({
      declarationId: z.number(), clientId: z.number().optional(), amount: z.string(),
      currency: z.string().optional(), paymentMethod: z.string().optional(),
      paymentDate: z.string().optional(), notes: z.string().optional(),
      paymentType: z.string().optional(), cashboxId: z.number().optional(),
    })).mutation(({ input }) => db.createClearanceReceipt(input)),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteClearanceReceipt(input.id)),
  }),

  // ===== Clearance Disbursements (المدفوعات) =====
  clearanceDisbursements: router({
    list: protectedProcedure.input(z.object({ declarationId: z.number().optional() }).optional()).query(({ input }) => db.listClearanceDisbursements(input?.declarationId)),
    create: protectedProcedure.input(z.object({
      declarationId: z.number(), payee: z.string(), amount: z.string(),
      currency: z.string().optional(), paymentMethod: z.string().optional(),
      paymentDate: z.string().optional(), expenseType: z.string().optional(),
      notes: z.string().optional(), paymentType: z.string().optional(), cashboxId: z.number().optional(),
    })).mutation(({ input }) => db.createClearanceDisbursement(input)),
    delete: protectedProcedure.input(z.object({ id: z.number()     })).mutation(({ input }) => db.deleteClearanceDisbursement(input.id)),
  }),
  // ===== Job Orders (أوامر العمل) =====
  jobOrders: router({
    list: protectedProcedure.query(() => db.listJobOrders()),
    create: protectedProcedure.input(z.object({
      clientId: z.number(), shipmentId: z.number().optional(), jobType: z.string().optional(),
      priority: z.string().optional(), notes: z.string().optional(),
    })).mutation(({ input }) => db.createJobOrder(input)),
    update: protectedProcedure.input(z.object({ id: z.number(), status: z.string().optional(), declarationId: z.number().optional(), notes: z.string().optional(), priority: z.string().optional(), jobType: z.string().optional() })).mutation(({ input }) => {
      const { id, ...data } = input;
      return db.updateJobOrder(id, data);
    }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteJobOrder(input.id)),
  }),
  // ===== Internal Transport Orders =====
  internalTransport: router({
    list: protectedProcedure.input(z.object({ jobOrderId: z.number().optional() }).optional()).query(({ input }) => db.listInternalTransportOrders(input?.jobOrderId)),
    create: protectedProcedure.input(z.object({
      jobOrderId: z.number(), declarationId: z.number().optional(), vehiclePlate: z.string().optional(),
      driverName: z.string().optional(), driverPhone: z.string().optional(), destination: z.string().optional(),
      departureTime: z.string().optional(), notes: z.string().optional(),
    })).mutation(({ input }) => db.createInternalTransportOrder(input)),
    update: protectedProcedure.input(z.object({ id: z.number(), status: z.string().optional(), arrivalTime: z.string().optional(), receiverName: z.string().optional(), receiverSignature: z.string().optional(), podNotes: z.string().optional(), podImage: z.string().optional() })).mutation(({ input }) => {
      const { id, ...data } = input;
      return db.updateInternalTransportOrder(id, data);
    }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteInternalTransportOrder(input.id)),
  }),
  // ===== Fixed Assets =====
  fixedAssets: router({
    list: protectedProcedure.query(() => db.listFixedAssets()),
    create: protectedProcedure.input(z.object({
      assetType: z.string(), name: z.string(), plateNumber: z.string().optional(),
      purchaseDate: z.string().optional(), purchaseValue: z.string(),
      usefulLifeYears: z.string().optional(), notes: z.string().optional(),
    })).mutation(({ input }) => db.createFixedAsset(input)),
    update: protectedProcedure.input(z.object({ id: z.number(), status: z.string().optional(), notes: z.string().optional() })).mutation(({ input }) => {
      const { id, ...data } = input;
      return db.updateFixedAsset(id, data);
    }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteFixedAsset(input.id)),
    depreciate: protectedProcedure.mutation(() => db.runDepreciation()),
  }),
  // ===== Evaluations =====
  evaluations: router({
    list: protectedProcedure.input(z.object({ jobOrderId: z.number().optional() }).optional()).query(({ input }) => db.listEvaluations(input?.jobOrderId)),
    create: protectedProcedure.input(z.object({
      jobOrderId: z.number(), declarationId: z.number().optional(), clientId: z.number().optional(),
      rating: z.number().optional(), clearanceSpeed: z.number().optional(),
      cargoSafety: z.number().optional(), driverHandling: z.number().optional(),
      feedback: z.string().optional(),
    })).mutation(({ input }) => db.createEvaluation(input)),
  }),

  // ===== Module Access Control (Permissions) =====
  moduleAccess: router({
    // List all modules + current user's permissions (everyone can see this)
    myPermissions: protectedProcedure.query(async ({ ctx }) => {
      const isAdmin = ctx.user.role === "admin";
      const modules = isAdmin ? [] : await db.listModulePermissions(ctx.user.id);
      return { isAdmin, modules };
    }),
    // List all users (admin only)
    listUsers: protectedProcedure.query(() => db.listAllUsers()),
    // Get permissions for a specific user (admin only)
    getUserPermissions: protectedProcedure.input(z.object({ userId: z.number() })).query(({ input }) => db.listModulePermissions(input.userId)),
    // Set a module permission for a user (admin only)
    setPermission: protectedProcedure.input(z.object({
      userId: z.number(),
      moduleId: z.string(),
      canView: z.boolean(),
    })).mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "ليس لديك صلاحية لتعديل الصلاحيات" });
      }
      await db.upsertModulePermission(input.userId, input.moduleId, input.canView);
      db.logPermissionChangeAsync({
        userId: input.userId,
        moduleId: input.moduleId,
        action: input.canView ? "granted" : "revoked",
        grantedBy: ctx.user.id,
      });
      return { success: true };
    }),
    // Batch set permissions for a user (admin only)
    setPermissions: protectedProcedure.input(z.object({
      userId: z.number(),
      permissions: z.array(z.object({ moduleId: z.string(), canView: z.boolean() })),
    })).mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "ليس لديك صلاحية لتعديل الصلاحيات" });
      }
      await Promise.all(input.permissions.map(p => db.upsertModulePermission(input.userId, p.moduleId, p.canView)));
      // Log each item individually for clear, unambiguous audit semantics
      input.permissions.forEach(p => {
        db.logPermissionChangeAsync({
          userId: input.userId,
          moduleId: p.moduleId,
          action: p.canView ? "granted" : "revoked",
          grantedBy: ctx.user.id,
        });
      });
      return { success: true };
    }),
    // Permission change audit log (admin only)
    auditLog: protectedProcedure.input(z.object({ userId: z.number().optional() }).optional()).query(({ ctx, input }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "ليس لديك صلاحية لعرض سجل التغييرات" });
      }
      return db.listPermissionAuditLogs(input?.userId);
    }),
  }),

  // ===== الموردين (Suppliers) =====
  suppliers: router({
    list: publicProcedure.query(() => db.listSuppliers()),
    create: protectedProcedure.input(z.object({
      name: z.string(), phone: z.string().optional(), email: z.string().optional(),
      address: z.string().optional(), category: z.string().optional(), notes: z.string().optional(),
    })).mutation(({ input }) => db.createSupplier(input)),
    update: protectedProcedure.input(z.object({
      id: z.number(),
      name: z.string().optional(), phone: z.string().optional(), email: z.string().optional(),
      address: z.string().optional(), category: z.string().optional(), notes: z.string().optional(),
    })).mutation(({ input }) => { const { id, ...data } = input; return db.updateSupplier(id, data); }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteSupplier(input.id)),
  }),

  // ===== الموظفين (Employees) =====
  employees: router({
    list: publicProcedure.query(() => db.listEmployees()),
    create: protectedProcedure.input(z.object({
      name: z.string(), phone: z.string().optional(), email: z.string().optional(),
      jobTitle: z.string().optional(), department: z.string().optional(),
      salary: z.number().optional(), joinDate: z.date().optional(),
      status: z.enum(["نشط", "متوقف", "استقالة"]).optional(), notes: z.string().optional(),
    })).mutation(({ input }) => db.createEmployee(input)),
    update: protectedProcedure.input(z.object({
      id: z.number(),
      name: z.string().optional(), phone: z.string().optional(), email: z.string().optional(),
      jobTitle: z.string().optional(), department: z.string().optional(),
      salary: z.number().optional(), joinDate: z.date().optional(),
      status: z.enum(["نشط", "متوقف", "استقالة"]).optional(), notes: z.string().optional(),
    })).mutation(({ input }) => { const { id, ...data } = input; return db.updateEmployee(id, data); }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteEmployee(input.id)),
  }),

  // ===== العهد والسلف (Custody) =====
  custody: router({
    list: publicProcedure.query(() => db.listCustodyRecords()),
    create: protectedProcedure.input(z.object({
      employeeId: z.number(),
      type: z.enum(["سلفة", "عهدة", "مصروفات مقدمة"]),
      amount: z.number(),
      currency: z.string().default("YER"),
      cashboxId: z.number().optional(),
      purpose: z.string().optional(),
      paymentType: z.enum(["نقداً", "آجل", "حوالة"]).default("نقداً"),
      status: z.enum(["معلّقة", "مسدّدة", "ملغاة", "جزئية"]).default("معلّقة"),
      repaidAmount: z.number().optional(),
      settledDate: z.date().optional(),
      notes: z.string().optional(),
    })).mutation(({ input }) => db.createCustodyRecord(input)),
    update: protectedProcedure.input(z.object({
      id: z.number(),
      employeeId: z.number().optional(),
      type: z.enum(["سلفة", "عهدة", "مصروفات مقدمة"]).optional(),
      amount: z.number().optional(),
      currency: z.string().optional(),
      cashboxId: z.number().optional(),
      purpose: z.string().optional(),
      paymentType: z.enum(["نقداً", "آجل", "حوالة"]).optional(),
      status: z.enum(["معلّقة", "مسدّدة", "ملغاة", "جزئية"]).optional(),
      repaidAmount: z.number().optional(),
      settledDate: z.date().optional(),
      notes: z.string().optional(),
    })).mutation(({ input }) => { const { id, ...data } = input; return db.updateCustodyRecord(id, data); }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteCustodyRecord(input.id)),
  }),

  // ===== الصناديق والبنوك (Cashboxes - New) =====
  cashboxes: router({
    list: publicProcedure.query(() => db.listCashboxes()),
    create: protectedProcedure.input(z.object({
      name: z.string(), type: z.enum(["صندوق نقدي", "بنك"]),
      currency: z.string().default("YER"),
      initialBalance: z.number().default(0), currentBalance: z.number().default(0),
      isActive: z.boolean().default(true), notes: z.string().optional(),
      linkedAccountId: z.number().optional(),
    })).mutation(({ input }) => db.createCashbox(input)),
    update: protectedProcedure.input(z.object({
      id: z.number(),
      name: z.string().optional(), type: z.enum(["صندوق نقدي", "بنك"]).optional(),
      currency: z.string().optional(),
      initialBalance: z.number().optional(), currentBalance: z.number().optional(),
      isActive: z.boolean().optional(), notes: z.string().optional(),
      linkedAccountId: z.number().optional(),
    })).mutation(({ input }) => { const { id, ...data } = input; return db.updateCashbox(id, data); }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ input }) => db.deleteCashbox(input.id)),
  }),

  customsEntries: router({
    list: protectedProcedure.input(z.object({ limit: z.number().optional() }).optional()).query(async ({ input }) => {
      return await db.listCustomsEntries(input?.limit);
    }),
    get: protectedProcedure.input(z.number()).query(async ({ input }) => {
      return await db.getCustomsEntry(input);
    }),
    getByNumber: protectedProcedure.input(z.string()).query(async ({ input }) => {
      return await db.getCustomsEntryByNumber(input);
    }),
    create: protectedProcedure.input(z.object({
      entryNumber: z.string(),
      clientId: z.number(),
      operationType: z.string().optional(),
      entryDate: z.string().optional(),
      goodsType: z.string().optional(),
      customsPort: z.string().optional(),
      plateNumber: z.string().optional(),
      driverName: z.string().optional(),
      notes: z.string().optional(),
      status: z.string().optional(),
    })).mutation(async ({ input }) => {
      return await db.createCustomsEntry(input);
    }),
    update: protectedProcedure.input(z.object({ 
      id: z.number(), 
      data: z.object({
        entryNumber: z.string().optional(),
        clientId: z.number().optional(),
        operationType: z.string().optional(),
        entryDate: z.string().optional(),
        goodsType: z.string().optional(),
        customsPort: z.string().optional(),
        plateNumber: z.string().optional(),
        driverName: z.string().optional(),
        notes: z.string().optional(),
        status: z.string().optional(),
      })
    })).mutation(async ({ input }) => {
      return await db.updateCustomsEntry(input.id, input.data);
    }),
    delete: protectedProcedure.input(z.number()).mutation(async ({ input }) => {
      return await db.deleteCustomsEntry(input);
    }),
  }),

  // ===== التراخيص والتخصيم (Permits & Deductions) =====
  permits: router({
    list: protectedProcedure.query(async () => {
      return await db.listPermits();
    }),
    create: protectedProcedure.input(z.object({
      permitNumber: z.string(),
      date: z.string().optional(),
      authority: z.string().optional(),
      totalQuantity: z.string(),
      notes: z.string().optional(),
    })).mutation(async ({ input }) => {
      return await db.createPermit(input);
    }),
    update: protectedProcedure.input(z.object({
      id: z.number(),
      data: z.any()
    })).mutation(async ({ input }) => {
      return await db.updatePermit(input.id, input.data);
    }),
    delete: protectedProcedure.input(z.number()).mutation(async ({ input }) => {
      return await db.deletePermit(input);
    }),
    getReport: protectedProcedure.query(async () => {
      const all = await db.listPermits();
      const totalCount = all.length;
      const expired = all.filter(p => Number(p.remainingQuantity) <= 0);
      const nearExpiry = all.filter(p => {
        const remaining = Number(p.remainingQuantity);
        const total = Number(p.totalQuantity);
        return remaining > 0 && (remaining / total) <= 0.1; // Less than 10%
      });
      const active = all.filter(p => Number(p.remainingQuantity) > 0 && (Number(p.remainingQuantity) / Number(p.totalQuantity)) > 0.1);

      const stats = {
        totalCount,
        expiredCount: expired.length,
        nearExpiryCount: nearExpiry.length,
        activeCount: active.length,
        totalRemaining: all.reduce((acc, p) => acc + Number(p.remainingQuantity), 0),
      };

      return { stats, expired, nearExpiry, active };
    }),
  }),

  permitDeductions: router({
    list: protectedProcedure.input(z.object({ permitId: z.number().optional() }).optional()).query(async ({ input }) => {
      return await db.listPermitDeductions(input?.permitId);
    }),
    create: protectedProcedure.input(z.object({
      permitId: z.number(),
      declarationNumber: z.string().optional(),
      declarationDate: z.string().optional(),
      deductedQuantity: z.string(),
      date: z.string().optional(),
      notes: z.string().optional(),
    })).mutation(async ({ input }) => {
      return await db.createPermitDeduction(input);
    }),
  }),

  quantityDeductions: router({
    list: protectedProcedure.query(async () => {
      return await db.listQuantityDeductions();
    }),
    get: protectedProcedure.input(z.number()).query(async ({ input }) => {
      return await db.getQuantityDeduction(input);
    }),
    create: protectedProcedure.input(z.object({
      referenceNumber: z.string(),
      referenceDate: z.string(),
      goodsType: z.string().optional(),
      authority: z.string().optional(),
      totalQuantity: z.string(),
      notes: z.string().optional(),
    })).mutation(async ({ input }) => {
      return await db.createQuantityDeduction(input);
    }),
    delete: protectedProcedure.input(z.number()).mutation(async ({ input }) => {
      return await db.deleteQuantityDeduction(input);
    }),
    listDetails: protectedProcedure.input(z.number()).query(async ({ input }) => {
      return await db.listQuantityDeductionDetails(input);
    }),
    createDetail: protectedProcedure.input(z.object({
      quantityDeductionId: z.number(),
      declarationNumber: z.string(),
      declarationDate: z.string(),
      deductedQuantity: z.string(),
      notes: z.string().optional(),
    })).mutation(async ({ input }) => {
      return await db.createQuantityDeductionDetail(input);
    }),
  }),
});
export type AppRouter = typeof appRouter;
