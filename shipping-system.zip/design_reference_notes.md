# Design Reference Notes - Invoice/Voucher PDF Format

Based on the user's reference image (Screenshot_20260820_045157_Docs.jpg):

## Header Section (3 columns)
- Right: "فيدل القاضي للتخليص الجمركي" + "- مكتب صنعاء الرئيسي -" + "الجمهورية اليمنية"
- Center: Logo image (h-20) + "للتخليص الجمركي والخدمات اللوجستية"
- Left: "FAIDAL AL-QADHI OFFICE" + "- SANA'A MAIN OFFICE -" + "REPUBLIC OF YEMEN"
- Bottom border: 2px solid gray-700

## Title
- Centered, underlined, bold: "تكاليف خدمة التخليص" or "سند قبض" / "سند صرف"

## Details Row
- Border box with two columns: "التفاصيل" (fixed width w-32, bold) | content text

## Operation Info Table
- Dark header (#4a6d7a) with white text: "رقم العملية" | "التاريخ" | "طريقة الدفع"
- Data row below

## Customer Info Grid (3 columns, 2 rows)
- اسم العميل / نوع البضاعة / المنفذ الجمركي
- رقم البيان / تاريخ البيان / رقم الحاوية

## Services Table
- Dark header (#4a6d7a): "تفاصيل العملية" (flex-2) | "العدد" | "نوع الخدمة" | "التكلفة" | "العملة" | "الإجمالي"
- Each row: detail | count | type | cost (bold) | currency code | total (bold)

## Totals Section
- Bordered box max-w-300px, aligned right:
  - "إجمالي التكلفة" | value
  - "الخصومات" | value
  - "صافي التكلفة" (bg-gray-100, bold) | value (bold)

## Amount in Words
- Bordered box bg-gray-50: "المبلغ كتابةً: [words] ريال يمني فقط لا غير"

## Signatures
- Two columns: "المحاسب : ........." | "توقيع المستلم: ........."

## Logo Path
- /manus-storage/faidal-logo_11e2a37b.png
