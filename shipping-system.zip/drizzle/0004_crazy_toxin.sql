CREATE TABLE `clearanceCosts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`declarationId` int NOT NULL,
	`costType` enum('رسوم_تخليص','نقل','تحميل','تفريغ','نثريات','أتعاب','رسوم_أخرى') NOT NULL,
	`amount` decimal(14,2) NOT NULL,
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `clearanceCosts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `clearanceExpenses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`declarationId` int NOT NULL,
	`expenseType` enum('نقل','تحميل','تفريغ','ضيافة','اتصالات','رسوم_صغيرة','مصاريف_أخرى') NOT NULL,
	`amount` decimal(14,2) NOT NULL,
	`description` text,
	`expenseDate` varchar(20),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `clearanceExpenses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `clearancePayments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`declarationId` int NOT NULL,
	`paymentType` enum('مقبوض','مدفوع') NOT NULL,
	`amount` decimal(14,2) NOT NULL,
	`currency` varchar(10) DEFAULT 'SAR',
	`paymentMethod` varchar(50),
	`paymentDate` varchar(20),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `clearancePayments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `customsDeclarations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`entryNumber` varchar(50) NOT NULL,
	`declarationNumber` varchar(50) NOT NULL,
	`declarationDate` varchar(20),
	`clientId` int,
	`clientName` varchar(200),
	`goodsType` varchar(200),
	`customsPort` varchar(200),
	`plateNumber` varchar(50),
	`driverName` varchar(200),
	`declarationFee` decimal(14,2) DEFAULT '0',
	`currency` varchar(10) DEFAULT 'SAR',
	`status` enum('نشط','مكتمل','ملغي') NOT NULL DEFAULT 'نشط',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `customsDeclarations_id` PRIMARY KEY(`id`),
	CONSTRAINT `customsDeclarations_entryNumber_unique` UNIQUE(`entryNumber`),
	CONSTRAINT `customsDeclarations_declarationNumber_unique` UNIQUE(`declarationNumber`)
);
