CREATE TABLE `customsEntries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`entryNumber` varchar(50) NOT NULL,
	`clientId` int NOT NULL,
	`operationType` varchar(100),
	`entryDate` varchar(20),
	`goodsType` varchar(200),
	`customsPort` varchar(100),
	`plateNumber` varchar(50),
	`driverName` varchar(200),
	`notes` text,
	`status` enum('نشط','مرتبط_ببيان','ملغي') NOT NULL DEFAULT 'نشط',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `customsEntries_id` PRIMARY KEY(`id`),
	CONSTRAINT `customsEntries_entryNumber_unique` UNIQUE(`entryNumber`)
);
--> statement-breakpoint
ALTER TABLE `customsDeclarations` ADD `releaseAttachmentUrl` text;--> statement-breakpoint
ALTER TABLE `customsDeclarations` ADD `releaseAttachmentKey` varchar(255);--> statement-breakpoint
ALTER TABLE `customsDeclarations` ADD `attachmentUrl` text;--> statement-breakpoint
ALTER TABLE `customsDeclarations` ADD `attachmentKey` varchar(255);--> statement-breakpoint
ALTER TABLE `customsDeclarations` ADD `customsEntryId` int;