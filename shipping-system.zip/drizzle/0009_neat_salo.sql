ALTER TABLE `declarationDeductions` MODIFY COLUMN `declarationId` int;--> statement-breakpoint
ALTER TABLE `declarationDeductions` ADD `manualDeclarationNumber` varchar(50);--> statement-breakpoint
ALTER TABLE `declarationDeductions` ADD `goodsType` varchar(200);--> statement-breakpoint
ALTER TABLE `declarationQuantityDeductions` ADD `manualSubDeclarationNumber` varchar(50);