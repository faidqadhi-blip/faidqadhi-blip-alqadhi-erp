CREATE TABLE `clients` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(20) NOT NULL,
	`name` varchar(200) NOT NULL,
	`phone` varchar(20),
	`address` text,
	`nationalId` varchar(30),
	`commercialReg` varchar(30),
	`taxNumber` varchar(30),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `clients_id` PRIMARY KEY(`id`),
	CONSTRAINT `clients_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `entries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`shipmentId` int NOT NULL,
	`clientId` int NOT NULL,
	`invoiceType` enum('تخليص_جمركي','شحن_داخلي','تعبئة_وتغليف') NOT NULL,
	`entryDate` varchar(20),
	`releaseDate` varchar(20),
	`driverName` varchar(100),
	`routeFrom` varchar(100),
	`routeTo` varchar(100),
	`goodsType` varchar(100),
	`customsPort` varchar(100),
	`unit` varchar(30),
	`quantity` varchar(50),
	`quantityTons` decimal(12,2),
	`amount` decimal(14,2) DEFAULT '0',
	`companyShare` decimal(14,2) DEFAULT '0',
	`transferredAt` timestamp DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `entries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `invoices` (
	`id` int AUTO_INCREMENT NOT NULL,
	`number` int NOT NULL,
	`invoiceType` enum('تخليص_جمركي','شحن_داخلي','تعبئة_وتغليف') NOT NULL,
	`clientId` int NOT NULL,
	`shipmentId` int,
	`date` varchar(20),
	`totalAmount` decimal(14,2) DEFAULT '0',
	`items` text,
	`notes` text,
	`status` enum('مسودة','معتمدة','مدفوعة_جزئياً','مدفوعة','ملغاة') NOT NULL DEFAULT 'مسودة',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `invoices_id` PRIMARY KEY(`id`),
	CONSTRAINT `invoices_number_unique` UNIQUE(`number`)
);
--> statement-breakpoint
CREATE TABLE `payments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`invoiceId` int NOT NULL,
	`clientId` int NOT NULL,
	`amount` decimal(14,2) NOT NULL,
	`paymentDate` varchar(20),
	`method` varchar(50),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `payments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `salesTransfers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`invoiceId` int NOT NULL,
	`invoiceType` enum('تخليص_جمركي','شحن_داخلي','تعبئة_وتغليف') NOT NULL,
	`clientId` int NOT NULL,
	`totalAmount` decimal(14,2),
	`goodsType` varchar(100),
	`quantity` varchar(50),
	`quantityTons` decimal(12,2),
	`companyShare` decimal(14,2),
	`customsPort` varchar(100),
	`monthNum` int,
	`year` int,
	`transferredAt` timestamp DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `salesTransfers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`key` varchar(100) NOT NULL,
	`value` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `settings_id` PRIMARY KEY(`id`),
	CONSTRAINT `settings_key_unique` UNIQUE(`key`)
);
--> statement-breakpoint
CREATE TABLE `shipments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`clientId` int NOT NULL,
	`invoiceType` enum('تخليص_جمركي','شحن_داخلي','تعبئة_وتغليف') NOT NULL,
	`entryDate` varchar(20),
	`releaseDate` varchar(20),
	`driverName` varchar(100),
	`routeFrom` varchar(100),
	`routeTo` varchar(100),
	`goodsType` varchar(100),
	`customsPort` varchar(100),
	`unit` varchar(30),
	`quantity` varchar(50),
	`quantityTons` decimal(12,2),
	`invoiceNumber` int,
	`agriLicense` varchar(50),
	`paymentLicense` varchar(50),
	`status` enum('جديد','تم_الترحيل','مكتمل','ملغي') NOT NULL DEFAULT 'جديد',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `shipments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `transferLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`transferType` varchar(100) NOT NULL,
	`recordCount` int DEFAULT 0,
	`status` varchar(50) DEFAULT 'تم بنجاح',
	`performedBy` text,
	`performedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `transferLogs_id` PRIMARY KEY(`id`)
);
