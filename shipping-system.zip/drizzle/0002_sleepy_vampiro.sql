CREATE TABLE `accounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(20) NOT NULL,
	`name` varchar(200) NOT NULL,
	`type` enum('أصول','خصوم','حقوق_ملكية','إيرادات','مصروفات') NOT NULL,
	`parentId` int,
	`balance` decimal(16,2) DEFAULT '0',
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `accounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `accounts_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `backups` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(200) NOT NULL,
	`size` varchar(50),
	`status` enum('قيد_الإنشاء','تم','فشل') NOT NULL DEFAULT 'قيد_الإنشاء',
	`fileUrl` text,
	`createdBy` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `backups_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `cashBoxes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`balance` decimal(16,2) DEFAULT '0',
	`currency` varchar(10) DEFAULT 'SAR',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cashBoxes_id` PRIMARY KEY(`id`),
	CONSTRAINT `cashBoxes_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
CREATE TABLE `currencies` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(10) NOT NULL,
	`name` varchar(100) NOT NULL,
	`rate` decimal(12,4) DEFAULT '1',
	`isDefault` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `currencies_id` PRIMARY KEY(`id`),
	CONSTRAINT `currencies_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `dailyMovements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`date` varchar(20),
	`type` enum('إيراد','مصروف','تحويل','سند_قبض','سند_صرف') NOT NULL,
	`accountId` int NOT NULL,
	`amount` decimal(14,2) NOT NULL,
	`currency` varchar(10) DEFAULT 'SAR',
	`description` text,
	`reference` varchar(100),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `dailyMovements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `fonts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`fontFamily` varchar(200) NOT NULL,
	`isDefault` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `fonts_id` PRIMARY KEY(`id`),
	CONSTRAINT `fonts_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
CREATE TABLE `journalEntries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`entryNumber` int NOT NULL,
	`date` varchar(20),
	`description` text,
	`entryType` enum('قيد_يومي','قيد_مزدوج','تسوية') NOT NULL DEFAULT 'قيد_يومي',
	`status` enum('مسودة','مرحل','ملغي') NOT NULL DEFAULT 'مسودة',
	`createdBy` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `journalEntries_id` PRIMARY KEY(`id`),
	CONSTRAINT `journalEntries_entryNumber_unique` UNIQUE(`entryNumber`)
);
--> statement-breakpoint
CREATE TABLE `journalEntryItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`entryId` int NOT NULL,
	`accountId` int NOT NULL,
	`debit` varchar(50) DEFAULT '0',
	`credit` varchar(50) DEFAULT '0',
	`description` text,
	CONSTRAINT `journalEntryItems_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `languages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(10) NOT NULL,
	`name` varchar(100) NOT NULL,
	`isDefault` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `languages_id` PRIMARY KEY(`id`),
	CONSTRAINT `languages_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `permissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`role` varchar(50) NOT NULL,
	`module` varchar(100) NOT NULL,
	`canView` int DEFAULT 0,
	`canCreate` int DEFAULT 0,
	`canEdit` int DEFAULT 0,
	`canDelete` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `permissions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `serviceInvoices` (
	`id` int AUTO_INCREMENT NOT NULL,
	`number` int NOT NULL,
	`clientId` int NOT NULL,
	`serviceName` varchar(200) NOT NULL,
	`serviceDescription` text,
	`quantity` varchar(20),
	`unitPrice` varchar(50),
	`discount` varchar(10),
	`taxRate` varchar(10),
	`totalAmount` decimal(14,2),
	`currency` varchar(10) DEFAULT 'SAR',
	`date` varchar(20),
	`status` enum('مسودة','معتمدة','مدفوعة_جزئياً','مدفوعة','ملغاة') NOT NULL DEFAULT 'مسودة',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `serviceInvoices_id` PRIMARY KEY(`id`),
	CONSTRAINT `serviceInvoices_number_unique` UNIQUE(`number`)
);
--> statement-breakpoint
CREATE TABLE `templates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`type` enum('فاتورة','سند','تقرير','فاتورة_خدمية') NOT NULL,
	`header` text,
	`body` text,
	`footer` text,
	`isActive` int DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `templates_id` PRIMARY KEY(`id`),
	CONSTRAINT `templates_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
CREATE TABLE `vouchers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`number` int NOT NULL,
	`voucherType` enum('سند_قبض','سند_صرف') NOT NULL,
	`clientId` int,
	`amount` decimal(14,2) NOT NULL,
	`currency` varchar(10) DEFAULT 'SAR',
	`date` varchar(20),
	`paymentMethod` varchar(50),
	`cashBox` varchar(100),
	`description` text,
	`status` enum('مسودة','معتمد','ملغي') NOT NULL DEFAULT 'معتمد',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `vouchers_id` PRIMARY KEY(`id`),
	CONSTRAINT `vouchers_number_unique` UNIQUE(`number`)
);
