CREATE TABLE `declarationDeductions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`declarationId` int NOT NULL,
	`authority` varchar(100),
	`totalQuantity` decimal(14,2) DEFAULT '0',
	`remainingQuantity` decimal(14,2) DEFAULT '0',
	`date` varchar(20),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `declarationDeductions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `declarationQuantityDeductions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`declarationDeductionId` int NOT NULL,
	`subDeclarationId` int,
	`deductedQuantity` decimal(14,2) DEFAULT '0',
	`remainingQuantity` decimal(14,2) DEFAULT '0',
	`date` varchar(20),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `declarationQuantityDeductions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `permitDeductions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`permitId` int NOT NULL,
	`declarationId` int,
	`deductedQuantity` decimal(14,2) DEFAULT '0',
	`remainingQuantity` decimal(14,2) DEFAULT '0',
	`date` varchar(20),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `permitDeductions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `permits` (
	`id` int AUTO_INCREMENT NOT NULL,
	`permitNumber` varchar(50) NOT NULL,
	`date` varchar(20),
	`authority` varchar(100),
	`totalQuantity` decimal(14,2) DEFAULT '0',
	`remainingQuantity` decimal(14,2) DEFAULT '0',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `permits_id` PRIMARY KEY(`id`),
	CONSTRAINT `permits_permitNumber_unique` UNIQUE(`permitNumber`)
);
