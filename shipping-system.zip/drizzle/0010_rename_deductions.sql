CREATE TABLE `quantityDeductionDetails` (
	`id` int AUTO_INCREMENT NOT NULL,
	`quantityDeductionId` int NOT NULL,
	`declarationNumber` varchar(50) NOT NULL,
	`declarationDate` varchar(20) NOT NULL,
	`deductedQuantity` decimal(14,2) DEFAULT '0',
	`remainingQuantity` decimal(14,2) DEFAULT '0',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `quantityDeductionDetails_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `quantityDeductions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`referenceNumber` varchar(50) NOT NULL,
	`referenceDate` varchar(20) NOT NULL,
	`goodsType` varchar(200),
	`authority` varchar(100),
	`totalQuantity` decimal(14,2) DEFAULT '0',
	`remainingQuantity` decimal(14,2) DEFAULT '0',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `quantityDeductions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
DROP TABLE `declarationDeductions`;--> statement-breakpoint
DROP TABLE `declarationQuantityDeductions`;