ALTER TABLE `permitDeductions` MODIFY COLUMN `date` varchar(20) NOT NULL;--> statement-breakpoint
ALTER TABLE `permitDeductions` ADD `declarationNumber` varchar(50);--> statement-breakpoint
ALTER TABLE `permitDeductions` ADD `declarationDate` varchar(20);--> statement-breakpoint
ALTER TABLE `permitDeductions` DROP COLUMN `declarationId`;