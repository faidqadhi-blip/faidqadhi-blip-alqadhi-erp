CREATE TABLE `cashboxes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`type` enum('صندوق نقدي','بنك') NOT NULL,
	`currency` varchar(10) DEFAULT 'YER',
	`initialBalance` decimal(16,2) DEFAULT '0',
	`currentBalance` decimal(16,2) DEFAULT '0',
	`isActive` boolean NOT NULL DEFAULT true,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cashboxes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `clearanceDisbursements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`declarationId` int NOT NULL,
	`payee` varchar(200) NOT NULL,
	`amount` decimal(14,2) NOT NULL,
	`currency` varchar(10) DEFAULT 'SAR',
	`paymentDate` varchar(20),
	`paymentMethod` varchar(50),
	`paymentType` enum('نقداً','آجل','حوالة') NOT NULL DEFAULT 'نقداً',
	`cashboxId` int,
	`expenseType` varchar(50),
	`voucherId` int,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `clearanceDisbursements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `clearanceReceipts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`declarationId` int NOT NULL,
	`clientId` int,
	`amount` decimal(14,2) NOT NULL,
	`currency` varchar(10) DEFAULT 'SAR',
	`paymentDate` varchar(20),
	`paymentMethod` varchar(50),
	`paymentType` enum('نقداً','آجل','حوالة') NOT NULL DEFAULT 'نقداً',
	`cashboxId` int,
	`voucherId` int,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `clearanceReceipts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `custodyRecords` (
	`id` int AUTO_INCREMENT NOT NULL,
	`employeeId` int NOT NULL,
	`type` enum('سلفة','عهدة','مصروفات مقدمة') NOT NULL,
	`amount` decimal(14,2) NOT NULL,
	`currency` varchar(10) DEFAULT 'YER',
	`cashboxId` int,
	`purpose` text,
	`paymentType` enum('نقداً','آجل','حوالة') NOT NULL DEFAULT 'نقداً',
	`status` enum('معلّقة','مسدّدة','ملغاة','جزئية') NOT NULL DEFAULT 'معلّقة',
	`repaidAmount` decimal(14,2) DEFAULT '0',
	`settledDate` date,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `custodyRecords_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `employees` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`phone` varchar(50),
	`email` varchar(320),
	`jobTitle` varchar(100),
	`department` varchar(100),
	`salary` decimal(14,2) DEFAULT '0',
	`joinDate` date,
	`status` enum('نشط','متوقف','استقالة') NOT NULL DEFAULT 'نشط',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `employees_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `evaluations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`jobOrderId` int NOT NULL,
	`declarationId` int,
	`clientId` int,
	`rating` int,
	`clearanceSpeed` int,
	`cargoSafety` int,
	`driverHandling` int,
	`feedback` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `evaluations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `fixedAssets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`assetType` enum('شاحنة','مقطورة','معدات','أجهزة','مبنى','أخرى') NOT NULL,
	`name` varchar(200) NOT NULL,
	`plateNumber` varchar(50),
	`purchaseDate` varchar(20),
	`purchaseValue` decimal(14,2) NOT NULL,
	`usefulLifeYears` decimal(5,1) DEFAULT '10',
	`monthlyDepreciation` decimal(14,2) DEFAULT '0',
	`accumulatedDepreciation` decimal(14,2) DEFAULT '0',
	`bookValue` decimal(14,2) DEFAULT '0',
	`status` enum('نشط','صيانة','خارج_الخدمة','مباع') NOT NULL DEFAULT 'نشط',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `fixedAssets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `internalTransportOrders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`jobOrderId` int NOT NULL,
	`declarationId` int,
	`vehiclePlate` varchar(50),
	`driverName` varchar(200),
	`driverPhone` varchar(50),
	`destination` varchar(200),
	`departureTime` varchar(20),
	`arrivalTime` varchar(20),
	`podImage` text,
	`podNotes` text,
	`receiverName` varchar(200),
	`receiverSignature` varchar(50),
	`status` enum('قيد_الانتظار','تم_الانطلاق','وصل','تم_التسليم','ملغي') NOT NULL DEFAULT 'قيد_الانتظار',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `internalTransportOrders_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `jobOrders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`jobNumber` varchar(50) NOT NULL,
	`clientId` int NOT NULL,
	`shipmentId` int,
	`declarationId` int,
	`jobType` enum('تخليص_جمركي','شحن_داخلي','تعبئة_وتغليف','استشارة') NOT NULL DEFAULT 'تخليص_جمركي',
	`status` enum('استشارة','عرض_سعر','مفتوح','قيد_التخليص','مفروج','قيد_التسليم','مكتمل','ملغي') NOT NULL DEFAULT 'استشارة',
	`priority` enum('عادي','عاجل','أولوية') NOT NULL DEFAULT 'عادي',
	`notes` text,
	`createdBy` text,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `jobOrders_id` PRIMARY KEY(`id`),
	CONSTRAINT `jobOrders_jobNumber_unique` UNIQUE(`jobNumber`)
);
--> statement-breakpoint
CREATE TABLE `modulePermissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`moduleId` varchar(64) NOT NULL,
	`canView` boolean NOT NULL DEFAULT false,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `modulePermissions_id` PRIMARY KEY(`id`),
	CONSTRAINT `modulePermissions_user_module_uniq` UNIQUE(`userId`,`moduleId`)
);
--> statement-breakpoint
CREATE TABLE `permissionAuditLog` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`moduleId` varchar(64) NOT NULL,
	`action` enum('granted','revoked','bulk_grant','bulk_revoke') NOT NULL,
	`grantedBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `permissionAuditLog_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `suppliers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`phone` varchar(50),
	`email` varchar(320),
	`address` text,
	`category` varchar(100),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `suppliers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
DROP TABLE `clearanceExpenses`;--> statement-breakpoint
DROP TABLE `clearancePayments`;--> statement-breakpoint
ALTER TABLE `currencies` MODIFY COLUMN `isDefault` enum('نعم','لا') NOT NULL DEFAULT 'لا';--> statement-breakpoint
ALTER TABLE `customsDeclarations` MODIFY COLUMN `clientId` int NOT NULL;--> statement-breakpoint
ALTER TABLE `customsDeclarations` MODIFY COLUMN `status` enum('مسودة','معتمد','مكتمل','ملغي') NOT NULL DEFAULT 'مسودة';--> statement-breakpoint
ALTER TABLE `clearanceCosts` ADD `declarationFee` decimal(14,2) DEFAULT '0';--> statement-breakpoint
ALTER TABLE `clearanceCosts` ADD `inspectionFee` decimal(14,2) DEFAULT '0';--> statement-breakpoint
ALTER TABLE `clearanceCosts` ADD `penalties` decimal(14,2) DEFAULT '0';--> statement-breakpoint
ALTER TABLE `clearanceCosts` ADD `weightDifferences` decimal(14,2) DEFAULT '0';--> statement-breakpoint
ALTER TABLE `clearanceCosts` ADD `otherGovtFees` decimal(14,2) DEFAULT '0';--> statement-breakpoint
ALTER TABLE `clearanceCosts` ADD `transport` decimal(14,2) DEFAULT '0';--> statement-breakpoint
ALTER TABLE `clearanceCosts` ADD `fuel` decimal(14,2) DEFAULT '0';--> statement-breakpoint
ALTER TABLE `clearanceCosts` ADD `driverCost` decimal(14,2) DEFAULT '0';--> statement-breakpoint
ALTER TABLE `clearanceCosts` ADD `maintenance` decimal(14,2) DEFAULT '0';--> statement-breakpoint
ALTER TABLE `clearanceCosts` ADD `otherExpenses` decimal(14,2) DEFAULT '0';--> statement-breakpoint
ALTER TABLE `clearanceCosts` ADD `pettyCash` decimal(14,2) DEFAULT '0';--> statement-breakpoint
ALTER TABLE `clearanceCosts` ADD `totalCost` decimal(14,2) DEFAULT '0';--> statement-breakpoint
ALTER TABLE `clearanceCosts` ADD `discount` decimal(14,2) DEFAULT '0';--> statement-breakpoint
ALTER TABLE `clearanceCosts` ADD `netCost` decimal(14,2) DEFAULT '0';--> statement-breakpoint
ALTER TABLE `clearanceCosts` ADD `isApproved` boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE `clearanceCosts` ADD `notes` text;--> statement-breakpoint
ALTER TABLE `clearanceCosts` ADD `updatedAt` timestamp DEFAULT (now()) NOT NULL ON UPDATE CURRENT_TIMESTAMP;--> statement-breakpoint
ALTER TABLE `currencies` ADD `symbol` varchar(10) NOT NULL;--> statement-breakpoint
ALTER TABLE `currencies` ADD `exchangeRate` decimal(10,4) DEFAULT '1';--> statement-breakpoint
ALTER TABLE `customsDeclarations` ADD `shipmentId` int;--> statement-breakpoint
ALTER TABLE `customsDeclarations` ADD `hsCode` varchar(50);--> statement-breakpoint
ALTER TABLE `customsDeclarations` ADD `jobOrderId` int;--> statement-breakpoint
ALTER TABLE `customsDeclarations` ADD `approvedAt` timestamp;--> statement-breakpoint
ALTER TABLE `customsDeclarations` ADD `releaseDate` varchar(20);--> statement-breakpoint
ALTER TABLE `customsDeclarations` ADD `releasedBy` varchar(200);--> statement-breakpoint
ALTER TABLE `customsDeclarations` ADD `releaseNotes` text;--> statement-breakpoint
ALTER TABLE `invoices` ADD `paymentType` enum('نقداً','آجل','حوالة') DEFAULT 'نقداً' NOT NULL;--> statement-breakpoint
ALTER TABLE `serviceInvoices` ADD `paymentType` enum('نقداً','آجل','حوالة') DEFAULT 'نقداً' NOT NULL;--> statement-breakpoint
ALTER TABLE `vouchers` ADD `sourceDeclarationId` int;--> statement-breakpoint
ALTER TABLE `clearanceCosts` DROP COLUMN `costType`;--> statement-breakpoint
ALTER TABLE `clearanceCosts` DROP COLUMN `amount`;--> statement-breakpoint
ALTER TABLE `clearanceCosts` DROP COLUMN `description`;--> statement-breakpoint
ALTER TABLE `currencies` DROP COLUMN `rate`;--> statement-breakpoint
ALTER TABLE `currencies` DROP COLUMN `updatedAt`;--> statement-breakpoint
ALTER TABLE `customsDeclarations` DROP COLUMN `clientName`;