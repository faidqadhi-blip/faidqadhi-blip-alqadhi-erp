import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, bigint, boolean, uniqueIndex, date } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ===== صلاحيات الأقسام (Module Access Control) =====
// Each row grants a user access to a specific module.
// If no row exists for a user+module, the module is HIDDEN (denied by default).
// Admin users (role = 'admin') always have access to all modules.
export const modulePermissions = mysqlTable("modulePermissions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  moduleId: varchar("moduleId", { length: 64 }).notNull(),
  canView: boolean("canView").default(false).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [uniqueIndex("modulePermissions_user_module_uniq").on(table.userId, table.moduleId)]);

export type ModulePermission = typeof modulePermissions.$inferSelect;
export type InsertModulePermission = typeof modulePermissions.$inferInsert;

// ===== سجل تغييرات الصلاحيات (Audit Log) =====
// Records every permission grant/revocation with who performed it and when.
export const permissionAuditLog = mysqlTable("permissionAuditLog", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  moduleId: varchar("moduleId", { length: 64 }).notNull(),
  action: mysqlEnum("action", ["granted", "revoked", "bulk_grant", "bulk_revoke"]).notNull(),
  grantedBy: int("grantedBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PermissionAuditLog = typeof permissionAuditLog.$inferSelect;
export type InsertPermissionAuditLog = typeof permissionAuditLog.$inferInsert;

// ===== العملاء =====
export const clients = mysqlTable("clients", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 20 }).notNull().unique(),
  name: varchar("name", { length: 200 }).notNull(),
  phone: varchar("phone", { length: 20 }),
  address: text("address"),
  nationalId: varchar("nationalId", { length: 30 }),
  commercialReg: varchar("commercialReg", { length: 30 }),
  taxNumber: varchar("taxNumber", { length: 30 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Client = typeof clients.$inferSelect;
export type InsertClient = typeof clients.$inferInsert;

// ===== الشحنات =====
export const shipments = mysqlTable("shipments", {
  id: int("id").autoincrement().primaryKey(),
  clientId: int("clientId").notNull(),
  invoiceType: mysqlEnum("invoiceType", ["تخليص_جمركي", "شحن_داخلي", "تعبئة_وتغليف"]).notNull(),
  entryDate: varchar("entryDate", { length: 20 }),
  releaseDate: varchar("releaseDate", { length: 20 }),
  driverName: varchar("driverName", { length: 100 }),
  routeFrom: varchar("routeFrom", { length: 100 }),
  routeTo: varchar("routeTo", { length: 100 }),
  goodsType: varchar("goodsType", { length: 100 }),
  customsPort: varchar("customsPort", { length: 100 }),
  unit: varchar("unit", { length: 30 }),
  quantity: varchar("quantity", { length: 50 }),
  quantityTons: decimal("quantityTons", { precision: 12, scale: 2 }),
  invoiceNumber: int("invoiceNumber"),
  agriLicense: varchar("agriLicense", { length: 50 }),
  paymentLicense: varchar("paymentLicense", { length: 50 }),
  status: mysqlEnum("status", ["جديد", "تم_الترحيل", "مكتمل", "ملغي"]).default("جديد").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Shipment = typeof shipments.$inferSelect;
export type InsertShipment = typeof shipments.$inferInsert;

// ===== الفواتير =====
export const invoices = mysqlTable("invoices", {
  id: int("id").autoincrement().primaryKey(),
  number: int("number").notNull().unique(),
  invoiceType: mysqlEnum("invoiceType", ["تخليص_جمركي", "شحن_داخلي", "تعبئة_وتغليف"]).notNull(),
  clientId: int("clientId").notNull(),
  shipmentId: int("shipmentId"),
  date: varchar("date", { length: 20 }),
  totalAmount: decimal("totalAmount", { precision: 14, scale: 2 }).default("0"),
  items: text("items"),
  notes: text("notes"),
  currency: varchar("currency", { length: 10 }).default("SAR"),
  status: mysqlEnum("status", ["مسودة", "معتمدة", "مدفوعة_جزئياً", "مدفوعة", "ملغاة"]).default("مسودة").notNull(),
  paymentType: mysqlEnum("paymentType", ["نقداً", "آجل", "حوالة"]).default("نقداً").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Invoice = typeof invoices.$inferSelect;
export type InsertInvoice = typeof invoices.$inferInsert;

// ===== المدخلات (ترحيل الشحنات) =====
export const entries = mysqlTable("entries", {
  id: int("id").autoincrement().primaryKey(),
  shipmentId: int("shipmentId").notNull(),
  clientId: int("clientId").notNull(),
  invoiceType: mysqlEnum("invoiceType", ["تخليص_جمركي", "شحن_داخلي", "تعبئة_وتغليف"]).notNull(),
  entryDate: varchar("entryDate", { length: 20 }),
  releaseDate: varchar("releaseDate", { length: 20 }),
  driverName: varchar("driverName", { length: 100 }),
  routeFrom: varchar("routeFrom", { length: 100 }),
  routeTo: varchar("routeTo", { length: 100 }),
  goodsType: varchar("goodsType", { length: 100 }),
  customsPort: varchar("customsPort", { length: 100 }),
  unit: varchar("unit", { length: 30 }),
  quantity: varchar("quantity", { length: 50 }),
  quantityTons: decimal("quantityTons", { precision: 12, scale: 2 }),
  amount: decimal("amount", { precision: 14, scale: 2 }).default("0"),
  companyShare: decimal("companyShare", { precision: 14, scale: 2 }).default("0"),
  transferredAt: timestamp("transferredAt").defaultNow(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Entry = typeof entries.$inferSelect;
export type InsertEntry = typeof entries.$inferInsert;

// ===== ترحيل المبيعات =====
export const salesTransfers = mysqlTable("salesTransfers", {
  id: int("id").autoincrement().primaryKey(),
  invoiceId: int("invoiceId").notNull(),
  invoiceType: mysqlEnum("invoiceType", ["تخليص_جمركي", "شحن_داخلي", "تعبئة_وتغليف"]).notNull(),
  clientId: int("clientId").notNull(),
  totalAmount: decimal("totalAmount", { precision: 14, scale: 2 }),
  goodsType: varchar("goodsType", { length: 100 }),
  quantity: varchar("quantity", { length: 50 }),
  quantityTons: decimal("quantityTons", { precision: 12, scale: 2 }),
  companyShare: decimal("companyShare", { precision: 14, scale: 2 }),
  customsPort: varchar("customsPort", { length: 100 }),
  monthNum: int("monthNum"),
  year: int("year"),
  transferredAt: timestamp("transferredAt").defaultNow(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SalesTransfer = typeof salesTransfers.$inferSelect;
export type InsertSalesTransfer = typeof salesTransfers.$inferInsert;

// ===== المدفوعات =====
export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  invoiceId: int("invoiceId").notNull(),
  clientId: int("clientId").notNull(),
  amount: decimal("amount", { precision: 14, scale: 2 }).notNull(),
  paymentDate: varchar("paymentDate", { length: 20 }),
  method: varchar("method", { length: 50 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = typeof payments.$inferInsert;

// ===== سجل الترحيل =====
export const transferLogs = mysqlTable("transferLogs", {
  id: int("id").autoincrement().primaryKey(),
  transferType: varchar("transferType", { length: 100 }).notNull(),
  recordCount: int("recordCount").default(0),
  status: varchar("status", { length: 50 }).default("تم بنجاح"),
  performedBy: text("performedBy"),
  performedAt: timestamp("performedAt").defaultNow().notNull(),
});

export type TransferLog = typeof transferLogs.$inferSelect;
export type InsertTransferLog = typeof transferLogs.$inferInsert;

// ===== الإعدادات =====
export const settings = mysqlTable("settings", {
  id: int("id").autoincrement().primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  value: text("value"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Setting = typeof settings.$inferSelect;
export type InsertSetting = typeof settings.$inferInsert;

// ===== الفواتير الخدمية =====
export const serviceInvoices = mysqlTable("serviceInvoices", {
  id: int("id").autoincrement().primaryKey(),
  number: int("number").notNull().unique(),
  clientId: int("clientId").notNull(),
  serviceName: varchar("serviceName", { length: 200 }).notNull(),
  serviceDescription: text("serviceDescription"),
  quantity: varchar("quantity", { length: 20 }),
  unitPrice: varchar("unitPrice", { length: 50 }),
  discount: varchar("discount", { length: 10 }),
  taxRate: varchar("taxRate", { length: 10 }),
  totalAmount: decimal("totalAmount", { precision: 14, scale: 2 }),
  currency: varchar("currency", { length: 10 }).default("SAR"),
  date: varchar("date", { length: 20 }),
  status: mysqlEnum("status", ["مسودة", "معتمدة", "مدفوعة_جزئياً", "مدفوعة", "ملغاة"]).default("مسودة").notNull(),
  paymentType: mysqlEnum("paymentType", ["نقداً", "آجل", "حوالة"]).default("نقداً").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ServiceInvoice = typeof serviceInvoices.$inferSelect;
export type InsertServiceInvoice = typeof serviceInvoices.$inferInsert;

// ===== السندات =====
export const vouchers = mysqlTable("vouchers", {
  id: int("id").autoincrement().primaryKey(),
  number: int("number").notNull().unique(),
  voucherType: mysqlEnum("voucherType", ["سند_قبض", "سند_صرف"]).notNull(),
  clientId: int("clientId"),
  amount: decimal("amount", { precision: 14, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 10 }).default("SAR"),
  date: varchar("date", { length: 20 }),
  paymentMethod: varchar("paymentMethod", { length: 50 }),
  cashBox: varchar("cashBox", { length: 100 }),
  cashboxId: int("cashboxId"), // FK → cashboxes (الارتباط الجديد بالصناديق)
  description: text("description"),
  status: mysqlEnum("status", ["مسودة", "معتمد", "ملغي", "مرحل"]).default("معتمد").notNull(),
  sourceDeclarationId: int("sourceDeclarationId"), // FK → customsDeclarations (ربط السند بالبيان الجمركي)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Voucher = typeof vouchers.$inferSelect;
export type InsertVoucher = typeof vouchers.$inferInsert;

// ===== دليل الحسابات =====
export const accounts = mysqlTable("accounts", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 20 }).notNull().unique(),
  name: varchar("name", { length: 200 }).notNull(),
  type: mysqlEnum("type", ["أصول", "خصوم", "حقوق_ملكية", "إيرادات", "مصروفات"]).notNull(),
  parentId: int("parentId"),
  balance: decimal("balance", { precision: 16, scale: 2 }).default("0"),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Account = typeof accounts.$inferSelect;
export type InsertAccount = typeof accounts.$inferInsert;

// ===== القيود اليومية =====
export const journalEntries = mysqlTable("journalEntries", {
  id: int("id").autoincrement().primaryKey(),
  entryNumber: int("entryNumber").notNull().unique(),
  date: varchar("date", { length: 20 }),
  description: text("description"),
  entryType: mysqlEnum("entryType", ["قيد_يومي", "قيد_مزدوج", "تسوية"]).default("قيد_يومي").notNull(),
  status: mysqlEnum("status", ["مسودة", "مرحل", "ملغي"]).default("مسودة").notNull(),
  createdBy: text("createdBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type JournalEntry = typeof journalEntries.$inferSelect;
export type InsertJournalEntry = typeof journalEntries.$inferInsert;

// ===== بنود القيود اليومية =====
export const journalEntryItems = mysqlTable("journalEntryItems", {
  id: int("id").autoincrement().primaryKey(),
  entryId: int("entryId").notNull(),
  accountId: int("accountId").notNull(),
  debit: varchar("debit", { length: 50 }).default("0"),
  credit: varchar("credit", { length: 50 }).default("0"),
  description: text("description"),
});

export type JournalEntryItem = typeof journalEntryItems.$inferSelect;
export type InsertJournalEntryItem = typeof journalEntryItems.$inferInsert;

// ===== الحركة اليومية =====
export const dailyMovements = mysqlTable("dailyMovements", {
  id: int("id").autoincrement().primaryKey(),
  date: varchar("date", { length: 20 }),
  type: mysqlEnum("type", ["إيراد", "مصروف", "تحويل", "سند_قبض", "سند_صرف"]).notNull(),
  accountId: int("accountId").notNull(),
  amount: decimal("amount", { precision: 14, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 10 }).default("SAR"),
  description: text("description"),
  reference: varchar("reference", { length: 100 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type DailyMovement = typeof dailyMovements.$inferSelect;
export type InsertDailyMovement = typeof dailyMovements.$inferInsert;



// ===== العملات =====
export const currencies = mysqlTable("currencies", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 10 }).notNull().unique(),
  name: varchar("name", { length: 100 }).notNull(),
  symbol: varchar("symbol", { length: 10 }).notNull(),
  exchangeRate: decimal("exchangeRate", { precision: 10, scale: 4 }).default("1"),
  isDefault: mysqlEnum("isDefault", ["نعم", "لا"]).default("لا").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Currency = typeof currencies.$inferSelect;
export type InsertCurrency = typeof currencies.$inferInsert;

// ===== اللغات =====
export const languages = mysqlTable("languages", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 10 }).notNull().unique(),
  name: varchar("name", { length: 100 }).notNull(),
  isDefault: int("isDefault").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Language = typeof languages.$inferSelect;
export type InsertLanguage = typeof languages.$inferInsert;

// ===== الخطوط =====
export const fonts = mysqlTable("fonts", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(),
  fontFamily: varchar("fontFamily", { length: 200 }).notNull(),
  isDefault: int("isDefault").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Font = typeof fonts.$inferSelect;
export type InsertFont = typeof fonts.$inferInsert;

// ===== النماذج =====
export const templates = mysqlTable("templates", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(),
  type: mysqlEnum("type", ["فاتورة", "سند", "تقرير", "فاتورة_خدمية"]).notNull(),
  header: text("header"),
  body: text("body"),
  footer: text("footer"),
  isActive: int("isActive").default(1),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Template = typeof templates.$inferSelect;
export type InsertTemplate = typeof templates.$inferInsert;

// ===== الصلاحيات =====
export const permissions = mysqlTable("permissions", {
  id: int("id").autoincrement().primaryKey(),
  role: varchar("role", { length: 50 }).notNull(),
  module: varchar("module", { length: 100 }).notNull(),
  canView: int("canView").default(0),
  canCreate: int("canCreate").default(0),
  canEdit: int("canEdit").default(0),
  canDelete: int("canDelete").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Permission = typeof permissions.$inferSelect;
export type InsertPermission = typeof permissions.$inferInsert;

// ===== نسخ احتياطية =====
export const backups = mysqlTable("backups", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 200 }).notNull(),
  size: varchar("size", { length: 50 }),
  status: mysqlEnum("status", ["قيد_الإنشاء", "تم", "فشل"]).default("قيد_الإنشاء").notNull(),
  fileUrl: text("fileUrl"),
  createdBy: text("createdBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Backup = typeof backups.$inferSelect;
export type InsertBackup = typeof backups.$inferInsert;

// ===== الخدمات =====
export const services = mysqlTable("services", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 20 }).notNull().unique(),
  name: varchar("name", { length: 200 }).notNull(),
  description: text("description"),
  price: decimal("price", { precision: 14, scale: 2 }),
  category: varchar("category", { length: 100 }),
  isActive: int("isActive").default(1),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Service = typeof services.$inferSelect;
export type InsertService = typeof services.$inferInsert;

// ===== التصريحات الجمركية (بيانات جمركية) =====
// ===== البيانات الجمركية =====
export const customsDeclarations = mysqlTable("customsDeclarations", {
  id: int("id").autoincrement().primaryKey(),
  entryNumber: varchar("entryNumber", { length: 50 }).notNull().unique(), // رقم القيد/الدخول
  declarationNumber: varchar("declarationNumber", { length: 50 }).notNull().unique(), // رقم البيان (CD-001)
  shipmentId: int("shipmentId"), // FK → shipments (الشحنة المرتبطة)
  clientId: int("clientId").notNull(), // FK → clients (العميل المرتبط)
  goodsType: varchar("goodsType", { length: 200 }), // نوع البضاعة
  customsPort: varchar("customsPort", { length: 200 }), // المنفذ الجمركي
  declarationDate: varchar("declarationDate", { length: 20 }), // تاريخ البيان
  plateNumber: varchar("plateNumber", { length: 50 }), // رقم اللوحة
  driverName: varchar("driverName", { length: 200 }), // اسم السائق
  declarationFee: decimal("declarationFee", { precision: 14, scale: 2 }).default("0"), // رسوم البيان
  hsCode: varchar("hsCode", { length: 50 }), // التعرفة الجمركية
  currency: varchar("currency", { length: 10 }).default("SAR"), // العملة
  jobOrderId: int("jobOrderId"), // FK → jobOrders
  status: mysqlEnum("status", ["مسودة", "معتمد", "مكتمل", "ملغي"]).default("مسودة").notNull(),
  approvedAt: timestamp("approvedAt"), // تاريخ الاعتماد
  releaseDate: varchar("releaseDate", { length: 20 }), // تاريخ الإفراج
  releasedBy: varchar("releasedBy", { length: 200 }), // من أفرج
  releaseNotes: text("releaseNotes"), // ملاحظات الإفراج
  releaseAttachmentUrl: text("releaseAttachmentUrl"), // رابط مرفق الإفراج
  releaseAttachmentKey: varchar("releaseAttachmentKey", { length: 255 }), // مفتاح ملف الإفراج في S3
  attachmentUrl: text("attachmentUrl"), // رابط المرفق (صورة أو PDF)
  attachmentKey: varchar("attachmentKey", { length: 255 }), // مفتاح الملف في S3
  customsEntryId: int("customsEntryId"), // FK → customsEntries (ربط البيان بالقيد)
  notes: text("notes"), // ملاحظات
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CustomsDeclaration = typeof customsDeclarations.$inferSelect;
export type InsertCustomsDeclaration = typeof customsDeclarations.$inferInsert;

// ===== تكاليف التخليص =====
export const clearanceCosts = mysqlTable("clearanceCosts", {
  id: int("id").autoincrement().primaryKey(),
  declarationId: int("declarationId").notNull(), // FK → customsDeclarations
  declarationFee: decimal("declarationFee", { precision: 14, scale: 2 }).default("0"), // رسوم البيان
  inspectionFee: decimal("inspectionFee", { precision: 14, scale: 2 }).default("0"), // رسوم المعاينة
  penalties: decimal("penalties", { precision: 14, scale: 2 }).default("0"), // غرامات
  weightDifferences: decimal("weightDifferences", { precision: 14, scale: 2 }).default("0"), // فوارق الوزن
  otherGovtFees: decimal("otherGovtFees", { precision: 14, scale: 2 }).default("0"), // رسوم حكومية أخرى
  transport: decimal("transport", { precision: 14, scale: 2 }).default("0"), // نقل
  fuel: decimal("fuel", { precision: 14, scale: 2 }).default("0"), // وقود
  driverCost: decimal("driverCost", { precision: 14, scale: 2 }).default("0"), // سائق
  maintenance: decimal("maintenance", { precision: 14, scale: 2 }).default("0"), // صيانة
  otherExpenses: decimal("otherExpenses", { precision: 14, scale: 2 }).default("0"), // مصاريف أخرى
  pettyCash: decimal("pettyCash", { precision: 14, scale: 2 }).default("0"), // نثريات
  totalCost: decimal("totalCost", { precision: 14, scale: 2 }).default("0"), // إجمالي التكلفة (محسوب)
  discount: decimal("discount", { precision: 14, scale: 2 }).default("0"), // الخصم
  netCost: decimal("netCost", { precision: 14, scale: 2 }).default("0"), // الصافي
  isApproved: boolean("isApproved").default(false), // اعتماد التكلفة
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ClearanceCost = typeof clearanceCosts.$inferSelect;
export type InsertClearanceCost = typeof clearanceCosts.$inferInsert;

// ===== المقبوضات =====
export const clearanceReceipts = mysqlTable("clearanceReceipts", {
  id: int("id").autoincrement().primaryKey(),
  declarationId: int("declarationId").notNull(), // FK → customsDeclarations
  clientId: int("clientId"), // FK → clients (من البيان تلقائياً)
  amount: decimal("amount", { precision: 14, scale: 2 }).notNull(), // المبلغ
  currency: varchar("currency", { length: 10 }).default("SAR"), // العملة
  paymentDate: varchar("paymentDate", { length: 20 }), // التاريخ
    paymentMethod: varchar("paymentMethod", { length: 50 }), // طريقة الدفع
  paymentType: mysqlEnum("paymentType", ["نقداً", "آجل", "حوالة"]).default("نقداً").notNull(), // نوع الدفع
  cashboxId: int("cashboxId"), // FK → cashboxes (إلى أي صندوق/بنك تم القبض)
  voucherId: int("voucherId"), // FK → vouchers (رابط سند القبض)
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type ClearanceReceipt = typeof clearanceReceipts.$inferSelect;
export type InsertClearanceReceipt = typeof clearanceReceipts.$inferInsert;

// ===== المدفوعات =====
export const clearanceDisbursements = mysqlTable("clearanceDisbursements", {
  id: int("id").autoincrement().primaryKey(),
  declarationId: int("declarationId").notNull(), // FK → customsDeclarations
  payee: varchar("payee", { length: 200 }).notNull(), // الجهة المدفوع لها
  amount: decimal("amount", { precision: 14, scale: 2 }).notNull(), // المبلغ
  currency: varchar("currency", { length: 10 }).default("SAR"), // العملة
  paymentDate: varchar("paymentDate", { length: 20 }), // التاريخ
    paymentMethod: varchar("paymentMethod", { length: 50 }), // طريقة الدفع
  paymentType: mysqlEnum("paymentType", ["نقداً", "آجل", "حوالة"]).default("نقداً").notNull(), // نوع الدفع
  cashboxId: int("cashboxId"), // FK → cashboxes (من أي صندوق/بنك تم الصرف)
  expenseType: varchar("expenseType", { length: 50 }), // نوع المصروف
  voucherId: int("voucherId"), // FK → vouchers (رابط سند الصرف)
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type ClearanceDisbursement = typeof clearanceDisbursements.$inferSelect;
export type InsertClearanceDisbursement = typeof clearanceDisbursements.$inferInsert;

// ===== أوامر العمل (Job Orders) =====
// جدول يربط جميع العمليات برقم مرجعي موحد
export const jobOrders = mysqlTable("jobOrders", {
  id: int("id").autoincrement().primaryKey(),
  jobNumber: varchar("jobNumber", { length: 50 }).notNull().unique(), // رقم أمر العمل (JO-0001)
  clientId: int("clientId").notNull(), // FK → clients
  shipmentId: int("shipmentId"), // FK → shipments
  declarationId: int("declarationId"), // FK → customsDeclarations
  jobType: mysqlEnum("jobType", ["تخليص_جمركي", "شحن_داخلي", "تعبئة_وتغليف", "استشارة"]).default("تخليص_جمركي").notNull(),
  status: mysqlEnum("status", ["استشارة", "عرض_سعر", "مفتوح", "قيد_التخليص", "مفروج", "قيد_التسليم", "مكتمل", "ملغي"]).default("استشارة").notNull(),
  priority: mysqlEnum("priority", ["عادي", "عاجل", "أولوية"]).default("عادي").notNull(),
  notes: text("notes"),
  createdBy: text("createdBy"),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type JobOrder = typeof jobOrders.$inferSelect;
export type InsertJobOrder = typeof jobOrders.$inferInsert;

// ===== أمر الحركة الداخلي + إثبات التسليم (POD) =====
export const internalTransportOrders = mysqlTable("internalTransportOrders", {
  id: int("id").autoincrement().primaryKey(),
  jobOrderId: int("jobOrderId").notNull(), // FK → jobOrders
  declarationId: int("declarationId"), // FK → customsDeclarations
  vehiclePlate: varchar("vehiclePlate", { length: 50 }), // رقم اللوحة
  driverName: varchar("driverName", { length: 200 }), // اسم السائق
  driverPhone: varchar("driverPhone", { length: 50 }), // هاتف السائق
  destination: varchar("destination", { length: 200 }), // وجهه التسليم
  departureTime: varchar("departureTime", { length: 20 }), // وقت الانطلاق
  arrivalTime: varchar("arrivalTime", { length: 20 }), // وقت الوصول
  podImage: text("podImage"), // صورة محضر التسليم (URL)
  podNotes: text("podNotes"), // ملاحظات سلامة الشحنة
  receiverName: varchar("receiverName", { length: 200 }), // اسم المستلم
  receiverSignature: varchar("receiverSignature", { length: 50 }), // ختم/توقيع
  status: mysqlEnum("status", ["قيد_الانتظار", "تم_الانطلاق", "وصل", "تم_التسليم", "ملغي"]).default("قيد_الانتظار").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type InternalTransportOrder = typeof internalTransportOrders.$inferSelect;
export type InsertInternalTransportOrder = typeof internalTransportOrders.$inferInsert;

// ===== الأصول الثابتة (Fixed Assets) =====
export const fixedAssets = mysqlTable("fixedAssets", {
  id: int("id").autoincrement().primaryKey(),
  assetType: mysqlEnum("assetType", ["شاحنة", "مقطورة", "معدات", "أجهزة", "مبنى", "أخرى"]).notNull(),
  name: varchar("name", { length: 200 }).notNull(),
  plateNumber: varchar("plateNumber", { length: 50 }), // رقم اللوحة (للشاحنات)
  purchaseDate: varchar("purchaseDate", { length: 20 }), // تاريخ الشراء
  purchaseValue: decimal("purchaseValue", { precision: 14, scale: 2 }).notNull(), // قيمة الشراء
  usefulLifeYears: decimal("usefulLifeYears", { precision: 5, scale: 1 }).default("10"), // عمر افتراضي
  monthlyDepreciation: decimal("monthlyDepreciation", { precision: 14, scale: 2 }).default("0"), // الإهلاك الشهري
  accumulatedDepreciation: decimal("accumulatedDepreciation", { precision: 14, scale: 2 }).default("0"), // الإهلاك المتراكم
  bookValue: decimal("bookValue", { precision: 14, scale: 2 }).default("0"), // القيمة الدفترية
  status: mysqlEnum("status", ["نشط", "صيانة", "خارج_الخدمة", "مباع"]).default("نشط").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FixedAsset = typeof fixedAssets.$inferSelect;
export type InsertFixedAsset = typeof fixedAssets.$inferInsert;

// ===== التقييمات (CSAT) =====
export const evaluations = mysqlTable("evaluations", {
  id: int("id").autoincrement().primaryKey(),
  jobOrderId: int("jobOrderId").notNull(), // FK → jobOrders
  declarationId: int("declarationId"), // FK → customsDeclarations
  clientId: int("clientId"), // FK → clients
  rating: int("rating"), // تقييم من 1-5
  clearanceSpeed: int("clearanceSpeed"), // سرعة التخليص 1-5
  cargoSafety: int("cargoSafety"), // سلامة البضاعة 1-5
  driverHandling: int("driverHandling"), // تعامل السائق 1-5
  feedback: text("feedback"), // ملاحظات العميل
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Evaluation = typeof evaluations.$inferSelect;
export type InsertEvaluation = typeof evaluations.$inferInsert;

// ===== القيود الجمركية (Customs Entries) =====
export const customsEntries = mysqlTable("customsEntries", {
  id: int("id").autoincrement().primaryKey(),
  entryNumber: varchar("entryNumber", { length: 50 }).notNull().unique(), // رقم القيد/الدخول
  clientId: int("clientId").notNull(), // العميل المرتبط
  operationType: varchar("operationType", { length: 100 }), // نوع العملية
  entryDate: varchar("entryDate", { length: 20 }), // التاريخ
  goodsType: varchar("goodsType", { length: 200 }), // نوع البضاعة
  customsPort: varchar("customsPort", { length: 100 }), // المنفذ الجمركي
  plateNumber: varchar("plateNumber", { length: 50 }), // رقم اللوحة
  driverName: varchar("driverName", { length: 200 }), // اسم السائق
  notes: text("notes"),
  status: mysqlEnum("status", ["نشط", "مرتبط_ببيان", "ملغي"]).default("نشط").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CustomsEntry = typeof customsEntries.$inferSelect;
export type InsertCustomsEntry = typeof customsEntries.$inferInsert;

// ===== التراخيص (Permits) =====
export const permits = mysqlTable("permits", {
  id: int("id").autoincrement().primaryKey(),
  permitNumber: varchar("permitNumber", { length: 50 }).notNull().unique(),
  date: varchar("date", { length: 20 }),
  authority: varchar("authority", { length: 100 }), // الزراعة، التجارة، إلخ
  totalQuantity: decimal("totalQuantity", { precision: 14, scale: 2 }).default("0"),
  remainingQuantity: decimal("remainingQuantity", { precision: 14, scale: 2 }).default("0"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Permit = typeof permits.$inferSelect;
export type InsertPermit = typeof permits.$inferInsert;

// ===== تخصيم التراخيص (Permit Deductions) =====
export const permitDeductions = mysqlTable("permitDeductions", {
  id: int("id").autoincrement().primaryKey(),
  permitId: int("permitId").notNull(),
  declarationNumber: varchar("declarationNumber", { length: 50 }), // رقم البيان الجمركي (يدوي)
  declarationDate: varchar("declarationDate", { length: 20 }), // تاريخ البيان (يدوي)
  deductedQuantity: decimal("deductedQuantity", { precision: 14, scale: 2 }).default("0"),
  remainingQuantity: decimal("remainingQuantity", { precision: 14, scale: 2 }).default("0"),
  date: varchar("date", { length: 20 }).notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PermitDeduction = typeof permitDeductions.$inferSelect;
export type InsertPermitDeduction = typeof permitDeductions.$inferInsert;

// ===== تخصيم الكميات (Quantity Deductions) =====
export const quantityDeductions = mysqlTable("quantityDeductions", {
  id: int("id").autoincrement().primaryKey(),
  referenceNumber: varchar("referenceNumber", { length: 50 }).notNull(), // رقم المرجع
  referenceDate: varchar("referenceDate", { length: 20 }).notNull(), // تاريخ المرجع
  goodsType: varchar("goodsType", { length: 200 }), // نوع البضاعة
  authority: varchar("authority", { length: 100 }), // ميناء عدن، منفذ شحن، إلخ
  totalQuantity: decimal("totalQuantity", { precision: 14, scale: 2 }).default("0"),
  remainingQuantity: decimal("remainingQuantity", { precision: 14, scale: 2 }).default("0"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type QuantityDeduction = typeof quantityDeductions.$inferSelect;
export type InsertQuantityDeduction = typeof quantityDeductions.$inferInsert;

// ===== تفاصيل تخصيم الكميات (Quantity Deduction Details) =====
export const quantityDeductionDetails = mysqlTable("quantityDeductionDetails", {
  id: int("id").autoincrement().primaryKey(),
  quantityDeductionId: int("quantityDeductionId").notNull(),
  declarationNumber: varchar("declarationNumber", { length: 50 }).notNull(), // رقم البيان الجمركي
  declarationDate: varchar("declarationDate", { length: 20 }).notNull(), // تاريخ البيان
  deductedQuantity: decimal("deductedQuantity", { precision: 14, scale: 2 }).default("0"),
  remainingQuantity: decimal("remainingQuantity", { precision: 14, scale: 2 }).default("0"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type QuantityDeductionDetail = typeof quantityDeductionDetails.$inferSelect;
export type InsertQuantityDeductionDetail = typeof quantityDeductionDetails.$inferInsert;

// ===== الموردين (Suppliers) =====
export const suppliers = mysqlTable("suppliers", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(), // اسم المورد
  phone: varchar("phone", { length: 50 }), // الهاتف
  email: varchar("email", { length: 320 }), // البريد الإلكتروني
  address: text("address"), // العنوان
  category: varchar("category", { length: 100 }), // التصنيف (نقل، وقود، صيانة، إلخ)
  notes: text("notes"), // ملاحظات
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type Supplier = typeof suppliers.$inferSelect;
export type InsertSupplier = typeof suppliers.$inferInsert;

// ===== الموظفين (Employees) =====
export const employees = mysqlTable("employees", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(), // اسم الموظف
  phone: varchar("phone", { length: 50 }), // الهاتف
  email: varchar("email", { length: 320 }), // البريد الإلكتروني
  jobTitle: varchar("jobTitle", { length: 100 }), // المسمى الوظيفي
  department: varchar("department", { length: 100 }), // القسم
  salary: decimal("salary", { precision: 14, scale: 2 }).default("0"), // الراتب الأساسي
  joinDate: date("joinDate"), // تاريخ الالتحاق
  status: mysqlEnum("status", ["نشط", "متوقف", "استقالة"]).default("نشط").notNull(),
  notes: text("notes"), // ملاحظات
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type Employee = typeof employees.$inferSelect;
export type InsertEmployee = typeof employees.$inferInsert;

// ===== العهد والسلف (Custody & Advances) =====
export const custodyRecords = mysqlTable("custodyRecords", {
  id: int("id").autoincrement().primaryKey(),
  employeeId: int("employeeId").notNull(), // FK → employees
  type: mysqlEnum("type", ["سلفة", "عهدة", "مصروفات مقدمة"]).notNull(), // نوع السلفة
  amount: decimal("amount", { precision: 14, scale: 2 }).notNull(), // المبلغ
  currency: varchar("currency", { length: 10 }).default("YER"), // العملة
  cashboxId: int("cashboxId"), // FK → cashboxes (من أي صندوق تم الصرف)
  purpose: text("purpose"), // الغرض
  paymentType: mysqlEnum("paymentType", ["نقداً", "آجل", "حوالة"]).default("نقداً").notNull(), // نوع الدفع
  status: mysqlEnum("status", ["معلّقة", "مسدّدة", "ملغاة", "جزئية"]).default("معلّقة").notNull(),
  repaidAmount: decimal("repaidAmount", { precision: 14, scale: 2 }).default("0"), // المبلغ المسدد
  settledDate: date("settledDate"), // تاريخ التسوية
  notes: text("notes"), // ملاحظات
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type CustodyRecord = typeof custodyRecords.$inferSelect;
export type InsertCustodyRecord = typeof custodyRecords.$inferInsert;

// ===== الصناديق والبنوك (Cashboxes & Banks) =====
export const cashboxes = mysqlTable("cashboxes", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(), // اسم الصندوق أو البنك
  type: mysqlEnum("type", ["صندوق نقدي", "بنك"]).notNull(), // النوع
  currency: varchar("currency", { length: 10 }).default("YER"), // العملة الافتراضية
  initialBalance: decimal("initialBalance", { precision: 16, scale: 2 }).default("0"), // الرصيد الافتتاحي
  currentBalance: decimal("currentBalance", { precision: 16, scale: 2 }).default("0"), // الرصيد الحالي
  isActive: boolean("isActive").default(true).notNull(), // نشط
  linkedAccountId: int("linkedAccountId"), // FK → accounts (الحساب المحاسبي المرتبط)
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type Cashbox = typeof cashboxes.$inferSelect;
export type InsertCashbox = typeof cashboxes.$inferInsert;
