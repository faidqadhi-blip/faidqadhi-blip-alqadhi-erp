import { useAuth } from "@/_core/hooks/useAuth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { startLogin } from "@/const";
import {
  LayoutDashboard, Users, Truck, FileText, ArrowLeftRight,
  BarChart3, CreditCard, DollarSign, Settings, LogOut,
  Receipt, ClipboardList, BookOpen, CalendarDays,
  FileInput, Calculator, Wallet, PackageX, PieChart, PanelLeftClose, PanelLeft,
  Briefcase, ArrowDownUp, Building2, Star, UserCog, HandCoins, Landmark,
  ShieldCheck, ShieldAlert,
} from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import { DashboardLayoutSkeleton } from './DashboardLayoutSkeleton';
import { Button } from "./ui/button";
import { useIsMobile } from "@/hooks/useMobile";
import { trpc } from "@/lib/trpc";
import { FINANCIAL_MODULE_IDS } from "@/pages/Settings";

const menuItems = [
  { icon: LayoutDashboard, label: "لوحة التحكم", path: "/" },
  { icon: Users, label: "العملاء", path: "/clients" },
  { icon: Truck, label: "الشحنات", path: "/shipments" },
  { icon: ArrowLeftRight, label: "الترحيل", path: "/transfers" },
  { icon: BarChart3, label: "المبيعات", path: "/sales-report" },
  { icon: Users, label: "كشف حساب", path: "/client-statement" },
  { icon: CreditCard, label: "المدفوعات", path: "/payments" },
  { icon: DollarSign, label: "الإيرادات", path: "/revenue" },
  { icon: UserCog, label: "الموظفين", path: "/employees" },
  { icon: HandCoins, label: "العهد والسلف", path: "/petty-cash" },
  { icon: Landmark, label: "الصناديق والبنوك", path: "/cashboxes" },
  { icon: Receipt, label: "الفواتير الخدمية", path: "/service-invoices" },
  { icon: ClipboardList, label: "السندات", path: "/vouchers" },
  { icon: BookOpen, label: "القيود المحاسبية", path: "/journal-entries" },
  { icon: BarChart3, label: "الأستاذ العام", path: "/general-ledger" },
  { icon: CalendarDays, label: "الحركة اليومية", path: "/daily-movements" },
  { icon: Settings, label: "الإعدادات", path: "/settings" },
];

const customsMenuItems = [
  { icon: Briefcase, label: "أوامر العمل", path: "/job-orders" },
  { icon: ClipboardList, label: "القيود الجمركية", path: "/customs-entries" },
  { icon: FileInput, label: "البيانات الجمركية", path: "/customs-declarations" },
  { icon: Calculator, label: "تكاليف التخليص", path: "/clearance-costs" },
  { icon: Receipt, label: "الفواتير", path: "/clearance-invoices" },
  { icon: Wallet, label: "المقبوضات والمدفوعات", path: "/clearance-payments" },
  { icon: CreditCard, label: "المصاريف والنثريات", path: "/clearance-expenses" },
  { icon: PieChart, label: "التقارير", path: "/clearance-reports" },
];

const permitMenuItems = [
  { icon: Receipt, label: "أولاً: التراخيص", path: "/permits" },
  { icon: Calculator, label: "ثانياً: تخصيم الكميات", path: "/quantity-deductions" },
];

const logisticsMenuItems = [
  { icon: ArrowDownUp, label: "أوامر الحركة والتسليم", path: "/internal-transport" },
  { icon: Truck, label: "الأصول والإهلاك", path: "/fixed-assets" },
  { icon: Star, label: "تقييمات العملاء", path: "/evaluations" },
  { icon: Building2, label: "الموردين", path: "/suppliers" },
];

const SIDEBAR_WIDTH = "16rem";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { loading, user } = useAuth();

  if (loading) {
    return <DashboardLayoutSkeleton />
  }

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="flex flex-col items-center gap-8 p-8 max-w-md w-full">
          <div className="text-center space-y-4">
            <div className="inline-flex h-20 w-20 items-center justify-center rounded-2xl bg-primary/10">
              <img src="/manus-storage/faidal-logo_11e2a37b.png" alt="Faidal Alqadhi" className="h-16 w-16 object-contain" />
            </div>
            <h1 className="text-2xl font-bold text-foreground">
              Faidal Alqadhi
            </h1>
            <p className="text-sm text-muted-foreground">
              للتخليص الجمركي والخدمات اللوجستية
            </p>
          </div>
          <Button
            onClick={() => startLogin()}
            size="lg"
            className="w-full shadow-lg hover:shadow-xl transition-all"
          >
            تسجيل الدخول
          </Button>
        </div>
      </div>
    );
  }

  return <DashboardLayoutContent>{children}</DashboardLayoutContent>;
}

function DashboardLayoutContent({
  children,
}: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const [location, setLocation] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const isMobile = useIsMobile();
  const isCollapsed = sidebarCollapsed;

  const activeMenuItem = menuItems.find(item => item.path === location);

  if (isMobile) {
    return (
      <div className="min-h-screen bg-background flex flex-col" dir="rtl">
        {/* Mobile header */}
        <div className="flex items-center justify-between border-b h-14 px-4 bg-sidebar text-sidebar-foreground sticky top-0 z-50">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 rounded-lg hover:bg-sidebar-accent transition-colors"
            >
              <PanelLeft className="h-5 w-5" />
            </button>
            <span className="font-semibold text-sm truncate max-w-[120px]">
              {activeMenuItem?.label || "القائمة"}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <img src="/manus-storage/faidal-logo-dark_dd1a219c.png" alt="Faidal Alqadhi" className="h-8 w-8 object-contain" />
            <span className="text-xs font-bold">FAIDAL</span>
          </div>
        </div>

        {/* Mobile sidebar overlay with animation classes */}
        <div 
          className={`fixed inset-0 bg-black/50 z-40 transition-opacity duration-300 ${sidebarOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
          onClick={() => setSidebarOpen(false)}
        />
        <div 
          className={`fixed inset-y-0 right-0 w-72 bg-sidebar text-sidebar-foreground z-50 flex flex-col shadow-xl transform transition-transform duration-300 ease-in-out ${sidebarOpen ? 'translate-x-0' : 'translate-x-full'}`}
        >
          <div className="flex items-center justify-between p-4 border-b border-sidebar-border">
            <div className="flex items-center gap-2">
              <img src="/manus-storage/faidal-logo-dark_dd1a219c.png" alt="Logo" className="h-8 w-8" />
              <span className="font-bold">القائمة الرئيسية</span>
            </div>
            <button onClick={() => setSidebarOpen(false)} className="p-1 hover:bg-sidebar-accent rounded">
              <PanelLeftClose className="h-5 w-5" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto">
            <SidebarContentInner
              isCollapsed={false}
              isMobile={true}
              location={location}
              setLocation={(path: string) => { setLocation(path); setSidebarOpen(false); }}
              user={user}
              logout={logout}
              onToggle={() => {}}
            />
          </div>
        </div>

        {/* Mobile Quick Actions Bar (Bottom) */}
        <div className="fixed bottom-4 left-4 right-4 h-14 bg-white/80 backdrop-blur-md border border-gray-200 rounded-full shadow-lg z-30 flex items-center justify-around px-2 md:hidden">
          <button onClick={() => setLocation('/')} className={`p-2 rounded-full ${location === '/' ? 'bg-primary text-white' : 'text-gray-500'}`}>
            <LayoutDashboard className="h-6 w-6" />
          </button>
          <button onClick={() => setLocation('/customs-entries')} className={`p-2 rounded-full ${location === '/customs-entries' ? 'bg-primary text-white' : 'text-gray-500'}`}>
            <ClipboardList className="h-6 w-6" />
          </button>
          <button onClick={() => setLocation('/quantity-deductions')} className={`p-2 rounded-full ${location === '/quantity-deductions' ? 'bg-primary text-white' : 'text-gray-500'}`}>
            <Calculator className="h-6 w-6" />
          </button>
          <button onClick={() => setLocation('/job-orders')} className={`p-2 rounded-full ${location === '/job-orders' ? 'bg-primary text-white' : 'text-gray-500'}`}>
            <Briefcase className="h-6 w-6" />
          </button>
        </div>

        {/* Mobile content */}
        <main className="flex-1 p-4 pb-20 overflow-x-hidden">{children}</main>
      </div>
    );
  }

  // Desktop layout - RTL: sidebar on right
  const sidebarWidth = isCollapsed ? "4.5rem" : SIDEBAR_WIDTH;

  return (
    <div className="min-h-screen bg-background flex" dir="rtl">
      {/* Desktop sidebar - fixed on right */}
      <aside
        className="fixed top-0 right-0 h-screen bg-sidebar text-sidebar-foreground flex flex-col z-40 transition-all duration-200"
        style={{ width: sidebarWidth }}
      >
        <SidebarContentInner
          isCollapsed={isCollapsed}
          isMobile={false}
          location={location}
          setLocation={setLocation}
          user={user}
          logout={logout}
          onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
        />
      </aside>

      {/* Main content - pushed left from sidebar */}
      <div
        className="flex-1 flex flex-col min-h-screen transition-all duration-200"
        style={{ marginRight: sidebarWidth }}
      >
        <main className="flex-1 p-4 md:p-6">{children}</main>
      </div>
    </div>
  );
}

// Map sidebar paths to module IDs for permission checking
const pathToModuleId: Record<string, string> = {
  "/": "dashboard",
  "/clients": "clients",
  "/shipments": "shipments",
  "/transfers": "transfers",
  "/sales-report": "sales-report",
  "/client-statement": "client-statement",
  "/payments": "payments",
  "/revenue": "revenue",
  "/settings": "settings",
  "/service-invoices": "service-invoices",
  "/vouchers": "vouchers",
  "/journal-entries": "journal-entries",
  "/general-ledger": "general-ledger",
  "/daily-movements": "daily-movements",
  "/customs-entries": "customs-entries",
  "/customs-declarations": "customs-declarations",
  "/clearance-costs": "clearance-costs",
  "/clearance-invoices": "clearance-invoices",
  "/clearance-payments": "clearance-payments",
  "/clearance-expenses": "clearance-expenses",
  "/clearance-reports": "clearance-reports",
  "/permits": "permits",
  "/quantity-deductions": "quantity-deductions",
  "/job-orders": "job-orders",
  "/internal-transport": "internal-transport",
  "/fixed-assets": "fixed-assets",
  "/evaluations": "evaluations",
  "/suppliers": "suppliers",
  "/employees": "employees",
  "/petty-cash": "petty-cash",
  "/cashboxes": "cashboxes",
};

function filterByPermissions(
  items: typeof menuItems,
  allowedModules: Set<string>,
  isAdmin: boolean,
) {
  return items.filter(item => {
    const moduleId = pathToModuleId[item.path];
    if (!moduleId) return true; // Show items not in module list
    // Admin always sees everything
    if (isAdmin) return true;
    // If module is financial, check permission
    const isFinancial = FINANCIAL_MODULE_IDS.includes(moduleId as any);
    if (!isFinancial) return true; // Operational modules always visible
    return allowedModules.has(moduleId);
  });
}

// Determine financial access status of the current user
function getFinancialAccessLevel(perms: { isAdmin: boolean; modules: { moduleId: string; canView: boolean }[] } | undefined): "admin" | "financial" | "restricted" {
  if (!perms) return "restricted";
  if (perms.isAdmin) return "admin";
  const hasAnyFinancial = (perms.modules ?? []).some(
    p => p.canView && FINANCIAL_MODULE_IDS.includes(p.moduleId as any),
  );
  return hasAnyFinancial ? "financial" : "restricted";
}

function FinancialAccessBadge({
  level,
  title,
  className,
}: {
  level: "admin" | "financial" | "restricted";
  title: string;
  className?: string;
}) {
  if (level === "admin") {
    return (
      <span
        className={
          `inline-flex items-center gap-1 rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-medium text-emerald-300 border border-emerald-500/25 ${className ?? ""}`
        }
        title={title}
      >
        <ShieldCheck className="h-3 w-3" />
        صلاحيات كاملة
      </span>
    );
  }
  if (level === "financial") {
    return (
      <span
        className={
          `inline-flex items-center gap-1 rounded-full bg-blue-500/15 px-2 py-0.5 text-[10px] font-medium text-blue-300 border border-blue-500/25 ${className ?? ""}`
        }
        title={title}
      >
        <DollarSign className="h-3 w-3" />
        صلاحيات مالية
      </span>
    );
  }
  return (
    <span
      className={
        `inline-flex items-center gap-1 rounded-full bg-amber-500/15 px-2 py-0.5 text-[10px] font-medium text-amber-300 border border-amber-500/25 ${className ?? ""}`
      }
      title={title}
    >
      <ShieldAlert className="h-3 w-3" />
      عمليات فقط
    </span>
  );
}

function SidebarContentInner({
  isCollapsed,
  isMobile,
  location,
  setLocation,
  user,
  logout,
  onToggle,
}: {
  isCollapsed: boolean;
  isMobile: boolean;
  location: string;
  setLocation: (path: string) => void;
  user: any;
  logout: () => void;
  onToggle: () => void;
}) {
  // Fetch permissions
  const { data: perms } = trpc.moduleAccess.myPermissions.useQuery();
  const isAdmin = perms?.isAdmin ?? false;
  const allowedModules = new Set(
    (perms?.modules ?? []).filter(p => p.canView).map(p => p.moduleId),
  );
  const financialLevel = getFinancialAccessLevel(perms);
  const financialTitle =
    financialLevel === "admin"
      ? "مدير النظام - صلاحيات كاملة على جميع الأقسام"
      : financialLevel === "financial"
        ? "يملك صلاحيات للوصول إلى الأقسام المالية"
        : "صلاحيات تشغيلية فقط - الأقسام المالية مخفية";

  const visibleMainItems = filterByPermissions(menuItems, allowedModules, isAdmin);
  const visibleCustomsItems = filterByPermissions(customsMenuItems, allowedModules, isAdmin);
  const visiblePermitItems = filterByPermissions(permitMenuItems, allowedModules, isAdmin);
  const visibleLogisticsItems = filterByPermissions(logisticsMenuItems, allowedModules, isAdmin);

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="h-16 flex items-center justify-center px-2 border-b border-sidebar-border shrink-0">
        <div className="flex items-center gap-3 w-full">
          <button
            onClick={onToggle}
            className="p-2 rounded-lg hover:bg-sidebar-accent transition-colors shrink-0"
          >
            {isCollapsed ? <PanelLeft className="h-5 w-5" /> : <PanelLeftClose className="h-5 w-5" />}
          </button>
          {!isCollapsed && (
            <div className="flex items-center gap-2 min-w-0 flex-1">
              <img
                src="/manus-storage/faidal-logo-dark_dd1a219c.png"
                alt="Faidal Alqadhi"
                className="h-9 w-9 object-contain shrink-0"
              />
              <div className="flex flex-col gap-0.5 min-w-0">
                <span className="font-bold text-sm text-sidebar-foreground truncate">Faidal Alqadhi</span>
                <span className="text-[10px] text-sidebar-foreground/60 leading-none truncate">التخليص الجمركي</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Menu items */}
      <div className="flex-1 overflow-y-auto py-2">
        <nav className="space-y-0.5 px-2">
          {visibleMainItems.map(item => {
            const isActive = location === item.path;
            return (
              <button
                key={item.path}
                onClick={() => setLocation(item.path)}
                className={`w-full flex items-center gap-3 rounded-md px-3 py-2.5 text-sm transition-all ${
                  isActive
                    ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
                    : "text-sidebar-foreground/80 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                } ${isCollapsed ? "justify-center" : ""}`}
                title={isCollapsed ? item.label : undefined}
              >
                <item.icon className="h-4 w-4 shrink-0" />
                {!isCollapsed && <span className="truncate">{item.label}</span>}
              </button>
            );
          })}
        </nav>

        {/* Customs section */}
        {!isCollapsed && (
          <div className="px-4 py-3 mt-2">
            <span className="text-xs font-semibold text-sidebar-foreground/50">التخليص الجمركي</span>
          </div>
        )}
        <nav className="space-y-0.5 px-2">
          {visibleCustomsItems.map(item => {
            const isActive = location === item.path;
            return (
              <button
                key={item.path}
                onClick={() => setLocation(item.path)}
                className={`w-full flex items-center gap-3 rounded-md px-3 py-2.5 text-sm transition-all ${
                  isActive
                    ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
                    : "text-sidebar-foreground/80 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                } ${isCollapsed ? "justify-center" : ""}`}
                title={isCollapsed ? item.label : undefined}
              >
                <item.icon className="h-4 w-4 shrink-0" />
                {!isCollapsed && <span className="truncate">{item.label}</span>}
              </button>
            );
                    })}
        </nav>

        {/* Permits & Deductions section */}
        {!isCollapsed && (
          <div className="px-4 py-3 mt-2">
            <span className="text-xs font-semibold text-sidebar-foreground/50">التراخيص والتخصيم</span>
          </div>
        )}
        <nav className="space-y-0.5 px-2">
          {visiblePermitItems.map(item => {
            const isActive = location === item.path;
            return (
              <button
                key={item.path}
                onClick={() => setLocation(item.path)}
                className={`w-full flex items-center gap-3 rounded-md px-3 py-2.5 text-sm transition-all ${
                  isActive
                    ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
                    : "text-sidebar-foreground/80 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                } ${isCollapsed ? "justify-center" : ""}`}
                title={isCollapsed ? item.label : undefined}
              >
                <item.icon className="h-4 w-4 shrink-0" />
                {!isCollapsed && <span className="truncate">{item.label}</span>}
              </button>
            );
                    })}
        </nav>

        {/* Logistics section */}
        {!isCollapsed && (
          <div className="px-4 py-3 mt-2">
            <span className="text-xs font-semibold text-sidebar-foreground/50">الخدمات اللوجستية</span>
          </div>
        )}
        <nav className="space-y-0.5 px-2">
          {visibleLogisticsItems.map(item => {
            const isActive = location === item.path;
            return (
              <button
                key={item.path}
                onClick={() => setLocation(item.path)}
                className={`w-full flex items-center gap-3 rounded-md px-3 py-2.5 text-sm transition-all ${
                  isActive
                    ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
                    : "text-sidebar-foreground/80 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                } ${isCollapsed ? "justify-center" : ""}`}
                title={isCollapsed ? item.label : undefined}
              >
                <item.icon className="h-4 w-4 shrink-0" />
                {!isCollapsed && <span className="truncate">{item.label}</span>}
              </button>
            );
          })}
        </nav>
      </div>
      {/* Footer */}
      <div className="border-t border-sidebar-border p-3 shrink-0">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex items-center gap-3 rounded-lg px-1 py-1 hover:bg-sidebar-accent/50 transition-colors w-full text-left group-data-[collapsible=icon]:justify-center">
              <Avatar className="h-9 w-9 border shrink-0">
                <AvatarFallback className="text-xs font-medium">
                  {user?.name?.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              {!isCollapsed && (
                <div className="flex-1 min-w-0 flex flex-col gap-1.5">
                  <p className="text-sm font-medium truncate leading-none">
                    {user?.name || "-"}
                  </p>
                  <FinancialAccessBadge
                    level={financialLevel}
                    title={financialTitle}
                  />
                  <p className="text-xs text-sidebar-foreground/60 truncate leading-none">
                    {user?.email || "-"}
                  </p>
                </div>
              )}
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <DropdownMenuItem
              onClick={logout}
              className="cursor-pointer text-destructive focus:text-destructive"
            >
              <LogOut className="mr-2 h-4 w-4" />
              <span>تسجيل الخروج</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}
