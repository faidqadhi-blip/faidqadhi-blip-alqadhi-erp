import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Loader2, Plus, Search, Trash2, History, Calculator, AlertTriangle, CheckCircle2, XCircle, BarChart3, Download } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend } from 'recharts';
import * as XLSX from 'xlsx';

export default function Permits() {
  const utils = trpc.useUtils();
  const [open, setOpen] = useState(false);
  const [deductOpen, setDeductOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedPermit, setSelectedPermit] = useState<any>(null);
  
  const [form, setForm] = useState({
    permitNumber: "",
    date: new Date().toISOString().split("T")[0],
    authority: "",
    totalQuantity: "",
    notes: "",
  });

  const [deductForm, setDeductForm] = useState({
    permitId: 0,
    declarationNumber: "",
    declarationDate: new Date().toISOString().split("T")[0],
    deductedQuantity: "",
    date: new Date().toISOString().split("T")[0],
    notes: "",
  });

  const { data: permits, isLoading } = trpc.permits.list.useQuery();
  const { data: deductions } = trpc.permitDeductions.list.useQuery(
    selectedPermit ? { permitId: selectedPermit.id } : undefined,
    { enabled: !!selectedPermit }
  );
  const { data: reportData } = trpc.permits.getReport.useQuery();

  const createMutation = trpc.permits.create.useMutation({
    onSuccess: () => {
      utils.permits.list.invalidate();
      utils.permits.getReport.invalidate();
      setOpen(false);
      setForm({
        permitNumber: "",
        date: new Date().toISOString().split("T")[0],
        authority: "",
        totalQuantity: "",
        notes: "",
      });
      toast.success("تم إضافة الترخيص بنجاح");
    },
    onError: (e) => toast.error(e.message),
  });

  const deductMutation = trpc.permitDeductions.create.useMutation({
    onSuccess: () => {
      utils.permits.list.invalidate();
      utils.permits.getReport.invalidate();
      utils.permitDeductions.list.invalidate();
      setDeductOpen(false);
      setDeductForm({
        permitId: 0,
        declarationNumber: "",
        declarationDate: new Date().toISOString().split("T")[0],
        deductedQuantity: "",
        date: new Date().toISOString().split("T")[0],
        notes: "",
      });
      toast.success("تم تخصيم الكمية بنجاح");
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = trpc.permits.delete.useMutation({
    onSuccess: () => {
      utils.permits.list.invalidate();
      utils.permits.getReport.invalidate();
      toast.success("تم حذف الترخيص");
    },
    onError: (e) => toast.error(e.message),
  });

  const filteredPermits = permits?.filter(p =>
    p.permitNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (p.authority || "").toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  const handleCreatePermit = () => {
    if (!form.permitNumber || !form.totalQuantity) {
      toast.error("يرجى ملء الحقول المطلوبة");
      return;
    }
    createMutation.mutate(form);
  };

  const handleDeduct = () => {
    if (!deductForm.permitId || !deductForm.deductedQuantity || !deductForm.declarationNumber) {
      toast.error("يرجى ملء الحقول المطلوبة (رقم البيان والكمية)");
      return;
    }
    deductMutation.mutate(deductForm);
  };

  const exportToExcel = () => {
    if (!permits) return;
    const data = permits.map(p => ({
      "رقم الترخيص": p.permitNumber,
      "الجهة": p.authority,
      "الكمية الكلية": Number(p.totalQuantity),
      "الكمية المتبقية": Number(p.remainingQuantity),
      "التاريخ": p.date,
      "ملاحظات": p.notes || ""
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "التراخيص");
    XLSX.writeFile(wb, `تقرير_التراخيص_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  const authorities = ["الزراعة", "التجارة والصناعة", "الأمن", "المواصفات", "الهيئة العليا للأدوية", "أخرى"];
  
  const chartData = reportData ? [
    { name: 'نشطة', value: reportData.stats.activeCount, color: '#10b981' },
    { name: 'وشيكة الانتهاء', value: reportData.stats.nearExpiryCount, color: '#f59e0b' },
    { name: 'منتهية', value: reportData.stats.expiredCount, color: '#ef4444' },
  ] : [];

  return (
    <div className="space-y-6 pb-20 md:pb-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">نظام التراخيص</h2>
          <p className="text-sm text-muted-foreground mt-1">إدارة التراخيص، التخصيم، والتقارير التحليلية</p>
        </div>
        <div className="flex gap-2 w-full md:w-auto">
          <Button variant="outline" onClick={exportToExcel} className="flex-1 md:flex-none h-12 md:h-10 gap-2">
            <Download className="h-4 w-4" /> تصدير إكسل
          </Button>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="flex-1 md:flex-none h-12 md:h-10 gap-2"><Plus className="h-4 w-4" /> ترخيص جديد</Button>
            </DialogTrigger>
            <DialogContent className="max-w-md w-[95vw] rounded-xl">
              <DialogHeader><DialogTitle>إضافة ترخيص جديد</DialogTitle></DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label className="font-bold">رقم الترخيص *</Label>
                  <Input value={form.permitNumber} onChange={(e) => setForm(p => ({ ...p, permitNumber: e.target.value }))} placeholder="أدخل رقم الترخيص" className="h-12" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="font-bold">تاريخ الترخيص</Label>
                    <Input type="date" value={form.date} onChange={(e) => setForm(p => ({ ...p, date: e.target.value }))} className="h-12" />
                  </div>
                  <div className="space-y-2">
                    <Label className="font-bold">الجهة</Label>
                    <Select value={form.authority} onValueChange={(v) => setForm(p => ({ ...p, authority: v }))}>
                      <SelectTrigger className="h-12"><SelectValue placeholder="اختر الجهة" /></SelectTrigger>
                      <SelectContent>
                        {authorities.map(a => <SelectItem key={a} value={a}>{a}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">الكمية الكلية *</Label>
                  <Input type="number" value={form.totalQuantity} onChange={(e) => setForm(p => ({ ...p, totalQuantity: e.target.value }))} placeholder="0.00" className="h-12" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">ملاحظات</Label>
                  <Input value={form.notes} onChange={(e) => setForm(p => ({ ...p, notes: e.target.value }))} className="h-12" />
                </div>
                <Button onClick={handleCreatePermit} className="w-full h-12 font-bold" disabled={createMutation.isPending}>حفظ الترخيص</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="management" className="space-y-6">
        <TabsList className="bg-muted/50 p-1">
          <TabsTrigger value="management" className="gap-2">إدارة التراخيص</TabsTrigger>
          <TabsTrigger value="reports" className="gap-2"><BarChart3 className="h-4 w-4" /> التقارير والتنبيهات</TabsTrigger>
        </TabsList>

        <TabsContent value="management">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2 overflow-hidden shadow-sm border-gray-200">
              <CardHeader className="bg-gray-50/50 border-b border-gray-100 p-4">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <CardTitle className="text-lg font-bold">قائمة التراخيص</CardTitle>
                  <div className="relative w-full md:w-64">
                    <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input placeholder="بحث..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pr-9 h-10 md:h-9" />
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                {isLoading ? (
                  <div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
                ) : filteredPermits.length === 0 ? (
                  <div className="text-center py-12 text-muted-foreground">لا توجد تراخيص مسجلة</div>
                ) : (
                  <>
                    {/* Desktop View */}
                    <div className="hidden md:block overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>رقم الترخيص</TableHead>
                            <TableHead>الجهة</TableHead>
                            <TableHead>الكمية الكلية</TableHead>
                            <TableHead>المتبقي</TableHead>
                            <TableHead>الحالة</TableHead>
                            <TableHead>إجراءات</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredPermits.map(p => {
                            const remaining = Number(p.remainingQuantity);
                            const total = Number(p.totalQuantity);
                            const isExpired = remaining <= 0;
                            const isNearExpiry = !isExpired && (remaining / total) <= 0.1;
                            
                            return (
                              <TableRow 
                                key={p.id} 
                                className={`cursor-pointer hover:bg-muted/50 transition-colors ${selectedPermit?.id === p.id ? 'bg-muted' : ''}`}
                                onClick={() => setSelectedPermit(p)}
                              >
                                <TableCell className="font-bold text-primary">{p.permitNumber}</TableCell>
                                <TableCell><Badge variant="outline" className="rounded-lg">{p.authority}</Badge></TableCell>
                                <TableCell className="font-mono">{total.toLocaleString('en-US')}</TableCell>
                                <TableCell className={`font-black font-mono ${isExpired ? 'text-red-600' : isNearExpiry ? 'text-amber-600' : 'text-green-600'}`}>
                                  {remaining.toLocaleString('en-US')}
                                </TableCell>
                                <TableCell>
                                  {isExpired ? (
                                    <Badge variant="destructive" className="gap-1 rounded-lg"><XCircle className="h-3 w-3" /> منتهي</Badge>
                                  ) : isNearExpiry ? (
                                    <Badge variant="secondary" className="bg-amber-100 text-amber-700 hover:bg-amber-100 gap-1 rounded-lg"><AlertTriangle className="h-3 w-3" /> وشيك</Badge>
                                  ) : (
                                    <Badge variant="secondary" className="bg-green-100 text-green-700 hover:bg-green-100 gap-1 rounded-lg"><CheckCircle2 className="h-3 w-3" /> نشط</Badge>
                                  )}
                                </TableCell>
                                <TableCell className="flex gap-1" onClick={e => e.stopPropagation()}>
                                  <Button variant="ghost" size="sm" onClick={() => {
                                    setSelectedPermit(p);
                                    setDeductForm(prev => ({ ...prev, permitId: p.id }));
                                    setDeductOpen(true);
                                  }} title="تخصيم كمية" disabled={isExpired}>
                                    <Calculator className="h-4 w-4 text-blue-600" />
                                  </Button>
                                  <Button variant="ghost" size="sm" onClick={() => { if(confirm("حذف الترخيص؟")) deleteMutation.mutate(p.id); }}>
                                    <Trash2 className="h-4 w-4 text-destructive" />
                                  </Button>
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </div>

                    {/* Mobile View */}
                    <div className="md:hidden divide-y divide-gray-100 bg-gray-50/30">
                      {filteredPermits.map(p => {
                        const remaining = Number(p.remainingQuantity);
                        const total = Number(p.totalQuantity);
                        const isExpired = remaining <= 0;
                        const isNearExpiry = !isExpired && (remaining / total) <= 0.1;
                        
                        return (
                          <div 
                            key={p.id} 
                            className={`p-4 space-y-3 bg-white active:bg-gray-50 transition-colors ${selectedPermit?.id === p.id ? 'border-r-4 border-primary' : ''}`}
                            onClick={() => setSelectedPermit(p)}
                          >
                            <div className="flex justify-between items-start">
                              <div>
                                <div className="text-[10px] text-muted-foreground font-bold uppercase">رقم الترخيص</div>
                                <div className="font-bold text-primary">{p.permitNumber}</div>
                              </div>
                              {isExpired ? (
                                <Badge variant="destructive" className="rounded-lg">منتهي</Badge>
                              ) : isNearExpiry ? (
                                <Badge variant="secondary" className="bg-amber-100 text-amber-700 rounded-lg">وشيك</Badge>
                              ) : (
                                <Badge variant="secondary" className="bg-green-100 text-green-700 rounded-lg">نشط</Badge>
                              )}
                            </div>
                            <div className="grid grid-cols-2 gap-3 text-sm">
                              <div>
                                <div className="text-[10px] text-muted-foreground">الجهة</div>
                                <div className="font-medium">{p.authority}</div>
                              </div>
                              <div>
                                <div className="text-[10px] text-muted-foreground">المتبقي</div>
                                <div className={`font-black font-mono ${isExpired ? 'text-red-600' : isNearExpiry ? 'text-amber-600' : 'text-green-600'}`}>
                                  {remaining.toLocaleString('en-US')}
                                </div>
                              </div>
                            </div>
                            <div className="flex gap-2 pt-2 border-t border-gray-50">
                              <Button variant="outline" size="sm" className="flex-1 h-10 gap-2 text-blue-600" onClick={(e) => {
                                e.stopPropagation();
                                setSelectedPermit(p);
                                setDeductForm(prev => ({ ...prev, permitId: p.id }));
                                setDeductOpen(true);
                              }} disabled={isExpired}>
                                <Calculator className="h-4 w-4" /> تخصيم
                              </Button>
                              <Button variant="outline" size="sm" className="h-10 text-destructive" onClick={(e) => {
                                e.stopPropagation();
                                if(confirm("حذف الترخيص؟")) deleteMutation.mutate(p.id);
                              }}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2 font-bold">
                  <History className="h-5 w-5 text-blue-600" />
                  سجل التخصيم
                </CardTitle>
              </CardHeader>
              <CardContent>
                {!selectedPermit ? (
                  <div className="text-center py-12 text-muted-foreground">اختر ترخيصاً لعرض سجل التخصيم</div>
                ) : (
                  <div className="space-y-4">
                    <div className="p-3 bg-blue-50 rounded-lg border border-blue-100">
                      <p className="text-xs text-blue-600 font-bold mb-1">الترخيص المختار:</p>
                      <p className="text-sm font-bold">{selectedPermit.permitNumber} - {selectedPermit.authority}</p>
                      <div className="flex justify-between mt-2 text-xs">
                        <span>الكلية: {Number(selectedPermit.totalQuantity).toLocaleString('en-US')}</span>
                        <span className="text-blue-700 font-bold">المتبقي: {Number(selectedPermit.remainingQuantity).toLocaleString('en-US')}</span>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      {deductions?.map((d: any) => (
                        <div key={d.id} className="text-sm p-3 border rounded-lg space-y-1 bg-card shadow-sm">
                          <div className="flex justify-between font-bold">
                            <span>مخصم: {Number(d.deductedQuantity).toLocaleString('en-US')}</span>
                            <span className="text-xs text-muted-foreground">{d.date}</span>
                          </div>
                          <div className="flex justify-between text-xs text-muted-foreground">
                            <span>بيان: {d.declarationNumber || "-"}</span>
                            <span>تاريخ: {d.declarationDate || "-"}</span>
                          </div>
                          <p className="text-xs text-muted-foreground">المتبقي بعد التخصيم: {Number(d.remainingQuantity).toLocaleString('en-US')}</p>
                          {d.notes && <p className="text-xs italic">{d.notes}</p>}
                        </div>
                      ))}
                      {deductions?.length === 0 && <p className="text-center py-4 text-xs text-muted-foreground">لا توجد عمليات تخصيم بعد</p>}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="reports">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="md:col-span-1">
              <CardHeader><CardTitle className="text-lg font-bold">توزيع حالات التراخيص</CardTitle></CardHeader>
              <CardContent className="h-[300px]">
                {reportData ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={chartData}
                        cx="50%" cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {chartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <RechartsTooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-full"><Loader2 className="h-6 w-6 animate-spin" /></div>
                )}
              </CardContent>
            </Card>

            <div className="md:col-span-2 space-y-6">
              <div className="grid grid-cols-3 gap-4">
                <Card className="bg-red-50 border-red-100">
                  <CardContent className="p-4 text-center">
                    <p className="text-xs text-red-600 font-bold mb-1">منتهية</p>
                    <p className="text-2xl font-bold text-red-700">{reportData?.stats.expiredCount || 0}</p>
                  </CardContent>
                </Card>
                <Card className="bg-amber-50 border-amber-100">
                  <CardContent className="p-4 text-center">
                    <p className="text-xs text-amber-600 font-bold mb-1">وشيكة الانتهاء</p>
                    <p className="text-2xl font-bold text-amber-700">{reportData?.stats.nearExpiryCount || 0}</p>
                  </CardContent>
                </Card>
                <Card className="bg-green-50 border-green-100">
                  <CardContent className="p-4 text-center">
                    <p className="text-xs text-green-600 font-bold mb-1">نشطة</p>
                    <p className="text-2xl font-bold text-green-700">{reportData?.stats.activeCount || 0}</p>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader><CardTitle className="text-lg font-bold text-red-600 flex items-center gap-2"><AlertTriangle className="h-5 w-5" /> تنبيهات الحالات الحرجة</CardTitle></CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {reportData?.expired.map(p => (
                      <div key={p.id} className="flex items-center justify-between p-3 border border-red-200 bg-red-50/50 rounded-lg">
                        <div>
                          <p className="font-bold text-sm">{p.permitNumber} - {p.authority}</p>
                          <p className="text-xs text-red-600">الكمية منتهية بالكامل (0 متبقي)</p>
                        </div>
                        <Badge variant="destructive">منتهي</Badge>
                      </div>
                    ))}
                    {reportData?.nearExpiry.map(p => (
                      <div key={p.id} className="flex items-center justify-between p-3 border border-amber-200 bg-amber-50/50 rounded-lg">
                        <div>
                          <p className="font-bold text-sm">{p.permitNumber} - {p.authority}</p>
                          <p className="text-xs text-amber-600">المتبقي: {Number(p.remainingQuantity).toLocaleString('en-US')} (أقل من 10%)</p>
                        </div>
                        <Badge variant="secondary" className="bg-amber-100 text-amber-700">وشيك</Badge>
                      </div>
                    ))}
                    {reportData?.expired.length === 0 && reportData?.nearExpiry.length === 0 && (
                      <div className="text-center py-8 text-muted-foreground">لا توجد تنبيهات حرجة حالياً</div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* Deduct Dialog */}
      <Dialog open={deductOpen} onOpenChange={setDeductOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>تخصيم من الترخيص</DialogTitle></DialogHeader>
          <div className="space-y-4 pt-4">
            <div className="p-3 bg-muted rounded-lg text-sm">
              <p><strong>رقم الترخيص:</strong> {selectedPermit?.permitNumber}</p>
              <p><strong>الكمية المتبقية الحالية:</strong> {Number(selectedPermit?.remainingQuantity).toLocaleString('en-US')}</p>
            </div>
            <div className="space-y-2">
              <Label>رقم البيان الجمركي *</Label>
              <Input 
                value={deductForm.declarationNumber} 
                onChange={(e) => setDeductForm(p => ({ ...p, declarationNumber: e.target.value }))} 
                placeholder="أدخل رقم البيان الجمركي" 
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>تاريخ البيان</Label>
                <Input 
                  type="date" 
                  value={deductForm.declarationDate} 
                  onChange={(e) => setDeductForm(p => ({ ...p, declarationDate: e.target.value }))} 
                />
              </div>
              <div className="space-y-2">
                <Label>الكمية المخصمة *</Label>
                <Input type="number" value={deductForm.deductedQuantity} onChange={(e) => setDeductForm(p => ({ ...p, deductedQuantity: e.target.value }))} placeholder="0.00" />
              </div>
              <div className="space-y-2">
                <Label>تاريخ التخصيم</Label>
                <Input type="date" value={deductForm.date} onChange={(e) => setDeductForm(p => ({ ...p, date: e.target.value }))} />
              </div>
            </div>
            <div className="space-y-2">
              <Label>ملاحظات</Label>
              <Input value={deductForm.notes} onChange={(e) => setDeductForm(p => ({ ...p, notes: e.target.value }))} />
            </div>
            <Button onClick={handleDeduct} className="w-full" disabled={deductMutation.isPending}>تأكيد التخصيم</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
