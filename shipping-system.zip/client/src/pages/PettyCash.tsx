import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Plus, Search, X, HandCoins, Pencil, Trash2, User, Wallet, Info, CheckCircle2, Clock } from "lucide-react";

type CustodyType = "سلفة" | "عهدة" | "مصروفات مقدمة";
type CustodyStatus = "معلّقة" | "مسدّدة" | "ملغاة" | "جزئية";
type PaymentType = "نقداً" | "آجل" | "حوالة";

export default function PettyCash() {
  const utils = trpc.useUtils();
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState({
    employeeName: "", type: "سلفة" as CustodyType, amount: "0", currency: "YER",
    cashboxId: 0, purpose: "", paymentType: "نقداً" as PaymentType,
    status: "معلّقة" as CustodyStatus, repaidAmount: "0", notes: "",
  });

  const { data: records, isLoading } = trpc.custody.list.useQuery();
  const { data: employees } = trpc.employees.list.useQuery();
  const { data: cashboxes } = trpc.cashboxes.list.useQuery();

  const filtered = useMemo(() => {
    if (!records) return [];
    if (!search.trim()) return records;
    const q = search.trim().toLowerCase();
    return records.filter(r =>
      r.purpose?.toLowerCase().includes(q) ||
      r.purpose?.includes(q)
    );
  }, [records, search]);

  const createMutation = trpc.custody.create.useMutation({
    onSuccess: () => {
      toast.success("تم تسجيل السلفة بنجاح");
      utils.custody.list.invalidate();
      setDialogOpen(false);
      resetForm();
    },
    onError: (e) => toast.error(e.message),
  });

  const updateMutation = trpc.custody.update.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث السلفة");
      utils.custody.list.invalidate();
      setDialogOpen(false);
      resetForm();
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = trpc.custody.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف السلفة");
      utils.custody.list.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  const resetForm = () => {
    setForm({
      employeeName: "", type: "سلفة", amount: "0", currency: "YER",
      cashboxId: 0, purpose: "", paymentType: "نقداً",
      status: "معلّقة", repaidAmount: "0", notes: "",
    });
    setEditingId(null);
  };

  const getEmployeeName = (id: number) => employees?.find(e => e.id === id)?.name || `موظف #${id}`;
  const getCashboxName = (id: number | null) => cashboxes?.find(c => c.id === id)?.name || "-";

  const openEdit = (r: NonNullable<typeof records>[number]) => {
    setForm({
      employeeName: getEmployeeName(r.employeeId),
      type: r.type as CustodyType,
      amount: r.amount.toString(),
      currency: r.currency || "YER",
      cashboxId: r.cashboxId || 0,
      purpose: r.purpose || "",
      paymentType: r.paymentType as PaymentType,
      status: r.status as CustodyStatus,
      repaidAmount: r.repaidAmount?.toString() || "0",
      notes: r.notes || "",
    });
    setEditingId(r.id);
    setDialogOpen(true);
  };

  const findEmployeeId = (): number => {
    const emp = employees?.find(e => e.name === form.employeeName);
    if (emp) return emp.id;
    const partial = employees?.find(e => e.name.includes(form.employeeName) || form.employeeName.includes(e.name));
    if (partial) return partial.id;
    return 0;
  };

  const handleSubmit = () => {
    if (!form.employeeName.trim()) { toast.error("اسم الموظف مطلوب"); return; }
    const empId = findEmployeeId();
    if (empId === 0) { toast.error("يجب اختيار موظف موجود في النظام"); return; }
    const amt = parseFloat(form.amount) || 0;
    if (amt <= 0) { toast.error("المبلغ يجب أن يكون أكبر من صفر"); return; }
    const data = {
      employeeId: empId,
      type: form.type,
      amount: amt,
      currency: form.currency,
      cashboxId: form.cashboxId > 0 ? form.cashboxId : undefined,
      purpose: form.purpose || undefined,
      paymentType: form.paymentType,
      status: form.status,
      repaidAmount: parseFloat(form.repaidAmount) || 0,
      notes: form.notes || undefined,
    };
    if (editingId) {
      updateMutation.mutate({ id: editingId, ...data });
    } else {
      createMutation.mutate(data);
    }
  };

  const totalPending = records?.filter(r => r.status === "معلّقة" || r.status === "جزئية").reduce((sum, r) => sum + parseFloat(r.amount.toString()), 0) || 0;

  return (
    <div className="space-y-4 pb-20 md:pb-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 px-1">
        <div>
          <h1 className="text-2xl font-bold text-foreground">العهد والسلف</h1>
          <p className="text-sm text-muted-foreground mt-1">إدارة العهد والسلف المالية للموظفين</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={(o) => { setDialogOpen(o); if (!o) resetForm(); }}>
          <DialogTrigger asChild>
            <Button className="w-full md:w-auto h-12 md:h-10 font-bold text-base">
              <Plus className="h-5 w-5 ml-2" /> إضافة سجل جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg p-0 gap-0 overflow-hidden">
            <DialogHeader className="p-6 pb-2">
              <DialogTitle className="text-xl">{editingId ? "تعديل سجل العهدة" : "إضافة سجل جديد"}</DialogTitle>
            </DialogHeader>
            <div className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="col-span-1 md:col-span-2 space-y-2">
                  <Label className="font-bold">اسم الموظف *</Label>
                  <Input 
                    value={form.employeeName} 
                    onChange={e => setForm(f => ({ ...f, employeeName: e.target.value }))} 
                    className="h-12 md:h-10"
                    placeholder="ابحث عن اسم الموظف..." 
                  />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">النوع</Label>
                  <Select value={form.type} onValueChange={v => setForm(f => ({ ...f, type: v as CustodyType }))}>
                    <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="سلفة" className="text-right">سلفة</SelectItem>
                      <SelectItem value="عهدة" className="text-right">عهدة</SelectItem>
                      <SelectItem value="مصروفات مقدمة" className="text-right">مصروفات مقدمة</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">المبلغ *</Label>
                  <Input 
                    type="number" 
                    value={form.amount} 
                    onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} 
                    className="h-12 md:h-10 text-left font-mono font-bold"
                    placeholder="0" 
                  />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">العملة</Label>
                  <Input 
                    value={form.currency} 
                    onChange={e => setForm(f => ({ ...f, currency: e.target.value }))} 
                    className="h-12 md:h-10"
                    placeholder="YER" 
                  />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">نوع الدفع</Label>
                  <Select value={form.paymentType} onValueChange={v => setForm(f => ({ ...f, paymentType: v as PaymentType }))}>
                    <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="نقداً" className="text-right">نقداً</SelectItem>
                      <SelectItem value="آجل" className="text-right">آجل</SelectItem>
                      <SelectItem value="حوالة" className="text-right">حوالة</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="col-span-1 md:col-span-2 space-y-2">
                  <Label className="font-bold">الصندوق / البنك</Label>
                  <Select value={form.cashboxId > 0 ? form.cashboxId.toString() : "0"} onValueChange={v => setForm(f => ({ ...f, cashboxId: parseInt(v) }))}>
                    <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue placeholder="اختر الصندوق أو البنك" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0" className="text-right">بدون تحديد</SelectItem>
                      {cashboxes?.filter(c => c.isActive).map(c => (
                        <SelectItem key={c.id} value={c.id.toString()} className="text-right">{c.name} ({c.type})</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="col-span-1 md:col-span-2 space-y-2">
                  <Label className="font-bold">الغرض</Label>
                  <Input 
                    value={form.purpose} 
                    onChange={e => setForm(f => ({ ...f, purpose: e.target.value }))} 
                    className="h-12 md:h-10"
                    placeholder="السبب من صرف السلفة" 
                  />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">الحالة</Label>
                  <Select value={form.status} onValueChange={v => setForm(f => ({ ...f, status: v as CustodyStatus }))}>
                    <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="معلّقة" className="text-right">معلّقة</SelectItem>
                      <SelectItem value="جزئية" className="text-right">جزئية</SelectItem>
                      <SelectItem value="مسدّدة" className="text-right">مسدّدة</SelectItem>
                      <SelectItem value="ملغاة" className="text-right">ملغاة</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">المبلغ المسدّد</Label>
                  <Input 
                    type="number" 
                    value={form.repaidAmount} 
                    onChange={e => setForm(f => ({ ...f, repaidAmount: e.target.value }))} 
                    className="h-12 md:h-10 text-left font-mono"
                    placeholder="0" 
                  />
                </div>
                <div className="col-span-1 md:col-span-2 space-y-2">
                  <Label className="font-bold">ملاحظات</Label>
                  <Textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} placeholder="أي ملاحظات إضافية" rows={2} />
                </div>
              </div>
              <div className="flex flex-col md:flex-row justify-end gap-3 pt-4 border-t">
                <Button variant="outline" onClick={() => { setDialogOpen(false); resetForm(); }} className="h-12 md:h-10 font-bold">إلغاء</Button>
                <Button onClick={handleSubmit} disabled={createMutation.isPending || updateMutation.isPending} className="h-12 md:h-10 font-bold text-base">
                  {editingId ? "تحديث البيانات" : "حفظ السجل"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 px-1">
        <Card className="shadow-sm border-blue-100 bg-blue-50/30 col-span-2 md:col-span-1">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
              <HandCoins className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <p className="text-[10px] font-bold text-blue-700 uppercase">إجمالي السلف المعلّقة</p>
              <p className="text-lg font-bold text-blue-900" dir="ltr">{totalPending.toLocaleString('en-US')}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="shadow-sm border-amber-100 bg-amber-50/30">
          <CardContent className="p-4">
            <p className="text-[10px] font-bold text-amber-700 uppercase">سلف معلّقة</p>
            <p className="text-lg font-bold text-amber-900">{records?.filter(r => r.status === "معلّقة").length || 0}</p>
          </CardContent>
        </Card>
        <Card className="shadow-sm border-green-100 bg-green-50/30">
          <CardContent className="p-4">
            <p className="text-[10px] font-bold text-green-700 uppercase">سلف مسدّدة</p>
            <p className="text-lg font-bold text-green-900">{records?.filter(r => r.status === "مسدّدة").length || 0}</p>
          </CardContent>
        </Card>
      </div>

      <Card className="shadow-sm border-gray-200">
        <CardHeader className="p-4 pb-2">
          <div className="relative">
            <Search className="absolute right-3 top-3 h-5 w-5 text-gray-400" />
            <Input
              placeholder="ابحث بالغرض أو الملاحظات..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pr-10 h-12 md:h-10 w-full"
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex flex-col items-center py-12 gap-3">
              <div className="h-10 w-10 animate-spin rounded-full border-4 border-primary border-t-transparent" />
              <span className="text-muted-foreground">جاري تحميل السجلات...</span>
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-12 flex flex-col items-center gap-3">
              <HandCoins className="h-16 w-16 text-gray-200" />
              <p className="text-muted-foreground">{search ? "لا توجد نتائج مطابقة" : "لا يوجد سجلات سلف"}</p>
            </div>
          ) : (
            <>
              {/* Desktop Table */}
              <div className="hidden md:block">
                <Table>
                  <TableHeader className="bg-gray-50">
                    <TableRow>
                      <TableHead className="text-right font-bold">الموظف</TableHead>
                      <TableHead className="text-right font-bold">النوع</TableHead>
                      <TableHead className="text-right font-bold">المبلغ</TableHead>
                      <TableHead className="text-right font-bold">العملة</TableHead>
                      <TableHead className="text-right font-bold">نوع الدفع</TableHead>
                      <TableHead className="text-right font-bold">الصندوق</TableHead>
                      <TableHead className="text-right font-bold">الحالة</TableHead>
                      <TableHead className="text-left font-bold">الإجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filtered.map(r => (
                      <TableRow key={r.id} className="hover:bg-gray-50/50 transition-colors">
                        <TableCell className="font-bold text-primary">{getEmployeeName(r.employeeId)}</TableCell>
                        <TableCell className="text-xs">{r.type}</TableCell>
                        <TableCell className="text-sm font-mono font-bold" dir="ltr">{parseFloat(r.amount.toString()).toLocaleString('en-US')}</TableCell>
                        <TableCell className="text-xs">{r.currency}</TableCell>
                        <TableCell className="text-xs">{r.paymentType}</TableCell>
                        <TableCell className="text-xs">{getCashboxName(r.cashboxId)}</TableCell>
                        <TableCell>
                          <Badge variant={r.status === "مسدّدة" ? "default" : r.status === "معلّقة" ? "outline" : "secondary"} className="text-[10px] font-bold">
                            {r.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex justify-end gap-1">
                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(r)}>
                              <Pencil className="h-3.5 w-3.5" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500 hover:bg-red-50" onClick={() => {
                              if (confirm(`هل تريد حذف هذا السجل؟`)) deleteMutation.mutate({ id: r.id });
                            }}>
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Mobile Card List */}
              <div className="md:hidden space-y-0 divide-y">
                {filtered.map(r => (
                  <div key={r.id} className="p-4 active:bg-gray-50 transition-colors">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex flex-col">
                        <h3 className="font-bold text-lg text-primary">{getEmployeeName(r.employeeId)}</h3>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-bold text-muted-foreground uppercase">{r.type}</span>
                          <Badge variant={r.status === "مسدّدة" ? "default" : r.status === "معلّقة" ? "outline" : "secondary"} className="text-[9px] py-0 h-4 font-bold">
                            {r.status}
                          </Badge>
                        </div>
                      </div>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" className="h-9 w-9 text-blue-600" onClick={() => openEdit(r)}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-9 w-9 text-red-500" onClick={() => {
                          if (confirm(`هل تريد حذف هذا السجل؟`)) deleteMutation.mutate({ id: r.id });
                        }}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3 mt-3">
                      <div className="flex items-center gap-2 text-sm text-blue-700 font-bold">
                        <HandCoins className="h-3.5 w-3.5 text-blue-500" />
                        <span dir="ltr">{parseFloat(r.amount.toString()).toLocaleString('en-US')} {r.currency}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Wallet className="h-3.5 w-3.5 text-gray-400" />
                        <span className="text-xs truncate">{getCashboxName(r.cashboxId)}</span>
                      </div>
                      <div className="flex items-start gap-2 text-sm text-gray-600 col-span-2">
                        <Info className="h-3.5 w-3.5 text-gray-400 mt-0.5" />
                        <span className="text-xs line-clamp-2">{r.purpose || "بدون غرض محدد"}</span>
                      </div>
                      <div className="flex items-center justify-between col-span-2 pt-2 text-[10px] text-muted-foreground border-t border-dashed">
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          <span>{r.createdAt ? new Date(r.createdAt).toLocaleDateString() : "-"}</span>
                        </div>
                        {parseFloat(r.repaidAmount?.toString() || "0") > 0 && (
                          <div className="flex items-center gap-1 text-green-600 font-bold">
                            <CheckCircle2 className="h-3 w-3" />
                            <span>مسدد: {parseFloat(r.repaidAmount?.toString() || "0").toLocaleString()}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
