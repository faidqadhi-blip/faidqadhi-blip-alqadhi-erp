import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Loader2, Plus, Trash2, BookOpen, Edit2, X, Search, ChevronDown, ChevronRight, Hash, Layers } from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";

interface AccountForm {
  code: string;
  name: string;
  type: string;
  parentId: string;
  balance: string;
  description: string;
}

const initialForm: AccountForm = {
  code: "", name: "", type: "أصول", parentId: "", balance: "0", description: "",
};

export default function GeneralLedger() {
  const utils = trpc.useUtils();
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [form, setForm] = useState<AccountForm>(initialForm);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [expandedIds, setExpandedIds] = useState<Set<number>>(new Set());

  const { data: accounts, isLoading } = trpc.accounts.list.useQuery();

  const filtered = useMemo(() => {
    if (!accounts) return [];
    if (!search.trim()) return accounts;
    const q = search.trim().toLowerCase();
    return accounts.filter(a => 
      a.name.toLowerCase().includes(q) || 
      a.code.includes(q)
    );
  }, [accounts, search]);

  const createMutation = trpc.accounts.create.useMutation({
    onSuccess: () => {
      utils.accounts.list.invalidate();
      setOpen(false);
      setForm(initialForm);
      setEditingId(null);
      toast.success("تم إنشاء الحساب بنجاح");
    },
    onError: (e) => toast.error(e.message),
  });

  const updateMutation = trpc.accounts.update.useMutation({
    onSuccess: () => {
      utils.accounts.list.invalidate();
      setOpen(false);
      setForm(initialForm);
      setEditingId(null);
      toast.success("تم تحديث الحساب");
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = trpc.accounts.delete.useMutation({
    onSuccess: () => {
      utils.accounts.list.invalidate();
      toast.success("تم حذف الحساب");
    },
    onError: (e) => toast.error(e.message),
  });

  const handleSubmit = () => {
    if (!form.code || !form.name) {
      toast.error("يرجى ملء رقم الحساب واسمه");
      return;
    }
    const payload = {
      code: form.code,
      name: form.name,
      type: form.type,
      parentId: form.parentId ? parseInt(form.parentId) : undefined,
      balance: form.balance,
      description: form.description || undefined,
    };
    if (editingId) {
      updateMutation.mutate({ id: editingId, ...payload });
    } else {
      createMutation.mutate(payload);
    }
  };

  const openEdit = (acc: NonNullable<typeof accounts>[number]) => {
    setForm({
      code: acc.code,
      name: acc.name,
      type: acc.type,
      parentId: acc.parentId ? String(acc.parentId) : "",
      balance: acc.balance ?? "0",
      description: acc.description || "",
    });
    setEditingId(acc.id);
    setOpen(true);
  };

  const toggleExpand = (id: number) => {
    const next = new Set(expandedIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setExpandedIds(next);
  };

  const typeColors: Record<string, string> = {
    "أصول": "bg-blue-500/10 text-blue-600 border-blue-200",
    "خصوم": "bg-red-500/10 text-red-600 border-red-200",
    "حقوق_ملكية": "bg-purple-500/10 text-purple-600 border-purple-200",
    "إيرادات": "bg-green-500/10 text-green-600 border-green-200",
    "مصروفات": "bg-orange-500/10 text-orange-600 border-orange-200",
  };

  const typeLabels: Record<string, string> = {
    "أصول": "أصول",
    "خصوم": "خصوم",
    "حقوق_ملكية": "حقوق ملكية",
    "إيرادات": "إيرادات",
    "مصروفات": "مصروفات",
  };

  const rootAccounts = useMemo(() => {
    if (search.trim()) return filtered;
    return accounts?.filter(a => !a.parentId) || [];
  }, [accounts, filtered, search]);

  return (
    <div className="space-y-4 pb-20 md:pb-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 px-1">
        <div>
          <h2 className="text-2xl font-bold text-foreground">دليل الحسابات</h2>
          <p className="text-sm text-muted-foreground mt-1">إدارة شجرة الحسابات والأستاذ العام</p>
        </div>
        <Dialog open={open} onOpenChange={(v) => { if (!v) { setForm(initialForm); setEditingId(null); } setOpen(v); }}>
          <DialogTrigger asChild>
            <Button className="w-full md:w-auto h-12 md:h-10 font-bold text-base gap-2">
              <Plus className="h-5 w-5" /> حساب جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg p-0 gap-0 overflow-hidden">
            <DialogHeader className="p-6 pb-2">
              <DialogTitle className="text-xl">{editingId ? "تعديل حساب محاسبي" : "إضافة حساب جديد"}</DialogTitle>
            </DialogHeader>
            <div className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="font-bold">رقم الحساب *</Label>
                  <Input value={form.code} onChange={(e) => setForm(p => ({ ...p, code: e.target.value }))} className="h-12 md:h-10 text-left font-mono" placeholder="مثلاً: 1001" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">اسم الحساب *</Label>
                  <Input value={form.name} onChange={(e) => setForm(p => ({ ...p, name: e.target.value }))} className="h-12 md:h-10" placeholder="اسم الحساب بالعربي" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">نوع الحساب *</Label>
                  <Select value={form.type} onValueChange={(v) => setForm(p => ({ ...p, type: v }))}>
                    <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="أصول" className="text-right">أصول</SelectItem>
                      <SelectItem value="خصوم" className="text-right">خصوم</SelectItem>
                      <SelectItem value="حقوق_ملكية" className="text-right">حقوق ملكية</SelectItem>
                      <SelectItem value="إيرادات" className="text-right">إيرادات</SelectItem>
                      <SelectItem value="مصروفات" className="text-right">مصروفات</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">الحساب الأب</Label>
                  <Select value={form.parentId} onValueChange={(v) => setForm(p => ({ ...p, parentId: v }))}>
                    <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue placeholder="حساب رئيسي (بدون أب)" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="" className="text-right">بدون (حساب رئيسي)</SelectItem>
                      {accounts?.filter(a => !a.parentId && a.id !== editingId).map(a => (
                        <SelectItem key={a.id} value={String(a.id)} className="text-right">{a.name} ({a.code})</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">الرصيد الافتتاحي</Label>
                  <Input type="number" value={form.balance} onChange={(e) => setForm(p => ({ ...p, balance: e.target.value }))} className="h-12 md:h-10 text-left font-mono" />
                </div>
                <div className="space-y-2 col-span-1 md:col-span-2">
                  <Label className="font-bold">الوصف</Label>
                  <Input value={form.description} onChange={(e) => setForm(p => ({ ...p, description: e.target.value }))} className="h-12 md:h-10" placeholder="وصف إضافي للحساب" />
                </div>
              </div>
              <div className="flex flex-col md:flex-row justify-end gap-3 pt-4 border-t">
                <Button variant="outline" onClick={() => setOpen(false)} className="h-12 md:h-10 font-bold">إلغاء</Button>
                <Button onClick={handleSubmit} className="h-12 md:h-10 font-bold text-base px-8" disabled={createMutation.isPending || updateMutation.isPending}>
                  {(createMutation.isPending || updateMutation.isPending) && <Loader2 className="h-4 w-4 animate-spin ml-2" />}
                  {editingId ? "حفظ التعديلات" : "إنشاء الحساب"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="shadow-sm border-gray-200">
        <CardHeader className="p-4 pb-2">
          <div className="relative">
            <Search className="absolute right-3 top-3 h-5 w-5 text-gray-400" />
            <Input
              placeholder="ابحث برقم أو اسم الحساب..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pr-10 h-12 md:h-10 w-full"
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex flex-col items-center py-12 gap-3">
              <Loader2 className="h-10 w-10 animate-spin text-primary" />
              <span className="text-muted-foreground">جاري تحميل دليل الحسابات...</span>
            </div>
          ) : rootAccounts.length === 0 ? (
            <div className="text-center py-12 flex flex-col items-center gap-3">
              <BookOpen className="h-16 w-16 text-gray-200" />
              <p className="text-muted-foreground">{search ? "لا توجد نتائج مطابقة" : "الدليل المحاسبي فارغ"}</p>
            </div>
          ) : (
            <>
              {/* Desktop Table */}
              <div className="hidden md:block overflow-x-auto">
                <Table>
                  <TableHeader className="bg-gray-50">
                    <TableRow>
                      <TableHead className="text-right font-bold w-32">الرقم</TableHead>
                      <TableHead className="text-right font-bold">اسم الحساب</TableHead>
                      <TableHead className="text-right font-bold w-32">النوع</TableHead>
                      <TableHead className="text-right font-bold w-40">الرصيد</TableHead>
                      <TableHead className="text-left font-bold w-24">الإجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {rootAccounts.map(acc => {
                      const children = accounts?.filter(a => a.parentId === acc.id) || [];
                      const isExpanded = expandedIds.has(acc.id);
                      return (
                        <div key={acc.id} className="contents">
                          <TableRow className="hover:bg-gray-50/50 transition-colors font-bold">
                            <TableCell className="font-mono">{acc.code}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                {children.length > 0 && (
                                  <Button variant="ghost" size="icon" className="h-6 w-6 p-0" onClick={() => toggleExpand(acc.id)}>
                                    {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                                  </Button>
                                )}
                                <span>{acc.name}</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className={`text-[10px] font-bold ${typeColors[acc.type] || ""}`}>
                                {typeLabels[acc.type] || acc.type}
                              </Badge>
                            </TableCell>
                            <TableCell className="font-mono text-blue-700" dir="ltr">{parseFloat(acc.balance || "0").toLocaleString()}</TableCell>
                            <TableCell>
                              <div className="flex justify-end gap-1">
                                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(acc)}>
                                  <Edit2 className="h-3.5 w-3.5" />
                                </Button>
                                <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500 hover:bg-red-50" onClick={() => { if (confirm("هل تريد حذف هذا الحساب؟")) deleteMutation.mutate({ id: acc.id }); }}>
                                  <Trash2 className="h-3.5 w-3.5" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                          {isExpanded && children.map(child => (
                            <TableRow key={child.id} className="bg-gray-50/30 text-sm italic">
                              <TableCell className="font-mono pr-8">{child.code}</TableCell>
                              <TableCell className="pr-12">{child.name}</TableCell>
                              <TableCell>
                                <Badge variant="outline" className={`text-[9px] font-bold ${typeColors[child.type] || ""}`}>
                                  {typeLabels[child.type] || child.type}
                                </Badge>
                              </TableCell>
                              <TableCell className="font-mono" dir="ltr">{parseFloat(child.balance || "0").toLocaleString()}</TableCell>
                              <TableCell>
                                <div className="flex justify-end gap-1">
                                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(child)}>
                                    <Edit2 className="h-3 w-3" />
                                  </Button>
                                  <Button variant="ghost" size="icon" className="h-7 w-7 text-red-500 hover:bg-red-50" onClick={() => { if (confirm("هل تريد حذف هذا الحساب؟")) deleteMutation.mutate({ id: child.id }); }}>
                                    <Trash2 className="h-3 w-3" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                        </div>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>

              {/* Mobile Card List */}
              <div className="md:hidden space-y-0 divide-y">
                {rootAccounts.map(acc => {
                  const children = accounts?.filter(a => a.parentId === acc.id) || [];
                  const isExpanded = expandedIds.has(acc.id);
                  return (
                    <div key={acc.id} className="bg-white">
                      <div className="p-4 active:bg-gray-50 transition-colors" onClick={() => children.length > 0 && toggleExpand(acc.id)}>
                        <div className="flex justify-between items-start mb-2">
                          <div className="flex flex-col">
                            <div className="flex items-center gap-2">
                              {children.length > 0 && (
                                <div className="text-primary">
                                  {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                                </div>
                              )}
                              <h3 className="font-bold text-base text-primary">{acc.name}</h3>
                            </div>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="text-[10px] font-mono font-bold text-muted-foreground">#{acc.code}</span>
                              <Badge variant="outline" className={`text-[9px] py-0 h-4 font-bold ${typeColors[acc.type] || ""}`}>
                                {typeLabels[acc.type] || acc.type}
                              </Badge>
                            </div>
                          </div>
                          <div className="flex gap-1" onClick={e => e.stopPropagation()}>
                            <Button variant="ghost" size="icon" className="h-9 w-9 text-blue-600" onClick={() => openEdit(acc)}>
                              <Edit2 className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-9 w-9 text-red-500" onClick={() => { if (confirm("هل تريد حذف هذا الحساب؟")) deleteMutation.mutate({ id: acc.id }); }}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        <div className="flex items-center justify-between mt-2">
                          <div className="text-sm font-bold text-blue-800" dir="ltr">
                            {parseFloat(acc.balance || "0").toLocaleString()} <span className="text-[10px] text-muted-foreground font-normal">رصيد</span>
                          </div>
                          {children.length > 0 && (
                            <span className="text-[10px] text-muted-foreground italic">
                              {children.length} حسابات فرعية
                            </span>
                          )}
                        </div>
                      </div>
                      
                      {isExpanded && children.length > 0 && (
                        <div className="bg-gray-50 border-t border-b divide-y">
                          {children.map(child => (
                            <div key={child.id} className="p-3 pr-8 flex justify-between items-center">
                              <div>
                                <div className="text-sm font-bold text-gray-700">{child.name}</div>
                                <div className="text-[9px] font-mono text-muted-foreground">#{child.code}</div>
                              </div>
                              <div className="flex items-center gap-3">
                                <div className="text-xs font-bold text-gray-600" dir="ltr">
                                  {parseFloat(child.balance || "0").toLocaleString()}
                                </div>
                                <div className="flex gap-0.5">
                                  <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-600" onClick={() => openEdit(child)}>
                                    <Edit2 className="h-3.5 w-3.5" />
                                  </Button>
                                  <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500" onClick={() => { if (confirm("هل تريد حذف هذا الحساب؟")) deleteMutation.mutate({ id: child.id }); }}>
                                    <Trash2 className="h-3.5 w-3.5" />
                                  </Button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
