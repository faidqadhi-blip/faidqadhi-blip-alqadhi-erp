import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { ArrowLeftRight, CheckCircle, Clock, Calendar, Info, ChevronRight } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useIsMobile } from "@/hooks/useMobile";

export default function Transfers() {
  const isMobile = useIsMobile();
  const [selectedShipments, setSelectedShipments] = useState<number[]>([]);
  const [selectedInvoices, setSelectedInvoices] = useState<number[]>([]);

  const { data: shipments, isLoading: loadingShipments, refetch: refetchShipments } = trpc.shipments.list.useQuery({
    status: "جديد",
  });
  const { data: invoices, isLoading: loadingInvoices, refetch: refetchInvoices } = trpc.invoices.list.useQuery();
  const { data: logs, refetch: refetchLogs } = trpc.transferLogs.list.useQuery();

  const transferShipments = trpc.entries.transferShipments.useMutation();
  const transferInvoices = trpc.sales.transferInvoices.useMutation();

  const toggleShipment = (id: number) => {
    setSelectedShipments(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const toggleInvoice = (id: number) => {
    setSelectedInvoices(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const handleTransferShipments = async () => {
    if (selectedShipments.length === 0) {
      toast.error("يرجى اختيار شحنات للترحيل");
      return;
    }
    try {
      const result = await transferShipments.mutateAsync({ shipmentIds: selectedShipments });
      toast.success(`تم ترحيل ${result.count} شحنة بنجاح`);
      setSelectedShipments([]);
      refetchShipments();
      refetchLogs();
    } catch {
      toast.error("حدث خطأ أثناء الترحيل");
    }
  };

  const handleTransferInvoices = async () => {
    if (selectedInvoices.length === 0) {
      toast.error("يرجى اختيار فواتير للترحيل");
      return;
    }
    try {
      const result = await transferInvoices.mutateAsync({ invoiceIds: selectedInvoices });
      toast.success(`تم ترحيل ${result.count} فاتورة إلى المبيعات`);
      setSelectedInvoices([]);
      refetchInvoices();
      refetchLogs();
    } catch {
      toast.error("حدث خطأ أثناء الترحيل");
    }
  };

  return (
    <div className="space-y-6 pb-20 md:pb-6" dir="rtl">
      <div className="px-1">
        <h1 className="text-2xl font-bold">نظام الترحيل</h1>
        <p className="text-sm text-muted-foreground mt-1">ترحيل الشحنات والفواتير مع سجل العمليات</p>
      </div>

      {/* Transfer Shipments */}
      <Card className="border-gray-200 shadow-sm overflow-hidden">
        <CardHeader className="bg-gray-50/50 p-4 border-b">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <CardTitle className="text-lg flex items-center gap-2">
              <ArrowLeftRight className="h-5 w-5 text-primary" />
              ترحيل الشحنات إلى المدخلات
            </CardTitle>
            <Button
              onClick={handleTransferShipments}
              disabled={selectedShipments.length === 0 || transferShipments.isPending}
              className="h-12 md:h-10 font-bold w-full md:w-auto"
            >
              <CheckCircle className="h-4 w-4 ml-2" />
              ترحيل المحدد ({selectedShipments.length})
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {loadingShipments ? (
            <div className="text-center py-16 text-muted-foreground">جاري التحميل...</div>
          ) : !shipments || shipments.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground bg-white">
              <Clock className="h-16 w-16 mx-auto mb-4 opacity-20" />
              <p className="text-lg">لا توجد شحنات جديدة للترحيل</p>
            </div>
          ) : isMobile ? (
            <div className="divide-y divide-gray-100">
              {shipments.map((sh: any) => (
                <div key={sh.id} className="p-4 bg-white flex items-start gap-3" onClick={() => toggleShipment(sh.id)}>
                  <Checkbox
                    checked={selectedShipments.includes(sh.id)}
                    onCheckedChange={() => toggleShipment(sh.id)}
                    className="mt-1"
                  />
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-1">
                      <span className="font-bold text-sm">شحنة #{sh.id}</span>
                      <span className="text-[10px] bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full">{sh.invoiceType.replace("_", " ")}</span>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="text-muted-foreground block">البضاعة</span>
                        <span className="font-medium">{sh.goodsType || "-"}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground block">المنفذ</span>
                        <span className="font-medium">{sh.customsPort || "-"}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-gray-50">
                  <TableRow>
                    <TableHead className="w-12"></TableHead>
                    <TableHead className="text-right font-bold">#</TableHead>
                    <TableHead className="text-right font-bold">النوع</TableHead>
                    <TableHead className="text-right font-bold">البضاعة</TableHead>
                    <TableHead className="text-right font-bold">المنفذ</TableHead>
                    <TableHead className="text-right font-bold">السائق</TableHead>
                    <TableHead className="text-right font-bold">تاريخ الدخول</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {shipments.map((sh: any) => (
                    <TableRow key={sh.id}>
                      <TableCell>
                        <Checkbox
                          checked={selectedShipments.includes(sh.id)}
                          onCheckedChange={() => toggleShipment(sh.id)}
                        />
                      </TableCell>
                      <TableCell className="font-medium">{sh.id}</TableCell>
                      <TableCell className="text-xs">{sh.invoiceType.replace("_", " ")}</TableCell>
                      <TableCell>{sh.goodsType || "-"}</TableCell>
                      <TableCell>{sh.customsPort || "-"}</TableCell>
                      <TableCell>{sh.driverName || "-"}</TableCell>
                      <TableCell>{sh.entryDate || "-"}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Transfer Invoices */}
      <Card className="border-gray-200 shadow-sm overflow-hidden">
        <CardHeader className="bg-gray-50/50 p-4 border-b">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <CardTitle className="text-lg flex items-center gap-2">
              <ArrowLeftRight className="h-5 w-5 text-emerald-600" />
              ترحيل الفواتير إلى تقرير المبيعات
            </CardTitle>
            <Button
              onClick={handleTransferInvoices}
              disabled={selectedInvoices.length === 0 || transferInvoices.isPending}
              variant="outline"
              className="h-12 md:h-10 font-bold w-full md:w-auto"
            >
              <CheckCircle className="h-4 w-4 ml-2" />
              ترحيل المحدد ({selectedInvoices.length})
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {loadingInvoices ? (
            <div className="text-center py-16 text-muted-foreground">جاري التحميل...</div>
          ) : !invoices || invoices.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground bg-white">
              <Info className="h-16 w-16 mx-auto mb-4 opacity-20" />
              <p className="text-lg">لا توجد فواتير للترحيل</p>
            </div>
          ) : isMobile ? (
            <div className="divide-y divide-gray-100">
              {invoices.map((inv: any) => (
                <div key={inv.id} className="p-4 bg-white flex items-start gap-3" onClick={() => toggleInvoice(inv.id)}>
                  <Checkbox
                    checked={selectedInvoices.includes(inv.id)}
                    onCheckedChange={() => toggleInvoice(inv.id)}
                    className="mt-1"
                  />
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-1">
                      <span className="font-bold text-sm">فاتورة #{inv.number}</span>
                      <span className="font-black text-green-600">{Number(inv.totalAmount || 0).toLocaleString('en-US')}</span>
                    </div>
                    <div className="flex justify-between items-center text-[10px] text-muted-foreground">
                      <span>{inv.invoiceType.replace("_", " ")}</span>
                      <span>{inv.date || "-"}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-gray-50">
                  <TableRow>
                    <TableHead className="w-12"></TableHead>
                    <TableHead className="text-right font-bold">رقم الفاتورة</TableHead>
                    <TableHead className="text-right font-bold">النوع</TableHead>
                    <TableHead className="text-right font-bold">المبلغ</TableHead>
                    <TableHead className="text-right font-bold">الحالة</TableHead>
                    <TableHead className="text-right font-bold">التاريخ</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {invoices.map((inv: any) => (
                    <TableRow key={inv.id}>
                      <TableCell>
                        <Checkbox
                          checked={selectedInvoices.includes(inv.id)}
                          onCheckedChange={() => toggleInvoice(inv.id)}
                        />
                      </TableCell>
                      <TableCell className="font-medium">{inv.number}</TableCell>
                      <TableCell className="text-xs">{inv.invoiceType.replace("_", " ")}</TableCell>
                      <TableCell>{Number(inv.totalAmount || 0).toLocaleString('en-US')} ر.س</TableCell>
                      <TableCell>{inv.status}</TableCell>
                      <TableCell>{inv.date || "-"}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Transfer Log */}
      <Card className="border-gray-200 shadow-sm overflow-hidden">
        <CardHeader className="bg-gray-50/50 p-4 border-b">
          <CardTitle className="text-lg">سجل العمليات</CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          {!logs || logs.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <p>لا توجد عمليات ترحيل سابقة</p>
            </div>
          ) : (
            <div className="space-y-3">
              {logs.map((log: any) => (
                <div key={log.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl border border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center text-green-600">
                      <CheckCircle className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="font-bold text-sm">{log.transferType}</p>
                      <p className="text-[10px] text-muted-foreground">
                        {log.recordCount} سجل | بواسطة: {log.performedBy || "-"}
                      </p>
                    </div>
                  </div>
                  <div className="text-left">
                    <span className="text-[10px] text-muted-foreground block">
                      {new Date(log.performedAt).toLocaleDateString('ar-SA')}
                    </span>
                    <span className="text-[10px] text-muted-foreground block">
                      {new Date(log.performedAt).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
