import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Download, Calculator, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { exportToExcel, exportToCSV } from "@/lib/export";

export default function ClearanceCosts() {
  const utils = trpc.useUtils();
  const [selectedDeclId, setSelectedDeclId] = useState<number | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);

  const [form, setForm] = useState({
    declarationFee: "", inspectionFee: "", penalties: "",
    weightDifferences: "", otherGovtFees: "", transport: "", fuel: "", driverCost: "",
    maintenance: "", otherExpenses: "", pettyCash: "",
    discount: "", notes: "",
  });

  const { data: declarations } = trpc.declarations.list.useQuery();
  const { data: costs } = trpc.clearanceCosts.list.useQuery(
    selectedDeclId ? { declarationId: selectedDeclId } : undefined,
    { enabled: !!selectedDeclId }
  );
  const { data: summary } = trpc.clearanceCosts.summary.useQuery(
    selectedDeclId ? { declarationId: selectedDeclId } : null as any,
    { enabled: !!selectedDeclId }
  );

  const { data: clients } = trpc.clients.list.useQuery();

  const createMutation = trpc.clearanceCosts.create.useMutation({
    onSuccess: () => {
      utils.clearanceCosts.list.invalidate();
      utils.clearanceCosts.summary.invalidate();
      toast.success("تم حفظ التكاليف بنجاح");
      resetForm();
    },
    onError: (e) => toast.error(e.message),
  });

  const updateMutation = trpc.clearanceCosts.update.useMutation({
    onSuccess: () => {
      utils.clearanceCosts.list.invalidate();
      utils.clearanceCosts.summary.invalidate();
      toast.success("تم تحديث التكاليف بنجاح");
      resetForm();
    },
    onError: (e) => toast.error(e.message),
  });

  const approveMutation = trpc.clearanceCosts.update.useMutation({
    onSuccess: () => {
      utils.clearanceCosts.list.invalidate();
      utils.clearanceCosts.summary.invalidate();
      toast.success("تم اعتماد التكلفة بنجاح");
    },
    onError: () => toast.error("فشل اعتماد التكلفة"),
  });

  const deleteMutation = trpc.clearanceCosts.delete.useMutation({
    onSuccess: () => {
      utils.clearanceCosts.list.invalidate();
      utils.clearanceCosts.summary.invalidate();
      toast.success("تم حذف التكاليف");
      resetForm();
    },
    onError: (e) => toast.error(e.message),
  });

  const resetForm = () => {
    setEditId(null);
    setIsEditing(false);
    setForm({
      declarationFee: "", inspectionFee: "", penalties: "",
      weightDifferences: "", otherGovtFees: "", transport: "", fuel: "", driverCost: "",
      maintenance: "", otherExpenses: "", pettyCash: "",
      discount: "", notes: "",
    });
  };

  const handleSave = () => {
    if (!selectedDeclId) {
      toast.error("يرجى اختيار البيان أولاً");
      return;
    }
    const totalCost = [form.declarationFee, form.inspectionFee, form.penalties, form.weightDifferences, form.otherGovtFees, form.transport, form.fuel, form.driverCost, form.maintenance, form.otherExpenses, form.pettyCash]
      .reduce((sum, v) => sum + (parseFloat(v) || 0), 0);
    const discount = parseFloat(form.discount) || 0;
    const netCost = totalCost - discount;

    if (editId) {
      updateMutation.mutate({ id: editId, ...form, totalCost: String(totalCost), netCost: String(netCost) });
    } else {
      createMutation.mutate({ declarationId: selectedDeclId, ...form, totalCost: String(totalCost), netCost: String(netCost) });
    }
  };

  const handleEdit = (cost: any) => {
    setEditId(cost.id);
    setIsEditing(true);
    setForm({
      declarationFee: String(cost.declarationFee || "0"),
      inspectionFee: String(cost.inspectionFee || "0"),
      penalties: String(cost.penalties || "0"),
      weightDifferences: String(cost.weightDifferences || "0"),
      otherGovtFees: String(cost.otherGovtFees || "0"),
      transport: String(cost.transport || "0"),
      fuel: String(cost.fuel || "0"),
      driverCost: String(cost.driverCost || "0"),
      maintenance: String(cost.maintenance || "0"),
      otherExpenses: String(cost.otherExpenses || "0"),
      pettyCash: String(cost.pettyCash || "0"),
      discount: String(cost.discount || "0"),
      notes: cost.notes || "",
    });
  };

  const selectedDecl = declarations?.find(d => d.id === selectedDeclId);
  const getClientName = (clientId: number | null) => {
    if (!clientId) return "-";
    const client = clients?.find(c => c.id === clientId);
    return client?.name || "-";
  };

  const costExportColumns = [
    { key: "declarationNumber", label: "رقم البيان" },
    { key: "clientName", label: "العميل" },
    { key: "declarationFee", label: "رسوم البيان" },
    { key: "inspectionFee", label: "معاينة" },
    { key: "penalties", label: "غرامات" },
    { key: "weightDifferences", label: "فوارق الوزن" },
    { key: "otherGovtFees", label: "حكومية أخرى" },
    { key: "transport", label: "نقل" },
    { key: "fuel", label: "وقود" },
    { key: "driverCost", label: "سائق" },
    { key: "maintenance", label: "صيانة" },
    { key: "otherExpenses", label: "مصاريف أخرى" },
    { key: "pettyCash", label: "نثريات" },
    { key: "totalCost", label: "الإجمالي" },
    { key: "discount", label: "خصم" },
    { key: "netCost", label: "صافي التكلفة" },
    { key: "status", label: "الحالة" },
  ];

  const handleExportCostsExcel = () => {
    if (!costs || costs.length === 0) {
      toast.warning("لا توجد تكاليف للتصدير");
      return;
    }
    const declNum = selectedDecl?.declarationNumber || "تكاليف";
    const exportData = costs.map(c => ({
      declarationNumber: declNum,
      clientName: getClientName(selectedDecl?.clientId ?? null),
      declarationFee: Number(c.declarationFee || 0).toLocaleString('en-US'),
      inspectionFee: Number(c.inspectionFee || 0).toLocaleString('en-US'),
      penalties: Number(c.penalties || 0).toLocaleString('en-US'),
      weightDifferences: Number(c.weightDifferences || 0).toLocaleString('en-US'),
      otherGovtFees: Number(c.otherGovtFees || 0).toLocaleString('en-US'),
      transport: Number(c.transport || 0).toLocaleString('en-US'),
      fuel: Number(c.fuel || 0).toLocaleString('en-US'),
      driverCost: Number(c.driverCost || 0).toLocaleString('en-US'),
      maintenance: Number(c.maintenance || 0).toLocaleString('en-US'),
      otherExpenses: Number(c.otherExpenses || 0).toLocaleString('en-US'),
      pettyCash: Number(c.pettyCash || 0).toLocaleString('en-US'),
      totalCost: Number(c.totalCost || 0).toLocaleString('en-US'),
      discount: Number(c.discount || 0).toLocaleString('en-US'),
      netCost: Number(c.netCost || 0).toLocaleString('en-US'),
      status: c.isApproved ? "معتمد" : "مسودة",
    }));
    exportToExcel(exportData, costExportColumns, `تكاليف_${declNum}_${new Date().toISOString().split('T')[0]}`);
    toast.success(`تم تصدير ${costs.length} سجل تكاليف إلى Excel`);
  };

  const CostForm = () => (
    <Card className="shadow-sm border-gray-200">
      <CardHeader className="p-4 border-b border-gray-100">
        <CardTitle className="text-lg font-bold">{isEditing ? "تعديل التكاليف" : "إدخال التكاليف"}</CardTitle>
      </CardHeader>
      <CardContent className="p-4 md:p-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="space-y-2">
            <Label className="font-bold">رسوم البيان</Label>
            <Input type="number" value={form.declarationFee} onChange={e => setForm({ ...form, declarationFee: e.target.value })} placeholder="0" className="h-12 font-mono" />
          </div>
          <div className="space-y-2">
            <Label className="font-bold">رسوم المعاينة</Label>
            <Input type="number" value={form.inspectionFee} onChange={e => setForm({ ...form, inspectionFee: e.target.value })} placeholder="0" className="h-12 font-mono" />
          </div>
          <div className="space-y-2">
            <Label className="font-bold">غرامات</Label>
            <Input type="number" value={form.penalties} onChange={e => setForm({ ...form, penalties: e.target.value })} placeholder="0" className="h-12 font-mono" />
          </div>
          <div className="space-y-2">
            <Label className="font-bold">فوارق الوزن</Label>
            <Input type="number" value={form.weightDifferences} onChange={e => setForm({ ...form, weightDifferences: e.target.value })} placeholder="0" className="h-12 font-mono" />
          </div>
          <div className="space-y-2">
            <Label className="font-bold">رسوم حكومية أخرى</Label>
            <Input type="number" value={form.otherGovtFees} onChange={e => setForm({ ...form, otherGovtFees: e.target.value })} placeholder="0" className="h-12 font-mono" />
          </div>
          <div className="space-y-2">
            <Label className="font-bold">نقل</Label>
            <Input type="number" value={form.transport} onChange={e => setForm({ ...form, transport: e.target.value })} placeholder="0" className="h-12 font-mono" />
          </div>
          <div className="space-y-2">
            <Label className="font-bold">وقود</Label>
            <Input type="number" value={form.fuel} onChange={e => setForm({ ...form, fuel: e.target.value })} placeholder="0" className="h-12 font-mono" />
          </div>
          <div className="space-y-2">
            <Label className="font-bold">سائق</Label>
            <Input type="number" value={form.driverCost} onChange={e => setForm({ ...form, driverCost: e.target.value })} placeholder="0" className="h-12 font-mono" />
          </div>
          <div className="space-y-2">
            <Label className="font-bold">صيانة</Label>
            <Input type="number" value={form.maintenance} onChange={e => setForm({ ...form, maintenance: e.target.value })} placeholder="0" className="h-12 font-mono" />
          </div>
          <div className="space-y-2">
            <Label className="font-bold">مصاريف أخرى</Label>
            <Input type="number" value={form.otherExpenses} onChange={e => setForm({ ...form, otherExpenses: e.target.value })} placeholder="0" className="h-12 font-mono" />
          </div>
          <div className="space-y-2">
            <Label className="font-bold">نثريات</Label>
            <Input type="number" value={form.pettyCash} onChange={e => setForm({ ...form, pettyCash: e.target.value })} placeholder="0" className="h-12 font-mono" />
          </div>
          <div className="space-y-2">
            <Label className="font-bold text-red-600">خصم</Label>
            <Input type="number" value={form.discount} onChange={e => setForm({ ...form, discount: e.target.value })} placeholder="0" className="h-12 font-mono text-red-600" />
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label className="font-bold">ملاحظات</Label>
            <Input value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} className="h-12" />
          </div>
          <div className="flex items-end gap-2 md:col-span-2">
            <Button onClick={handleSave} className="flex-1 h-12 font-bold text-lg" disabled={createMutation.isPending || updateMutation.isPending}>
              {(createMutation.isPending || updateMutation.isPending) ? <Loader2 className="h-5 w-5 animate-spin" /> : (isEditing ? "تحديث" : "حفظ التكاليف")}
            </Button>
            {isEditing && <Button variant="outline" onClick={resetForm} className="h-12 px-6">إلغاء</Button>}
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6 pb-20 md:pb-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">تكاليف التخليص</h2>
          <p className="text-sm text-muted-foreground mt-1">إدارة وتحليل تكاليف البيانات الجمركية</p>
        </div>
      </div>

      <Card className="shadow-sm border-gray-200">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-3 items-start md:items-center">
            <Label className="font-bold whitespace-nowrap">اختر البيان الجمركي:</Label>
            <Select value={selectedDeclId?.toString() || ""} onValueChange={v => { setSelectedDeclId(v ? Number(v) : null); resetForm(); }}>
              <SelectTrigger className="w-full md:max-w-md h-12">
                <SelectValue placeholder="ابحث عن رقم البيان..." />
              </SelectTrigger>
              <SelectContent>
                {declarations?.map(d => (
                  <SelectItem key={d.id} value={d.id.toString()}>
                    <div className="flex flex-col items-start">
                      <span className="font-bold">{d.declarationNumber}</span>
                      <span className="text-[10px] text-muted-foreground">{d.entryNumber} - {d.goodsType || "-"}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {selectedDecl && summary ? (
        <>
          {/* Declaration Info Card */}
          <Card className="bg-primary/5 border-primary/20 overflow-hidden shadow-sm">
            <CardHeader className="p-4 bg-primary/10 border-b border-primary/10">
              <div className="flex justify-between items-center">
                <div className="font-black text-primary text-lg">تفاصيل البيان: {summary.declaration.declarationNumber}</div>
                <Badge variant="outline" className="bg-white/80 font-bold">{summary.declaration.customsPort || "-"}</Badge>
              </div>
            </CardHeader>
            <CardContent className="p-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div>
                  <div className="text-[10px] text-muted-foreground font-bold">رقم القيد</div>
                  <div className="font-bold">{summary.declaration.entryNumber}</div>
                </div>
                <div>
                  <div className="text-[10px] text-muted-foreground font-bold">العميل</div>
                  <div className="font-bold">{getClientName(summary.declaration.clientId)}</div>
                </div>
                <div>
                  <div className="text-[10px] text-muted-foreground font-bold">نوع البضاعة</div>
                  <div className="font-bold">{summary.declaration.goodsType || "-"}</div>
                </div>
                <div>
                  <div className="text-[10px] text-muted-foreground font-bold">رقم اللوحة</div>
                  <div className="font-bold font-mono">{summary.declaration.plateNumber || "-"}</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Financial Summary Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-blue-50/50 border-blue-100 shadow-sm">
              <CardHeader className="py-3 px-4"><CardTitle className="text-xs font-bold text-blue-600 uppercase tracking-wider">إجمالي التكاليف</CardTitle></CardHeader>
              <CardContent className="py-2 px-4"><div className="text-2xl font-black font-mono text-blue-700">{Number(summary.totals.totalCost).toLocaleString('en-US')}</div></CardContent>
            </Card>
            <Card className="bg-green-50/50 border-green-100 shadow-sm">
              <CardHeader className="py-3 px-4"><CardTitle className="text-xs font-bold text-green-600 uppercase tracking-wider">إجمالي المقبوضات</CardTitle></CardHeader>
              <CardContent className="py-2 px-4"><div className="text-2xl font-black font-mono text-green-700">{Number(summary.totals.totalReceived).toLocaleString('en-US')}</div></CardContent>
            </Card>
            <Card className={`${summary.totals.net > 0 ? "bg-red-50/50 border-red-100" : "bg-emerald-50/50 border-emerald-100"} shadow-sm`}>
              <CardHeader className="py-3 px-4"><CardTitle className={`text-xs font-bold uppercase tracking-wider ${summary.totals.net > 0 ? "text-red-600" : "text-emerald-600"}`}>الرصيد المتبقي</CardTitle></CardHeader>
              <CardContent className="py-2 px-4"><div className={`text-2xl font-black font-mono ${summary.totals.net > 0 ? "text-red-700" : "text-emerald-700"}`}>{Number(summary.totals.net).toLocaleString('en-US')}</div></CardContent>
            </Card>
          </div>

          <CostForm />

          <Card className="shadow-sm border-gray-200">
            <CardHeader className="flex flex-row items-center justify-between p-4 border-b border-gray-100">
              <CardTitle className="text-lg font-bold">سجل التكاليف</CardTitle>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={handleExportCostsExcel} className="h-9 md:h-8 gap-1">
                  <Download className="h-3.5 w-3.5" /> Excel
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {/* Desktop Table */}
              <div className="hidden md:block overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>الإجمالي</TableHead>
                      <TableHead>الصافي</TableHead>
                      <TableHead>الحالة</TableHead>
                      <TableHead>ملاحظات</TableHead>
                      <TableHead>إجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {costs?.map(c => (
                      <TableRow key={c.id}>
                        <TableCell className="font-mono">{Number(c.totalCost).toLocaleString('en-US')}</TableCell>
                        <TableCell className="font-mono font-bold">{Number(c.netCost).toLocaleString('en-US')}</TableCell>
                        <TableCell>
                          <Badge variant={c.isApproved ? "default" : "outline"}>
                            {c.isApproved ? "معتمد" : "مسودة"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-muted-foreground max-w-[200px] truncate">{c.notes}</TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            {!c.isApproved ? (
                              <>
                                <Button variant="ghost" size="sm" onClick={() => handleEdit(c)}>تعديل</Button>
                                <Button variant="ghost" size="sm" onClick={() => { if(confirm("اعتماد التكلفة؟")) approveMutation.mutate({ id: c.id, isApproved: true }); }}>اعتماد</Button>
                                <Button variant="ghost" size="sm" className="text-destructive" onClick={() => { if(confirm("حذف؟")) deleteMutation.mutate({ id: c.id }); }}>حذف</Button>
                              </>
                            ) : (
                              <span className="text-xs text-muted-foreground italic px-2">معتمد</span>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                    {(!costs || costs.length === 0) && (
                      <TableRow><TableCell colSpan={5} className="py-12 text-center text-muted-foreground">لا توجد تكاليف مسجلة لهذا البيان</TableCell></TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>

              {/* Mobile Card View */}
              <div className="md:hidden divide-y divide-gray-100 bg-gray-50/30">
                {costs?.map(c => (
                  <div key={c.id} className="p-4 bg-white space-y-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="text-[10px] text-muted-foreground font-bold uppercase">صافي التكلفة</div>
                        <div className="text-xl font-black font-mono text-primary">{Number(c.netCost).toLocaleString('en-US')}</div>
                      </div>
                      <Badge variant={c.isApproved ? "default" : "outline"} className="h-6">
                        {c.isApproved ? "معتمد" : "مسودة"}
                      </Badge>
                    </div>
                    <div className="flex justify-between text-xs border-t border-gray-50 pt-2">
                      <div className="text-muted-foreground">الإجمالي: <span className="font-mono font-bold">{Number(c.totalCost).toLocaleString('en-US')}</span></div>
                      <div className="text-muted-foreground">الخصم: <span className="font-mono font-bold">{Number(c.discount || 0).toLocaleString('en-US')}</span></div>
                    </div>
                    {!c.isApproved && (
                      <div className="flex gap-2 pt-1">
                        <Button variant="outline" size="sm" className="flex-1 h-9 font-bold" onClick={() => handleEdit(c)}>تعديل</Button>
                        <Button variant="outline" size="sm" className="flex-1 h-9 font-bold text-green-600 border-green-200" onClick={() => { if(confirm("اعتماد التكلفة؟")) approveMutation.mutate({ id: c.id, isApproved: true }); }}>اعتماد</Button>
                        <Button variant="ghost" size="sm" className="text-destructive h-9" onClick={() => { if(confirm("حذف؟")) deleteMutation.mutate({ id: c.id }); }}>حذف</Button>
                      </div>
                    )}
                    {c.notes && <div className="text-[11px] text-muted-foreground bg-gray-50 p-2 rounded-lg italic">{c.notes}</div>}
                  </div>
                ))}
                {(!costs || costs.length === 0) && (
                  <div className="text-center py-12 text-muted-foreground">لا توجد تكاليف مسجلة لهذا البيان</div>
                )}
              </div>
            </CardContent>
          </Card>
        </>
      ) : (
        <Card className="h-[200px] md:h-[400px] flex flex-col items-center justify-center p-8 text-muted-foreground bg-gray-50/30 border-dashed border-2">
          <Calculator className="h-16 w-16 mb-4 opacity-10" />
          <p className="text-center font-medium">يرجى اختيار بيان جمركي من القائمة أعلاه للبدء في إدارة التكاليف</p>
        </Card>
      )}
    </div>
  );
}
