import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Loader2, Plus, Trash2, FileText, Search, Printer, Download, Pencil, Calendar, Info } from "lucide-react";
import { useState, useEffect } from "react";
import { getDefaultCurrency } from "@/lib/currency";
import { toast } from "sonner";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { useIsMobile } from "@/hooks/useMobile";

// تحويل الأرقام إلى كلمات عربية
function numberToArabicWords(num: number): string {
  if (num === 0) return "صفر";
  const ones = ["", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة"];
  const tens = ["", "عشرة", "عشرون", "ثلاثون", "أربعون", "خمسون", "ستون", "سبعون", "ثمانون", "تسعون"];
  const teens = ["عشرة", "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر", "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر"];
  let result = "";
  if (num >= 1000000) {
    const millions = Math.floor(num / 1000000);
    result += numberToArabicWords(millions) + " مليون ";
    num = num % 1000000;
  }
  if (num >= 1000) {
    const thousands = Math.floor(num / 1000);
    if (thousands === 1) result += "ألف ";
    else if (thousands === 2) result += "ألفين ";
    else result += numberToArabicWords(thousands) + " ألف ";
    num = num % 1000;
  }
  if (num >= 100) {
    const hundreds = Math.floor(num / 100);
    if (hundreds === 1) result += "مائة ";
    else if (hundreds === 2) result += "مائتان ";
    else if (hundreds >= 3) result += numberToArabicWords(hundreds).replace("ثمانية", "ثمان") + "مائة ";
    num = num % 100;
  }
  if (num > 0) {
    if (num < 10) result += ones[num];
    else if (num < 20) result += teens[num - 10];
    else {
      const t = Math.floor(num / 10);
      const o = num % 10;
      if (o > 0) result += ones[o] + " و" + tens[t];
      else result += tens[t];
    }
  }
  return result.trim();
}

interface ServiceInvoiceForm {
  clientId: string;
  serviceName: string;
  serviceDescription: string;
  quantity: string;
  unitPrice: string;
  discount: string;
  taxRate: string;
  currency: string;
  date: string;
  status: string;
  paymentType: string;
  notes: string;
}
const initialForm: ServiceInvoiceForm = {
  clientId: "", serviceName: "", serviceDescription: "",
  quantity: "1", unitPrice: "", discount: "0", taxRate: "15",
  currency: "YER", date: new Date().toISOString().split("T")[0],
  status: "معتمدة", paymentType: "نقداً", notes: "",
};

export default function ServiceInvoices() {
  const isMobile = useIsMobile();
  const utils = trpc.useUtils();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<ServiceInvoiceForm>(initialForm);
  const [searchQuery, setSearchQuery] = useState("");

  const { data: invoices, isLoading } = trpc.serviceInvoices.list.useQuery();
  const { data: clients } = trpc.clients.list.useQuery();
  const { data: nextNum } = trpc.serviceInvoices.nextNumber.useQuery();
  const { data: currencies } = trpc.currencies.list.useQuery();
  const { data: systemSettings } = trpc.settings.getAll.useQuery();

  useEffect(() => {
    if (systemSettings) {
      const defaultCurr = getDefaultCurrency(systemSettings);
      setForm(p => ({ ...p, currency: defaultCurr }));
    }
  }, [systemSettings]);

  const createMutation = trpc.serviceInvoices.create.useMutation({
    onSuccess: () => {
      utils.serviceInvoices.list.invalidate();
      utils.serviceInvoices.nextNumber.invalidate();
      setOpen(false);
      setForm(initialForm);
      toast.success("تم إنشاء الفاتورة الخدمية بنجاح");
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = trpc.serviceInvoices.delete.useMutation({
    onSuccess: () => {
      utils.serviceInvoices.list.invalidate();
      toast.success("تم حذف الفاتورة");
    },
    onError: (e) => toast.error(e.message),
  });

  const filteredInvoices = invoices?.filter(inv =>
    searchQuery === "" ||
    inv.serviceName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (inv.notes || "").toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  const statusColors: Record<string, string> = {
    "معتمدة": "bg-green-500/10 text-green-600 border-green-200",
    "مسودة": "bg-yellow-500/10 text-yellow-600 border-yellow-200",
    "ملغاة": "bg-red-500/10 text-red-600 border-red-200",
  };

  const handleSubmit = () => {
    if (!form.clientId || !form.serviceName || !form.unitPrice) {
      toast.error("يرجى ملء الحقول المطلوبة");
      return;
    }
    createMutation.mutate({
      number: nextNum || 1,
      clientId: parseInt(form.clientId),
      serviceName: form.serviceName,
      serviceDescription: form.serviceDescription,
      quantity: form.quantity,
      unitPrice: form.unitPrice,
      discount: form.discount,
      taxRate: form.taxRate,
      currency: form.currency,
      date: form.date,
      status: form.status,
      paymentType: form.paymentType as "نقداً" | "آجل" | "حوالة",
      notes: form.notes,
    });
  };

  const getCurrencyNameFn = (code: string | null | undefined) => {
    const c = currencies?.find(c => c.code === code);
    return c?.name || code;
  };

  const getClientNameFn = (clientId: number | null | undefined) => {
    if (!clientId) return "-";
    const client = clients?.find(c => c.id === clientId);
    return client?.name || "-";
  };

  const handlePrintInvoice = (inv: any) => {
    setTimeout(() => {
      const element = document.getElementById(`service-inv-print-${inv.id}`);
      if (!element) return;
      const printWindow = window.open('', '_blank');
      if (!printWindow) { toast.error("يرجى السماح بالنوافذ المنبثقة"); return; }
      printWindow.document.write(`
        <!DOCTYPE html><html dir="rtl"><head><meta charset="UTF-8"><title>فاتورة رقم ${inv.number}</title>
        <style>* { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Tajawal', Arial, sans-serif; }
        body { padding: 15mm; font-size: 13px; color: #333; }
        @media print { body { padding: 10mm; } }</style></head>
        <body>${element.innerHTML}</body></html>
      `);
      printWindow.document.close();
      printWindow.print();
    }, 100);
  };

  const handleDownloadInvoicePDF = async (inv: any) => {
    const element = document.getElementById(`service-inv-print-${inv.id}`);
    if (!element) { toast.error("لم يتم العثور على الفاتورة"); return; }
    const canvas = await html2canvas(element, { scale: 2, backgroundColor: '#ffffff' });
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF('p', 'mm', 'a4');
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    pdf.save(`فاتورة-خدمية-${inv.number}.pdf`);
    toast.success("تم تحميل الفاتورة PDF");
  };

  return (
    <div className="space-y-6 pb-20 md:pb-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 px-1">
        <div>
          <h2 className="text-2xl font-bold">الفواتير الخدمية</h2>
          <p className="text-sm text-muted-foreground mt-1">إصدار وإدارة فواتير الخدمات غير المتعلقة بالشحن</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="h-12 md:h-10 font-bold w-full md:w-auto">
              <Plus className="h-5 w-5 ml-2" /> فاتورة خدمية جديدة
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg p-6">
            <DialogHeader>
              <DialogTitle className="text-xl font-bold">فاتورة خدمية جديدة</DialogTitle>
            </DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              <div className="space-y-2">
                <Label className="font-bold">العميل *</Label>
                <Select value={form.clientId} onValueChange={(v) => setForm(p => ({ ...p, clientId: v }))}>
                  <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue placeholder="اختر العميل" /></SelectTrigger>
                  <SelectContent>
                    {clients?.map(c => <SelectItem key={c.id} value={String(c.id)} className="text-right">{c.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="font-bold">اسم الخدمة *</Label>
                <Input value={form.serviceName} onChange={(e) => setForm(p => ({ ...p, serviceName: e.target.value }))} placeholder="مثال: خدمات استشارية" className="h-12 md:h-10" />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label className="font-bold">وصف الخدمة</Label>
                <Input value={form.serviceDescription} onChange={(e) => setForm(p => ({ ...p, serviceDescription: e.target.value }))} className="h-12 md:h-10" />
              </div>
              <div className="space-y-2">
                <Label className="font-bold">الكمية</Label>
                <Input type="number" value={form.quantity} onChange={(e) => setForm(p => ({ ...p, quantity: e.target.value }))} className="h-12 md:h-10 font-mono" />
              </div>
              <div className="space-y-2">
                <Label className="font-bold">سعر الوحدة *</Label>
                <Input type="number" value={form.unitPrice} onChange={(e) => setForm(p => ({ ...p, unitPrice: e.target.value }))} className="h-12 md:h-10 font-mono" />
              </div>
              <div className="space-y-2">
                <Label className="font-bold">الخصم %</Label>
                <Input type="number" value={form.discount} onChange={(e) => setForm(p => ({ ...p, discount: e.target.value }))} className="h-12 md:h-10 font-mono" />
              </div>
              <div className="space-y-2">
                <Label className="font-bold">الضريبة %</Label>
                <Input type="number" value={form.taxRate} onChange={(e) => setForm(p => ({ ...p, taxRate: e.target.value }))} className="h-12 md:h-10 font-mono" />
              </div>
              <div className="space-y-2">
                <Label className="font-bold">العملة</Label>
                <Select value={form.currency} onValueChange={(v) => setForm(p => ({ ...p, currency: v }))}>
                  <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue placeholder="اختر العملة" /></SelectTrigger>
                  <SelectContent>
                    {currencies?.map(c => <SelectItem key={c.code} value={c.code} className="text-right">{c.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="font-bold">التاريخ</Label>
                <Input type="date" value={form.date} onChange={(e) => setForm(p => ({ ...p, date: e.target.value }))} className="h-12 md:h-10 text-right" />
              </div>
              <div className="space-y-2">
                <Label className="font-bold">الحالة</Label>
                <Select value={form.status} onValueChange={(v) => setForm(p => ({ ...p, status: v }))}>
                  <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="معتمدة" className="text-right">معتمدة</SelectItem>
                    <SelectItem value="مسودة" className="text-right">مسودة</SelectItem>
                    <SelectItem value="ملغاة" className="text-right">ملغاة</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="font-bold">نوع الدفع</Label>
                <Select value={form.paymentType} onValueChange={(v) => setForm(p => ({ ...p, paymentType: v }))}>
                  <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="نقداً" className="text-right">نقداً</SelectItem>
                    <SelectItem value="آجل" className="text-right">آجل</SelectItem>
                    <SelectItem value="حوالة" className="text-right">حوالة</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label className="font-bold">ملاحظات</Label>
                <Input value={form.notes} onChange={(e) => setForm(p => ({ ...p, notes: e.target.value }))} className="h-12 md:h-10" />
              </div>
            </div>
            <div className="flex gap-3 mt-8">
              <Button variant="outline" className="flex-1 h-12 md:h-10" onClick={() => setOpen(false)}>إلغاء</Button>
              <Button onClick={handleSubmit} className="flex-1 h-12 md:h-10 font-bold" disabled={createMutation.isPending}>
                {createMutation.isPending && <Loader2 className="h-4 w-4 animate-spin ml-2" />}
                إنشاء الفاتورة
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="border-gray-200 shadow-sm overflow-hidden">
        <CardContent className="p-4 md:p-6">
          <div className="relative w-full md:w-80">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="البحث في الفواتير..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10 h-12 md:h-10 text-right"
            />
          </div>
        </CardContent>
      </Card>

      <Card className="border-gray-200 shadow-sm overflow-hidden">
        <CardHeader className="bg-gray-50/50 p-4 border-b">
          <CardTitle className="text-lg flex items-center gap-2">
            <Info className="h-5 w-5 text-primary" /> قائمة الفواتير الخدمية
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex justify-center py-16"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
          ) : filteredInvoices.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground bg-white">
              <FileText className="h-16 w-16 mx-auto mb-4 opacity-20" />
              <p className="text-lg">لا توجد فواتير خدمية بعد</p>
            </div>
          ) : isMobile ? (
            <div className="divide-y divide-gray-100">
              {filteredInvoices.map((inv) => (
                <div key={inv.id} className="p-4 bg-white">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-bold text-base">فاتورة #{inv.number}</span>
                        <Badge variant="outline" className={statusColors[inv.status] + " text-[10px]"}>{inv.status}</Badge>
                      </div>
                      <div className="text-sm font-medium text-blue-600">{getClientNameFn(inv.clientId)}</div>
                    </div>
                    <div className="text-left">
                      <span className="font-black text-lg text-green-600">{Number(inv.totalAmount || 0).toLocaleString('en-US')}</span>
                      <span className="text-[10px] text-muted-foreground block">{getCurrencyNameFn(inv.currency)}</span>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center text-sm mb-4">
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      <span>{inv.date || "-"}</span>
                    </div>
                    <span className="text-xs text-muted-foreground">{inv.serviceName}</span>
                  </div>

                  <div className="flex gap-2 pt-2 border-t border-gray-50">
                    <Button variant="outline" size="sm" className="flex-1 h-10 font-bold" onClick={() => handlePrintInvoice(inv)}>
                      <Printer className="h-4 w-4 ml-2" /> طباعة
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1 h-10 font-bold" onClick={() => handleDownloadInvoicePDF(inv)}>
                      <Download className="h-4 w-4 ml-2" /> PDF
                    </Button>
                    <Button variant="outline" size="sm" className="h-10 w-10 text-red-600 border-red-100 hover:bg-red-50" onClick={() => { if(confirm("حذف الفاتورة؟")) deleteMutation.mutate({ id: inv.id }); }}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  {/* Hidden Print Template */}
                  <div id={`service-inv-print-${inv.id}`} className="hidden">
                    <div style={{ padding: '20px', border: '1px solid #eee' }}>
                      <h2 style={{ textAlign: 'center' }}>فاتورة خدمية</h2>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '20px' }}>
                        <div>
                          <p><strong>الرقم:</strong> {inv.number}</p>
                          <p><strong>التاريخ:</strong> {inv.date}</p>
                        </div>
                        <div style={{ textAlign: 'left' }}>
                          <p><strong>العميل:</strong> {getClientNameFn(inv.clientId)}</p>
                        </div>
                      </div>
                      <table style={{ width: '100%', marginTop: '30px', borderCollapse: 'collapse' }}>
                        <thead>
                          <tr style={{ background: '#f9f9f9' }}>
                            <th style={{ border: '1px solid #eee', padding: '10px' }}>الخدمة</th>
                            <th style={{ border: '1px solid #eee', padding: '10px' }}>الكمية</th>
                            <th style={{ border: '1px solid #eee', padding: '10px' }}>السعر</th>
                            <th style={{ border: '1px solid #eee', padding: '10px' }}>الإجمالي</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td style={{ border: '1px solid #eee', padding: '10px' }}>{inv.serviceName}</td>
                            <td style={{ border: '1px solid #eee', padding: '10px' }}>{inv.quantity}</td>
                            <td style={{ border: '1px solid #eee', padding: '10px' }}>{inv.unitPrice}</td>
                            <td style={{ border: '1px solid #eee', padding: '10px' }}>{inv.totalAmount}</td>
                          </tr>
                        </tbody>
                      </table>
                      <div style={{ marginTop: '20px', textAlign: 'left' }}>
                        <p><strong>المبلغ بالحروف:</strong> {numberToArabicWords(Number(inv.totalAmount))} {getCurrencyNameFn(inv.currency)}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-gray-50">
                  <TableRow>
                    <TableHead className="text-right font-bold">رقم الفاتورة</TableHead>
                    <TableHead className="text-right font-bold">العميل</TableHead>
                    <TableHead className="text-right font-bold">الخدمة</TableHead>
                    <TableHead className="text-right font-bold">المبلغ</TableHead>
                    <TableHead className="text-right font-bold">العملة</TableHead>
                    <TableHead className="text-right font-bold">التاريخ</TableHead>
                    <TableHead className="text-right font-bold">الحالة</TableHead>
                    <TableHead className="text-left font-bold w-32">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredInvoices.map((inv) => (
                    <TableRow key={inv.id}>
                      <TableCell className="font-bold">#{inv.number}</TableCell>
                      <TableCell>{getClientNameFn(inv.clientId)}</TableCell>
                      <TableCell>{inv.serviceName}</TableCell>
                      <TableCell className="font-bold text-green-600">{Number(inv.totalAmount || 0).toLocaleString('en-US')}</TableCell>
                      <TableCell>{getCurrencyNameFn(inv.currency)}</TableCell>
                      <TableCell>{inv.date || "-"}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={statusColors[inv.status]}>{inv.status}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-600" onClick={() => handlePrintInvoice(inv)}><Printer className="h-4 w-4" /></Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-600" onClick={() => handleDownloadInvoicePDF(inv)}><Download className="h-4 w-4" /></Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600" onClick={() => { if(confirm("هل أنت متأكد؟")) deleteMutation.mutate({ id: inv.id }); }}><Trash2 className="h-4 w-4" /></Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
