import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Plus, Search, X, Landmark, Pencil, Trash2, Wallet, Building2, MoreVertical, Loader2 } from "lucide-react";
import { useIsMobile } from "@/hooks/useMobile";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

type CashboxType = "صندوق نقدي" | "بنك";

export default function CashboxesPage() {
  const isMobile = useIsMobile();
  const utils = trpc.useUtils();
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState({
    name: "", type: "صندوق نقدي" as CashboxType, currency: "YER",
    initialBalance: "0", notes: "", linkedAccountId: "",
  });

  const { data: cashboxes, isLoading } = trpc.cashboxes.list.useQuery();
  const { data: accounts } = trpc.accounts.list.useQuery();

  const filtered = useMemo(() => {
    if (!cashboxes) return [];
    if (!search.trim()) return cashboxes;
    const q = search.trim().toLowerCase();
    return cashboxes.filter(c => c.name.toLowerCase().includes(q));
  }, [cashboxes, search]);

  const createMutation = trpc.cashboxes.create.useMutation({
    onSuccess: () => {
      toast.success("تمت إضافة الصندوق/البنك بنجاح");
      utils.cashboxes.list.invalidate();
      setDialogOpen(false);
      resetForm();
    },
    onError: (e) => toast.error(e.message),
  });

  const updateMutation = trpc.cashboxes.update.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث الصندوق/البنك");
      utils.cashboxes.list.invalidate();
      setDialogOpen(false);
      resetForm();
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = trpc.cashboxes.delete.useMutation({
    onSuccess: () => {
      utils.cashboxes.list.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  const resetForm = () => {
    setForm({ name: "", type: "صندوق نقدي", currency: "YER", initialBalance: "0", notes: "", linkedAccountId: "" });
    setEditingId(null);
  };

  const openEdit = (c: any) => {
    setForm({
      name: c.name, type: c.type as CashboxType,
      currency: c.currency || "YER",
      initialBalance: c.initialBalance?.toString() || "0",
      notes: c.notes || "",
      linkedAccountId: c.linkedAccountId ? c.linkedAccountId.toString() : "",
    });
    setEditingId(c.id);
    setDialogOpen(true);
  };

  const handleDelete = (c: any) => {
    if (confirm(`هل تريد حذف "${c.name}"؟`)) {
      deleteMutation.mutate({ id: c.id });
      toast.success("تم حذف الصندوق/البنك");
    }
  };

  const handleSubmit = () => {
    if (!form.name.trim()) { toast.error("الاسم مطلوب"); return; }
    const data = {
      name: form.name, type: form.type, currency: form.currency,
      initialBalance: parseFloat(form.initialBalance) || 0,
      currentBalance: parseFloat(form.initialBalance) || 0,
      isActive: true,
      notes: form.notes || undefined,
      linkedAccountId: form.linkedAccountId ? parseInt(form.linkedAccountId) : undefined,
    };
    if (editingId) {
      updateMutation.mutate({ id: editingId, ...data });
    } else {
      createMutation.mutate(data);
    }
  };

  const totalBalance = cashboxes?.filter(c => c.isActive).reduce((sum, c) => sum + parseFloat(c.currentBalance?.toString() || "0"), 0) || 0;

  return (
    <div className="space-y-4 pb-20 md:pb-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 px-1">
        <div>
          <h1 className="text-2xl font-bold">الصناديق والبنوك</h1>
          <p className="text-sm text-muted-foreground mt-1">إدارة الصناديق النقدية والحسابات البنكية</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={(o) => { setDialogOpen(o); if (!o) resetForm(); }}>
          <DialogTrigger asChild>
            <Button className="w-full md:w-auto h-12 md:h-10 font-bold text-base gap-2">
              <Plus className="h-5 w-5" /> إضافة صندوق/بنك
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md p-0 gap-0 overflow-hidden">
            <DialogHeader className="p-6 pb-2">
              <DialogTitle className="text-xl">{editingId ? "تعديل صندوق/بنك" : "إضافة صندوق/بنك جديد"}</DialogTitle>
            </DialogHeader>
            <div className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="col-span-1 md:col-span-2 space-y-2">
                  <Label className="font-bold">الاسم *</Label>
                  <Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="مثال: الصندوق الرئيسي، بنك الكريمي" className="h-12 md:h-10" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">النوع</Label>
                  <Select value={form.type} onValueChange={v => setForm(f => ({ ...f, type: v as CashboxType }))}>
                    <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="صندوق نقدي" className="text-right">صندوق نقدي</SelectItem>
                      <SelectItem value="بنك" className="text-right">بنك</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">العملة</Label>
                  <Select value={form.currency} onValueChange={v => setForm(f => ({ ...f, currency: v }))}>
                    <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="YER" className="text-right">ريال يمني</SelectItem>
                      <SelectItem value="SAR" className="text-right">ريال سعودي</SelectItem>
                      <SelectItem value="USD" className="text-right">دولار أمريكي</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">الرصيد الافتتاحي</Label>
                  <Input type="number" value={form.initialBalance} onChange={e => setForm(f => ({ ...f, initialBalance: e.target.value }))} placeholder="0" className="h-12 md:h-10 text-left font-mono" />
                </div>
                <div className="col-span-1 md:col-span-2 space-y-2">
                  <Label className="font-bold">الحساب المحاسبي المرتبط</Label>
                  <Select value={form.linkedAccountId} onValueChange={v => setForm(f => ({ ...f, linkedAccountId: v }))}>
                    <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue placeholder="اختر حساباً من الدليل" /></SelectTrigger>
                    <SelectContent>
                      {accounts?.map(a => <SelectItem key={a.id} value={String(a.id)} className="text-right">{a.code} - {a.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="col-span-1 md:col-span-2 space-y-2">
                  <Label className="font-bold">ملاحظات</Label>
                  <Input value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} placeholder="ملاحظات إضافية" className="h-12 md:h-10" />
                </div>
              </div>
              <div className="flex flex-col md:flex-row justify-end gap-3 pt-4 border-t">
                <Button variant="outline" onClick={() => setDialogOpen(false)} className="h-12 md:h-10 font-bold">إلغاء</Button>
                <Button onClick={handleSubmit} disabled={createMutation.isPending || updateMutation.isPending} className="h-12 md:h-10 font-bold text-base px-8">
                  {editingId ? "تحديث البيانات" : "إضافة الصندوق"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-2 gap-3 px-1">
        <Card className="border-0 shadow-sm bg-blue-50/50">
          <CardContent className="p-3 flex flex-col items-center justify-center text-center gap-1">
            <Landmark className="h-6 w-6 text-blue-600 mb-1" />
            <p className="text-[10px] text-blue-600 font-bold uppercase tracking-wider">إجمالي الأرصدة</p>
            <p className="text-base font-black text-blue-900 font-mono" dir="ltr">{totalBalance.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm bg-green-50/50">
          <CardContent className="p-3 flex flex-col items-center justify-center text-center gap-1">
            <Wallet className="h-6 w-6 text-green-600 mb-1" />
            <p className="text-[10px] text-green-600 font-bold uppercase tracking-wider">الحسابات النشطة</p>
            <p className="text-xl font-black text-green-900">{cashboxes?.filter(c => c.isActive).length || 0}</p>
          </CardContent>
        </Card>
      </div>

      <Card className="shadow-sm border-gray-200">
        <CardHeader className="p-4 pb-2">
          <div className="relative">
            <Search className="absolute right-3 top-3 h-5 w-5 text-gray-400" />
            <Input
              placeholder="بحث باسم الصندوق أو البنك..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pr-10 h-12 md:h-10 w-full"
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex flex-col items-center py-12 gap-3">
              <Loader2 className="h-10 w-10 animate-spin text-primary" />
              <span className="text-muted-foreground">جاري تحميل البيانات...</span>
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-12 flex flex-col items-center gap-3">
              <Landmark className="h-16 w-16 text-gray-200" />
              <p className="text-muted-foreground">{search ? "لا توجد نتائج مطابقة" : "لا توجد صناديق مسجلة"}</p>
            </div>
          ) : (
            <>
              {/* Desktop Table */}
              <div className="hidden md:block overflow-x-auto">
                <Table>
                  <TableHeader className="bg-gray-50">
                    <TableRow>
                      <TableHead className="text-right font-bold">الاسم</TableHead>
                      <TableHead className="text-right font-bold">النوع</TableHead>
                      <TableHead className="text-right font-bold">الحساب المرتبط</TableHead>
                      <TableHead className="text-right font-bold">العملة</TableHead>
                      <TableHead className="text-right font-bold">الرصيد الحالي</TableHead>
                      <TableHead className="text-right font-bold w-24">الحالة</TableHead>
                      <TableHead className="text-left font-bold w-24">الإجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filtered.map(c => (
                      <TableRow key={c.id} className="hover:bg-gray-50/50 transition-colors">
                        <TableCell className="font-bold">{c.name}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {c.type === "بنك" ? <Building2 className="h-4 w-4 text-blue-500" /> : <Wallet className="h-4 w-4 text-green-500" />}
                            <span>{c.type}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {c.linkedAccountId ? accounts?.find(a => a.id === c.linkedAccountId)?.name : "غير مرتبط"}
                        </TableCell>
                        <TableCell className="font-medium">{c.currency}</TableCell>
                        <TableCell className="font-mono font-bold text-blue-700" dir="ltr">
                          {parseFloat(c.currentBalance?.toString() || "0").toLocaleString()}
                        </TableCell>
                        <TableCell>
                          <Badge variant={c.isActive ? "default" : "outline"} className={c.isActive ? "bg-green-500" : ""}>
                            {c.isActive ? "نشط" : "متوقف"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-600" onClick={() => openEdit(c)}>
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600" onClick={() => handleDelete(c)}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Mobile Card List */}
              <div className="md:hidden space-y-0 divide-y">
                {filtered.map(c => (
                  <div key={c.id} className="p-4 active:bg-gray-50 transition-colors bg-white">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex flex-col gap-1">
                        <div className="flex items-center gap-2">
                          {c.type === "بنك" ? <Building2 className="h-4 w-4 text-blue-500" /> : <Wallet className="h-4 w-4 text-green-500" />}
                          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-tighter">{c.type}</span>
                          <Badge variant="outline" className={`py-0 h-4 font-bold text-[9px] ${c.isActive ? "text-green-600 border-green-200 bg-green-50" : "text-gray-400"}`}>
                            {c.isActive ? "نشط" : "متوقف"}
                          </Badge>
                        </div>
                        <h3 className="font-bold text-base text-gray-900">{c.name}</h3>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-9 w-9 -mt-1 -mr-1">
                            <MoreVertical className="h-5 w-5 text-gray-400" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="text-right">
                          <DropdownMenuItem onClick={() => openEdit(c)} className="flex justify-end gap-2">
                            <span>تعديل</span>
                            <Pencil className="h-4 w-4" />
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleDelete(c)} className="flex justify-end gap-2 text-red-600">
                            <span>حذف</span>
                            <Trash2 className="h-4 w-4" />
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-y-2 mt-3">
                      <div className="flex flex-col">
                        <span className="text-[10px] text-muted-foreground uppercase">الرصيد الحالي</span>
                        <span className="font-bold text-blue-700 font-mono text-sm" dir="ltr">
                          {parseFloat(c.currentBalance?.toString() || "0").toLocaleString()} {c.currency}
                        </span>
                      </div>
                      <div className="flex flex-col items-end">
                        <span className="text-[10px] text-muted-foreground uppercase">الحساب المرتبط</span>
                        <span className="text-xs font-medium truncate max-w-[120px]">
                          {c.linkedAccountId ? accounts?.find(a => a.id === c.linkedAccountId)?.name : "غير مرتبط"}
                        </span>
                      </div>
                      {c.notes && (
                        <div className="col-span-2 mt-1">
                          <p className="text-[10px] text-gray-400 italic">ملاحظات: {c.notes}</p>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
