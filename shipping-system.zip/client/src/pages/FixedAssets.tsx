import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { useIsMobile } from "@/hooks/useMobile";
import { Plus, Calculator, Truck, Wrench, Ban, DollarSign, Calendar, Info, Pencil, Trash2, TrendingDown, Wallet } from "lucide-react";

const assetTypes = ["شاحنة", "مقطورة", "معدات", "أجهزة", "مبنى", "أخرى"];
const assetStatuses = ["نشط", "صيانة", "خارج_الخدمة", "مباع"];

export default function FixedAssets() {
  const isMobile = useIsMobile();
  const utils = trpc.useUtils();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState({
    assetType: "شاحنة",
    name: "",
    plateNumber: "",
    purchaseDate: "",
    purchaseValue: "",
    usefulLifeYears: "5",
    notes: "",
  });

  const { data: assets } = trpc.fixedAssets.list.useQuery();
  const { data: systemSettings } = trpc.settings.getAll.useQuery();

  const createMutation = trpc.fixedAssets.create.useMutation({
    onSuccess: () => {
      utils.fixedAssets.list.invalidate();
      toast.success("تم إضافة الأصل بنجاح");
      setDialogOpen(false);
      resetForm();
    },
    onError: (e) => toast.error(e.message),
  });

  const updateMutation = trpc.fixedAssets.update.useMutation({
    onSuccess: () => {
      utils.fixedAssets.list.invalidate();
      toast.success("تم تحديث الأصل");
      setDialogOpen(false);
      resetForm();
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = trpc.fixedAssets.delete.useMutation({
    onSuccess: () => {
      utils.fixedAssets.list.invalidate();
      toast.success("تم حذف الأصل");
    },
    onError: (e) => toast.error(e.message),
  });

  const depreciateMutation = trpc.fixedAssets.depreciate.useMutation({
    onSuccess: (data) => {
      utils.fixedAssets.list.invalidate();
      toast.success(`تم احتساب إهلاك ${data} أصل بنجاح`);
    },
    onError: (e) => toast.error(e.message),
  });

  const resetForm = () => {
    setEditId(null);
    setForm({ assetType: "شاحنة", name: "", plateNumber: "", purchaseDate: "", purchaseValue: "", usefulLifeYears: "5", notes: "" });
  };

  const openEdit = (asset: any) => {
    setEditId(asset.id);
    setForm({
      assetType: asset.assetType || "شاحنة",
      name: asset.name || "",
      plateNumber: asset.plateNumber || "",
      purchaseDate: asset.purchaseDate || "",
      purchaseValue: String(asset.purchaseValue || "0"),
      usefulLifeYears: String(asset.usefulLifeYears || "5"),
      notes: asset.notes || "",
    });
    setDialogOpen(true);
  };

  const handleSubmit = () => {
    if (!form.name || !form.purchaseValue) {
      toast.error("يرجى ملء اسم الأصل وقيمة الشراء");
      return;
    }
    if (editId) {
      updateMutation.mutate({ id: editId, ...form });
    } else {
      createMutation.mutate(form);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "نشط": return "bg-green-100 text-green-800 border-green-200";
      case "صيانة": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "خارج_الخدمة": return "bg-red-100 text-red-800 border-red-200";
      case "مباع": return "bg-gray-100 text-gray-600 border-gray-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getDefaultCurrencyCode = () => {
    if (systemSettings) {
      const s = systemSettings.find((x: any) => x.key === "defaultCurrency");
      return s?.value || "YER";
    }
    return "YER";
  };

  const totalValue = assets?.reduce((sum, a) => sum + Number(a.purchaseValue), 0) || 0;
  const totalDepr = assets?.reduce((sum, a) => sum + Number(a.accumulatedDepreciation), 0) || 0;
  const totalBook = assets?.reduce((sum, a) => sum + Number(a.bookValue), 0) || 0;

  return (
    <div className="space-y-6 pb-20 md:pb-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 px-1">
        <div>
          <h2 className="text-2xl font-bold">الأصول والإهلاك</h2>
          <p className="text-sm text-muted-foreground mt-1">إدارة الأصول الثابتة وحساب الإهلاك الشهري</p>
        </div>
        <div className="flex gap-2 w-full md:w-auto">
          <Button variant="outline" onClick={() => depreciateMutation.mutate()} className="flex-1 md:flex-none h-12 md:h-10 font-bold border-orange-200 text-orange-700 hover:bg-orange-50">
            <TrendingDown className="h-4 w-4 ml-2" /> احتساب الإهلاك
          </Button>
          <Button onClick={() => { resetForm(); setDialogOpen(true); }} className="flex-1 md:flex-none h-12 md:h-10 font-bold">
            <Plus className="h-5 w-5 ml-2" /> إضافة أصل
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-gray-200 shadow-sm bg-blue-50/30">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center shrink-0">
              <Truck className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-0.5">إجمالي قيمة الأصول</p>
              <p className="text-xl font-black">{totalValue.toLocaleString("en-US")} <span className="text-xs font-normal">{getDefaultCurrencyCode()}</span></p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-gray-200 shadow-sm bg-orange-50/30">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="h-12 w-12 rounded-full bg-orange-100 flex items-center justify-center shrink-0">
              <TrendingDown className="h-6 w-6 text-orange-600" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-0.5">الإهلاك المتراكم</p>
              <p className="text-xl font-black text-orange-600">{totalDepr.toLocaleString("en-US")} <span className="text-xs font-normal">{getDefaultCurrencyCode()}</span></p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-gray-200 shadow-sm bg-green-50/30">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center shrink-0">
              <Wallet className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-0.5">القيمة الدفترية</p>
              <p className="text-xl font-black text-green-600">{totalBook.toLocaleString("en-US")} <span className="text-xs font-normal">{getDefaultCurrencyCode()}</span></p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-gray-200 shadow-sm overflow-hidden">
        <CardHeader className="bg-gray-50/50 p-4 border-b">
          <CardTitle className="text-lg flex items-center gap-2">
            <Info className="h-5 w-5 text-primary" /> قائمة الأصول
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {!assets?.length ? (
            <div className="text-center py-16 text-muted-foreground bg-white">
              <Truck className="h-16 w-16 mx-auto mb-4 opacity-20" />
              <p className="text-lg">لا توجد أصول مسجلة</p>
            </div>
          ) : isMobile ? (
            <div className="divide-y divide-gray-100">
              {assets.map((asset) => (
                <div key={asset.id} className="p-4 bg-white">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="secondary" className="text-[10px]">{asset.assetType}</Badge>
                        <span className="font-bold text-base">{asset.name}</span>
                      </div>
                      <div className="text-xs text-muted-foreground font-mono">{asset.plateNumber || "بدون لوحة"}</div>
                    </div>
                    <Badge className={getStatusColor(asset.status)}>
                      {asset.status === "خارج_الخدمة" ? "خارج الخدمة" : asset.status}
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-y-3 gap-x-4 mb-4 text-sm">
                    <div>
                      <span className="text-muted-foreground text-xs block mb-0.5">قيمة الشراء</span>
                      <span className="font-bold">{Number(asset.purchaseValue).toLocaleString("en-US")}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground text-xs block mb-0.5">القيمة الدفترية</span>
                      <span className="font-bold text-blue-600">{Number(asset.bookValue).toLocaleString("en-US")}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground text-xs block mb-0.5">الإهلاك الشهري</span>
                      <span className="font-bold text-orange-600">{Number(asset.monthlyDepreciation).toLocaleString("en-US")}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground text-xs block mb-0.5">تاريخ الشراء</span>
                      <span className="font-medium">{asset.purchaseDate || "-"}</span>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-2 border-t border-gray-50">
                    <Button variant="outline" size="sm" className="flex-1 h-10 font-bold" onClick={() => openEdit(asset)}>
                      <Pencil className="h-4 w-4 ml-2" /> تعديل
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1 h-10 font-bold text-red-600 border-red-100 hover:bg-red-50" onClick={() => { if(confirm("حذف الأصل؟")) deleteMutation.mutate({ id: asset.id }); }}>
                      <Trash2 className="h-4 w-4 ml-2" /> حذف
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-gray-50">
                  <TableRow>
                    <TableHead className="text-right font-bold">النوع</TableHead>
                    <TableHead className="text-right font-bold">الاسم</TableHead>
                    <TableHead className="text-right font-bold">اللوحة</TableHead>
                    <TableHead className="text-right font-bold">تاريخ الشراء</TableHead>
                    <TableHead className="text-right font-bold">قيمة الشراء</TableHead>
                    <TableHead className="text-right font-bold">العمر</TableHead>
                    <TableHead className="text-right font-bold">الإهلاك الشهري</TableHead>
                    <TableHead className="text-right font-bold">القيمة الدفترية</TableHead>
                    <TableHead className="text-right font-bold">الحالة</TableHead>
                    <TableHead className="text-left font-bold w-24">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {assets.map((asset) => (
                    <TableRow key={asset.id}>
                      <TableCell>{asset.assetType}</TableCell>
                      <TableCell className="font-bold">{asset.name}</TableCell>
                      <TableCell className="font-mono">{asset.plateNumber || "-"}</TableCell>
                      <TableCell>{asset.purchaseDate || "-"}</TableCell>
                      <TableCell>{Number(asset.purchaseValue).toLocaleString("en-US")}</TableCell>
                      <TableCell>{asset.usefulLifeYears} سنة</TableCell>
                      <TableCell className="text-orange-600 font-bold">{Number(asset.monthlyDepreciation).toLocaleString("en-US")}</TableCell>
                      <TableCell className="text-blue-600 font-black">{Number(asset.bookValue).toLocaleString("en-US")}</TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(asset.status)}>
                          {asset.status === "خارج_الخدمة" ? "خارج الخدمة" : asset.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-600" onClick={() => openEdit(asset)}><Pencil className="h-4 w-4" /></Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600" onClick={() => { if(confirm("هل أنت متأكد؟")) deleteMutation.mutate({ id: asset.id }); }}><Trash2 className="h-4 w-4" /></Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg p-6">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">{editId ? "تعديل الأصل" : "إضافة أصل جديد"}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
            <div className="space-y-2">
              <Label className="font-bold">نوع الأصل</Label>
              <Select value={form.assetType} onValueChange={v => setForm({ ...form, assetType: v })}>
                <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {assetTypes.map(t => <SelectItem key={t} value={t} className="text-right">{t}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="font-bold">الاسم *</Label>
              <Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="مثال: شاحنة Isuzu" className="h-12 md:h-10" />
            </div>
            <div className="space-y-2">
              <Label className="font-bold">رقم اللوحة</Label>
              <Input value={form.plateNumber} onChange={e => setForm({ ...form, plateNumber: e.target.value })} className="h-12 md:h-10 font-mono" />
            </div>
            <div className="space-y-2">
              <Label className="font-bold">تاريخ الشراء</Label>
              <Input type="date" value={form.purchaseDate} onChange={e => setForm({ ...form, purchaseDate: e.target.value })} className="h-12 md:h-10 text-right" />
            </div>
            <div className="space-y-2">
              <Label className="font-bold">قيمة الشراء *</Label>
              <Input type="number" value={form.purchaseValue} onChange={e => setForm({ ...form, purchaseValue: e.target.value })} placeholder="0" className="h-12 md:h-10 font-mono" />
            </div>
            <div className="space-y-2">
              <Label className="font-bold">العمر الافتراضي (سنوات)</Label>
              <Input type="number" value={form.usefulLifeYears} onChange={e => setForm({ ...form, usefulLifeYears: e.target.value })} className="h-12 md:h-10 font-mono" />
            </div>
            {editId && (
              <div className="space-y-2 col-span-1 md:col-span-2">
                <Label className="font-bold">الحالة</Label>
                <Select value={""} onValueChange={v => {
                  if (v) updateMutation.mutate({ id: editId!, status: v });
                }}>
                  <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue placeholder="تغيير الحالة" /></SelectTrigger>
                  <SelectContent>
                    {assetStatuses.map(s => <SelectItem key={s} value={s} className="text-right">{s === "خارج_الخدمة" ? "خارج الخدمة" : s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div className="space-y-2 col-span-1 md:col-span-2">
              <Label className="font-bold">ملاحظات</Label>
              <Textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} rows={3} className="text-right" />
            </div>
          </div>
          <div className="flex gap-3 mt-8">
            <Button variant="outline" className="flex-1 h-12 md:h-10" onClick={() => setDialogOpen(false)}>إلغاء</Button>
            <Button className="flex-1 h-12 md:h-10 font-bold" onClick={handleSubmit} disabled={createMutation.isPending || updateMutation.isPending}>
              {editId ? "تحديث البيانات" : "حفظ الأصل"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
