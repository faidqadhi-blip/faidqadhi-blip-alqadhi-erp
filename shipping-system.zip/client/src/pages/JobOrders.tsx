import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Search, Filter, RotateCcw, Calendar, Download, Plus, Pencil, Trash2, Info, ChevronDown, ChevronUp } from "lucide-react";
import { toast } from "sonner";
import { exportToExcel, exportToCSV, exportMultiSheetExcel } from "@/lib/export";
import { useIsMobile } from "@/hooks/useMobile";

const jobTypes = ["تخليص جمركي", "شحن داخلي", "تعبئة وتغليف", "استشارة", "أخرى"];
const priorities = ["عادي", "عاجل", "أولوية"];
const statuses = ["استشارة", "عرض سعر", "مفتوح", "قيد التخليص", "مفروج", "قيد التسليم", "مكتمل", "ملغي"];

export default function JobOrders() {
  const isMobile = useIsMobile();
  const utils = trpc.useUtils();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [selectedClientId, setSelectedClientId] = useState<number | null>(null);
  const [form, setForm] = useState({
    jobType: "تخليص جمركي",
    priority: "عادي",
    notes: "",
  });

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [jobTypeFilter, setJobTypeFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  const { data: jobOrders, isLoading } = trpc.jobOrders.list.useQuery();
  const { data: clients } = trpc.clients.list.useQuery();

  const createMutation = trpc.jobOrders.create.useMutation({
    onSuccess: () => {
      utils.jobOrders.list.invalidate();
      toast.success("تم إنشاء أمر العمل بنجاح");
      setDialogOpen(false);
      resetForm();
    },
    onError: (e) => toast.error(e.message),
  });

  const updateMutation = trpc.jobOrders.update.useMutation({
    onSuccess: () => {
      utils.jobOrders.list.invalidate();
      toast.success("تم تحديث أمر العمل");
      setDialogOpen(false);
      resetForm();
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = trpc.jobOrders.delete.useMutation({
    onSuccess: () => {
      utils.jobOrders.list.invalidate();
      toast.success("تم حذف أمر العمل");
    },
    onError: (e) => toast.error(e.message),
  });

  const resetForm = () => {
    setEditId(null);
    setSelectedClientId(null);
    setForm({ jobType: "تخليص جمركي", priority: "عادي", notes: "" });
  };

  const resetFilters = () => {
    setSearchQuery("");
    setStatusFilter("all");
    setJobTypeFilter("all");
    setPriorityFilter("all");
    setDateFrom("");
    setDateTo("");
  };

  const openEdit = (jo: any) => {
    setEditId(jo.id);
    setSelectedClientId(jo.clientId ?? null);
    setForm({
      jobType: jo.jobType || "تخليص جمركي",
      priority: jo.priority || "عادي",
      notes: jo.notes || "",
    });
    setDialogOpen(true);
  };

  const handleSubmit = () => {
    if (!selectedClientId) {
      toast.error("يرجى اختيار العميل");
      return;
    }
    if (editId) {
      updateMutation.mutate({ id: editId, ...form });
    } else {
      createMutation.mutate({ clientId: selectedClientId, ...form });
    }
  };

  const getClientName = (clientId: number | null) => {
    if (!clientId) return "-";
    const client = clients?.find(c => c.id === clientId);
    return client?.name || "-";
  };

  const filteredOrders = useMemo(() => {
    let result = jobOrders || [];

    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      result = result.filter(jo => {
        const clientName = getClientName(jo.clientId).toLowerCase();
        return jo.jobNumber?.toLowerCase().includes(q) ||
          clientName.includes(q) ||
          jo.notes?.toLowerCase().includes(q) ||
          jo.jobType?.toLowerCase().includes(q);
      });
    }

    if (statusFilter !== "all") result = result.filter(jo => jo.status === statusFilter);
    if (jobTypeFilter !== "all") result = result.filter(jo => jo.jobType === jobTypeFilter);
    if (priorityFilter !== "all") result = result.filter(jo => jo.priority === priorityFilter);

    if (dateFrom) {
      const fromDate = new Date(dateFrom).getTime();
      result = result.filter(jo => jo.createdAt && jo.createdAt.getTime() >= fromDate);
    }
    if (dateTo) {
      const toDate = new Date(dateTo).getTime() + 86400000;
      result = result.filter(jo => jo.createdAt && jo.createdAt.getTime() <= toDate);
    }

    return result;
  }, [jobOrders, searchQuery, statusFilter, jobTypeFilter, priorityFilter, dateFrom, dateTo, clients]);

  const hasActiveFilters = useMemo(() => {
    return searchQuery !== "" || statusFilter !== "all" ||
      jobTypeFilter !== "all" || priorityFilter !== "all" ||
      dateFrom !== "" || dateTo !== "";
  }, [searchQuery, statusFilter, jobTypeFilter, priorityFilter, dateFrom, dateTo]);

  const handleExportExcel = () => {
    const data = filteredOrders.map(jo => ({
      jobNumber: jo.jobNumber,
      clientName: getClientName(jo.clientId),
      jobType: jo.jobType || "-",
      priority: jo.priority || "عادي",
      status: jo.status || "مفتوح",
      createdAtStr: jo.createdAt ? new Date(jo.createdAt).toLocaleDateString('en-US') : "-",
      notes: jo.notes || "",
    }));
    exportToExcel(data, [
      { key: "jobNumber", label: "رقم الأمر" },
      { key: "clientName", label: "العميل" },
      { key: "jobType", label: "نوع العمل" },
      { key: "priority", label: "الأولوية" },
      { key: "status", label: "الحالة" },
      { key: "createdAtStr", label: "التاريخ" },
      { key: "notes", label: "ملاحظات" },
    ], `أوامر_العمل_${new Date().toISOString().split('T')[0]}`);
  };

  const getStatusVariant = (status: string) => {
    switch (status) {
      case "مكتمل": return "default";
      case "قيد التخليص":
      case "قيد التسليم": return "secondary";
      case "ملغي": return "destructive";
      default: return "outline";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "أولوية": return "bg-red-100 text-red-800 border-red-200";
      case "عاجل": return "bg-orange-100 text-orange-800 border-orange-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  return (
    <div className="space-y-6 pb-20 md:pb-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 px-1">
        <div>
          <h2 className="text-2xl font-bold">أوامر العمل</h2>
          <p className="text-sm text-muted-foreground mt-1">إدارة ومتابعة أوامر العمل التشغيلية</p>
        </div>
        <Button onClick={() => { resetForm(); setDialogOpen(true); }} className="h-12 md:h-10 font-bold w-full md:w-auto">
          <Plus className="h-5 w-5 ml-2" /> أمر عمل جديد
        </Button>
      </div>

      <Card className="border-gray-200 shadow-sm overflow-hidden">
        <CardContent className="p-4 md:p-6">
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="بحث بالرقم أو اسم العميل..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="pr-10 h-12 md:h-10 text-right"
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant={showFilters ? "secondary" : "outline"}
                onClick={() => setShowFilters(!showFilters)}
                className="flex-1 md:flex-none h-12 md:h-10 font-bold gap-2"
              >
                <Filter className="w-4 h-4" />
                {isMobile ? "" : (showFilters ? "إخفاء" : "الفلاتر")}
              </Button>
              <Button variant="outline" onClick={handleExportExcel} className="flex-1 md:flex-none h-12 md:h-10 font-bold gap-2">
                <Download className="w-4 h-4" />
                {isMobile ? "" : "تصدير"}
              </Button>
              {hasActiveFilters && (
                <Button variant="ghost" onClick={resetFilters} className="h-12 md:h-10 text-muted-foreground px-2">
                  <RotateCcw className="w-4 h-4" />
                </Button>
              )}
            </div>
          </div>

          {showFilters && (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-4 pt-4 border-t border-gray-100">
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-muted-foreground">الحالة</Label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="h-10 text-right"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all" className="text-right">جميع الحالات</SelectItem>
                    {statuses.map(s => <SelectItem key={s} value={s} className="text-right">{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-muted-foreground">نوع العمل</Label>
                <Select value={jobTypeFilter} onValueChange={setJobTypeFilter}>
                  <SelectTrigger className="h-10 text-right"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all" className="text-right">الكل</SelectItem>
                    {jobTypes.map(t => <SelectItem key={t} value={t} className="text-right">{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-muted-foreground">من تاريخ</Label>
                <Input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} className="h-10 text-right" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-muted-foreground">إلى تاريخ</Label>
                <Input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} className="h-10 text-right" />
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="border-gray-200 shadow-sm overflow-hidden">
        <CardHeader className="bg-gray-50/50 p-4 border-b">
          <CardTitle className="text-lg flex items-center gap-2">
            <Info className="h-5 w-5 text-primary" /> قائمة أوامر العمل
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="text-center py-16 text-muted-foreground">جاري التحميل...</div>
          ) : filteredOrders.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground bg-white">
              <Search className="h-16 w-16 mx-auto mb-4 opacity-20" />
              <p className="text-lg">لا توجد أوامر عمل مطابقة للبحث</p>
            </div>
          ) : isMobile ? (
            <div className="divide-y divide-gray-100">
              {filteredOrders.map((jo) => (
                <div key={jo.id} className="p-4 bg-white">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-bold text-base">{jo.jobNumber}</span>
                        <Badge className={getPriorityColor(jo.priority || "عادي") + " text-[10px]"}>{jo.priority || "عادي"}</Badge>
                      </div>
                      <div className="text-sm font-medium text-blue-600">{getClientName(jo.clientId)}</div>
                    </div>
                    <Badge variant={getStatusVariant(jo.status || "مفتوح")}>
                      {jo.status || "مفتوح"}
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-y-3 gap-x-4 mb-4 text-sm">
                    <div>
                      <span className="text-muted-foreground text-xs block mb-0.5">نوع العمل</span>
                      <span className="font-medium">{jo.jobType || "-"}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground text-xs block mb-0.5">تاريخ الإنشاء</span>
                      <span className="font-medium">{jo.createdAt ? new Date(jo.createdAt).toLocaleDateString('ar-SA') : "-"}</span>
                    </div>
                  </div>

                  {jo.notes && (
                    <div className="mb-4 p-2 bg-gray-50 rounded text-xs text-muted-foreground">
                      {jo.notes}
                    </div>
                  )}

                  <div className="flex gap-2 pt-2 border-t border-gray-50">
                    <Button variant="outline" size="sm" className="flex-1 h-10 font-bold" onClick={() => openEdit(jo)}>
                      <Pencil className="h-4 w-4 ml-2" /> تعديل
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1 h-10 font-bold text-red-600 border-red-100 hover:bg-red-50" onClick={() => { if(confirm("حذف أمر العمل؟")) deleteMutation.mutate({ id: jo.id }); }}>
                      <Trash2 className="h-4 w-4 ml-2" /> حذف
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-gray-50">
                  <TableRow>
                    <TableHead className="text-right font-bold">رقم الأمر</TableHead>
                    <TableHead className="text-right font-bold">العميل</TableHead>
                    <TableHead className="text-right font-bold">نوع العمل</TableHead>
                    <TableHead className="text-right font-bold">الأولوية</TableHead>
                    <TableHead className="text-right font-bold">الحالة</TableHead>
                    <TableHead className="text-right font-bold">التاريخ</TableHead>
                    <TableHead className="text-left font-bold w-24">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredOrders.map((jo) => (
                    <TableRow key={jo.id}>
                      <TableCell className="font-bold">{jo.jobNumber}</TableCell>
                      <TableCell>{getClientName(jo.clientId)}</TableCell>
                      <TableCell>{jo.jobType}</TableCell>
                      <TableCell>
                        <Badge className={getPriorityColor(jo.priority || "عادي")}>{jo.priority || "عادي"}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={getStatusVariant(jo.status || "مفتوح")}>{jo.status || "مفتوح"}</Badge>
                      </TableCell>
                      <TableCell>{jo.createdAt ? new Date(jo.createdAt).toLocaleDateString('ar-SA') : "-"}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-600" onClick={() => openEdit(jo)}><Pencil className="h-4 w-4" /></Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600" onClick={() => { if(confirm("هل أنت متأكد؟")) deleteMutation.mutate({ id: jo.id }); }}><Trash2 className="h-4 w-4" /></Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg p-6">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">{editId ? "تعديل أمر العمل" : "إنشاء أمر عمل جديد"}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 gap-4 mt-4">
            <div className="space-y-2">
              <Label className="font-bold">العميل *</Label>
              <Select value={String(selectedClientId || "")} onValueChange={v => setSelectedClientId(Number(v))}>
                <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue placeholder="اختر العميل" /></SelectTrigger>
                <SelectContent>
                  {clients?.map(c => <SelectItem key={c.id} value={String(c.id)} className="text-right">{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="font-bold">نوع العمل</Label>
                <Select value={form.jobType} onValueChange={v => setForm({ ...form, jobType: v })}>
                  <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {jobTypes.map(t => <SelectItem key={t} value={t} className="text-right">{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="font-bold">الأولوية</Label>
                <Select value={form.priority} onValueChange={v => setForm({ ...form, priority: v })}>
                  <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {priorities.map(p => <SelectItem key={p} value={p} className="text-right">{p}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label className="font-bold">ملاحظات</Label>
              <Textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} rows={4} className="text-right" />
            </div>
          </div>
          <div className="flex gap-3 mt-8">
            <Button variant="outline" className="flex-1 h-12 md:h-10" onClick={() => setDialogOpen(false)}>إلغاء</Button>
            <Button className="flex-1 h-12 md:h-10 font-bold" onClick={handleSubmit} disabled={createMutation.isPending || updateMutation.isPending}>
              {editId ? "تحديث البيانات" : "إنشاء الأمر"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
