import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Plus, Search, Edit2, Trash2, Truck, Filter, Download } from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";

const invoiceTypes = ["تخليص_جمركي", "شحن_داخلي", "تعبئة_وتغليف"] as const;
const statuses = ["جديد", "تم_الترحيل", "مكتمل", "ملغي"] as const;

export default function Shipments() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState({
    clientId: "", invoiceType: "تخليص_جمركي" as typeof invoiceTypes[number],
    entryDate: "", releaseDate: "", driverName: "", routeFrom: "",
    routeTo: "", goodsType: "", customsPort: "", unit: "",
    quantity: "", quantityTons: "", invoiceNumber: "", agriLicense: "", paymentLicense: "",
  });

  const { data: clients } = trpc.clients.list.useQuery();
  const { data: shipments, isLoading, refetch } = trpc.shipments.list.useQuery({
    status: statusFilter === "all" ? undefined : statusFilter,
  });
  const createMutation = trpc.shipments.create.useMutation();
  const updateMutation = trpc.shipments.update.useMutation();
  const deleteMutation = trpc.shipments.delete.useMutation();

  const filtered = useMemo(() => {
    if (!shipments) return [];
    let result = shipments;
    if (search) {
      const s = search.toLowerCase();
      result = result.filter((sh: any) =>
        sh.driverName?.toLowerCase().includes(s) ||
        sh.goodsType?.toLowerCase().includes(s) ||
        sh.routeFrom?.toLowerCase().includes(s) ||
        sh.customsPort?.toLowerCase().includes(s) ||
        String(sh.id).includes(s)
      );
    }
    if (typeFilter !== "all") {
      result = result.filter((sh: any) => sh.invoiceType === typeFilter);
    }
    if (dateFrom) {
      const from = new Date(dateFrom).getTime();
      result = result.filter((sh: any) => {
        const d = sh.createdAt ? new Date(sh.createdAt).getTime() : 0;
        return d >= from;
      });
    }
    if (dateTo) {
      const to = new Date(dateTo).getTime() + 86400000;
      result = result.filter((sh: any) => {
        const d = sh.createdAt ? new Date(sh.createdAt).getTime() : 0;
        return d <= to;
      });
    }
    return result;
  }, [shipments, search, statusFilter, typeFilter, dateFrom, dateTo]);

  const getClientName = (id: number) => clients?.find((c: any) => c.id === id)?.name || "غير معروف";

  const handleSubmit = async () => {
    if (!form.clientId) { toast.error("يرجى اختيار العميل"); return; }
    try {
      const data = {
        clientId: Number(form.clientId),
        invoiceType: form.invoiceType,
        entryDate: form.entryDate || undefined,
        releaseDate: form.releaseDate || undefined,
        driverName: form.driverName || undefined,
        routeFrom: form.routeFrom || undefined,
        routeTo: form.routeTo || undefined,
        goodsType: form.goodsType || undefined,
        customsPort: form.customsPort || undefined,
        unit: form.unit || undefined,
        quantity: form.quantity || undefined,
        quantityTons: form.quantityTons || undefined,
        invoiceNumber: form.invoiceNumber ? Number(form.invoiceNumber) : undefined,
        agriLicense: form.agriLicense || undefined,
        paymentLicense: form.paymentLicense || undefined,
      };
      if (editId) {
        await updateMutation.mutateAsync({ id: editId, ...data });
        toast.success("تم تحديث الشحنة");
      } else {
        await createMutation.mutateAsync(data);
        toast.success("تم إضافة الشحنة");
      }
      resetForm();
      refetch();
    } catch {
      toast.error("حدث خطأ");
    }
  };

  const resetForm = () => {
    setForm({ clientId: "", invoiceType: "تخليص_جمركي", entryDate: "", releaseDate: "", driverName: "", routeFrom: "", routeTo: "", goodsType: "", customsPort: "", unit: "", quantity: "", quantityTons: "", invoiceNumber: "", agriLicense: "", paymentLicense: "" });
    setEditId(null);
    setOpen(false);
  };

  const handleEdit = (sh: any) => {
    setForm({
      clientId: String(sh.clientId), invoiceType: sh.invoiceType,
      entryDate: sh.entryDate || "", releaseDate: sh.releaseDate || "",
      driverName: sh.driverName || "", routeFrom: sh.routeFrom || "",
      routeTo: sh.routeTo || "", goodsType: sh.goodsType || "",
      customsPort: sh.customsPort || "", unit: sh.unit || "",
      quantity: sh.quantity || "", quantityTons: sh.quantityTons || "",
      invoiceNumber: sh.invoiceNumber ? String(sh.invoiceNumber) : "",
      agriLicense: sh.agriLicense || "", paymentLicense: sh.paymentLicense || "",
    });
    setEditId(sh.id);
    setOpen(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm("هل أنت متأكد من حذف هذه الشحنة؟")) return;
    try {
      await deleteMutation.mutateAsync({ id });
      toast.success("تم الحذف");
      refetch();
    } catch { toast.error("حدث خطأ"); }
  };

  const handleExport = () => {
    const headers = ["#", "العميل", "النوع", "السائق", "البضاعة", "المنفذ", "الحالة", "الكمية"];
    const rows = filtered.map((sh: any) => [
      sh.id, getClientName(sh.clientId), sh.invoiceType.replace("_", " "),
      sh.driverName || "-", sh.goodsType || "-", sh.customsPort || "-",
      sh.status.replace("_", " "), sh.quantity || "-",
    ]);
    const csv = [headers.join(","), ...rows.map((r: any) => r.join(","))].join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `shipments_${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    toast.success("تم تصدير التقرير");
  };

  return (
    <div className="space-y-4 pb-20 md:pb-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 px-1">
        <div>
          <h1 className="text-2xl font-bold text-foreground">إدارة الشحنات</h1>
          <p className="text-sm text-muted-foreground mt-1">تسجيل ومتابعة عمليات التخليص والشحن</p>
        </div>
        <Dialog open={open} onOpenChange={(v) => { if (!v) resetForm(); else setOpen(v); }}>
          <DialogTrigger asChild>
            <Button className="w-full md:w-auto h-12 md:h-10 font-bold text-base">
              <Plus className="h-5 w-5 ml-2" />شحنة جديدة
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto p-0 gap-0">
            <DialogHeader className="p-6 pb-2">
              <DialogTitle className="text-xl">{editId ? "تعديل الشحنة" : "تسجيل شحنة جديدة"}</DialogTitle>
            </DialogHeader>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="font-bold">العميل *</Label>
                  <Select value={form.clientId} onValueChange={v => setForm({ ...form, clientId: v })}>
                    <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue placeholder="اختر العميل" /></SelectTrigger>
                    <SelectContent>
                      {clients?.map((c: any) => (
                        <SelectItem key={c.id} value={String(c.id)} className="text-right">{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">نوع الفاتورة</Label>
                  <Select value={form.invoiceType} onValueChange={v => setForm({ ...form, invoiceType: v as any })}>
                    <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {invoiceTypes.map(t => <SelectItem key={t} value={t} className="text-right">{t.replace("_", " ")}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">تاريخ الدخول</Label>
                  <Input value={form.entryDate} onChange={e => setForm({ ...form, entryDate: e.target.value })} type="date" className="h-12 md:h-10" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">تاريخ الإفراج</Label>
                  <Input value={form.releaseDate} onChange={e => setForm({ ...form, releaseDate: e.target.value })} type="date" className="h-12 md:h-10" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">اسم السائق</Label>
                  <Input value={form.driverName} onChange={e => setForm({ ...form, driverName: e.target.value })} className="h-12 md:h-10" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">نوع البضاعة</Label>
                  <Input value={form.goodsType} onChange={e => setForm({ ...form, goodsType: e.target.value })} className="h-12 md:h-10" />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-2">
                    <Label className="font-bold">من</Label>
                    <Input value={form.routeFrom} onChange={e => setForm({ ...form, routeFrom: e.target.value })} className="h-12 md:h-10" />
                  </div>
                  <div className="space-y-2">
                    <Label className="font-bold">إلى</Label>
                    <Input value={form.routeTo} onChange={e => setForm({ ...form, routeTo: e.target.value })} className="h-12 md:h-10" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">المنفذ الجمركي</Label>
                  <Input value={form.customsPort} onChange={e => setForm({ ...form, customsPort: e.target.value })} className="h-12 md:h-10" />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-2">
                    <Label className="font-bold">الوحدة</Label>
                    <Input value={form.unit} onChange={e => setForm({ ...form, unit: e.target.value })} className="h-12 md:h-10" />
                  </div>
                  <div className="space-y-2">
                    <Label className="font-bold">الكمية</Label>
                    <Input value={form.quantity} onChange={e => setForm({ ...form, quantity: e.target.value })} className="h-12 md:h-10" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">الكمية (طن)</Label>
                  <Input value={form.quantityTons} onChange={e => setForm({ ...form, quantityTons: e.target.value })} className="h-12 md:h-10" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">رقم الفاتورة</Label>
                  <Input value={form.invoiceNumber} onChange={e => setForm({ ...form, invoiceNumber: e.target.value })} type="number" className="h-12 md:h-10" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">ترخيص الزراعة</Label>
                  <Input value={form.agriLicense} onChange={e => setForm({ ...form, agriLicense: e.target.value })} className="h-12 md:h-10" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">ترخيص المدفوعات</Label>
                  <Input value={form.paymentLicense} onChange={e => setForm({ ...form, paymentLicense: e.target.value })} className="h-12 md:h-10" />
                </div>
              </div>
              <div className="flex flex-col md:flex-row justify-end gap-3 pt-4 border-t">
                <Button variant="outline" onClick={resetForm} className="h-12 md:h-10 font-bold">إلغاء</Button>
                <Button onClick={handleSubmit} className="h-12 md:h-10 font-bold text-base">{editId ? "تحديث الشحنة" : "حفظ الشحنة"}</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <Card className="shadow-sm border-gray-200">
        <CardContent className="p-4 space-y-4">
          <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-end">
            <div className="flex-1">
              <Label className="font-bold mb-1.5 block">بحث سريع</Label>
              <div className="relative">
                <Search className="absolute right-3 top-3 h-5 w-5 text-gray-400" />
                <Input
                  placeholder="السائق، البضاعة، المنفذ..."
                  className="pr-10 h-12 md:h-10"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
            </div>

            <div className="flex gap-2">
              <div className="flex-1 md:w-40">
                <Label className="font-bold mb-1.5 block text-xs">الحالة</Label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue placeholder="الكل" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all" className="text-right">جميع الحالات</SelectItem>
                    {statuses.map(s => <SelectItem key={s} value={s} className="text-right">{s.replace("_", " ")}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              <Button
                variant="outline"
                onClick={() => setTypeFilter(typeFilter === "all" ? invoiceTypes[0] : "all")}
                className={`h-12 md:h-10 px-3 ${typeFilter !== "all" ? "bg-primary/10 border-primary text-primary" : ""}`}
              >
                <Filter className="h-5 w-5" />
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-3 border-t border-gray-100">
            <div className="col-span-1">
              <Label className="text-[10px] font-bold mb-1 block">من تاريخ</Label>
              <Input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} className="h-10 text-xs" />
            </div>
            <div className="col-span-1">
              <Label className="text-[10px] font-bold mb-1 block">إلى تاريخ</Label>
              <Input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} className="h-10 text-xs" />
            </div>
            <div className="col-span-2 flex items-end gap-2">
              <Button variant="outline" size="sm" onClick={handleExport} disabled={filtered.length === 0} className="flex-1 h-10 font-bold text-xs">
                <Download className="h-4 w-4 ml-2" />تصدير إكسل
              </Button>
              {(search || statusFilter !== "all" || typeFilter !== "all" || dateFrom || dateTo) && (
                <Button variant="ghost" size="sm" onClick={() => { setSearch(""); setStatusFilter("all"); setTypeFilter("all"); setDateFrom(""); setDateTo(""); }} className="h-10 px-2 text-red-500">
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Desktop Table View */}
      <div className="hidden md:block">
        <Card className="shadow-sm border-gray-200 overflow-hidden">
          <Table>
            <TableHeader className="bg-gray-50">
              <TableRow>
                <TableHead className="font-bold text-right">#</TableHead>
                <TableHead className="font-bold text-right">العميل</TableHead>
                <TableHead className="font-bold text-right">النوع</TableHead>
                <TableHead className="font-bold text-right">السائق</TableHead>
                <TableHead className="font-bold text-right">البضاعة</TableHead>
                <TableHead className="font-bold text-right">المنفذ</TableHead>
                <TableHead className="font-bold text-center">الكمية</TableHead>
                <TableHead className="font-bold text-right">الحالة</TableHead>
                <TableHead className="text-left font-bold">الإجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={9} className="text-center py-12">
                    <div className="flex flex-col items-center gap-2">
                      <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
                      <span className="text-muted-foreground">جاري التحميل...</span>
                    </div>
                  </TableCell>
                </TableRow>
              ) : filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} className="text-center py-12 text-muted-foreground italic">
                    لا توجد شحنات مطابقة للبحث
                  </TableCell>
                </TableRow>
              ) : (
                filtered.map((sh: any) => (
                  <TableRow key={sh.id} className="hover:bg-gray-50/50 transition-colors">
                    <TableCell className="font-mono text-xs">{sh.id}</TableCell>
                    <TableCell className="font-bold text-primary">{getClientName(sh.clientId)}</TableCell>
                    <TableCell className="text-[10px] font-medium uppercase">{sh.invoiceType.replace("_", " ")}</TableCell>
                    <TableCell className="text-sm">{sh.driverName || "-"}</TableCell>
                    <TableCell className="text-sm">{sh.goodsType || "-"}</TableCell>
                    <TableCell className="text-sm">{sh.customsPort || "-"}</TableCell>
                    <TableCell className="text-center font-mono font-bold">{sh.quantity || "-"}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                        sh.status === "تم_الترحيل" ? "bg-blue-100 text-blue-700 border border-blue-200" : 
                        sh.status === "مكتمل" ? "bg-green-100 text-green-700 border border-green-200" : 
                        "bg-gray-100 text-gray-700 border border-gray-200"
                      }`}>
                        {sh.status.replace("_", " ")}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex justify-end gap-1">
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => handleEdit(sh)}>
                          <Edit2 className="h-3.5 w-3.5" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500 hover:bg-red-50" onClick={() => handleDelete(sh.id)}>
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </Card>
      </div>

      {/* Mobile Card View */}
      <div className="md:hidden space-y-3">
        {isLoading ? (
          <div className="flex flex-col items-center py-12 gap-3">
            <div className="h-10 w-10 animate-spin rounded-full border-4 border-primary border-t-transparent" />
            <span className="text-muted-foreground">جاري التحميل...</span>
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl border border-dashed border-gray-300 text-muted-foreground">
            لا توجد شحنات مسجلة
          </div>
        ) : (
          filtered.map((sh: any) => (
            <Card key={sh.id} className="shadow-sm border-gray-200 overflow-hidden active:scale-[0.98] transition-transform">
              <div className="bg-gray-50 px-4 py-2 border-b flex justify-between items-center">
                <span className="font-bold text-primary">{getClientName(sh.clientId)}</span>
                <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                  sh.status === "تم_الترحيل" ? "bg-blue-100 text-blue-700" : 
                  sh.status === "مكتمل" ? "bg-green-100 text-green-700" : 
                  "bg-gray-100 text-gray-700"
                }`}>
                  {sh.status.replace("_", " ")}
                </span>
              </div>
              <CardContent className="p-4 space-y-3">
                <div className="grid grid-cols-2 gap-y-3 gap-x-2 text-sm">
                  <div>
                    <p className="text-[10px] text-muted-foreground uppercase font-bold">السائق</p>
                    <p className="font-bold truncate">{sh.driverName || "-"}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-muted-foreground uppercase font-bold">نوع البضاعة</p>
                    <p className="truncate">{sh.goodsType || "-"}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-muted-foreground uppercase font-bold">المسار / المنفذ</p>
                    <p className="truncate text-xs">{sh.routeFrom} ➔ {sh.routeTo} ({sh.customsPort})</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-muted-foreground uppercase font-bold">الكمية</p>
                    <p className="font-bold text-green-700 font-mono">{sh.quantity || "-"} {sh.unit}</p>
                  </div>
                </div>

                <div className="pt-3 border-t flex justify-between items-center">
                  <span className="text-[10px] text-muted-foreground">{sh.createdAt ? new Date(sh.createdAt).toLocaleDateString() : "-"}</span>
                  <div className="flex gap-2">
                    <Button variant="secondary" size="sm" className="h-9 px-4 font-bold" onClick={() => handleEdit(sh)}>تعديل</Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-9 w-9 p-0 text-red-500"
                      onClick={() => handleDelete(sh.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
