import { useState } from "react";
import { trpc } from "@/lib/trpc";
import * as XLSX from 'xlsx';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, Download, Printer } from "lucide-react";
import { toast } from "sonner";

export default function ClearanceReports() {
  const [activeTab, setActiveTab] = useState<string>("declarations");

  const { data: declarations } = trpc.declarations.list.useQuery();
  const { data: allCosts } = trpc.clearanceCosts.list.useQuery();
  const { data: allReceipts } = trpc.clearanceReceipts.list.useQuery();
  const { data: allDisbursements } = trpc.clearanceDisbursements.list.useQuery();
  const { data: clients } = trpc.clients.list.useQuery();
  const { data: evaluations, isLoading: evalLoading } = trpc.evaluations.list.useQuery();
  const { data: jobOrders } = trpc.jobOrders.list.useQuery();

  const getClientName = (clientId: number | null) => {
    if (!clientId) return "-";
    const client = clients?.find(c => c.id === clientId);
    return client?.name || "-";
  };

  const getDeclNumber = (declId: number | null) => {
    if (!declId) return "-";
    const decl = declarations?.find(d => d.id === declId);
    return decl?.declarationNumber || "-";
  };

  const totalReceipts = allReceipts?.reduce((sum: number, r) => sum + Number(r.amount || 0), 0) || 0;
  const totalDisbursements = allDisbursements?.reduce((sum: number, d) => sum + Number(d.amount || 0), 0) || 0;
  const totalCosts = allCosts?.reduce((sum: number, c) => sum + Number(c.netCost || c.totalCost || 0), 0) || 0;

  const tabs = [
    { id: "declarations", label: "تقرير البيانات" },
    { id: "costs", label: "تقرير التكاليف" },
    { id: "receipts", label: "تقرير المقبوضات" },
    { id: "disbursements", label: "تقرير المدفوعات" },
    { id: "profitability", label: "تقرير الربحية" },
    { id: "evaluations", label: "تقييمات العملاء" },
  ];

  const handlePrint = () => {
    window.print();
  };

  const handleExportPDF = () => {
    toast.success("يمكنك استخدام Ctrl+P لحفظ PDF");
    window.print();
  };

  const handleExportExcel = () => {
    const wb = XLSX.utils.book_new();

    // 1. Declarations Sheet
    const declData = (declarations || []).map(d => ({
      "رقم البيان": d.declarationNumber,
      "رقم القيد": d.entryNumber,
      "التاريخ": d.declarationDate || "-",
      "العميل": getClientName(d.clientId),
      "نوع البضاعة": d.goodsType || "-",
      "المنفذ": d.customsPort || "-",
      "رسوم البيان": Number(d.declarationFee || 0),
      "الحالة": d.status
    }));
    const wsDecl = XLSX.utils.json_to_sheet(declData);
    XLSX.utils.book_append_sheet(wb, wsDecl, "البيانات الجمركية");

    // 2. Costs Sheet
    const costsData = (allCosts || []).map(c => ({
      "البيان": getDeclNumber(c.declarationId),
      "رسوم": Number(c.declarationFee || 0),
      "نقل": Number(c.transport || 0),
      "وقود": Number(c.fuel || 0),
      "سائق": Number(c.driverCost || 0),
      "صيانة": Number(c.maintenance || 0),
      "أخرى": Number(c.otherExpenses || 0),
      "نثريات": Number(c.pettyCash || 0),
      "إجمالي": Number(c.totalCost || 0),
      "صافي": Number(c.netCost || 0)
    }));
    const wsCosts = XLSX.utils.json_to_sheet(costsData);
    XLSX.utils.book_append_sheet(wb, wsCosts, "التكاليف");

    // 3. Receipts Sheet
    const receiptsData = (allReceipts || []).map(r => ({
      "البيان": getDeclNumber(r.declarationId),
      "العميل": getClientName(r.clientId),
      "المبلغ": Number(r.amount || 0),
      "العملة": r.currency || "SAR",
      "التاريخ": r.paymentDate || "-",
      "الطريقة": r.paymentMethod || "-"
    }));
    const wsReceipts = XLSX.utils.json_to_sheet(receiptsData);
    XLSX.utils.book_append_sheet(wb, wsReceipts, "المقبوضات");

    // 4. Disbursements Sheet
    const disbursementsData = (allDisbursements || []).map(d => ({
      "البيان": getDeclNumber(d.declarationId),
      "الجهة": d.payee || "-",
      "المبلغ": Number(d.amount || 0),
      "العملة": d.currency || "SAR",
      "التاريخ": d.paymentDate || "-",
      "الطريقة": d.paymentMethod || "-",
      "النوع": d.expenseType || "-"
    }));
    const wsDisb = XLSX.utils.json_to_sheet(disbursementsData);
    XLSX.utils.book_append_sheet(wb, wsDisb, "المدفوعات");

    // 5. Profitability Sheet
    const profitData = (declarations || []).map(decl => {
      const declReceipts = allReceipts?.filter(r => r.declarationId === decl.id).reduce((sum, r) => sum + Number(r.amount || 0), 0) || 0;
      const declCosts = allCosts?.filter(c => c.declarationId === decl.id).reduce((sum, c) => sum + Number(c.netCost || c.totalCost || 0), 0) || 0;
      const declDisbursements = allDisbursements?.filter(d => d.declarationId === decl.id).reduce((sum, d) => sum + Number(d.amount || 0), 0) || 0;
      return {
        "رقم البيان": decl.declarationNumber,
        "العميل": getClientName(decl.clientId),
        "إجمالي المقبوضات": declReceipts,
        "إجمالي التكاليف": declCosts,
        "إجمالي المدفوعات": declDisbursements,
        "صافي الربح/الخسارة": declReceipts - declCosts - declDisbursements
      };
    });
    const wsProfit = XLSX.utils.json_to_sheet(profitData);
    XLSX.utils.book_append_sheet(wb, wsProfit, "الربحية");

    XLSX.writeFile(wb, `تقرير_شامل_التخليص_${new Date().toISOString().split('T')[0]}.xlsx`);
    toast.success("تم تصدير ملف Excel بنجاح");
  };

  return (
    <div className="space-y-4 p-4">
      <h2 className="text-2xl font-bold">تقارير التخليص الجمركي</h2>

      {/* Tabs */}
      <div className="flex gap-1 overflow-x-auto pb-2 scrollbar-hide no-scrollbar -mx-4 px-4 md:mx-0 md:px-0 border-b border-gray-100">
        {tabs.map(tab => (
          <button
            key={tab.id}
            className={`px-4 py-2 whitespace-nowrap rounded-t-lg text-sm font-bold transition-all ${activeTab === tab.id ? "bg-primary/10 text-primary border-b-2 border-primary" : "text-muted-foreground hover:bg-gray-50"}`}
            onClick={() => setActiveTab(tab.id)}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
        <Card className="shadow-sm border-gray-200">
          <CardContent className="p-3 md:p-4 text-center">
            <div className="text-[10px] md:text-sm font-bold text-muted-foreground uppercase">عدد البيانات</div>
            <div className="text-xl md:text-2xl font-black text-primary">{declarations?.length || 0}</div>
          </CardContent>
        </Card>
        <Card className="shadow-sm border-gray-200">
          <CardContent className="p-3 md:p-4 text-center">
            <div className="text-[10px] md:text-sm font-bold text-muted-foreground uppercase">إجمالي المقبوضات</div>
            <div className="text-xl md:text-2xl font-black text-green-600">{totalReceipts.toLocaleString('en-US')}</div>
          </CardContent>
        </Card>
        <Card className="shadow-sm border-gray-200">
          <CardContent className="p-3 md:p-4 text-center">
            <div className="text-[10px] md:text-sm font-bold text-muted-foreground uppercase">إجمالي التكاليف</div>
            <div className="text-xl md:text-2xl font-black text-red-500">{totalCosts.toLocaleString('en-US')}</div>
          </CardContent>
        </Card>
        <Card className="shadow-sm border-gray-200">
          <CardContent className="p-3 md:p-4 text-center">
            <div className="text-[10px] md:text-sm font-bold text-muted-foreground uppercase">صافي الربح</div>
            <div className={`text-xl md:text-2xl font-black ${totalReceipts - totalCosts - totalDisbursements >= 0 ? "text-blue-600" : "text-orange-600"}`}>
              {(totalReceipts - totalCosts - totalDisbursements).toLocaleString('en-US')}
            </div>
          </CardContent>
        </Card>
      </div>

      {activeTab === "declarations" && (
        <Card className="overflow-hidden">
          <CardHeader className="flex flex-col md:flex-row justify-between items-center gap-4 border-b border-gray-100 bg-gray-50/50 p-4">
            <CardTitle className="text-lg font-bold">تقرير البيانات الجمركية</CardTitle>
            <div className="flex gap-2 w-full md:w-auto">
              <Button size="sm" variant="outline" onClick={handleExportExcel} className="flex-1 md:flex-none gap-2">
                <Download className="w-4 h-4" /> Excel
              </Button>
              <Button size="sm" variant="outline" onClick={handleExportPDF} className="flex-1 md:flex-none gap-2">
                <Printer className="w-4 h-4" /> طباعة
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {/* Desktop View */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="p-3 text-right">رقم البيان</th>
                    <th className="p-3 text-right">رقم القيد</th>
                    <th className="p-3 text-right">التاريخ</th>
                    <th className="p-3 text-right">العميل</th>
                    <th className="p-3 text-right">نوع البضاعة</th>
                    <th className="p-3 text-right">المنفذ</th>
                    <th className="p-3 text-right">رسوم البيان</th>
                    <th className="p-3 text-right">الحالة</th>
                  </tr>
                </thead>
                <tbody>
                  {declarations?.map(d => (
                    <tr key={d.id} className="border-t hover:bg-gray-50/50 transition-colors">
                      <td className="p-3 font-bold text-primary">{d.declarationNumber}</td>
                      <td className="p-3">{d.entryNumber}</td>
                      <td className="p-3">{d.declarationDate || "-"}</td>
                      <td className="p-3 font-medium">{getClientName(d.clientId)}</td>
                      <td className="p-3">{d.goodsType || "-"}</td>
                      <td className="p-3">{d.customsPort || "-"}</td>
                      <td className="p-3 font-mono">{Number(d.declarationFee || 0).toLocaleString('en-US')}</td>
                      <td className="p-3"><Badge variant="outline" className="rounded-lg">{d.status}</Badge></td>
                    </tr>
                  ))}
                  {!declarations?.length && (
                    <tr><td colSpan={8} className="text-center text-muted-foreground py-8">لا توجد بيانات</td></tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Mobile View */}
            <div className="md:hidden divide-y divide-gray-100 bg-gray-50/30">
              {declarations?.map(d => (
                <div key={d.id} className="p-4 space-y-3 bg-white">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="text-[10px] text-muted-foreground font-bold uppercase">رقم البيان</div>
                      <div className="font-bold text-primary">{d.declarationNumber}</div>
                    </div>
                    <Badge variant="outline" className="rounded-lg">{d.status}</Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <div className="text-[10px] text-muted-foreground">العميل</div>
                      <div className="font-medium">{getClientName(d.clientId)}</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-muted-foreground">التاريخ</div>
                      <div className="font-medium">{d.declarationDate || "-"}</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-muted-foreground">المنفذ</div>
                      <div className="font-medium">{d.customsPort || "-"}</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-muted-foreground">الرسوم</div>
                      <div className="font-mono font-bold text-blue-600">{Number(d.declarationFee || 0).toLocaleString('en-US')}</div>
                    </div>
                  </div>
                </div>
              ))}
              {!declarations?.length && (
                <div className="text-center text-muted-foreground py-12">لا توجد بيانات</div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === "costs" && (
        <Card>
          <CardHeader className="flex flex-row justify-between items-center">
            <CardTitle>تقرير التكاليف</CardTitle>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={handleExportExcel}>Excel</Button>
              <Button size="sm" variant="outline" onClick={handleExportPDF}>PDF</Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="p-2 text-right">البيان</th>
                    <th className="p-2 text-right">رسوم</th>
                    <th className="p-2 text-right">نقل</th>
                    <th className="p-2 text-right">وقود</th>
                    <th className="p-2 text-right">سائق</th>
                    <th className="p-2 text-right">صيانة</th>
                    <th className="p-2 text-right">أخرى</th>
                    <th className="p-2 text-right">نثريات</th>
                    <th className="p-2 text-right">إجمالي</th>
                    <th className="p-2 text-right">صافي</th>
                  </tr>
                </thead>
                <tbody>
                  {allCosts?.map(c => (
                    <tr key={c.id} className="border-t">
                      <td className="p-2">{getDeclNumber(c.declarationId)}</td>
                      <td className="p-2">{Number(c.declarationFee || 0).toLocaleString('en-US')}</td>
                      <td className="p-2">{Number(c.transport || 0).toLocaleString('en-US')}</td>
                      <td className="p-2">{Number(c.fuel || 0).toLocaleString('en-US')}</td>
                      <td className="p-2">{Number(c.driverCost || 0).toLocaleString('en-US')}</td>
                      <td className="p-2">{Number(c.maintenance || 0).toLocaleString('en-US')}</td>
                      <td className="p-2">{Number(c.otherExpenses || 0).toLocaleString('en-US')}</td>
                      <td className="p-2">{Number(c.pettyCash || 0).toLocaleString('en-US')}</td>
                      <td className="p-2 font-bold">{Number(c.totalCost || 0).toLocaleString('en-US')}</td>
                      <td className="p-2 font-bold text-green-700">{Number(c.netCost || 0).toLocaleString('en-US')}</td>
                    </tr>
                  ))}
                  {!allCosts?.length && (
                    <tr><td colSpan={10} className="text-center text-gray-500 py-4">لا توجد بيانات</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === "receipts" && (
        <Card>
          <CardHeader className="flex flex-row justify-between items-center">
            <CardTitle>تقرير المقبوضات</CardTitle>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={handleExportExcel}>Excel</Button>
              <Button size="sm" variant="outline" onClick={handleExportPDF}>PDF</Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="p-2 text-right">البيان</th>
                    <th className="p-2 text-right">العميل</th>
                    <th className="p-2 text-right">المبلغ</th>
                    <th className="p-2 text-right">العملة</th>
                    <th className="p-2 text-right">التاريخ</th>
                    <th className="p-2 text-right">الطريقة</th>
                  </tr>
                </thead>
                <tbody>
                  {allReceipts?.map(r => (
                    <tr key={r.id} className="border-t">
                      <td className="p-2">{getDeclNumber(r.declarationId)}</td>
                      <td className="p-2">{getClientName(r.clientId)}</td>
                      <td className="p-2 font-bold text-green-700">{Number(r.amount || 0).toLocaleString('en-US')}</td>
                      <td className="p-2">{r.currency || "SAR"}</td>
                      <td className="p-2">{r.paymentDate || "-"}</td>
                      <td className="p-2">{r.paymentMethod || "-"}</td>
                    </tr>
                  ))}
                  {!allReceipts?.length && (
                    <tr><td colSpan={6} className="text-center text-gray-500 py-4">لا توجد بيانات</td></tr>
                  )}
                </tbody>
              </table>
            </div>
            <div className="mt-4 p-3 bg-green-50 rounded text-center">
              <span className="text-sm text-gray-600">إجمالي المقبوضات: </span>
              <span className="text-xl font-bold text-green-700">{totalReceipts.toLocaleString('en-US')}</span>
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === "disbursements" && (
        <Card>
          <CardHeader className="flex flex-row justify-between items-center">
            <CardTitle>تقرير المدفوعات</CardTitle>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={handleExportExcel}>Excel</Button>
              <Button size="sm" variant="outline" onClick={handleExportPDF}>PDF</Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="p-2 text-right">البيان</th>
                    <th className="p-2 text-right">الجهة</th>
                    <th className="p-2 text-right">المبلغ</th>
                    <th className="p-2 text-right">العملة</th>
                    <th className="p-2 text-right">التاريخ</th>
                    <th className="p-2 text-right">الطريقة</th>
                    <th className="p-2 text-right">النوع</th>
                  </tr>
                </thead>
                <tbody>
                  {allDisbursements?.map(d => (
                    <tr key={d.id} className="border-t">
                      <td className="p-2">{getDeclNumber(d.declarationId)}</td>
                      <td className="p-2">{d.payee || "-"}</td>
                      <td className="p-2 font-bold text-red-700">{Number(d.amount || 0).toLocaleString('en-US')}</td>
                      <td className="p-2">{d.currency || "SAR"}</td>
                      <td className="p-2">{d.paymentDate || "-"}</td>
                      <td className="p-2">{d.paymentMethod || "-"}</td>
                      <td className="p-2">{d.expenseType || "-"}</td>
                    </tr>
                  ))}
                  {!allDisbursements?.length && (
                    <tr><td colSpan={7} className="text-center text-gray-500 py-4">لا توجد بيانات</td></tr>
                  )}
                </tbody>
              </table>
            </div>
            <div className="mt-4 p-3 bg-red-50 rounded text-center">
              <span className="text-sm text-gray-600">إجمالي المدفوعات: </span>
              <span className="text-xl font-bold text-red-700">{totalDisbursements.toLocaleString('en-US')}</span>
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === "profitability" && (
        <Card>
          <CardHeader className="flex flex-row justify-between items-center">
            <CardTitle>تقرير الربحية</CardTitle>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={handleExportExcel}>Excel</Button>
              <Button size="sm" variant="outline" onClick={handleExportPDF}>PDF</Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div className="p-4 bg-green-50 rounded text-center">
                <div className="text-sm text-gray-600">إجمالي المقبوضات</div>
                <div className="text-3xl font-bold text-green-700">{totalReceipts.toLocaleString('en-US')}</div>
              </div>
              <div className="p-4 bg-red-50 rounded text-center">
                <div className="text-sm text-gray-600">إجمالي التكاليف والمدفوعات</div>
                <div className="text-3xl font-bold text-red-700">{(totalCosts + totalDisbursements).toLocaleString('en-US')}</div>
              </div>
              <div className={`p-4 rounded text-center ${totalReceipts - totalCosts - totalDisbursements >= 0 ? "bg-blue-50" : "bg-orange-50"}`}>
                <div className="text-sm text-gray-600">صافي الربح/الخسارة</div>
                <div className={`text-3xl font-bold ${totalReceipts - totalCosts - totalDisbursements >= 0 ? "text-blue-700" : "text-orange-700"}`}>
                  {(totalReceipts - totalCosts - totalDisbursements).toLocaleString('en-US')}
                </div>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="p-2 text-right">البيان</th>
                    <th className="p-2 text-right">العميل</th>
                    <th className="p-2 text-right">المقبوضات</th>
                    <th className="p-2 text-right">التكاليف</th>
                    <th className="p-2 text-right">المدفوعات</th>
                    <th className="p-2 text-right">الصافي</th>
                  </tr>
                </thead>
                <tbody>
                  {declarations?.map(decl => {
                    const declReceipts = allReceipts?.filter(r => r.declarationId === decl.id).reduce((sum: number, r) => sum + Number(r.amount || 0), 0) || 0;
                    const declCosts = allCosts?.filter(c => c.declarationId === decl.id).reduce((sum: number, c) => sum + Number(c.netCost || c.totalCost || 0), 0) || 0;
                    const declDisbursements = allDisbursements?.filter(d => d.declarationId === decl.id).reduce((sum: number, d) => sum + Number(d.amount || 0), 0) || 0;
                    const net = declReceipts - declCosts - declDisbursements;
                    return (
                      <tr key={decl.id} className="border-t">
                        <td className="p-2">{decl.declarationNumber}</td>
                        <td className="p-2">{getClientName(decl.clientId)}</td>
                        <td className="p-2 text-green-700 font-bold">{declReceipts.toLocaleString('en-US')}</td>
                        <td className="p-2 text-red-600">{declCosts.toLocaleString('en-US')}</td>
                        <td className="p-2 text-orange-600">{declDisbursements.toLocaleString('en-US')}</td>
                        <td className={`p-2 font-bold ${net >= 0 ? "text-blue-700" : "text-orange-700"}`}>{net.toLocaleString('en-US')}</td>
                      </tr>
                    );
                  })}
                  {!declarations?.length && (
                    <tr><td colSpan={6} className="text-center text-gray-500 py-4">لا توجد بيانات</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === "evaluations" && (
        <Card>
          <CardHeader className="flex flex-row justify-between items-center">
            <CardTitle>تقييمات العملاء</CardTitle>
            <Button size="sm" variant="outline" onClick={handleExportPDF}>تصدير</Button>
          </CardHeader>
          <CardContent>
            {/* Average Rating */}
            <div className="flex items-center gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
              <div className="text-3xl font-bold">
                {evaluations?.length
                  ? (evaluations.reduce((sum, e) => sum + Number(e.rating), 0) / evaluations.length).toFixed(1)
                  : "-"}
              </div>
              <div className="flex gap-0.5">
                {evaluations?.length ? [1, 2, 3, 4, 5].map(i => (
                  <Star key={i} size={18} className={i <= Math.round(evaluations.reduce((sum, e) => sum + Number(e.rating), 0) / evaluations.length) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"} />
                )) : [1,2,3,4,5].map(i => <Star key={i} size={18} className="text-gray-300" />)}
              </div>
              <div className="text-sm text-muted-foreground">متوسط التقييم ({evaluations?.length || 0} تقييم)</div>
            </div>

            {evalLoading ? (
              <div className="text-center py-8 text-muted-foreground">جاري تحميل التقييمات...</div>
            ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="p-2 text-right">رقم أمر العمل</th>
                    <th className="p-2 text-right">العميل</th>
                    <th className="p-2 text-right">التقييم العام</th>
                    <th className="p-2 text-right">سرعة التخليص</th>
                    <th className="p-2 text-right">سلامة البضاعة</th>
                    <th className="p-2 text-right">تعامل السائق</th>
                    <th className="p-2 text-right">ملاحظات</th>
                  </tr>
                </thead>
                <tbody>
                  {evaluations?.map(e => {
                    const job = jobOrders?.find(j => j.id === e.jobOrderId);
                    return (
                      <tr key={e.id} className="border-t">
                        <td className="p-2">{job?.jobNumber || "-"}</td>
                        <td className="p-2">{getClientName(e.clientId)}</td>
                        <td className="p-2 font-bold">{e.rating} / 5</td>
                        <td className="p-2">{e.clearanceSpeed} / 5</td>
                        <td className="p-2">{e.cargoSafety} / 5</td>
                        <td className="p-2">{e.driverHandling} / 5</td>
                        <td className="p-2 text-xs text-gray-500">{e.feedback || "-"}</td>
                      </tr>
                    );
                  })}
                  {!evaluations?.length && (
                    <tr><td colSpan={7} className="text-center text-gray-500 py-4">لا توجد تقييمات</td></tr>
                  )}
                </tbody>
              </table>
            </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
