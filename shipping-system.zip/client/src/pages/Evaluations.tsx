import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, MessageSquare, Plus, Info, Calendar, User } from "lucide-react";
import { toast } from "sonner";
import { useIsMobile } from "@/hooks/useMobile";

export default function Evaluations() {
  const isMobile = useIsMobile();
  const utils = trpc.useUtils();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedJobOrderId, setSelectedJobOrderId] = useState<number | null>(null);
  const [form, setForm] = useState({
    rating: 5,
    clearanceSpeed: 5,
    cargoSafety: 5,
    driverHandling: 5,
    feedback: "",
  });

  const { data: evaluations, isLoading } = trpc.evaluations.list.useQuery();
  const { data: jobOrders } = trpc.jobOrders.list.useQuery();
  const { data: clients } = trpc.clients.list.useQuery();

  const createMutation = trpc.evaluations.create.useMutation({
    onSuccess: () => {
      utils.evaluations.list.invalidate();
      toast.success("تم حفظ التقييم بنجاح");
      setDialogOpen(false);
      resetForm();
    },
    onError: (e) => toast.error(e.message),
  });

  const resetForm = () => {
    setSelectedJobOrderId(null);
    setForm({ rating: 5, clearanceSpeed: 5, cargoSafety: 5, driverHandling: 5, feedback: "" });
  };

  const handleSubmit = () => {
    if (!selectedJobOrderId) {
      toast.error("يرجى اختيار أمر العمل");
      return;
    }
    createMutation.mutate({
      jobOrderId: selectedJobOrderId,
      ...form,
    });
  };

  const getJobOrderInfo = (joId: number | null) => {
    if (!joId) return { number: "-", client: "-" };
    const jo = jobOrders?.find(j => j.id === joId);
    const client = clients?.find(c => c.id === jo?.clientId);
    return { number: jo?.jobNumber || "-", client: client?.name || "-" };
  };

  const StarRating = ({ value, size = 14 }: { value: number, size?: number }) => (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map(i => (
        <Star key={i} size={size} className={i <= value ? "fill-yellow-400 text-yellow-400" : "text-gray-300"} />
      ))}
    </div>
  );

  const avgRating = evaluations?.length 
    ? (evaluations.reduce((sum, e) => sum + Number(e.rating), 0) / evaluations.length).toFixed(1) 
    : "0.0";

  return (
    <div className="space-y-6 pb-20 md:pb-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 px-1">
        <div>
          <h2 className="text-2xl font-bold">تقييمات العملاء</h2>
          <p className="text-sm text-muted-foreground mt-1">آراء العملاء حول جودة الخدمة والأداء</p>
        </div>
        <Button onClick={() => { resetForm(); setDialogOpen(true); }} className="h-12 md:h-10 font-bold w-full md:w-auto">
          <Plus className="h-5 w-5 ml-2" /> إضافة تقييم جديد
        </Button>
      </div>

      {/* Summary Card */}
      <Card className="border-gray-200 shadow-sm overflow-hidden bg-gradient-to-br from-white to-gray-50">
        <CardContent className="p-6 flex flex-col md:flex-row items-center gap-6">
          <div className="flex flex-col items-center justify-center p-6 bg-white rounded-2xl shadow-sm border border-gray-100 min-w-[160px]">
            <div className="text-5xl font-black text-primary mb-2">{avgRating}</div>
            <StarRating value={Math.round(Number(avgRating))} size={24} />
            <p className="text-xs text-muted-foreground mt-2 font-bold">متوسط التقييم العام</p>
          </div>
          <div className="flex-1 w-full space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-4 bg-white rounded-xl border border-gray-100 text-center">
                <span className="text-2xl font-bold block">{evaluations?.length || 0}</span>
                <span className="text-[10px] text-muted-foreground uppercase font-bold">إجمالي التقييمات</span>
              </div>
              <div className="p-4 bg-white rounded-xl border border-gray-100 text-center">
                <span className="text-2xl font-bold block text-green-600">{evaluations?.filter(e => Number(e.rating) >= 4).length || 0}</span>
                <span className="text-[10px] text-muted-foreground uppercase font-bold">ممتاز / جيد جداً</span>
              </div>
              <div className="p-4 bg-white rounded-xl border border-gray-100 text-center">
                <span className="text-2xl font-bold block text-yellow-600">{evaluations?.filter(e => Number(e.rating) === 3).length || 0}</span>
                <span className="text-[10px] text-muted-foreground uppercase font-bold">متوسط</span>
              </div>
              <div className="p-4 bg-white rounded-xl border border-gray-100 text-center">
                <span className="text-2xl font-bold block text-red-600">{evaluations?.filter(e => Number(e.rating) <= 2).length || 0}</span>
                <span className="text-[10px] text-muted-foreground uppercase font-bold">ضعيف</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-gray-200 shadow-sm overflow-hidden">
        <CardHeader className="bg-gray-50/50 p-4 border-b">
          <CardTitle className="text-lg flex items-center gap-2">
            <MessageSquare className="h-5 w-5 text-primary" /> سجل التقييمات التفصيلي
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="text-center py-16 text-muted-foreground">جاري التحميل...</div>
          ) : !evaluations?.length ? (
            <div className="text-center py-16 text-muted-foreground bg-white">
              <Star className="h-16 w-16 mx-auto mb-4 opacity-20" />
              <p className="text-lg">لا توجد تقييمات بعد</p>
            </div>
          ) : isMobile ? (
            <div className="divide-y divide-gray-100">
              {evaluations.map((ev) => {
                const info = getJobOrderInfo(ev.jobOrderId);
                return (
                  <div key={ev.id} className="p-4 bg-white">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-bold text-base">أمر #{info.number}</span>
                          <StarRating value={Number(ev.rating)} />
                        </div>
                        <div className="text-sm font-medium text-blue-600 flex items-center gap-1">
                          <User className="h-3 w-3" /> {info.client}
                        </div>
                      </div>
                      <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {ev.createdAt ? new Date(ev.createdAt).toLocaleDateString("ar-SA") : "-"}
                      </span>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-y-3 gap-x-4 mb-4 text-xs bg-gray-50 p-3 rounded-lg">
                      <div>
                        <span className="text-muted-foreground block mb-1">سرعة التخليص</span>
                        <StarRating value={Number(ev.clearanceSpeed)} />
                      </div>
                      <div>
                        <span className="text-muted-foreground block mb-1">سلامة البضاعة</span>
                        <StarRating value={Number(ev.cargoSafety)} />
                      </div>
                      <div className="col-span-2">
                        <span className="text-muted-foreground block mb-1">تعامل السائق</span>
                        <StarRating value={Number(ev.driverHandling)} />
                      </div>
                    </div>

                    {ev.feedback && (
                      <div className="p-3 border border-dashed border-gray-200 rounded-lg text-xs text-muted-foreground italic relative">
                        <MessageSquare className="h-3 w-3 absolute -top-1.5 -right-1.5 bg-white text-gray-400" />
                        "{ev.feedback}"
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-gray-50">
                  <TableRow>
                    <TableHead className="text-right font-bold">رقم أمر العمل</TableHead>
                    <TableHead className="text-right font-bold">العميل</TableHead>
                    <TableHead className="text-right font-bold">التقييم العام</TableHead>
                    <TableHead className="text-right font-bold">سرعة التخليص</TableHead>
                    <TableHead className="text-right font-bold">سلامة البضاعة</TableHead>
                    <TableHead className="text-right font-bold">تعامل السائق</TableHead>
                    <TableHead className="text-right font-bold">التاريخ</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {evaluations.map((ev) => {
                    const info = getJobOrderInfo(ev.jobOrderId);
                    return (
                      <TableRow key={ev.id}>
                        <TableCell className="font-bold">{info.number}</TableCell>
                        <TableCell>{info.client}</TableCell>
                        <TableCell><StarRating value={Number(ev.rating)} /></TableCell>
                        <TableCell><StarRating value={Number(ev.clearanceSpeed)} /></TableCell>
                        <TableCell><StarRating value={Number(ev.cargoSafety)} /></TableCell>
                        <TableCell><StarRating value={Number(ev.driverHandling)} /></TableCell>
                        <TableCell>{ev.createdAt ? new Date(ev.createdAt).toLocaleDateString("ar-SA") : "-"}</TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg p-6">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">إضافة تقييم جديد</DialogTitle>
          </DialogHeader>
          <div className="space-y-6 mt-4">
            <div className="space-y-2">
              <Label className="font-bold text-sm">أمر العمل المكتمل *</Label>
              <Select value={selectedJobOrderId ? String(selectedJobOrderId) : ""} onValueChange={v => setSelectedJobOrderId(Number(v))}>
                <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue placeholder="اختر أمر العمل" /></SelectTrigger>
                <SelectContent>
                  {jobOrders?.filter(jo => jo.status === "مكتمل").map(jo => (
                    <SelectItem key={jo.id} value={String(jo.id)} className="text-right">
                      {jo.jobNumber} - {clients?.find(c => c.id === jo.clientId)?.name || "-"}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <Label className="font-bold text-xs text-muted-foreground block uppercase tracking-wider">التقييم العام</Label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map(i => (
                    <Star key={i} size={28} className={`cursor-pointer transition-all ${i <= form.rating ? "fill-yellow-400 text-yellow-400 scale-110" : "text-gray-200 hover:text-gray-300"}`}
                      onClick={() => setForm({ ...form, rating: i })} />
                  ))}
                </div>
              </div>
              <div className="space-y-3">
                <Label className="font-bold text-xs text-muted-foreground block uppercase tracking-wider">سرعة التخليص</Label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map(i => (
                    <Star key={i} size={28} className={`cursor-pointer transition-all ${i <= form.clearanceSpeed ? "fill-yellow-400 text-yellow-400 scale-110" : "text-gray-200 hover:text-gray-300"}`}
                      onClick={() => setForm({ ...form, clearanceSpeed: i })} />
                  ))}
                </div>
              </div>
              <div className="space-y-3">
                <Label className="font-bold text-xs text-muted-foreground block uppercase tracking-wider">سلامة البضاعة</Label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map(i => (
                    <Star key={i} size={28} className={`cursor-pointer transition-all ${i <= form.cargoSafety ? "fill-yellow-400 text-yellow-400 scale-110" : "text-gray-200 hover:text-gray-300"}`}
                      onClick={() => setForm({ ...form, cargoSafety: i })} />
                  ))}
                </div>
              </div>
              <div className="space-y-3">
                <Label className="font-bold text-xs text-muted-foreground block uppercase tracking-wider">تعامل السائق</Label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map(i => (
                    <Star key={i} size={28} className={`cursor-pointer transition-all ${i <= form.driverHandling ? "fill-yellow-400 text-yellow-400 scale-110" : "text-gray-200 hover:text-gray-300"}`}
                      onClick={() => setForm({ ...form, driverHandling: i })} />
                  ))}
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="font-bold text-sm">ملاحظات العميل</Label>
              <Textarea value={form.feedback} onChange={e => setForm({ ...form, feedback: e.target.value })} rows={4} placeholder="اكتب هنا أي ملاحظات أو مقترحات للتحسين..." className="text-right resize-none" />
            </div>
          </div>
          <div className="flex gap-3 mt-8">
            <Button variant="outline" className="flex-1 h-12 md:h-10" onClick={() => setDialogOpen(false)}>إلغاء</Button>
            <Button className="flex-1 h-12 md:h-10 font-bold" onClick={handleSubmit} disabled={createMutation.isPending}>حفظ التقييم</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
