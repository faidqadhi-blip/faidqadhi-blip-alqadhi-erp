import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Loader2, Plus, Search, History, Calculator, Download, ArrowLeft } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { exportToExcel, exportMultiSheetExcel } from "@/lib/export";

export default function QuantityDeductions() {
  const utils = trpc.useUtils();
  const [open, setOpen] = useState(false);
  const [deductOpen, setDeductOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDeduction, setSelectedDeduction] = useState<any>(null);
  
  const [form, setForm] = useState({
    referenceNumber: "",
    referenceDate: new Date().toISOString().split("T")[0],
    goodsType: "",
    authority: "",
    totalQuantity: "",
    notes: "",
  });

  const [quantityDeductForm, setQuantityDeductForm] = useState({
    quantityDeductionId: 0,
    declarationNumber: "",
    declarationDate: new Date().toISOString().split("T")[0],
    deductedQuantity: "",
    notes: "",
  });

  const { data: deductions, isLoading } = trpc.quantityDeductions.list.useQuery();
  const { data: details } = trpc.quantityDeductions.listDetails.useQuery(
    selectedDeduction ? selectedDeduction.id : 0,
    { enabled: !!selectedDeduction }
  );

  const createMainMutation = trpc.quantityDeductions.create.useMutation({
    onSuccess: () => {
      utils.quantityDeductions.list.invalidate();
      setOpen(false);
      setForm({
        referenceNumber: "",
        referenceDate: new Date().toISOString().split("T")[0],
        goodsType: "",
        authority: "",
        totalQuantity: "",
        notes: "",
      });
      toast.success("تم تسجيل المرجع بنجاح");
    },
    onError: (e) => toast.error(e.message),
  });

  const createDetailMutation = trpc.quantityDeductions.createDetail.useMutation({
    onSuccess: () => {
      utils.quantityDeductions.list.invalidate();
      utils.quantityDeductions.listDetails.invalidate();
      setDeductOpen(false);
      setQuantityDeductForm({
        quantityDeductionId: 0,
        declarationNumber: "",
        declarationDate: new Date().toISOString().split("T")[0],
        deductedQuantity: "",
        notes: "",
      });
      toast.success("تم تخصيم الكمية بنجاح");
    },
    onError: (e) => toast.error(e.message),
  });

  const filteredDeductions = deductions?.filter((d: any) => {
    return (d.referenceNumber || "").toLowerCase().includes(searchQuery.toLowerCase()) ||
           (d.authority || "").toLowerCase().includes(searchQuery.toLowerCase()) ||
           (d.goodsType || "").toLowerCase().includes(searchQuery.toLowerCase());
  }) || [];

  const handleCreateMain = () => {
    if (!form.referenceNumber || !form.totalQuantity) {
      toast.error("يرجى ملء الحقول المطلوبة (رقم المرجع والكمية)");
      return;
    }
    createMainMutation.mutate(form);
  };

  const handleCreateDetail = () => {
    if (!quantityDeductForm.quantityDeductionId || !quantityDeductForm.declarationNumber || !quantityDeductForm.deductedQuantity) {
      toast.error("يرجى ملء الحقول المطلوبة");
      return;
    }
    createDetailMutation.mutate(quantityDeductForm);
  };

  const handleExportAll = () => {
    if (!filteredDeductions.length) return;
    exportToExcel(
      filteredDeductions,
      [
        { key: "referenceNumber", label: "رقم المرجع" },
        { key: "referenceDate", label: "تاريخ المرجع" },
        { key: "goodsType", label: "نوع البضاعة" },
        { key: "authority", label: "الجهة" },
        { key: "totalQuantity", label: "الكمية الكلية" },
        { key: "remainingQuantity", label: "الكمية المتبقية" },
        { key: "notes", label: "ملاحظات" },
      ],
      "سجل_تخصيم_الكميات"
    );
  };

  const handleExportDetails = () => {
    if (!selectedDeduction || !details) return;
    
    const mainInfo = [{
      referenceNumber: selectedDeduction.referenceNumber,
      goodsType: selectedDeduction.goodsType || "-",
      authority: selectedDeduction.authority || "-",
      totalQuantity: selectedDeduction.totalQuantity,
      remainingQuantity: selectedDeduction.remainingQuantity,
      referenceDate: selectedDeduction.referenceDate,
    }];

    exportMultiSheetExcel(
      [
        {
          sheetName: "معلومات المرجع",
          data: mainInfo,
          columns: [
            { key: "referenceNumber", label: "رقم المرجع" },
            { key: "goodsType", label: "نوع البضاعة" },
            { key: "authority", label: "الجهة" },
            { key: "totalQuantity", label: "الكمية الكلية" },
            { key: "remainingQuantity", label: "الكمية المتبقية" },
            { key: "referenceDate", label: "التاريخ" },
          ]
        },
        {
          sheetName: "سجل التخصيم",
          data: details,
          columns: [
            { key: "declarationNumber", label: "رقم البيان الجمركي" },
            { key: "declarationDate", label: "تاريخ البيان" },
            { key: "deductedQuantity", label: "الكمية المخصمة" },
            { key: "remainingQuantity", label: "الكمية المتبقية" },
            { key: "notes", label: "ملاحظات" },
          ]
        }
      ],
      `تفاصيل_تخصيم_مرجع_${selectedDeduction.referenceNumber}`
    );
  };

  const authorities = ["الزراعة", "التجارة والصناعة", "الأمن", "المواصفات", "الهيئة العليا للأدوية", "أخرى"];
  const ports = ["ميناء عدن", "منفذ شحن", "منفذ الوديعة", "منفذ الطوال", "منفذ حرض", "أخرى"];

  return (
    <div className="space-y-6 pb-20 md:pb-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">تخصيم الكميات</h2>
          <p className="text-sm text-muted-foreground mt-1">متابعة تخصيم الكميات من المراجع (المنافذ والموانئ)</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" className="flex-1 md:flex-none gap-2 h-12 md:h-10" onClick={handleExportAll} disabled={filteredDeductions.length === 0}>
            <Download className="h-4 w-4" /> تصدير السجل
          </Button>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="flex-1 md:flex-none gap-2 h-12 md:h-10"><Plus className="h-4 w-4" /> تسجيل مرجع</Button>
            </DialogTrigger>
            <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
              <DialogHeader><DialogTitle>تسجيل كمية مرجع</DialogTitle></DialogHeader>
              <div className="space-y-5 pt-4">
                <div className="space-y-2">
                  <Label className="font-bold text-sm">رقم المرجع *</Label>
                  <Input 
                    placeholder="رقم مرجع الميناء أو المنفذ" 
                    value={form.referenceNumber} 
                    onChange={(e) => setForm(p => ({ ...p, referenceNumber: e.target.value }))}
                    className="h-12 md:h-10 text-lg"
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="font-bold text-sm">تاريخ المرجع</Label>
                    <Input type="date" value={form.referenceDate} onChange={(e) => setForm(p => ({ ...p, referenceDate: e.target.value }))} className="h-12 md:h-10" />
                  </div>
                  <div className="space-y-2">
                    <Label className="font-bold text-sm">الجهة (المنفذ)</Label>
                    <Select value={form.authority} onValueChange={(v) => setForm(p => ({ ...p, authority: v }))}>
                      <SelectTrigger className="h-12 md:h-10"><SelectValue placeholder="اختر المنفذ" /></SelectTrigger>
                      <SelectContent>
                        {ports.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="font-bold text-sm">نوع البضاعة</Label>
                  <Input 
                    placeholder="مثلاً: قطع غيار، مواد غذائية..." 
                    value={form.goodsType} 
                    onChange={(e) => setForm(p => ({ ...p, goodsType: e.target.value }))}
                    className="h-12 md:h-10"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold text-sm">الكمية *</Label>
                  <Input type="number" value={form.totalQuantity} onChange={(e) => setForm(p => ({ ...p, totalQuantity: e.target.value }))} placeholder="0.00" className="h-12 md:h-10 text-lg" inputMode="decimal" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold text-sm">ملاحظات</Label>
                  <Input value={form.notes} onChange={(e) => setForm(p => ({ ...p, notes: e.target.value }))} className="h-12 md:h-10" />
                </div>
                <Button onClick={handleCreateMain} className="w-full h-12" disabled={createMainMutation.isPending}>حفظ البيانات</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 overflow-hidden">
          <CardHeader className="p-4 md:p-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <CardTitle className="text-lg">سجل المراجع والكميات</CardTitle>
              <div className="relative w-full md:w-64">
                <Search className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input placeholder="بحث..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pr-9 h-10" />
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0 md:p-6">
            {isLoading ? (
              <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>
            ) : filteredDeductions.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">لا توجد بيانات مسجلة</div>
            ) : (
              <>
                {/* Desktop View */}
                <div className="hidden md:block">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>رقم المرجع</TableHead>
                        <TableHead>نوع البضاعة</TableHead>
                        <TableHead>الجهة</TableHead>
                        <TableHead>الكمية الكلية</TableHead>
                        <TableHead>المتبقي</TableHead>
                        <TableHead>التاريخ</TableHead>
                        <TableHead>إجراءات</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredDeductions.map((d: any) => (
                        <TableRow 
                          key={d.id} 
                          className={`cursor-pointer hover:bg-muted/50 ${selectedDeduction?.id === d.id ? 'bg-muted' : ''}`}
                          onClick={() => setSelectedDeduction(d)}
                        >
                          <TableCell className="font-medium">{d.referenceNumber}</TableCell>
                          <TableCell>{d.goodsType || "-"}</TableCell>
                          <TableCell><Badge variant="outline">{d.authority}</Badge></TableCell>
                          <TableCell>{Number(d.totalQuantity).toLocaleString('en-US')}</TableCell>
                          <TableCell className="font-bold text-green-600">{Number(d.remainingQuantity).toLocaleString('en-US')}</TableCell>
                          <TableCell>{d.referenceDate}</TableCell>
                          <TableCell className="flex gap-1" onClick={e => e.stopPropagation()}>
                            <Button variant="ghost" size="sm" onClick={() => {
                              setSelectedDeduction(d);
                              setQuantityDeductForm(prev => ({ ...prev, quantityDeductionId: d.id }));
                              setDeductOpen(true);
                            }} title="تخصيم كمية">
                              <Calculator className="h-4 w-4 text-green-600" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                {/* Mobile View */}
                <div className="md:hidden space-y-2 p-4">
                  {filteredDeductions.map((d: any) => (
                    <div 
                      key={d.id} 
                      className={`p-4 rounded-xl border transition-all ${selectedDeduction?.id === d.id ? 'bg-primary/5 border-primary shadow-sm' : 'bg-card border-border'}`}
                      onClick={() => setSelectedDeduction(d)}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <div className="text-[10px] text-muted-foreground uppercase font-bold">رقم المرجع</div>
                          <div className="font-bold text-lg">{d.referenceNumber}</div>
                        </div>
                        <Badge variant="outline" className="bg-white">{d.authority}</Badge>
                      </div>
                      <div className="grid grid-cols-2 gap-y-3 gap-x-2 text-sm">
                        <div>
                          <div className="text-[10px] text-muted-foreground">البضاعة</div>
                          <div className="font-medium truncate">{d.goodsType || "-"}</div>
                        </div>
                        <div>
                          <div className="text-[10px] text-muted-foreground">التاريخ</div>
                          <div className="font-medium">{d.referenceDate}</div>
                        </div>
                        <div className="bg-muted/30 p-2 rounded-lg">
                          <div className="text-[10px] text-muted-foreground">الكمية الكلية</div>
                          <div className="font-bold">{Number(d.totalQuantity).toLocaleString('en-US')}</div>
                        </div>
                        <div className="bg-green-50 p-2 rounded-lg border border-green-100">
                          <div className="text-[10px] text-green-600">المتبقي</div>
                          <div className="font-bold text-green-700">{Number(d.remainingQuantity).toLocaleString('en-US')}</div>
                        </div>
                      </div>
                      <div className="mt-3 pt-3 border-t flex justify-end gap-2">
                        <Button 
                          variant="secondary" 
                          size="sm" 
                          className="h-9 gap-1"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedDeduction(d);
                            setQuantityDeductForm(prev => ({ ...prev, quantityDeductionId: d.id }));
                            setDeductOpen(true);
                          }}
                        >
                          <Calculator className="h-4 w-4" /> تخصيم كمية
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </CardContent>
        </Card>

        <div className="space-y-6">
          {selectedDeduction ? (
            <Card className="border-primary/20 shadow-md">
              <CardHeader className="pb-3 bg-primary/5 p-4 md:p-6">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <History className="h-5 w-5 text-primary" /> سجل التخصيم
                  </CardTitle>
                  <Button variant="ghost" size="sm" onClick={handleExportDetails} title="تصدير التفاصيل" className="h-8 w-8 p-0">
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
                <div className="mt-2 text-sm">
                  المرجع: <span className="font-bold text-primary">{selectedDeduction.referenceNumber}</span>
                </div>
              </CardHeader>
              <CardContent className="p-4 md:p-6">
                {!details || details.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground text-sm border-2 border-dashed rounded-xl">
                    لا توجد عمليات تخصيم لهذا المرجع
                  </div>
                ) : (
                  <div className="space-y-3">
                    {details.map((s: any) => (
                      <div key={s.id} className="p-4 border rounded-xl space-y-3 bg-muted/20 relative overflow-hidden">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="text-[10px] text-muted-foreground font-bold">رقم البيان الجمركي</div>
                            <div className="text-sm font-bold">{s.declarationNumber}</div>
                          </div>
                          <div className="text-left">
                            <div className="text-[10px] text-muted-foreground">التاريخ</div>
                            <div className="text-xs">{s.declarationDate}</div>
                          </div>
                        </div>
                        <div className="flex justify-between items-center pt-2 border-t border-border/50">
                          <div>
                            <div className="text-[10px] text-muted-foreground">الكمية المخصمة</div>
                            <div className="text-sm font-bold text-red-600">-{Number(s.deductedQuantity).toLocaleString('en-US')}</div>
                          </div>
                          <div className="text-left">
                            <div className="text-[10px] text-muted-foreground">المتبقي</div>
                            <div className="text-sm font-bold text-green-600">{Number(s.remainingQuantity).toLocaleString('en-US')}</div>
                          </div>
                        </div>
                        {s.notes && (
                          <div className="text-[11px] text-muted-foreground bg-white/60 p-2 rounded-lg mt-1 border border-border/20">
                            {s.notes}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          ) : (
            <Card className="bg-muted/10 border-dashed hidden md:block">
              <CardContent className="py-12 text-center text-muted-foreground">
                <Calculator className="h-12 w-12 mx-auto mb-4 opacity-10" />
                اختر مرجعاً من الجدول لعرض سجل التخصيم الخاص به
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      <Dialog open={deductOpen} onOpenChange={setDeductOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>تخصيم كمية من المرجع</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div className="p-3 bg-primary/5 rounded-lg border border-primary/10">
              <div className="text-sm text-muted-foreground">رقم المرجع: <span className="font-bold text-foreground">{selectedDeduction?.referenceNumber}</span></div>
              <div className="text-sm text-muted-foreground">الكمية المتاحة: <span className="font-bold text-green-600">{Number(selectedDeduction?.remainingQuantity).toLocaleString('en-US')}</span></div>
            </div>
            
            <div className="space-y-2">
              <Label>رقم البيان الجمركي *</Label>
              <Input 
                placeholder="رقم البيان الجمركي المخصم له" 
                value={quantityDeductForm.declarationNumber} 
                onChange={(e) => setQuantityDeductForm(p => ({ ...p, declarationNumber: e.target.value }))}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>تاريخ البيان</Label>
                <Input type="date" value={quantityDeductForm.declarationDate} onChange={(e) => setQuantityDeductForm(p => ({ ...p, declarationDate: e.target.value }))} />
              </div>
              <div className="space-y-2">
                <Label>الكمية المخصمة *</Label>
                <Input 
                  type="number" 
                  value={quantityDeductForm.deductedQuantity} 
                  onChange={(e) => setQuantityDeductForm(p => ({ ...p, deductedQuantity: e.target.value }))} 
                  placeholder="0.00"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label>ملاحظات</Label>
              <Input value={quantityDeductForm.notes} onChange={(e) => setQuantityDeductForm(p => ({ ...p, notes: e.target.value }))} />
            </div>
            
            <Button onClick={handleCreateDetail} className="w-full" disabled={createDetailMutation.isPending}>تأكيد التخصيم</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
