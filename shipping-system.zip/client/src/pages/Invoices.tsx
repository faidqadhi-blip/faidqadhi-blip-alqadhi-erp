import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Plus, Search, FileText, Printer, Download, Eye, Hash, User, Calendar, Wallet, MoreVertical, Edit2, Loader2 } from "lucide-react";
import { useState, useMemo, useEffect } from "react";
import { toast } from "sonner";
import { getDefaultCurrency } from "@/lib/currency";
import { useIsMobile } from "@/hooks/useMobile";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const invoiceTypes = ["تخليص_جمركي", "شحن_داخلي", "تعبئة_وتغليف"] as const;
const statuses = ["مسودة", "معتمدة", "مدفوعة_جزئياً", "مدفوعة", "ملغاة"] as const;

// تحويل الأرقام إلى كلمات عربية
function numberToArabicWords(num: number): string {
  if (num === 0) return "صفر";
  const ones = ["", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة"];
  const tens = ["", "عشرة", "عشرون", "ثلاثون", "أربعون", "خمسون", "ستون", "سبعون", "ثمانون", "تسعون"];
  const teens = ["عشرة", "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر", "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر"];
  let result = "";
  if (num >= 1000000) {
    const millions = Math.floor(num / 1000000);
    result += numberToArabicWords(millions) + " مليون ";
    num = num % 1000000;
  }
  if (num >= 1000) {
    const thousands = Math.floor(num / 1000);
    if (thousands === 1) result += "ألف ";
    else if (thousands === 2) result += "ألفين ";
    else result += numberToArabicWords(thousands) + " ألف ";
    num = num % 1000;
  }
  if (num >= 100) {
    const hundreds = Math.floor(num / 100);
    if (hundreds === 1) result += "مائة ";
    else if (hundreds === 2) result += "مائتان ";
    else if (hundreds >= 3) result += numberToArabicWords(hundreds).replace("ثمانية", "ثمان") + "مائة ";
    num = num % 100;
  }
  if (num > 0) {
    if (num < 10) result += ones[num];
    else if (num < 20) result += teens[num - 10];
    else {
      const t = Math.floor(num / 10);
      const o = num % 10;
      if (o > 0) result += ones[o] + " و" + tens[t];
      else result += tens[t];
    }
  }
  return result.trim();
}

function generateInvoiceHTML(inv: any, clientName: string, currencyName: string, invDate: string) {
  const total = Number(inv.totalAmount || 0);
  const itemsText = inv.items || inv.serviceName || "خدمات تخليص جمركي";
  return `
    <div class="bg-white p-6" style="direction: rtl; font-family: 'Tajawal', Arial, sans-serif;">
      <div class="flex justify-between items-start mb-4 pb-3" style="border-bottom: 2px solid #444;">
        <div class="text-right" style="flex:1;">
          <p class="font-bold" style="font-size:14px; margin:0;">فيدل القاضي للتخليص الجمركي</p>
          <p style="font-size:12px; color:#666; margin:2px 0;">- مكتب صنعاء الرئيسي -</p>
          <p style="font-size:12px; color:#666; margin:2px 0;">الجمهورية اليمنية</p>
        </div>
        <div class="text-center" style="flex:1;">
          <img src="/manus-storage/faidal-logo_11e2a37b.png" alt="Logo" style="height:80px; margin:0 auto; display:block;" />
          <p style="font-size:11px; color:#999; margin:2px 0;">للتخليص الجمركي والخدمات اللوجستية</p>
        </div>
        <div class="text-left" style="flex:1;">
          <p class="font-bold" style="font-size:14px; margin:0;">FAIDAL AL-QADHI OFFICE</p>
          <p style="font-size:12px; color:#666; margin:2px 0;">- SANA'A MAIN OFFICE -</p>
          <p style="font-size:12px; color:#666; margin:2px 0;">REPUBLIC OF YEMEN</p>
        </div>
      </div>

      <div class="text-center mb-4">
        <h1 class="font-bold" style="font-size:20px; margin:0; text-decoration:underline;">فاتورة خدمة التخليص</h1>
      </div>

      <div class="mb-4" style="border:1px solid #999; display:flex;">
        <div class="px-3 py-2 font-bold text-center" style="width:128px; border-left:1px solid #999; font-size:13px;">التفاصيل</div>
        <div class="flex-1 text-center py-2" style="font-size:13px;">${itemsText}</div>
      </div>

      <div class="mb-4" style="border:1px solid #999;">
        <div class="flex text-white font-bold" style="background:#4a6d7a; font-size:13px;">
          <div class="flex-1 text-center py-1.5" style="border-left:1px solid #6a8a9a;">رقم الفاتورة</div>
          <div class="flex-1 text-center py-1.5" style="border-left:1px solid #6a8a9a;">التاريخ</div>
          <div class="flex-1 text-center py-1.5">طريقة الدفع</div>
        </div>
        <div class="flex" style="font-size:13px;">
          <div class="flex-1 text-center py-1.5" style="border-left:1px solid #ccc;">#${inv.number}</div>
          <div class="flex-1 text-center py-1.5" style="border-left:1px solid #ccc;">${invDate}</div>
          <div class="flex-1 text-center py-1.5">آجل</div>
        </div>
      </div>

      <div class="mb-4 pb-3" style="display:grid; grid-template-columns:1fr 1fr; gap:16px; border-bottom:1px solid #999; font-size:13px;">
        <div><span style="color:#666;">اسم العميل: </span><span class="font-bold">${clientName}</span></div>
        <div><span style="color:#666;">نوع الخدمة: </span><span class="font-bold">${inv.invoiceType.replace("_", " ")}</span></div>
      </div>

      <div class="mb-4" style="border:1px solid #999;">
        <div class="flex text-white font-bold" style="background:#4a6d7a; font-size:13px;">
          <div class="text-center py-1.5 font-medium" style="flex:2; border-left:1px solid #6a8a9a;">تفاصيل العملية</div>
          <div class="flex-1 text-center py-1.5" style="border-left:1px solid #6a8a9a;">العدد</div>
          <div class="flex-1 text-center py-1.5" style="border-left:1px solid #6a8a9a;">نوع الخدمة</div>
          <div class="flex-1 text-center py-1.5" style="border-left:1px solid #6a8a9a;">التكلفة</div>
          <div class="flex-1 text-center py-1.5" style="border-left:1px solid #6a8a9a;">العملة</div>
          <div class="flex-1 text-center py-1.5">الإجمالي</div>
        </div>
        <div class="flex border-b" style="font-size:13px; border-color:#eee;">
          <div class="text-center py-2 font-medium" style="flex:2; border-left:1px solid #ccc;">${itemsText}</div>
          <div class="flex-1 text-center py-2" style="border-left:1px solid #ccc;">1</div>
          <div class="flex-1 text-center py-2" style="border-left:1px solid #ccc;">خدمة</div>
          <div class="flex-1 text-center py-2 font-bold" style="border-left:1px solid #ccc;">${total.toLocaleString('en-US')}</div>
          <div class="flex-1 text-center py-2" style="border-left:1px solid #ccc;">ر.ي</div>
          <div class="flex-1 text-center py-2 font-bold">${total.toLocaleString('en-US')}</div>
        </div>
      </div>

      <div class="mb-4" style="border:1px solid #999; max-width:300px; margin-left:auto;">
        <div class="flex" style="background:#f0f0f0; font-size:13px;">
          <div class="flex-1 text-center py-2 font-bold" style="border-left:1px solid #ccc;">صافي التكلفة</div>
          <div class="flex-1 text-center py-2 font-bold">${total.toLocaleString('en-US')}</div>
        </div>
      </div>

      <div class="px-4 py-2 mb-6" style="border:1px solid #999; background:#f9f9f9; font-size:13px;">
        <strong>المبلغ كتابةً:</strong> ${numberToArabicWords(total)} ريال يمني فقط لا غير
      </div>

      <div class="flex justify-between mt-10" style="font-size:13px;">
        <div><span class="font-bold">المحاسب : </span><span>............................</span></div>
        <div><span class="font-bold">توقيع المستلم: </span><span>............................</span></div>
      </div>
    </div>
  `;
}

export default function Invoices() {
  const isMobile = useIsMobile();
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState({
    clientId: "", invoiceType: "تخليص_جمركي" as typeof invoiceTypes[number],
    date: new Date().toISOString().split("T")[0], totalAmount: "", items: "", notes: "",
    currency: "YER",
    status: "مسودة" as typeof statuses[number],
  });

  const { data: clients } = trpc.clients.list.useQuery();
  const { data: invoices, isLoading, refetch } = trpc.invoices.list.useQuery();
  const { data: nextNumber } = trpc.invoices.nextNumber.useQuery();
  const { data: systemSettings } = trpc.settings.getAll.useQuery();
  const createMutation = trpc.invoices.create.useMutation();
  const updateMutation = trpc.invoices.update.useMutation();
  const { data: currencies } = trpc.currencies.list.useQuery();

  useEffect(() => {
    if (systemSettings) {
      const defaultCurr = getDefaultCurrency(systemSettings);
      setForm(p => ({ ...p, currency: defaultCurr }));
    }
  }, [systemSettings]);

  const filtered = useMemo(() => {
    if (!invoices) return [];
    if (!search) return invoices;
    const s = search.toLowerCase();
    return invoices.filter((inv: any) => {
      const clientName = clients?.find((c: any) => c.id === inv.clientId)?.name?.toLowerCase() || "";
      return String(inv.number).includes(s) || clientName.includes(s);
    });
  }, [invoices, search, clients]);

  const getClientName = (id: number | null | undefined) => {
    if (!id) return "غير معروف";
    return clients?.find((c: any) => c.id === id)?.name || "غير معروف";
  };

  const getCurrencyNameFn = (code: string | null | undefined) => {
    const c = currencies?.find((c: any) => c.code === code);
    return c?.name || code || "YER";
  };

  const invoiceDate = (date: string | null | undefined) => {
    if (!date) return "-";
    return new Date(date).toLocaleDateString("ar-SA", { year: "numeric", month: "long", day: "numeric" });
  };

  const handleSubmit = async () => {
    if (!form.clientId) { toast.error("يرجى اختيار العميل"); return; }
    try {
      const data = {
        number: editId ? (filtered.find((i: any) => i.id === editId) as any)?.number || 0 : nextNumber || 1,
        clientId: Number(form.clientId),
        invoiceType: form.invoiceType,
        date: form.date || undefined,
        totalAmount: form.totalAmount || "0",
        items: form.items || undefined,
        notes: form.notes || undefined,
        currency: form.currency,
        status: form.status,
      };
      if (editId) {
        await updateMutation.mutateAsync({ id: editId, ...data });
        toast.success("تم تحديث الفاتورة");
      } else {
        await createMutation.mutateAsync(data);
        toast.success("تم إنشاء الفاتورة");
      }
      resetForm();
      refetch();
    } catch { toast.error("حدث خطأ"); }
  };

  const resetForm = () => {
    setForm({ clientId: "", invoiceType: "تخليص_جمركي", date: new Date().toISOString().split("T")[0], totalAmount: "", items: "", notes: "", currency: "YER", status: "مسودة" });
    setEditId(null);
    setOpen(false);
  };

  const openEdit = (inv: any) => {
    setEditId(inv.id);
    setForm({
      clientId: String(inv.clientId),
      invoiceType: inv.invoiceType,
      date: inv.date || "",
      totalAmount: String(inv.totalAmount),
      items: inv.items || "",
      notes: inv.notes || "",
      currency: inv.currency || "YER",
      status: inv.status || "مسودة",
    });
    setOpen(true);
  };

  const handlePrint = (inv: any) => {
    const clientName = getClientName(inv.clientId);
    const currName = getCurrencyNameFn(inv.currency);
    const invDateStr = invoiceDate(inv.date);
    const html = generateInvoiceHTML(inv, clientName, currName, invDateStr);
    const printWindow = window.open("", "_blank", "width=800,height=600");
    if (!printWindow) { toast.error("يرجى السماح بفتح النوافذ المنبثقة"); return; }
    printWindow.document.write(`
      <!DOCTYPE html><html dir="rtl"><head><meta charset="UTF-8"><title>فاتورة رقم ${inv.number}</title>
      <style>* { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Tajawal', Arial, sans-serif; }
      body { padding: 15mm; font-size: 13px; color: #333; }
      @media print { body { padding: 10mm; } }</style></head>
      <body>${html}</body></html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

  const handleExportPDF = async (inv: any) => {
    const clientName = getClientName(inv.clientId);
    const currName = getCurrencyNameFn(inv.currency);
    const invDateStr = invoiceDate(inv.date);
    const html = generateInvoiceHTML(inv, clientName, currName, invDateStr);
    let container: HTMLDivElement | null = null;
    try {
      toast.loading("جاري إنشاء ملف PDF...");
      container = document.createElement("div");
      container.style.cssText = "position:fixed;left:-9999px;top:0;width:800px;z-index:-1;direction:rtl;font-family:'Tajawal',sans-serif;";
      const parser = new DOMParser();
      const doc = parser.parseFromString(`<html dir="rtl"><body>${html}</body></html>`, "text/html");
      container.innerHTML = doc.body.innerHTML;
      document.body.appendChild(container);
      await new Promise(r => setTimeout(r, 800));
      const html2canvas = (await import("html2canvas")).default;
      const { jsPDF } = await import("jspdf");
      const canvas = await html2canvas(container, { scale: 2, useCORS: true, logging: false });
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF("p", "mm", "a4");
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      const imgWidth = canvas.width;
      const imgHeight = canvas.height;
      const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);
      const imgX = (pdfWidth - imgWidth * ratio) / 2;
      pdf.addImage(imgData, "PNG", imgX, 10, imgWidth * ratio, imgHeight * ratio);
      pdf.save(`invoice_${inv.number}.pdf`);
      document.body.removeChild(container);
      toast.dismiss();
      toast.success("تم تصدير الفاتورة بصيغة PDF");
    } catch {
      if (container && container.parentNode) document.body.removeChild(container);
      toast.dismiss();
      toast.error("حدث خطأ أثناء إنشاء PDF");
    }
  };

  const statusColors: Record<string, string> = {
    "مسودة": "bg-gray-500/10 text-gray-600 border-gray-200",
    "معتمدة": "bg-blue-500/10 text-blue-600 border-blue-200",
    "مدفوعة_جزئياً": "bg-orange-500/10 text-orange-600 border-orange-200",
    "مدفوعة": "bg-green-500/10 text-green-600 border-green-200",
    "ملغاة": "bg-red-500/10 text-red-600 border-red-200",
  };

  return (
    <div className="space-y-4 pb-20 md:pb-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 px-1">
        <div>
          <h1 className="text-2xl font-bold">الفواتير</h1>
          <p className="text-sm text-muted-foreground mt-1">إنشاء وإدارة فواتير الخدمات</p>
        </div>
        <Dialog open={open} onOpenChange={(v) => { if (!v) resetForm(); else setOpen(v); }}>
          <DialogTrigger asChild>
            <Button className="w-full md:w-auto h-12 md:h-10 font-bold text-base gap-2">
              <Plus className="h-5 w-5" /> فاتورة جديدة
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl p-0 gap-0 overflow-hidden">
            <DialogHeader className="p-6 pb-2">
              <DialogTitle className="text-xl">{editId ? "تعديل فاتورة" : "إنشاء فاتورة جديدة"}</DialogTitle>
            </DialogHeader>
            <div className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="font-bold">العميل *</Label>
                  <Select value={form.clientId} onValueChange={(v) => setForm(p => ({ ...p, clientId: v }))}>
                    <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue placeholder="اختر العميل" /></SelectTrigger>
                    <SelectContent>
                      {clients?.map(c => (
                        <SelectItem key={c.id} value={String(c.id)} className="text-right">{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">نوع الفاتورة</Label>
                  <Select value={form.invoiceType} onValueChange={(v: any) => setForm(p => ({ ...p, invoiceType: v }))}>
                    <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {invoiceTypes.map(t => (
                        <SelectItem key={t} value={t} className="text-right">{t.replace("_", " ")}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">التاريخ</Label>
                  <Input type="date" value={form.date} onChange={(e) => setForm(p => ({ ...p, date: e.target.value }))} className="h-12 md:h-10" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">الحالة</Label>
                  <Select value={form.status} onValueChange={(v: any) => setForm(p => ({ ...p, status: v }))}>
                    <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {statuses.map(s => (
                        <SelectItem key={s} value={s} className="text-right">{s.replace("_", " ")}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">المبلغ الإجمالي *</Label>
                  <Input type="number" value={form.totalAmount} onChange={(e) => setForm(p => ({ ...p, totalAmount: e.target.value }))} className="h-12 md:h-10 text-left font-mono" placeholder="0.00" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">العملة</Label>
                  <Select value={form.currency} onValueChange={(v) => setForm(p => ({ ...p, currency: v }))}>
                    <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="YER" className="text-right">ريال يمني</SelectItem>
                      <SelectItem value="SAR" className="text-right">ريال سعودي</SelectItem>
                      <SelectItem value="USD" className="text-right">دولار أمريكي</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2 col-span-1 md:col-span-2">
                  <Label className="font-bold">تفاصيل الخدمات</Label>
                  <Input value={form.items} onChange={(e) => setForm(p => ({ ...p, items: e.target.value }))} className="h-12 md:h-10" placeholder="وصف مختصر للخدمات المقدمة" />
                </div>
                <div className="space-y-2 col-span-1 md:col-span-2">
                  <Label className="font-bold">ملاحظات</Label>
                  <Input value={form.notes} onChange={(e) => setForm(p => ({ ...p, notes: e.target.value }))} className="h-12 md:h-10" />
                </div>
              </div>
              <div className="flex flex-col md:flex-row justify-end gap-3 pt-4 border-t">
                <Button variant="outline" onClick={resetForm} className="h-12 md:h-10 font-bold">إلغاء</Button>
                <Button onClick={handleSubmit} className="h-12 md:h-10 font-bold text-base px-8">
                  {editId ? "حفظ التعديلات" : "إصدار الفاتورة"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="shadow-sm border-gray-200">
        <CardHeader className="p-4 pb-2">
          <div className="relative">
            <Search className="absolute right-3 top-3 h-5 w-5 text-gray-400" />
            <Input
              placeholder="ابحث برقم الفاتورة أو اسم العميل..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pr-10 h-12 md:h-10 w-full"
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex flex-col items-center py-12 gap-3">
              <Loader2 className="h-10 w-10 animate-spin text-primary" />
              <span className="text-muted-foreground">جاري تحميل الفواتير...</span>
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-12 flex flex-col items-center gap-3">
              <FileText className="h-16 w-16 text-gray-200" />
              <p className="text-muted-foreground">{search ? "لا توجد نتائج مطابقة" : "لا توجد فواتير مسجلة"}</p>
            </div>
          ) : (
            <>
              {/* Desktop Table */}
              <div className="hidden md:block overflow-x-auto">
                <Table>
                  <TableHeader className="bg-gray-50">
                    <TableRow>
                      <TableHead className="text-right font-bold w-24">الرقم</TableHead>
                      <TableHead className="text-right font-bold">العميل</TableHead>
                      <TableHead className="text-right font-bold w-32">التاريخ</TableHead>
                      <TableHead className="text-right font-bold w-32">الإجمالي</TableHead>
                      <TableHead className="text-right font-bold w-24">العملة</TableHead>
                      <TableHead className="text-right font-bold w-32">الحالة</TableHead>
                      <TableHead className="text-left font-bold w-40">الإجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filtered.map(inv => (
                      <TableRow key={inv.id} className="hover:bg-gray-50/50 transition-colors">
                        <TableCell className="font-mono font-bold">#{inv.number}</TableCell>
                        <TableCell className="font-medium">{getClientName(inv.clientId)}</TableCell>
                        <TableCell className="text-muted-foreground text-sm">{invoiceDate(inv.date)}</TableCell>
                        <TableCell className="font-mono font-bold" dir="ltr">{parseFloat(inv.totalAmount || "0").toLocaleString()}</TableCell>
                        <TableCell className="text-muted-foreground">{inv.currency}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className={`font-bold ${statusColors[inv.status] || ""}`}>
                            {inv.status.replace("_", " ")}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-600" onClick={() => openEdit(inv)}>
                              <Edit2 className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => handlePrint(inv)}>
                              <Printer className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-orange-600" onClick={() => handleExportPDF(inv)}>
                              <Download className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Mobile Card List */}
              <div className="md:hidden space-y-0 divide-y">
                {filtered.map(inv => (
                  <div key={inv.id} className="p-4 active:bg-gray-50 transition-colors bg-white">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex flex-col gap-1">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-primary text-sm">#{inv.number}</span>
                          <Badge variant="outline" className={`py-0 h-4 font-bold text-[9px] ${statusColors[inv.status] || ""}`}>
                            {inv.status.replace("_", " ")}
                          </Badge>
                        </div>
                        <h3 className="font-bold text-base text-gray-900">{getClientName(inv.clientId)}</h3>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-9 w-9 -mt-1 -mr-1">
                            <MoreVertical className="h-5 w-5 text-gray-400" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="text-right">
                          <DropdownMenuItem onClick={() => openEdit(inv)} className="flex justify-end gap-2">
                            <span>تعديل</span>
                            <Edit2 className="h-4 w-4" />
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handlePrint(inv)} className="flex justify-end gap-2">
                            <span>طباعة</span>
                            <Printer className="h-4 w-4" />
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleExportPDF(inv)} className="flex justify-end gap-2 text-orange-600">
                            <span>تصدير PDF</span>
                            <Download className="h-4 w-4" />
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-y-2 mt-3">
                      <div className="flex flex-col">
                        <span className="text-[10px] text-muted-foreground">المبلغ</span>
                        <span className="font-bold text-blue-700" dir="ltr">
                          {parseFloat(inv.totalAmount || "0").toLocaleString()} {inv.currency}
                        </span>
                      </div>
                      <div className="flex flex-col items-end">
                        <span className="text-[10px] text-muted-foreground">التاريخ</span>
                        <span className="text-xs font-medium">{inv.date ? new Date(inv.date).toLocaleDateString("ar-SA") : "-"}</span>
                      </div>
                      <div className="flex flex-col">
                        <span className="text-[10px] text-muted-foreground">النوع</span>
                        <span className="text-xs">{inv.invoiceType.replace("_", " ")}</span>
                      </div>
                      <div className="flex flex-col items-end">
                        <span className="text-[10px] text-muted-foreground">الخدمات</span>
                        <span className="text-xs truncate max-w-[120px]">{inv.items || "-"}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
