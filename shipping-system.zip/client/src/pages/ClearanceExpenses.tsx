import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, Filter, Search } from "lucide-react";
import { toast } from "sonner";
import { exportToExcel, exportToCSV } from "@/lib/export";

export default function ClearanceExpenses() {
  const utils = trpc.useUtils();
  const [selectedDeclId, setSelectedDeclId] = useState<number | null>(null);
  const [expenseType, setExpenseType] = useState("");
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");

  const { data: declarations } = trpc.declarations.list.useQuery();
  const { data: clients } = trpc.clients.list.useQuery();
  const { data: costs } = trpc.clearanceCosts.list.useQuery(
    selectedDeclId ? { declarationId: selectedDeclId } : undefined,
    { enabled: !!selectedDeclId }
  );

  const updateMutation = trpc.clearanceCosts.update.useMutation({
    onSuccess: () => {
      utils.clearanceCosts.list.invalidate();
      utils.clearanceCosts.summary.invalidate();
      toast.success("تم حفظ المصروف");
    },
    onError: (e: { message: string }) => toast.error(e.message),
  });

  const handleSave = (costId: number) => {
    if (!expenseType || !amount) {
      toast.error("يرجى اختيار نوع المصروف وإدخال المبلغ");
      return;
    }

    const fieldMap: Record<string, keyof Parameters<typeof updateMutation.mutate>[0]> = {
      "رسوم البيان": "declarationFee",
      "نقل": "transport",
      "وقود": "fuel",
      "سائق": "driverCost",
      "صيانة": "maintenance",
      "نثريات": "pettyCash",
      "مصاريف أخرى": "otherExpenses",
    };

    const field = fieldMap[expenseType] || "otherExpenses";
    updateMutation.mutate({
      id: costId,
      [field]: amount,
      notes: description,
    });
    setAmount("");
    setDescription("");
  };

  const getClientName = (clientId: number | null) => {
    if (!clientId) return "-";
    const client = clients?.find(c => c.id === clientId);
    return client?.name || "-";
  };

  const selectedDecl = declarations?.find(d => d.id === selectedDeclId);

  const expenseExportColumns = [
    { key: "declarationNumber", label: "رقم البيان" },
    { key: "clientName", label: "العميل" },
    { key: "declarationFee", label: "رسوم البيان" },
    { key: "transport", label: "نقل" },
    { key: "fuel", label: "وقود" },
    { key: "driverCost", label: "سائق" },
    { key: "maintenance", label: "صيانة" },
    { key: "pettyCash", label: "نثريات" },
    { key: "otherExpenses", label: "مصاريف أخرى" },
    { key: "totalCost", label: "الإجمالي" },
    { key: "notes", label: "ملاحظات" },
  ];

  const handleExportExpensesExcel = () => {
    if (!costs || costs.length === 0) {
      toast.warning("لا توجد مصاريف للتصدير");
      return;
    }
    const declNum = selectedDecl?.declarationNumber || "مصاريف";
    const exportData = costs.map(c => ({
      declarationNumber: declNum,
      clientName: getClientName(selectedDecl?.clientId ?? null),
      declarationFee: Number(c.declarationFee || 0).toLocaleString('en-US'),
      transport: Number(c.transport || 0).toLocaleString('en-US'),
      fuel: Number(c.fuel || 0).toLocaleString('en-US'),
      driverCost: Number(c.driverCost || 0).toLocaleString('en-US'),
      maintenance: Number(c.maintenance || 0).toLocaleString('en-US'),
      pettyCash: Number(c.pettyCash || 0).toLocaleString('en-US'),
      otherExpenses: Number(c.otherExpenses || 0).toLocaleString('en-US'),
      totalCost: Number(c.totalCost || 0).toLocaleString('en-US'),
      notes: c.notes || "",
    }));
    exportToExcel(exportData, expenseExportColumns, `مصاريف_${declNum}_${new Date().toISOString().split('T')[0]}`);
    toast.success(`تم تصدير ملخص المصاريف إلى Excel`);
  };

  const handleExportExpensesCSV = () => {
    if (!costs || costs.length === 0) {
      toast.warning("لا توجد مصاريف للتصدير");
      return;
    }
    const declNum = selectedDecl?.declarationNumber || "مصاريف";
    const exportData = costs.map(c => ({
      declarationNumber: declNum,
      clientName: getClientName(selectedDecl?.clientId ?? null),
      declarationFee: Number(c.declarationFee || 0).toLocaleString('en-US'),
      transport: Number(c.transport || 0).toLocaleString('en-US'),
      fuel: Number(c.fuel || 0).toLocaleString('en-US'),
      driverCost: Number(c.driverCost || 0).toLocaleString('en-US'),
      maintenance: Number(c.maintenance || 0).toLocaleString('en-US'),
      pettyCash: Number(c.pettyCash || 0).toLocaleString('en-US'),
      otherExpenses: Number(c.otherExpenses || 0).toLocaleString('en-US'),
      totalCost: Number(c.totalCost || 0).toLocaleString('en-US'),
      notes: c.notes || "",
    }));
    exportToCSV(exportData, expenseExportColumns, `مصاريف_${declNum}_${new Date().toISOString().split('T')[0]}`);
    toast.success(`تم تصدير ملخص المصاريف إلى CSV`);
  };

  return (
    <div className="space-y-4 pb-20 md:pb-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 px-1">
        <div>
          <h2 className="text-2xl font-bold text-foreground">المصاريف والنثريات</h2>
          <p className="text-sm text-muted-foreground mt-1">إدارة تكاليف التشغيل والنثريات للبيانات الجمركية</p>
        </div>
      </div>

      <Card className="shadow-sm border-gray-200">
        <CardContent className="p-4">
          <div className="space-y-2">
            <Label className="font-bold text-sm block">اختر البيان الجمركي</Label>
            <Select value={selectedDeclId?.toString() || ""} onValueChange={v => setSelectedDeclId(v ? Number(v) : null)}>
              <SelectTrigger className="w-full h-12 md:h-10 text-right">
                <SelectValue placeholder="ابحث عن رقم البيان أو العميل..." />
              </SelectTrigger>
              <SelectContent>
                {declarations?.map(d => (
                  <SelectItem key={d.id} value={d.id.toString()} className="text-right">
                    <div className="flex flex-col items-start py-1">
                      <span className="font-bold">{d.declarationNumber}</span>
                      <span className="text-[10px] text-muted-foreground">{getClientName(d.clientId)} - {d.goodsType || "-"}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {selectedDeclId && costs && costs.length > 0 && (
        <Card className="shadow-sm border-primary/20 bg-primary/5">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-primary animate-pulse" />
              إضافة مصروف جديد
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs font-bold">نوع المصروف</Label>
                <Select value={expenseType} onValueChange={setExpenseType}>
                  <SelectTrigger className="h-12 md:h-10"><SelectValue placeholder="اختر النوع" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="رسوم البيان">رسوم البيان</SelectItem>
                    <SelectItem value="نقل">نقل</SelectItem>
                    <SelectItem value="وقود">وقود</SelectItem>
                    <SelectItem value="سائق">سائق</SelectItem>
                    <SelectItem value="صيانة">صيانة</SelectItem>
                    <SelectItem value="نثريات">نثريات</SelectItem>
                    <SelectItem value="مصاريف أخرى">مصاريف أخرى</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-bold">المبلغ</Label>
                <Input 
                  type="number" 
                  value={amount} 
                  onChange={e => setAmount(e.target.value)} 
                  placeholder="0.00" 
                  className="h-12 md:h-10 text-left font-mono text-lg md:text-base"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-bold">ملاحظات / وصف</Label>
                <Input 
                  value={description} 
                  onChange={e => setDescription(e.target.value)} 
                  placeholder="أدخل تفاصيل المصروف..."
                  className="h-12 md:h-10"
                />
              </div>
            </div>
            <Button 
              onClick={() => handleSave(costs[0].id)} 
              disabled={updateMutation.isPending}
              className="w-full h-12 md:h-10 font-bold text-base"
            >
              {updateMutation.isPending ? "جاري الحفظ..." : "حفظ المصروف وتحديث الرصيد"}
            </Button>
          </CardContent>
        </Card>
      )}

      {selectedDeclId && !costs?.length && (
        <Card className="border-dashed border-gray-300">
          <CardContent className="py-12 text-center flex flex-col items-center gap-3">
            <div className="h-12 w-12 rounded-full bg-gray-100 flex items-center justify-center">
              <Filter className="h-6 w-6 text-gray-400" />
            </div>
            <p className="text-sm text-muted-foreground max-w-[250px]">
              لا يوجد سجل تكاليف لهذا البيان. يرجى إنشاء السجل أولاً من صفحة تكاليف التخليص.
            </p>
          </CardContent>
        </Card>
      )}

      {selectedDeclId && costs && costs.length > 0 && (
        <Card className="shadow-sm border-gray-200 overflow-hidden">
          <CardHeader className="bg-gray-50/50 pb-3 border-b">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg">ملخص المصاريف الحالية</CardTitle>
                <p className="text-[10px] text-muted-foreground mt-0.5">للبيان رقم: {selectedDecl?.declarationNumber}</p>
              </div>
              <div className="flex gap-1">
                <Button variant="outline" size="sm" onClick={handleExportExpensesExcel} className="h-8 px-2 text-[10px] font-bold">
                  <Download className="w-3 h-3 ml-1" /> إكسل
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { label: "رسوم البيان", value: costs[0].declarationFee, color: "bg-blue-50 text-blue-700 border-blue-100" },
                { label: "نقل", value: costs[0].transport, color: "bg-indigo-50 text-indigo-700 border-indigo-100" },
                { label: "وقود", value: costs[0].fuel, color: "bg-orange-50 text-orange-700 border-orange-100" },
                { label: "سائق", value: costs[0].driverCost, color: "bg-emerald-50 text-emerald-700 border-emerald-100" },
                { label: "صيانة", value: costs[0].maintenance, color: "bg-rose-50 text-rose-700 border-rose-100" },
                { label: "نثريات", value: costs[0].pettyCash, color: "bg-purple-50 text-purple-700 border-purple-100" },
                { label: "مصاريف أخرى", value: costs[0].otherExpenses, color: "bg-slate-50 text-slate-700 border-slate-100" },
              ].map((item, idx) => (
                <div key={idx} className={`p-3 rounded-lg border ${item.color} flex flex-col`}>
                  <span className="text-[10px] opacity-70 font-bold uppercase mb-1">{item.label}</span>
                  <span className="text-lg font-mono font-bold leading-none">{Number(item.value || 0).toLocaleString()}</span>
                </div>
              ))}
              
              <div className="p-3 bg-primary text-primary-foreground rounded-lg border border-primary shadow-sm flex flex-col col-span-2 md:col-span-1">
                <span className="text-[10px] opacity-80 font-bold uppercase mb-1">إجمالي المصاريف</span>
                <span className="text-xl font-mono font-bold leading-none">{Number(costs[0].totalCost || 0).toLocaleString()}</span>
              </div>
            </div>

            {costs[0].notes && (
              <div className="mt-4 p-3 bg-gray-50 rounded-lg border border-gray-100">
                <Label className="text-[10px] font-bold text-muted-foreground block mb-1">آخر الملاحظات</Label>
                <p className="text-sm italic text-gray-600">"{costs[0].notes}"</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {!selectedDeclId && (
        <div className="flex flex-col items-center justify-center py-20 px-6 text-center">
          <div className="h-20 w-20 rounded-full bg-gray-50 flex items-center justify-center mb-4">
            <Search className="h-10 w-10 text-gray-200" />
          </div>
          <h3 className="text-lg font-bold text-gray-400">لم يتم اختيار بيان</h3>
          <p className="text-sm text-gray-400 mt-2 max-w-[280px]">
            يرجى اختيار بيان جمركي من القائمة أعلاه لعرض وإدارة المصاريف والنثريات الخاصة به.
          </p>
        </div>
      )}
    </div>
  );
}
