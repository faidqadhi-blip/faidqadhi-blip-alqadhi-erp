import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, TrendingUp, Target, Calendar, BarChart3, ChevronLeft } from "lucide-react";
import { useIsMobile } from "@/hooks/useMobile";
import { Progress } from "@/components/ui/progress";

export default function Revenue() {
  const isMobile = useIsMobile();
  const [goal] = [50000];
  const { data: monthlyData, isLoading } = trpc.sales.revenue.useQuery();

  const months = [
    "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
    "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
  ];

  const totalRevenue = monthlyData?.reduce((sum: number, m: any) => sum + Number(m.totalAmount || 0), 0) || 0;
  const totalCount = monthlyData?.reduce((sum: number, m: any) => sum + Number(m.count || 0), 0) || 0;
  const goalProgress = goal > 0 ? Math.round((totalRevenue / goal) * 100) : 0;

  return (
    <div className="space-y-6 pb-20 md:pb-6" dir="rtl">
      <div className="px-1">
        <h1 className="text-2xl font-bold">تقرير الإيرادات</h1>
        <p className="text-sm text-muted-foreground mt-1">الإيرادات الشهرية والسنوية</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-gray-200 shadow-sm overflow-hidden bg-gradient-to-br from-blue-50 to-white">
          <CardContent className="p-6 flex items-center gap-4">
            <div className="h-14 w-14 rounded-2xl bg-blue-100 flex items-center justify-center shrink-0 shadow-sm">
              <DollarSign className="h-7 w-7 text-blue-600" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1 font-bold uppercase tracking-wider">إجمالي الإيرادات</p>
              <div className="flex items-baseline gap-1">
                <span className="text-3xl font-black text-gray-900">{totalRevenue.toLocaleString('en-US')}</span>
                <span className="text-xs font-bold text-muted-foreground">ر.ي</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-gray-200 shadow-sm overflow-hidden bg-gradient-to-br from-green-50 to-white">
          <CardContent className="p-6 flex items-center gap-4">
            <div className="h-14 w-14 rounded-2xl bg-green-100 flex items-center justify-center shrink-0 shadow-sm">
              <TrendingUp className="h-7 w-7 text-green-600" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1 font-bold uppercase tracking-wider">عدد العمليات</p>
              <span className="text-3xl font-black text-green-600">{totalCount.toLocaleString('en-US')}</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-gray-200 shadow-sm overflow-hidden bg-gradient-to-br from-amber-50 to-white">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="h-12 w-12 rounded-2xl bg-amber-100 flex items-center justify-center shrink-0 shadow-sm">
                <Target className="h-6 w-6 text-amber-600" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-muted-foreground mb-1 font-bold uppercase tracking-wider">نسبة تحقيق الهدف</p>
                <span className="text-2xl font-black text-gray-900">{goalProgress}%</span>
              </div>
            </div>
            <div className="space-y-1.5">
              <Progress value={Math.min(goalProgress, 100)} className="h-2.5 bg-amber-100" />
              <div className="flex justify-between text-[10px] font-bold text-muted-foreground">
                <span>0</span>
                <span>{goal.toLocaleString('en-US')} ر.ي</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-gray-200 shadow-sm overflow-hidden">
        <CardHeader className="bg-gray-50/50 p-4 border-b">
          <CardTitle className="text-lg flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" /> الإيرادات الشهرية التفصيلية
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="text-center py-16 text-muted-foreground">جاري التحميل...</div>
          ) : !monthlyData || monthlyData.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground bg-white">
              <BarChart3 className="h-16 w-16 mx-auto mb-4 opacity-20" />
              <p className="text-lg">لا توجد بيانات إيرادات مسجلة</p>
            </div>
          ) : isMobile ? (
            <div className="divide-y divide-gray-100">
              {monthlyData.map((row: any, i: number) => (
                <div key={i} className="p-4 bg-white flex justify-between items-center active:bg-gray-50 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-xl bg-gray-50 flex flex-col items-center justify-center text-primary border border-gray-100">
                      <span className="text-[10px] font-bold leading-none">{row.year || "-"}</span>
                      <span className="text-xs font-black">{row.month || "-"}</span>
                    </div>
                    <div>
                      <div className="font-bold text-base text-gray-900">{months[(row.month || 1) - 1]}</div>
                      <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                        <TrendingUp className="h-3 w-3" />
                        <span>{row.count || 0} عملية مكتملة</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-left">
                    <div className="font-black text-lg text-blue-600 leading-none mb-1">
                      {Number(row.totalAmount || 0).toLocaleString('en-US')}
                    </div>
                    <span className="text-[10px] text-muted-foreground font-bold uppercase">ر.ي</span>
                  </div>
                </div>
              ))}
              <div className="p-5 bg-primary/5 flex justify-between items-center">
                <span className="font-black text-gray-900">الإجمالي السنوي</span>
                <div className="text-left">
                  <div className="text-2xl font-black text-primary leading-none mb-1">
                    {totalRevenue.toLocaleString('en-US')}
                  </div>
                  <span className="text-[10px] text-muted-foreground font-bold uppercase">ريال يمني</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gray-50 border-b">
                    <th className="text-right p-4 font-bold text-sm text-gray-600">الشهر</th>
                    <th className="text-right p-4 font-bold text-sm text-gray-600">السنة</th>
                    <th className="text-right p-4 font-bold text-sm text-gray-600">عدد العمليات</th>
                    <th className="text-right p-4 font-bold text-sm text-gray-600">الإيرادات</th>
                  </tr>
                </thead>
                <tbody>
                  {monthlyData.map((row: any, i: number) => (
                    <tr key={i} className="border-b hover:bg-gray-50 transition-colors">
                      <td className="p-4 font-bold text-gray-900">{months[(row.month || 1) - 1]}</td>
                      <td className="p-4 text-muted-foreground font-medium">{row.year || "-"}</td>
                      <td className="p-4 font-medium">{row.count || 0}</td>
                      <td className="p-4 font-black text-blue-600">{Number(row.totalAmount || 0).toLocaleString('en-US')} ر.ي</td>
                    </tr>
                  ))}
                  <tr className="bg-primary/5 font-black">
                    <td className="p-4 text-gray-900" colSpan={2}>الإجمالي العام</td>
                    <td className="p-4 text-gray-900">{totalCount}</td>
                    <td className="p-4 text-primary text-xl">{totalRevenue.toLocaleString('en-US')} ر.ي</td>
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
