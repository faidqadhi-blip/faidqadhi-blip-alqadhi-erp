import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Loader2, Plus, Trash2, CalendarClock, Search, Filter, Hash, Wallet } from "lucide-react";
import { useState, useEffect, useMemo } from "react";
import { getDefaultCurrency } from "@/lib/currency";
import { toast } from "sonner";
import { useIsMobile } from "@/hooks/useMobile";

interface MovementForm {
  date: string;
  type: string;
  accountId: string;
  amount: string;
  currency: string;
  description: string;
  reference: string;
}

const initialForm: MovementForm = {
  date: new Date().toISOString().split("T")[0],
  type: "إيراد",
  accountId: "",
  amount: "",
  currency: "SAR",
  description: "",
  reference: "",
};

export default function DailyMovements() {
  const isMobile = useIsMobile();
  const utils = trpc.useUtils();
  const { data: systemSettings } = trpc.settings.getAll.useQuery();

  // Set default currency from settings
  useEffect(() => {
    if (systemSettings) {
      const defaultCurr = getDefaultCurrency(systemSettings);
      setForm(p => ({ ...p, currency: defaultCurr }));
    }
  }, [systemSettings]);

  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<MovementForm>(initialForm);
  const [searchQuery, setSearchQuery] = useState("");

  const { data: movements, isLoading } = trpc.dailyMovements.list.useQuery();
  const { data: accounts } = trpc.accounts.list.useQuery();

  const createMutation = trpc.dailyMovements.create.useMutation({
    onSuccess: () => {
      utils.dailyMovements.list.invalidate();
      setOpen(false);
      setForm(initialForm);
      toast.success("تم تسجيل الحركة بنجاح");
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = trpc.dailyMovements.delete.useMutation({
    onSuccess: () => {
      utils.dailyMovements.list.invalidate();
      toast.success("تم حذف الحركة");
    },
    onError: (e) => toast.error(e.message),
  });

  const filtered = useMemo(() => {
    return movements?.filter(m =>
      searchQuery === "" ||
      (m.description || "").toLowerCase().includes(searchQuery.toLowerCase()) ||
      (m.reference || "").toLowerCase().includes(searchQuery.toLowerCase())
    ) || [];
  }, [movements, searchQuery]);

  const typeColors: Record<string, string> = {
    "إيراد": "bg-green-500/10 text-green-600 border-green-200",
    "مصروف": "bg-red-500/10 text-red-600 border-red-200",
    "تحويل": "bg-blue-500/10 text-blue-600 border-blue-200",
    "سند_قبض": "bg-green-500/10 text-green-600 border-green-200",
    "سند_صرف": "bg-red-500/10 text-red-600 border-red-200",
  };

  const handleSubmit = () => {
    if (!form.type || !form.accountId || !form.amount) {
      toast.error("يرجى ملء الحقول المطلوبة");
      return;
    }
    createMutation.mutate({
      date: form.date,
      type: form.type,
      accountId: parseInt(form.accountId),
      amount: form.amount,
      currency: form.currency,
      description: form.description || undefined,
      reference: form.reference || undefined,
    });
  };

  return (
    <div className="space-y-4 pb-20 md:pb-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 px-1">
        <div>
          <h2 className="text-2xl font-bold text-foreground">الحركة اليومية</h2>
          <p className="text-sm text-muted-foreground mt-1">تسجيل ومتابعة الإيرادات والمصروفات اليومية</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="w-full md:w-auto h-12 md:h-10 font-bold text-base gap-2">
              <Plus className="h-5 w-5" /> حركة جديدة
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg p-0 gap-0 overflow-hidden">
            <DialogHeader className="p-6 pb-2">
              <DialogTitle className="text-xl">تسجيل حركة يومية جديدة</DialogTitle>
            </DialogHeader>
            <div className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="font-bold">النوع *</Label>
                  <Select value={form.type} onValueChange={(v) => setForm(p => ({ ...p, type: v }))}>
                    <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="إيراد" className="text-right">إيراد</SelectItem>
                      <SelectItem value="مصروف" className="text-right">مصروف</SelectItem>
                      <SelectItem value="تحويل" className="text-right">تحويل</SelectItem>
                      <SelectItem value="سند_قبض" className="text-right">سند قبض</SelectItem>
                      <SelectItem value="سند_صرف" className="text-right">سند صرف</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">الحساب *</Label>
                  <Select value={form.accountId} onValueChange={(v) => setForm(p => ({ ...p, accountId: v }))}>
                    <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue placeholder="اختر الحساب" /></SelectTrigger>
                    <SelectContent>
                      {accounts?.map(a => (
                        <SelectItem key={a.id} value={String(a.id)} className="text-right">{a.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">المبلغ *</Label>
                  <Input type="number" value={form.amount} onChange={(e) => setForm(p => ({ ...p, amount: e.target.value }))} className="h-12 md:h-10 text-left font-mono" placeholder="0.00" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">العملة</Label>
                  <Select value={form.currency} onValueChange={(v) => setForm(p => ({ ...p, currency: v }))}>
                    <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="SAR" className="text-right">ريال سعودي</SelectItem>
                      <SelectItem value="USD" className="text-right">دولار أمريكي</SelectItem>
                      <SelectItem value="EUR" className="text-right">يورو</SelectItem>
                      <SelectItem value="AED" className="text-right">درهم إماراتي</SelectItem>
                      <SelectItem value="YER" className="text-right">ريال يمني</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">التاريخ</Label>
                  <Input type="date" value={form.date} onChange={(e) => setForm(p => ({ ...p, date: e.target.value }))} className="h-12 md:h-10" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">المرجع</Label>
                  <Input value={form.reference} onChange={(e) => setForm(p => ({ ...p, reference: e.target.value }))} className="h-12 md:h-10" placeholder="رقم الفاتورة أو الشحنة" />
                </div>
                <div className="space-y-2 col-span-1 md:col-span-2">
                  <Label className="font-bold">الوصف</Label>
                  <Input value={form.description} onChange={(e) => setForm(p => ({ ...p, description: e.target.value }))} className="h-12 md:h-10" />
                </div>
              </div>
              <div className="flex flex-col md:flex-row justify-end gap-3 pt-4 border-t">
                <Button variant="outline" onClick={() => setOpen(false)} className="h-12 md:h-10 font-bold">إلغاء</Button>
                <Button onClick={handleSubmit} className="h-12 md:h-10 font-bold text-base px-8" disabled={createMutation.isPending}>
                  {createMutation.isPending && <Loader2 className="h-4 w-4 animate-spin ml-2" />}
                  تسجيل الحركة
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="shadow-sm border-gray-200">
        <CardHeader className="p-4 pb-2">
          <div className="relative">
            <Search className="absolute right-3 top-3 h-5 w-5 text-gray-400" />
            <Input
              placeholder="البحث في الحركات والوصف..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="pr-10 h-12 md:h-10 w-full"
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex flex-col items-center py-12 gap-3">
              <Loader2 className="h-10 w-10 animate-spin text-primary" />
              <span className="text-muted-foreground">جاري تحميل الحركات...</span>
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-12 flex flex-col items-center gap-3">
              <CalendarClock className="h-16 w-16 text-gray-200" />
              <p className="text-muted-foreground">{searchQuery ? "لا توجد نتائج مطابقة" : "لا توجد حركات مسجلة لليوم"}</p>
            </div>
          ) : (
            <>
              {/* Desktop Table */}
              <div className="hidden md:block overflow-x-auto">
                <Table>
                  <TableHeader className="bg-gray-50">
                    <TableRow>
                      <TableHead className="text-right font-bold w-32">النوع</TableHead>
                      <TableHead className="text-right font-bold">الحساب</TableHead>
                      <TableHead className="text-right font-bold w-32">المبلغ</TableHead>
                      <TableHead className="text-right font-bold w-24">العملة</TableHead>
                      <TableHead className="text-right font-bold w-40">المرجع</TableHead>
                      <TableHead className="text-right font-bold w-32">التاريخ</TableHead>
                      <TableHead className="text-left font-bold w-24">الإجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filtered.map(m => (
                      <TableRow key={m.id} className="hover:bg-gray-50/50 transition-colors">
                        <TableCell>
                          <Badge variant="outline" className={`font-bold ${typeColors[m.type] || ""}`}>
                            {m.type}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-medium">
                          {accounts?.find(a => a.id === m.accountId)?.name || "-"}
                        </TableCell>
                        <TableCell className="font-mono font-bold" dir="ltr">{parseFloat(m.amount).toLocaleString()}</TableCell>
                        <TableCell className="text-muted-foreground">{m.currency || "SAR"}</TableCell>
                        <TableCell className="text-muted-foreground">{m.reference || "-"}</TableCell>
                        <TableCell className="text-muted-foreground">{m.date || "-"}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500 hover:bg-red-50" onClick={() => { if (confirm("هل تريد حذف هذه الحركة؟")) deleteMutation.mutate({ id: m.id }); }}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Mobile Card List */}
              <div className="md:hidden space-y-0 divide-y">
                {filtered.map(m => (
                  <div key={m.id} className="p-4 active:bg-gray-50 transition-colors bg-white">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex flex-col gap-1">
                        <Badge variant="outline" className={`w-fit py-0 h-5 font-bold text-[10px] ${typeColors[m.type] || ""}`}>
                          {m.type}
                        </Badge>
                        <h3 className="font-bold text-base text-gray-900">
                          {accounts?.find(a => a.id === m.accountId)?.name || "حساب غير معروف"}
                        </h3>
                      </div>
                      <Button variant="ghost" size="icon" className="h-9 w-9 text-red-500 -mt-1 -mr-1" onClick={() => { if (confirm("هل تريد حذف هذه الحركة؟")) deleteMutation.mutate({ id: m.id }); }}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-y-2 mt-3">
                      <div className="flex flex-col">
                        <span className="text-[10px] text-muted-foreground">المبلغ</span>
                        <span className="font-bold text-blue-700" dir="ltr">
                          {parseFloat(m.amount).toLocaleString()} {m.currency}
                        </span>
                      </div>
                      <div className="flex flex-col items-end">
                        <span className="text-[10px] text-muted-foreground">التاريخ</span>
                        <span className="text-xs font-medium">{m.date}</span>
                      </div>
                      <div className="flex flex-col">
                        <span className="text-[10px] text-muted-foreground">المرجع</span>
                        <div className="flex items-center gap-1">
                          <Hash className="h-3 w-3 text-gray-400" />
                          <span className="text-xs">{m.reference || "بدون مرجع"}</span>
                        </div>
                      </div>
                      <div className="flex flex-col items-end">
                        <span className="text-[10px] text-muted-foreground">الوصف</span>
                        <span className="text-xs truncate max-w-[120px]">{m.description || "-"}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
