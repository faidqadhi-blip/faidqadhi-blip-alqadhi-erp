import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { Settings as SettingsIcon, Trash2, Plus, Database, ShieldCheck, FileText, Type, Globe, Coins, Package, Building2, Pencil, History, CheckCircle2, XCircle, UserCheck, Minus, Calculator, Wallet, MoreVertical, Edit2, Loader2 } from "lucide-react";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { useIsMobile } from "@/hooks/useMobile";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// Module definitions for access control
export const FINANCIAL_MODULE_IDS = [
  "sales-report",
  "client-statement",
  "payments",
  "revenue",
  "service-invoices",
  "vouchers",
  "journal-entries",
  "general-ledger",
  "daily-movements",
  "clearance-payments",
  "clearance-expenses",
  "clearance-costs",
  "clearance-reports",
] as const;

export const OPERATIONAL_MODULE_IDS = [
  "dashboard",
  "clients",
  "shipments",
  "transfers",
  "job-orders",
  "customs-declarations",
  "clearance-invoices",
  "internal-transport",
  "fixed-assets",
  "evaluations",
  "settings",
  "permits",
  "quantity-deductions",
  "suppliers",
  "employees",
  "petty-cash",
  "cashboxes",
] as const;

export type FinancialModuleId = typeof FINANCIAL_MODULE_IDS[number];
export type OperationalModuleId = typeof OPERATIONAL_MODULE_IDS[number];
export type ModuleId = FinancialModuleId | OperationalModuleId;

export const financialModules: { id: FinancialModuleId; label: string }[] = [
  { id: "sales-report", label: "المبيعات" },
  { id: "client-statement", label: "كشف حساب العملاء" },
  { id: "payments", label: "المدفوعات (المالية)" },
  { id: "revenue", label: "الإيرادات" },
  { id: "service-invoices", label: "الفواتير الخدمية" },
  { id: "vouchers", label: "السندات" },
  { id: "journal-entries", label: "القيود المحاسبية" },
  { id: "general-ledger", label: "الأستاذ العام" },
  { id: "daily-movements", label: "الحركة اليومية" },
  { id: "clearance-payments", label: "مقبوضات التخليص" },
  { id: "clearance-expenses", label: "مصروفات التخليص" },
  { id: "clearance-costs", label: "تكاليف التخليص" },
  { id: "clearance-reports", label: "تقارير التخليص (المالية)" },
];

export const operationalModules: { id: OperationalModuleId; label: string }[] = [
  { id: "dashboard", label: "لوحة التحكم" },
  { id: "clients", label: "العملاء" },
  { id: "shipments", label: "الشحنات" },
  { id: "transfers", label: "الترحيل" },
  { id: "job-orders", label: "أوامر العمل" },
  { id: "customs-declarations", label: "البيانات الجمركية" },
  { id: "clearance-invoices", label: "فواتير التخليص" },
  { id: "internal-transport", label: "النقل الداخلي" },
  { id: "fixed-assets", label: "الأصول" },
  { id: "evaluations", label: "التقييمات" },
  { id: "settings", label: "الإعدادات" },
  { id: "permits", label: "التراخيص" },
  { id: "quantity-deductions", label: "تخصيم الكميات" },
  { id: "suppliers", label: "الموردين" },
  { id: "employees", label: "الموظفين" },
  { id: "petty-cash", label: "العهد والسلف" },
  { id: "cashboxes", label: "الصناديق والبنوك" },
];

export default function Settings() {
  const isMobile = useIsMobile();
  const utils = trpc.useUtils();
  const { user } = useAuth();
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);

  // Module permissions
  const { data: myPerms } = trpc.moduleAccess.myPermissions.useQuery();
  const { data: usersList } = trpc.moduleAccess.listUsers.useQuery(undefined, {
    enabled: user?.role === "admin",
  });
  const { data: selectedUserPerms, refetch: refetchSelectedPerms } = trpc.moduleAccess.getUserPermissions.useQuery(
    { userId: selectedUserId ?? 0 },
    { enabled: selectedUserId !== null && user?.role === "admin", refetchOnWindowFocus: true }
  );
  const setPermissionMutation = trpc.moduleAccess.setPermission.useMutation({
    onSuccess: () => {
      refetchSelectedPerms();
      utils.moduleAccess.myPermissions.invalidate();
    },
    onError: (err: any) => toast.error(err.message),
  });
  const setPermissionsMutation = trpc.moduleAccess.setPermissions.useMutation({
    onSuccess: () => {
      refetchSelectedPerms();
      utils.moduleAccess.myPermissions.invalidate();
      toast.success("تم فتح جميع الأقسام");
    },
    onError: (err: any) => toast.error(err.message),
  });
  const deselectPermissionsMutation = trpc.moduleAccess.setPermissions.useMutation({
    onSuccess: () => {
      refetchSelectedPerms();
      utils.moduleAccess.myPermissions.invalidate();
      toast.success("تم إخفاء الأقسام المالية");
    },
    onError: (err: any) => toast.error(err.message),
  });

  // Permission audit log (admin only)
  const { data: auditLogs, refetch: refetchAuditLogs } = trpc.moduleAccess.auditLog.useQuery(
    { userId: selectedUserId ?? undefined },
    { enabled: selectedUserId !== null && user?.role === "admin", refetchOnWindowFocus: true }
  );

  // Auto-select current user (admin) when the users list loads
  useEffect(() => {
    if (user?.role === "admin" && selectedUserId === null && usersList && usersList.length > 0) {
      const me = usersList.find(u => u.id === user.id);
      setSelectedUserId(me?.id ?? usersList[0].id);
    }
  }, [usersList, user, selectedUserId]);


  const isModuleAllowed = (moduleId: string): boolean => {
    if (user?.role === "admin" && !selectedUserId) return true;
    if (user?.role === "admin" && selectedUserId === user.id) return true;
    const perms = selectedUserPerms ?? [];
    const perm = perms.find(p => p.moduleId === moduleId);
    return perm ? perm.canView : false;
  };

  const toggleModule = (moduleId: string, canView: boolean) => {
    if (!selectedUserId || selectedUserId <= 0) return;
    setPermissionMutation.mutate({ userId: selectedUserId, moduleId, canView });
  };

  const selectAllFinancial = () => {
    if (!selectedUserId || selectedUserId <= 0) return;
    const permissions = financialModules.map(m => ({ moduleId: m.id, canView: true }));
    setPermissionsMutation.mutate({ userId: selectedUserId, permissions });
  };

  const deselectAllFinancial = () => {
    if (!selectedUserId || selectedUserId <= 0) return;
    const permissions = financialModules.map(m => ({ moduleId: m.id, canView: false }));
    deselectPermissionsMutation.mutate({ userId: selectedUserId, permissions });
  };

  const formatAuditDate = (d: Date | string) => {
    const date = d instanceof Date ? d : new Date(d);
    return date.toLocaleString("ar-SA-u-nu-latn", {
      year: "numeric", month: "short", day: "numeric",
      hour: "2-digit", minute: "2-digit", calendar: "gregory",
    });
  };

  const allModuleLabels: Record<string, string> = {
    ...Object.fromEntries(financialModules.map(m => [m.id, m.label])),
    ...Object.fromEntries(operationalModules.map(m => [m.id, m.label])),
  };

  const allowedCount = (modules: { id: string }[]) =>
    modules.filter(m => isModuleAllowed(m.id)).length;

  useEffect(() => {
    if (selectedUserId !== null) refetchAuditLogs();
  }, [selectedUserPerms, selectedUserId, refetchAuditLogs]);

  const [settings, setSettings] = useState({
    companyName: "فيدل القاضي للتخليص الجمركي والخدمات اللوجستية",
    companyPhone: "",
    companyEmail: "",
    companyAddress: "",
    companyTaxNumber: "",
    annualGoal: "50000",
    invoicePrefix: "FC-",
    defaultCurrency: "YER",
  });

  const { data: currencies } = trpc.currencies.list.useQuery();
  const { data: systemSettings } = trpc.settings.getAll.useQuery();
  const saveSettingMutation = trpc.settings.save.useMutation();
  const { data: languages } = trpc.languages.list.useQuery();
  const { data: fonts } = trpc.fonts.list.useQuery();
  const { data: accounts } = trpc.accounts.list.useQuery();

  const [newCurrency, setNewCurrency] = useState({ code: "", name: "", symbol: "", exchangeRate: "1.00" });
  const [newLang, setNewLang] = useState({ code: "", name: "" });
  const [newFont, setNewFont] = useState({ name: "", fontFamily: "" });
  
  const [editingCurrency, setEditingCurrency] = useState<{ id: number; code: string; name: string; exchangeRate: string } | null>(null);
  const [mappingForm, setMappingForm] = useState({ receivableId: "", revenueId: "", expenseId: "" });

  const createCurrencyMutation = trpc.currencies.create.useMutation({
    onSuccess: () => {
      utils.currencies.list.invalidate();
      toast.success("تمت إضافة العملة بنجاح");
      setNewCurrency({ code: "", name: "", symbol: "", exchangeRate: "1.00" });
    },
    onError: (e) => toast.error(e.message),
  });

  const updateCurrencyMutation = trpc.currencies.update.useMutation({
    onSuccess: () => {
      utils.currencies.list.invalidate();
      setEditingCurrency(null);
      toast.success("تم تحديث العملة بنجاح");
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteCurrencyMutation = trpc.currencies.delete.useMutation({
    onSuccess: () => { utils.currencies.list.invalidate(); toast.success("تم حذف العملة"); },
  });

  const createLangMutation = trpc.languages.create.useMutation({
    onSuccess: () => { utils.languages.list.invalidate(); toast.success("تمت إضافة اللغة"); },
  });
  const deleteLangMutation = trpc.languages.delete.useMutation({
    onSuccess: () => { utils.languages.list.invalidate(); toast.success("تم حذف اللغة"); },
  });

  const createFontMutation = trpc.fonts.create.useMutation({
    onSuccess: () => { utils.fonts.list.invalidate(); toast.success("تمت إضافة الخط"); },
  });
  const deleteFontMutation = trpc.fonts.delete.useMutation({
    onSuccess: () => { utils.fonts.list.invalidate(); toast.success("تم حذف الخط"); },
  });

  const createBackupMutation = trpc.backups.create.useMutation({
    onSuccess: () => { utils.backups.list.invalidate(); toast.success("تم إنشاء النسخة الاحتياطية"); },
  });

  const { data: backups } = trpc.backups.list.useQuery();

  const handleSave = () => {
    if (settings.companyName) saveSettingMutation.mutate({ key: "companyName", value: settings.companyName });
    if (settings.companyPhone) saveSettingMutation.mutate({ key: "companyPhone", value: settings.companyPhone });
    if (settings.companyEmail) saveSettingMutation.mutate({ key: "companyEmail", value: settings.companyEmail });
    if (settings.companyAddress) saveSettingMutation.mutate({ key: "companyAddress", value: settings.companyAddress });
    if (settings.companyTaxNumber) saveSettingMutation.mutate({ key: "companyTaxNumber", value: settings.companyTaxNumber });
    saveSettingMutation.mutate({ key: "annualGoal", value: settings.annualGoal });
    saveSettingMutation.mutate({ key: "invoicePrefix", value: settings.invoicePrefix });
    if (settings.defaultCurrency) saveSettingMutation.mutate({ key: "defaultCurrency", value: settings.defaultCurrency });
    toast.success("تم حفظ الإعدادات بنجاح");
  };

  const handleSaveMappings = () => {
    saveSettingMutation.mutate({ key: "acc_receivable_id", value: mappingForm.receivableId });
    saveSettingMutation.mutate({ key: "acc_revenue_id", value: mappingForm.revenueId });
    saveSettingMutation.mutate({ key: "acc_expense_id", value: mappingForm.expenseId });
    toast.success("تم حفظ ربط الحسابات");
  };

  useEffect(() => {
    if (systemSettings) {
      const getVal = (key: string) => systemSettings.find(s => s.key === key)?.value || "";
      setSettings({
        companyName: getVal("companyName") || "فيدل القاضي للتخليص الجمركي والخدمات اللوجستية",
        companyPhone: getVal("companyPhone"),
        companyEmail: getVal("companyEmail"),
        companyAddress: getVal("companyAddress"),
        companyTaxNumber: getVal("companyTaxNumber"),
        annualGoal: getVal("annualGoal") || "50000",
        invoicePrefix: getVal("invoicePrefix") || "FC-",
        defaultCurrency: getVal("defaultCurrency") || "YER",
      });
      setMappingForm({
        receivableId: getVal("acc_receivable_id"),
        revenueId: getVal("acc_revenue_id"),
        expenseId: getVal("acc_expense_id"),
      });
    }
  }, [systemSettings]);

  return (
    <div className="space-y-6 pb-20 md:pb-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 px-1">
        <div>
          <h1 className="text-2xl font-bold">الإعدادات</h1>
          <p className="text-sm text-muted-foreground mt-1">إدارة إعدادات النظام، العملات، والصلاحيات</p>
        </div>
        <Button onClick={handleSave} className="w-full md:w-auto h-12 md:h-10 font-bold text-base">
          <CheckCircle2 className="h-5 w-5 ml-2" /> حفظ الإعدادات العامة
        </Button>
      </div>

      <Tabs defaultValue="general" className="w-full">
        <TabsList className={`grid w-full ${isMobile ? 'grid-cols-2 h-auto gap-1 bg-transparent' : 'grid-cols-6'}`}>
          <TabsTrigger value="general" className={isMobile ? 'h-12 border rounded-md data-[state=active]:bg-primary data-[state=active]:text-white' : ''}>العامة</TabsTrigger>
          <TabsTrigger value="accounting" className={isMobile ? 'h-12 border rounded-md data-[state=active]:bg-primary data-[state=active]:text-white' : ''}>المحاسبة</TabsTrigger>
          <TabsTrigger value="currencies" className={isMobile ? 'h-12 border rounded-md data-[state=active]:bg-primary data-[state=active]:text-white' : ''}>العملات</TabsTrigger>
          <TabsTrigger value="permissions" className={isMobile ? 'h-12 border rounded-md data-[state=active]:bg-primary data-[state=active]:text-white' : ''}>الصلاحيات</TabsTrigger>
          <TabsTrigger value="appearance" className={isMobile ? 'h-12 border rounded-md data-[state=active]:bg-primary data-[state=active]:text-white' : ''}>المظهر</TabsTrigger>
          <TabsTrigger value="backup" className={isMobile ? 'h-12 border rounded-md data-[state=active]:bg-primary data-[state=active]:text-white' : ''}>النسخ</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-4 mt-6">
          <Card className="border-gray-200 shadow-sm">
            <CardHeader className="p-6 pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <Building2 className="h-5 w-5 text-primary" /> معلومات الشركة
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6 pt-2 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="font-bold">اسم النظام / الشركة</Label>
                  <Input value={settings.companyName} onChange={e => setSettings(s => ({ ...s, companyName: e.target.value }))} className="h-12 md:h-10" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">رقم الهاتف</Label>
                  <Input value={settings.companyPhone} onChange={e => setSettings(s => ({ ...s, companyPhone: e.target.value }))} className="h-12 md:h-10 text-left font-mono" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">البريد الإلكتروني</Label>
                  <Input value={settings.companyEmail} onChange={e => setSettings(s => ({ ...s, companyEmail: e.target.value }))} className="h-12 md:h-10 text-left font-mono" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">العنوان</Label>
                  <Input value={settings.companyAddress} onChange={e => setSettings(s => ({ ...s, companyAddress: e.target.value }))} className="h-12 md:h-10" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">الرقم الضريبي</Label>
                  <Input value={settings.companyTaxNumber} onChange={e => setSettings(s => ({ ...s, companyTaxNumber: e.target.value }))} className="h-12 md:h-10 text-left font-mono" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">العملة الافتراضية للنظام</Label>
                  <Select value={settings.defaultCurrency} onValueChange={v => setSettings(s => ({ ...s, defaultCurrency: v }))}>
                    <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="YER" className="text-right">ريال يمني</SelectItem>
                      <SelectItem value="SAR" className="text-right">ريال سعودي</SelectItem>
                      <SelectItem value="USD" className="text-right">دولار أمريكي</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="accounting" className="space-y-4 mt-6">
          <Card className="border-gray-200 shadow-sm">
            <CardHeader className="p-6 pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <Calculator className="h-5 w-5 text-primary" /> ربط الحسابات التلقائي
              </CardTitle>
              <CardDescription>تحديد الحسابات الافتراضية للقيود المحاسبية التلقائية</CardDescription>
            </CardHeader>
            <CardContent className="p-6 pt-2 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label className="font-bold">حساب العملاء (المدينون)</Label>
                  <Select value={mappingForm.receivableId} onValueChange={v => setMappingForm(p => ({ ...p, receivableId: v }))}>
                    <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue placeholder="اختر حساباً" /></SelectTrigger>
                    <SelectContent>
                      {accounts?.map(a => <SelectItem key={a.id} value={String(a.id)} className="text-right">{a.code} - {a.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">حساب الإيرادات</Label>
                  <Select value={mappingForm.revenueId} onValueChange={v => setMappingForm(p => ({ ...p, revenueId: v }))}>
                    <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue placeholder="اختر حساباً" /></SelectTrigger>
                    <SelectContent>
                      {accounts?.map(a => <SelectItem key={a.id} value={String(a.id)} className="text-right">{a.code} - {a.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">حساب المصاريف</Label>
                  <Select value={mappingForm.expenseId} onValueChange={v => setMappingForm(p => ({ ...p, expenseId: v }))}>
                    <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue placeholder="اختر حساباً" /></SelectTrigger>
                    <SelectContent>
                      {accounts?.map(a => <SelectItem key={a.id} value={String(a.id)} className="text-right">{a.code} - {a.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Button onClick={handleSaveMappings} className="w-full md:w-auto font-bold h-12 md:h-10">حفظ ربط الحسابات</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="currencies" className="space-y-4 mt-6">
          <Card className="border-gray-200 shadow-sm">
            <CardHeader className="p-6 pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Coins className="h-5 w-5 text-primary" /> إدارة العملات وأسعار الصرف
                </CardTitle>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button size="sm" className="h-9 font-bold"><Plus className="h-4 w-4 ml-1" /> إضافة عملة</Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-md p-6">
                    <DialogHeader>
                      <DialogTitle>إضافة عملة جديدة</DialogTitle>
                    </DialogHeader>
                    <div className="grid grid-cols-2 gap-4 mt-4">
                      <div className="space-y-2">
                        <Label>الرمز (مثل: YER)</Label>
                        <Input value={newCurrency.code} onChange={e => setNewCurrency(c => ({ ...c, code: e.target.value.toUpperCase() }))} />
                      </div>
                      <div className="space-y-2">
                        <Label>الاسم</Label>
                        <Input value={newCurrency.name} onChange={e => setNewCurrency(c => ({ ...c, name: e.target.value }))} />
                      </div>
                      <div className="space-y-2">
                        <Label>سعر الصرف</Label>
                        <Input type="number" step="0.01" value={newCurrency.exchangeRate} onChange={e => setNewCurrency(c => ({ ...c, exchangeRate: e.target.value }))} />
                      </div>
                      <div className="space-y-2">
                        <Label>الرمز الرمزي</Label>
                        <Input value={newCurrency.symbol} onChange={e => setNewCurrency(c => ({ ...c, symbol: e.target.value }))} />
                      </div>
                    </div>
                    <Button className="w-full mt-6 h-12 md:h-10 font-bold" onClick={() => createCurrencyMutation.mutate(newCurrency)}>إضافة العملة</Button>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {isMobile ? (
                <div className="divide-y">
                  {currencies?.map(c => (
                    <div key={c.id} className="p-4 flex justify-between items-center bg-white">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-lg">{c.code}</span>
                          <span className="text-sm text-muted-foreground">({c.name})</span>
                        </div>
                        <div className="text-sm font-mono mt-1 text-blue-600 font-bold">
                          1.00 = {parseFloat(c.exchangeRate || "1").toLocaleString()}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="ghost" size="icon" className="text-blue-600" onClick={() => setEditingCurrency({ id: c.id, code: c.code, name: c.name, exchangeRate: c.exchangeRate || "1.00" })}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="text-red-600" onClick={() => { if(confirm("حذف العملة؟")) deleteCurrencyMutation.mutate({ id: c.id }); }}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <Table>
                  <TableHeader className="bg-gray-50">
                    <TableRow>
                      <TableHead className="text-right font-bold">الرمز</TableHead>
                      <TableHead className="text-right font-bold">الاسم</TableHead>
                      <TableHead className="text-right font-bold">سعر الصرف</TableHead>
                      <TableHead className="text-left font-bold w-24">الإجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {currencies?.map(c => (
                      <TableRow key={c.id}>
                        <TableCell className="font-bold">{c.code}</TableCell>
                        <TableCell>{c.name}</TableCell>
                        <TableCell className="font-mono">{c.exchangeRate}</TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-600" onClick={() => setEditingCurrency({ id: c.id, code: c.code, name: c.name, exchangeRate: c.exchangeRate || "1.00" })}>
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600" onClick={() => { if(confirm("هل أنت متأكد؟")) deleteCurrencyMutation.mutate({ id: c.id }); }}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="permissions" className="space-y-4 mt-6">
          <Card className="border-gray-200 shadow-sm">
            <CardHeader className="p-6 pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <ShieldCheck className="h-5 w-5 text-primary" /> إدارة صلاحيات الموظفين
              </CardTitle>
              <CardDescription>التحكم في الأقسام المالية والتشغيلية المتاحة لكل مستخدم</CardDescription>
            </CardHeader>
            <CardContent className="p-6 pt-2 space-y-6">
              <div className="space-y-2">
                <Label className="font-bold">اختر الموظف / المندوب</Label>
                <Select value={selectedUserId ? String(selectedUserId) : ""} onValueChange={v => setSelectedUserId(parseInt(v))}>
                  <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue placeholder="اختر مستخدماً لتعديل صلاحياته" /></SelectTrigger>
                  <SelectContent>
                    {usersList?.map(u => (
                      <SelectItem key={u.id} value={String(u.id)} className="text-right">
                        {u.name} {u.role === "admin" ? "(مدير)" : "(موظف)"}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedUserId && (
                <div className="space-y-6">
                  <div className="flex flex-col md:flex-row gap-3">
                    <Button variant="outline" onClick={selectAllFinancial} className="h-12 md:h-10 flex-1 font-bold border-blue-200 text-blue-700 hover:bg-blue-50">
                      <CheckCircle2 className="h-4 w-4 ml-2" /> فتح جميع الأقسام المالية
                    </Button>
                    <Button variant="outline" onClick={deselectAllFinancial} className="h-12 md:h-10 flex-1 font-bold border-red-200 text-red-700 hover:bg-red-50">
                      <XCircle className="h-4 w-4 ml-2" /> إخفاء الأقسام المالية
                    </Button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-4">
                      <h3 className="font-black text-blue-900 border-b pb-2 flex justify-between items-center">
                        <span>الأقسام المالية</span>
                        <Badge variant="secondary">{allowedCount(financialModules)}/{financialModules.length}</Badge>
                      </h3>
                      <div className="grid grid-cols-1 gap-2">
                        {financialModules.map(m => (
                          <div key={m.id} className="flex items-center justify-between p-3 rounded-lg border bg-white hover:bg-gray-50 transition-colors">
                            <span className="text-sm font-medium">{m.label}</span>
                            <Button 
                              size="sm" 
                              variant={isModuleAllowed(m.id) ? "default" : "outline"}
                              className={isModuleAllowed(m.id) ? "bg-green-600 hover:bg-green-700" : ""}
                              onClick={() => toggleModule(m.id, !isModuleAllowed(m.id))}
                            >
                              {isModuleAllowed(m.id) ? "متاح" : "مخفي"}
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h3 className="font-black text-green-900 border-b pb-2 flex justify-between items-center">
                        <span>الأقسام التشغيلية</span>
                        <Badge variant="secondary">{allowedCount(operationalModules)}/{operationalModules.length}</Badge>
                      </h3>
                      <div className="grid grid-cols-1 gap-2">
                        {operationalModules.map(m => (
                          <div key={m.id} className="flex items-center justify-between p-3 rounded-lg border bg-white hover:bg-gray-50 transition-colors">
                            <span className="text-sm font-medium">{m.label}</span>
                            <Button 
                              size="sm" 
                              variant={isModuleAllowed(m.id) ? "default" : "outline"}
                              className={isModuleAllowed(m.id) ? "bg-green-600 hover:bg-green-700" : ""}
                              onClick={() => toggleModule(m.id, !isModuleAllowed(m.id))}
                            >
                              {isModuleAllowed(m.id) ? "متاح" : "مخفي"}
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {auditLogs && auditLogs.length > 0 && (
                    <div className="mt-8 pt-8 border-t">
                      <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                        <History className="h-5 w-5 text-muted-foreground" /> سجل تغييرات الصلاحيات
                      </h3>
                      <div className="overflow-x-auto border rounded-lg">
                        <Table>
                          <TableHeader className="bg-gray-50">
                            <TableRow>
                              <TableHead className="text-right font-bold">التاريخ</TableHead>
                              <TableHead className="text-right font-bold">القسم</TableHead>
                              <TableHead className="text-right font-bold">الإجراء</TableHead>
                              <TableHead className="text-right font-bold">بواسطة</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {auditLogs.map(log => (
                              <TableRow key={log.id}>
                                <TableCell className="text-xs text-muted-foreground">{formatAuditDate(log.createdAt)}</TableCell>
                                <TableCell className="font-medium text-xs">{allModuleLabels[log.moduleId] || log.moduleId}</TableCell>
                                <TableCell>
                                  <Badge variant={log.canView ? "default" : "destructive"} className="text-[10px] py-0">
                                    {log.canView ? "تفعيل" : "إلغاء"}
                                  </Badge>
                                </TableCell>
                                <TableCell className="text-xs">{log.adminName}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="appearance" className="space-y-4 mt-6">
          <Card className="border-gray-200 shadow-sm">
            <CardHeader className="p-6 pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <Type className="h-5 w-5 text-primary" /> تخصيص المظهر والخطوط
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6 pt-2 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="font-bold border-b pb-2">الخطوط المتاحة</h3>
                  <div className="flex gap-2">
                    <Input value={newFont.name} onChange={e => setNewFont(f => ({ ...f, name: e.target.value }))} placeholder="اسم الخط" className="h-10" />
                    <Button onClick={() => createFontMutation.mutate(newFont)} size="sm" className="h-10">إضافة</Button>
                  </div>
                  <div className="space-y-2 mt-4">
                    {fonts?.map(f => (
                      <div key={f.id} className="flex items-center justify-between p-2 border rounded bg-white">
                        <span style={{ fontFamily: f.fontFamily }}>{f.name}</span>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600" onClick={() => deleteFontMutation.mutate({ id: f.id })}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="space-y-4">
                  <h3 className="font-bold border-b pb-2">اللغات</h3>
                  <div className="flex gap-2">
                    <Input value={newLang.name} onChange={e => setNewLang(l => ({ ...l, name: e.target.value }))} placeholder="اللغة" className="h-10" />
                    <Button onClick={() => createLangMutation.mutate(newLang)} size="sm" className="h-10">إضافة</Button>
                  </div>
                  <div className="space-y-2 mt-4">
                    {languages?.map(l => (
                      <div key={l.id} className="flex items-center justify-between p-2 border rounded bg-white">
                        <span>{l.name}</span>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600" onClick={() => deleteLangMutation.mutate({ id: l.id })}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="backup" className="space-y-4 mt-6">
          <Card className="border-gray-200 shadow-sm">
            <CardHeader className="p-6 pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Database className="h-5 w-5 text-primary" /> النسخ الاحتياطي
                </CardTitle>
                <Button onClick={() => createBackupMutation.mutate({ name: `نسخة ${new Date().toLocaleDateString("ar-SA")}` })} className="h-9 font-bold">
                  <Plus className="h-4 w-4 ml-1" /> إنشاء نسخة الآن
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {isMobile ? (
                <div className="divide-y">
                  {backups?.map(b => (
                    <div key={b.id} className="p-4 flex justify-between items-center bg-white">
                      <div>
                        <div className="font-bold text-sm">نسخة احتياطية #{b.id}</div>
                        <div className="text-xs text-muted-foreground mt-1">
                          {new Date(b.createdAt).toLocaleString("ar-SA")}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="ghost" size="icon" className="text-blue-600">
                          <History className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="text-red-600">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <Table>
                  <TableHeader className="bg-gray-50">
                    <TableRow>
                      <TableHead className="text-right font-bold">المعرف</TableHead>
                      <TableHead className="text-right font-bold">التاريخ</TableHead>
                      <TableHead className="text-left font-bold w-24">الإجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {backups?.map(b => (
                      <TableRow key={b.id}>
                        <TableCell>#{b.id}</TableCell>
                        <TableCell>{new Date(b.createdAt).toLocaleString("ar-SA")}</TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-600"><History className="h-4 w-4" /></Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600"><Trash2 className="h-4 w-4" /></Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Currency Edit Dialog */}
      {editingCurrency && (
        <Dialog open={!!editingCurrency} onOpenChange={() => setEditingCurrency(null)}>
          <DialogContent className="max-w-md p-6">
            <DialogHeader>
              <DialogTitle>تعديل العملة: {editingCurrency.code}</DialogTitle>
            </DialogHeader>
            <div className="grid grid-cols-1 gap-4 mt-4">
              <div className="space-y-2">
                <Label>الاسم</Label>
                <Input value={editingCurrency.name} onChange={e => setEditingCurrency(c => c ? { ...c, name: e.target.value } : null)} />
              </div>
              <div className="space-y-2">
                <Label>سعر الصرف (مقابل العملة الأساسية)</Label>
                <Input type="number" step="0.01" value={editingCurrency.exchangeRate} onChange={e => setEditingCurrency(c => c ? { ...c, exchangeRate: e.target.value } : null)} />
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <Button variant="outline" className="flex-1 h-12 md:h-10" onClick={() => setEditingCurrency(null)}>إلغاء</Button>
              <Button className="flex-1 h-12 md:h-10 font-bold" onClick={() => updateCurrencyMutation.mutate({ id: editingCurrency.id, name: editingCurrency.name, exchangeRate: editingCurrency.exchangeRate })}>تحديث</Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
