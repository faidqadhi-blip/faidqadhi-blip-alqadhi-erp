import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Users, Receipt, CreditCard, Calendar, ArrowUpRight, ArrowDownLeft, Wallet } from "lucide-react";
import { useState } from "react";
import { useIsMobile } from "@/hooks/useMobile";
import { Badge } from "@/components/ui/badge";

export default function ClientStatement() {
  const isMobile = useIsMobile();
  const [clientId, setClientId] = useState("");
  const { data: clients } = trpc.clients.list.useQuery();
  const { data: statement } = trpc.statements.get.useQuery(
    { clientId: Number(clientId) },
    { enabled: !!clientId }
  );

  return (
    <div className="space-y-4 pb-20 md:pb-4" dir="rtl">
      <div className="px-1">
        <h1 className="text-2xl font-bold">كشف حساب العميل</h1>
        <p className="text-sm text-muted-foreground mt-1">عرض الفواتير والمدفوعات لكل عميل</p>
      </div>

      <Card className="border-gray-200 shadow-sm overflow-hidden">
        <CardContent className="p-4 md:p-5">
          <div className="w-full md:w-80">
            <label className="text-xs font-bold text-muted-foreground mb-1.5 block">اختر العميل</label>
            <Select value={clientId} onValueChange={setClientId}>
              <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue placeholder="اختر العميل" /></SelectTrigger>
              <SelectContent>
                {clients?.map((c: any) => (
                  <SelectItem key={c.id} value={String(c.id)} className="text-right">{c.name} ({c.code})</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {statement?.client && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="border-gray-200 shadow-sm bg-blue-50/30">
              <CardContent className="p-4 flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center shrink-0">
                  <Receipt className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-0.5">إجمالي الفواتير</p>
                  <p className="text-xl font-black">{Number(statement.totalInvoices || 0).toLocaleString('en-US')} <span className="text-xs font-normal">ر.ي</span></p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-gray-200 shadow-sm bg-green-50/30">
              <CardContent className="p-4 flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center shrink-0">
                  <CreditCard className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-0.5">إجمالي المدفوعات</p>
                  <p className="text-xl font-black text-green-600">{Number(statement.totalPayments || 0).toLocaleString('en-US')} <span className="text-xs font-normal">ر.ي</span></p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-gray-200 shadow-sm bg-orange-50/30">
              <CardContent className="p-4 flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-orange-100 flex items-center justify-center shrink-0">
                  <Wallet className="h-6 w-6 text-orange-600" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-0.5">الرصيد المستحق</p>
                  <p className={`text-xl font-black ${Number(statement.balance || 0) > 0 ? "text-red-600" : "text-green-600"}`}>
                    {Number(statement.balance || 0).toLocaleString('en-US')} <span className="text-xs font-normal">ر.ي</span>
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="border-gray-200 shadow-sm overflow-hidden">
            <CardHeader className="bg-gray-50/50 p-4 border-b">
              <CardTitle className="text-lg flex items-center gap-2">
                <ArrowUpRight className="h-5 w-5 text-blue-600" /> الفواتير
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {statement.invoices.length === 0 ? (
                <p className="text-center py-10 text-muted-foreground">لا توجد فواتير</p>
              ) : isMobile ? (
                <div className="divide-y divide-gray-100">
                  {statement.invoices.map((inv: any) => (
                    <div key={inv.id} className="p-4 bg-white">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <span className="font-bold text-base block">{inv.number}</span>
                          <span className="text-xs text-muted-foreground">{inv.invoiceType.replace("_", " ")}</span>
                        </div>
                        <Badge variant={inv.status === "paid" ? "default" : "outline"} className={inv.status === "paid" ? "bg-green-600" : ""}>
                          {inv.status}
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <div className="flex items-center gap-1 text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          <span>{inv.date || "-"}</span>
                        </div>
                        <span className="font-black text-blue-600">{Number(inv.totalAmount || 0).toLocaleString('en-US')} ر.ي</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <Table>
                  <TableHeader className="bg-gray-50">
                    <TableRow>
                      <TableHead className="text-right font-bold">رقم الفاتورة</TableHead>
                      <TableHead className="text-right font-bold">النوع</TableHead>
                      <TableHead className="text-right font-bold">التاريخ</TableHead>
                      <TableHead className="text-right font-bold">المبلغ</TableHead>
                      <TableHead className="text-right font-bold">الحالة</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {statement.invoices.map((inv: any) => (
                      <TableRow key={inv.id}>
                        <TableCell className="font-bold">{inv.number}</TableCell>
                        <TableCell className="text-xs">{inv.invoiceType.replace("_", " ")}</TableCell>
                        <TableCell>{inv.date || "-"}</TableCell>
                        <TableCell className="font-bold">{Number(inv.totalAmount || 0).toLocaleString('en-US')} ر.ي</TableCell>
                        <TableCell>
                          <Badge variant={inv.status === "paid" ? "default" : "outline"} className={inv.status === "paid" ? "bg-green-600" : ""}>
                            {inv.status}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          <Card className="border-gray-200 shadow-sm overflow-hidden">
            <CardHeader className="bg-gray-50/50 p-4 border-b">
              <CardTitle className="text-lg flex items-center gap-2">
                <ArrowDownLeft className="h-5 w-5 text-green-600" /> المدفوعات
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {statement.payments.length === 0 ? (
                <p className="text-center py-10 text-muted-foreground">لا توجد مدفوعات</p>
              ) : isMobile ? (
                <div className="divide-y divide-gray-100">
                  {statement.payments.map((p: any) => (
                    <div key={p.id} className="p-4 bg-white">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-bold">سند قبض #{p.id}</span>
                        <span className="font-black text-green-600">{Number(p.amount || 0).toLocaleString('en-US')} ر.ي</span>
                      </div>
                      <div className="flex justify-between items-center text-sm text-muted-foreground">
                        <span>فاتورة: {p.invoiceId || "-"}</span>
                        <div className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          <span>{p.paymentDate || "-"}</span>
                        </div>
                      </div>
                      <div className="mt-1 text-xs text-muted-foreground">طريقة الدفع: {p.method || "-"}</div>
                    </div>
                  ))}
                </div>
              ) : (
                <Table>
                  <TableHeader className="bg-gray-50">
                    <TableRow>
                      <TableHead className="text-right font-bold">#</TableHead>
                      <TableHead className="text-right font-bold">رقم الفاتورة</TableHead>
                      <TableHead className="text-right font-bold">المبلغ</TableHead>
                      <TableHead className="text-right font-bold">طريقة الدفع</TableHead>
                      <TableHead className="text-right font-bold">التاريخ</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {statement.payments.map((p: any) => (
                      <TableRow key={p.id}>
                        <TableCell className="font-medium">{p.id}</TableCell>
                        <TableCell>{p.invoiceId}</TableCell>
                        <TableCell className="font-bold text-green-600">{Number(p.amount || 0).toLocaleString('en-US')} ر.ي</TableCell>
                        <TableCell>{p.method || "-"}</TableCell>
                        <TableCell>{p.paymentDate || "-"}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </>
      )}

      {!statement?.client && clientId && (
        <div className="text-center py-16 text-muted-foreground bg-white rounded-lg border border-dashed border-gray-300 mx-1">
          <Users className="h-16 w-16 mx-auto mb-4 opacity-20" />
          <p className="text-lg">لم يتم العثور على بيانات العميل</p>
        </div>
      )}
    </div>
  );
}
