import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Loader2, Plus, Trash2, Receipt, Search, Printer, ArrowRight } from "lucide-react";
import { useState, useEffect } from "react";
import { getDefaultCurrency } from "@/lib/currency";
import { toast } from "sonner";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

// تحويل الأرقام إلى كلمات عربية
function numberToArabicWords(num: number): string {
  if (num === 0) return "صفر";
  const ones = ["", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة"];
  const tens = ["", "عشرة", "عشرون", "ثلاثون", "أربعون", "خمسون", "ستون", "سبعون", "ثمانون", "تسعون"];
  const teens = ["عشرة", "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر", "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر"];
  let result = "";
  if (num >= 1000000) {
    const millions = Math.floor(num / 1000000);
    result += numberToArabicWords(millions) + " مليون ";
    num = num % 1000000;
  }
  if (num >= 1000) {
    const thousands = Math.floor(num / 1000);
    if (thousands === 1) result += "ألف ";
    else if (thousands === 2) result += "ألفين ";
    else result += numberToArabicWords(thousands) + " ألف ";
    num = num % 1000;
  }
  if (num >= 100) {
    const hundreds = Math.floor(num / 100);
    if (hundreds === 1) result += "مائة ";
    else if (hundreds === 2) result += "مائتان ";
    else if (hundreds >= 3) result += numberToArabicWords(hundreds).replace("ثمانية", "ثمان") + "مائة ";
    num = num % 100;
  }
  if (num > 0) {
    if (num < 10) result += ones[num];
    else if (num < 20) result += teens[num - 10];
    else {
      const t = Math.floor(num / 10);
      const o = num % 10;
      if (o > 0) result += ones[o] + " و" + tens[t];
      else result += tens[t];
    }
  }
  return result.trim();
}

interface VoucherForm {
  voucherType: string;
  clientId: string;
  cashboxId: string;
  amount: string;
  currency: string;
  paymentMethod: string;
  description: string;
  date: string;
  status: string;
  declarationNumber: string;
}

const initialForm: VoucherForm = {
  voucherType: "سند_قبض", clientId: "", cashboxId: "", amount: "",
  currency: "YER", paymentMethod: "نقدي",
  description: "", date: new Date().toISOString().split("T")[0],
  status: "معتمد",
  declarationNumber: "",
};

export default function Vouchers() {
  const utils = trpc.useUtils();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<VoucherForm>(initialForm);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedVoucher, setSelectedVoucher] = useState<any>(null);

  const { data: vouchers, isLoading } = trpc.vouchers.list.useQuery();
  const { data: clients } = trpc.clients.list.useQuery();
  const { data: cashBoxes } = trpc.cashboxes.list.useQuery();
  const { data: nextNum } = trpc.vouchers.nextNumber.useQuery();
  const { data: currencies } = trpc.currencies.list.useQuery();
  const { data: systemSettings } = trpc.settings.getAll.useQuery();
  const { data: declarations } = trpc.declarations.list.useQuery();

  // Auto-fetch declaration data
  useEffect(() => {
    if (form.declarationNumber && declarations && form.declarationNumber !== "__none__") {
      const decl = declarations.find(d => d.declarationNumber === form.declarationNumber);
      if (decl) {
        setForm(prev => ({
          ...prev,
          clientId: decl.clientId ? String(decl.clientId) : prev.clientId,
          description: `رسوم ومصاريف البيان الجمركي رقم ${decl.declarationNumber} - ${decl.goodsType || ""}`,
          amount: String(decl.declarationFee || prev.amount),
        }));
      }
    }
  }, [form.declarationNumber, declarations]);

  useEffect(() => {
    if (systemSettings) {
      const defaultCurr = getDefaultCurrency(systemSettings);
      setForm(p => ({ ...p, currency: defaultCurr }));
    }
  }, [systemSettings]);

  const postMutation = trpc.vouchers.postToLedger.useMutation({
    onSuccess: () => {
      utils.vouchers.list.invalidate();
      toast.success("تم ترحيل السند إلى الأستاذ العام بنجاح");
    },
    onError: (e) => toast.error(e.message),
  });

  const createMutation = trpc.vouchers.create.useMutation({
    onSuccess: () => {
      utils.vouchers.list.invalidate();
      setOpen(false);
      setForm(initialForm);
      toast.success("تم إنشاء السند بنجاح");
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = trpc.vouchers.delete.useMutation({
    onSuccess: () => {
      utils.vouchers.list.invalidate();
      toast.success("تم حذف السند");
    },
    onError: (e) => toast.error(e.message),
  });

  const filtered = vouchers?.filter(v =>
    searchQuery === "" ||
    (v.description || "").toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  const typeLabels: Record<string, { label: string; cls: string }> = {
    "سند_قبض": { label: "سند قبض", cls: "bg-green-500/10 text-green-600 border-green-200" },
    "سند_صرف": { label: "سند صرف", cls: "bg-red-500/10 text-red-600 border-red-200" },
  };

  const handleSubmit = () => {
    if (!form.voucherType || !form.amount) {
      toast.error("يرجى ملء الحقول المطلوبة");
      return;
    }
    const selectedDecl = declarations?.find(d => d.declarationNumber === form.declarationNumber);
    createMutation.mutate({
      number: nextNum ?? 1,
      voucherType: form.voucherType,
      clientId: form.clientId ? parseInt(form.clientId) : undefined,
      cashboxId: form.cashboxId ? parseInt(form.cashboxId) : undefined,
      amount: form.amount,
      currency: form.currency,
      paymentMethod: form.paymentMethod,
      description: form.description,
      date: form.date,
      status: form.status,
      sourceDeclarationId: selectedDecl?.id,
    });
  };

  // Print voucher
  const handlePrintVoucher = (voucher: any) => {
    setSelectedVoucher(voucher);
    setTimeout(() => {
      const element = document.getElementById(`voucher-print-${voucher.id}`);
      if (!element) return;
      const printWindow = window.open('', '_blank');
      if (!printWindow) { toast.error("يرجى السماح بالنوافذ المنبثقة"); return; }
      printWindow.document.write(`
        <!DOCTYPE html><html dir="rtl"><head><meta charset="UTF-8"><title>سند رقم ${voucher.number}</title>
        <style>* { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Tajawal', Arial, sans-serif; }
        body { padding: 15mm; font-size: 13px; color: #333; }
        @media print { body { padding: 10mm; } }</style></head>
        <body>${element.innerHTML}</body></html>
      `);
      printWindow.document.close();
      printWindow.print();
    }, 100);
  };

  // Download voucher PDF
  const handleDownloadVoucherPDF = async (voucher: any) => {
    const element = document.getElementById(`voucher-print-${voucher.id}`);
    if (!element) { toast.error("لم يتم العثور على السند"); return; }
    const canvas = await html2canvas(element, { scale: 2, backgroundColor: '#ffffff' });
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF('p', 'mm', 'a4');
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    pdf.save(`سند-${voucher.number}.pdf`);
    toast.success("تم تحميل السند PDF");
  };

  const getClientName = (clientId: number | null | undefined) => {
    if (!clientId) return "-";
    const client = clients?.find(c => c.id === clientId);
    return client?.name || "-";
  };

  const getCurrencyNameFn = (code: string | null | undefined) => {
    const c = currencies?.find(c => c.code === code);
    return c?.name || code;
  };

  const voucherDate = (date: string | null | undefined) => {
    if (!date) return "-";
    return new Date(date).toLocaleDateString("ar-SA", { year: "numeric", month: "long", day: "numeric" });
  };

  return (
    <div className="space-y-6 pb-20 md:pb-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">السندات</h2>
          <p className="text-sm text-muted-foreground mt-1">إدارة سندات القبض والصرف</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="h-12 md:h-10 w-full md:w-auto gap-2 font-bold"><Plus className="h-4 w-4" /> سند جديد</Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg w-[95vw] rounded-xl overflow-y-auto max-h-[90vh]">
            <DialogHeader><DialogTitle>سند جديد</DialogTitle></DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
              <div className="space-y-2">
                <Label className="font-bold">نوع السند *</Label>
                <Select value={form.voucherType} onValueChange={(v) => setForm(p => ({ ...p, voucherType: v }))}>
                  <SelectTrigger className="h-12"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="سند_قبض">سند قبض</SelectItem>
                    <SelectItem value="سند_صرف">سند صرف</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="font-bold">رقم البيان الجمركي</Label>
                <Select value={form.declarationNumber} onValueChange={(v) => setForm(p => ({ ...p, declarationNumber: v }))}>
                  <SelectTrigger className="h-12"><SelectValue placeholder="اختر البيان" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none__">بدون بيان</SelectItem>
                    {declarations?.map(d => (
                      <SelectItem key={d.id} value={d.declarationNumber}>{d.declarationNumber}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="font-bold">العميل</Label>
                <Select value={form.clientId} onValueChange={(v) => setForm(p => ({ ...p, clientId: v }))}>
                  <SelectTrigger className="h-12"><SelectValue placeholder="اختر العميل" /></SelectTrigger>
                  <SelectContent>
                    {clients?.map(c => (
                      <SelectItem key={c.id} value={String(c.id)}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="font-bold">الصندوق</Label>
                <Select value={form.cashboxId} onValueChange={(v) => setForm(p => ({ ...p, cashboxId: v }))}>
                  <SelectTrigger className="h-12"><SelectValue placeholder="اختر الصندوق" /></SelectTrigger>
                  <SelectContent>
                    {cashBoxes?.map(cb => (
                      <SelectItem key={cb.id} value={String(cb.id)}>{cb.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="font-bold">المبلغ *</Label>
                <Input type="number" value={form.amount} onChange={(e) => setForm(p => ({ ...p, amount: e.target.value }))} placeholder="0.00" className="h-12 font-mono" />
              </div>
              <div className="space-y-2">
                <Label className="font-bold">العملة</Label>
                <Select value={form.currency} onValueChange={(v) => setForm(p => ({ ...p, currency: v }))}>
                  <SelectTrigger className="h-12"><SelectValue placeholder="اختر العملة" /></SelectTrigger>
                  <SelectContent>
                    {currencies?.map(c => (
                      <SelectItem key={c.code} value={c.code}>{c.name}</SelectItem>
                    )) || (
                      <>
                        <SelectItem value="YER">ريال يمني</SelectItem>
                        <SelectItem value="SAR">ريال سعودي</SelectItem>
                        <SelectItem value="USD">دولار أمريكي</SelectItem>
                      </>
                    )}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2 col-span-1 md:col-span-2">
                <Label className="font-bold">طريقة الدفع</Label>
                <Select value={form.paymentMethod} onValueChange={(v) => setForm(p => ({ ...p, paymentMethod: v }))}>
                  <SelectTrigger className="h-12"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="نقدي">نقدي</SelectItem>
                    <SelectItem value="تحويل بنكي">تحويل بنكي</SelectItem>
                    <SelectItem value="شيك">شيك</SelectItem>
                    <SelectItem value="بطاقة">بطاقة</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2 col-span-1 md:col-span-2">
                <Label className="font-bold">الوصف</Label>
                <Input value={form.description} onChange={(e) => setForm(p => ({ ...p, description: e.target.value }))} className="h-12" />
              </div>
              <div className="space-y-2">
                <Label className="font-bold">التاريخ</Label>
                <Input type="date" value={form.date} onChange={(e) => setForm(p => ({ ...p, date: e.target.value }))} className="h-12" />
              </div>
              <div className="space-y-2">
                <Label className="font-bold">الحالة</Label>
                <Select value={form.status} onValueChange={(v) => setForm(p => ({ ...p, status: v }))}>
                  <SelectTrigger className="h-12"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="معتمد">معتمد</SelectItem>
                    <SelectItem value="مسودة">مسودة</SelectItem>
                    <SelectItem value="ملغي">ملغي</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <Button onClick={handleSubmit} className="w-full mt-6 h-12 font-bold" disabled={createMutation.isPending}>
              {createMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin ml-2" /> : "حفظ السند"}
            </Button>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="shadow-sm border-gray-200">
        <CardContent className="p-3 md:p-4 pt-6">
          <div className="relative mb-4">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="البحث في السندات..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="pr-10 h-12 md:h-10"
            />
          </div>
          
          {isLoading ? (
            <div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Receipt className="h-12 w-12 mx-auto mb-3 opacity-30" />
              <p>لا توجد سندات بعد</p>
            </div>
          ) : (
            <>
              {/* Desktop Table */}
              <div className="hidden md:block overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>رقم السند</TableHead>
                      <TableHead>النوع</TableHead>
                      <TableHead>العميل</TableHead>
                      <TableHead>المبلغ</TableHead>
                      <TableHead>المرجع</TableHead>
                      <TableHead>التاريخ</TableHead>
                      <TableHead>الحالة</TableHead>
                      <TableHead>إجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filtered.map(v => (
                      <TableRow key={v.id}>
                        <TableCell className="font-bold">#{v.number}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className={`${typeLabels[v.voucherType]?.cls || ""} rounded-lg`}>{typeLabels[v.voucherType]?.label || v.voucherType}</Badge>
                        </TableCell>
                        <TableCell className="font-medium">{getClientName(v.clientId)}</TableCell>
                        <TableCell className="font-bold font-mono">{Number(v.amount || 0).toLocaleString('en-US')} {getCurrencyNameFn(v.currency)}</TableCell>
                        <TableCell>{v.paymentMethod || "-"}</TableCell>
                        <TableCell>{v.date || "-"}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className={`${v.status === "مرحل" ? "bg-blue-500/10 text-blue-600" : v.status === "معتمد" ? "bg-green-500/10 text-green-600" : "bg-gray-100 text-gray-600"} rounded-lg`}>
                            {v.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="flex gap-1">
                          {v.status !== "مرحل" && (
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => {
                                if (confirm("هل أنت متأكد من ترحيل هذا السند؟ لا يمكن التعديل بعد الترحيل.")) {
                                  postMutation.mutate({ id: v.id });
                                }
                              }}
                              disabled={postMutation.isPending}
                              title="ترحيل إلى الأستاذ العام"
                            >
                              <ArrowRight className="h-4 w-4 text-blue-600" />
                            </Button>
                          )}
                          <Button variant="ghost" size="sm" onClick={() => handlePrintVoucher(v)}>
                            <Printer className="h-4 w-4 text-blue-600" />
                          </Button>
                          <Button variant="ghost" size="sm" onClick={() => {
                            handlePrintVoucher(v);
                            setTimeout(() => handleDownloadVoucherPDF(v), 500);
                          }}>
                            <Receipt className="h-4 w-4 text-green-600" />
                          </Button>
                          <Button variant="ghost" size="sm" onClick={() => { if (confirm("حذف السند؟")) deleteMutation.mutate({ id: v.id }); }}>
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Mobile Card View */}
              <div className="md:hidden space-y-3 bg-gray-50/30 p-2 rounded-lg">
                {filtered.map(v => (
                  <div key={v.id} className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm space-y-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="text-[10px] text-muted-foreground font-bold uppercase">رقم السند</div>
                        <div className="font-bold text-primary">#{v.number}</div>
                      </div>
                      <Badge variant="outline" className={`${typeLabels[v.voucherType]?.cls || ""} rounded-lg`}>
                        {typeLabels[v.voucherType]?.label || v.voucherType}
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <div className="text-[10px] text-muted-foreground">العميل</div>
                        <div className="font-medium">{getClientName(v.clientId)}</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-muted-foreground">التاريخ</div>
                        <div className="font-medium">{v.date}</div>
                      </div>
                      <div className="col-span-2">
                        <div className="text-[10px] text-muted-foreground">المبلغ</div>
                        <div className="font-black font-mono text-lg">
                          {Number(v.amount || 0).toLocaleString('en-US')} <span className="text-xs text-muted-foreground">{v.currency}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-2 pt-3 border-t border-gray-50">
                      {v.status !== "مرحل" ? (
                        <Button variant="outline" size="sm" className="flex-1 h-10 gap-2 text-blue-600" onClick={() => postMutation.mutate({ id: v.id })} disabled={postMutation.isPending}>
                          <ArrowRight className="h-4 w-4" /> ترحيل
                        </Button>
                      ) : (
                        <Badge variant="default" className="flex-1 h-10 flex items-center justify-center rounded-lg">مرحل</Badge>
                      )}
                      <Button variant="outline" size="sm" className="h-10 w-12" onClick={() => handlePrintVoucher(v)}>
                        <Printer className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm" className="h-10 w-12 text-destructive" onClick={() => { if (confirm("حذف السند؟")) deleteMutation.mutate({ id: v.id }); }}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Hidden voucher print templates */}
      {filtered.map(v => (
        <div key={v.id} id={`voucher-print-${v.id}`} className="hidden">
          <div className="bg-white p-6 max-w-[850px] mx-auto" style={{ direction: 'rtl' }}>
            <div className="flex justify-between items-start mb-4 pb-3 border-b-2 border-gray-700">
              <div className="text-right flex-1">
                <p className="font-bold text-sm">فيدل القاضي للتخليص الجمركي</p>
                <p className="text-xs text-gray-600">- مكتب صنعاء الرئيسي -</p>
                <p className="text-xs text-gray-600">الجمهورية اليمنية</p>
              </div>
              <div className="text-center flex-1">
                <img src="/manus-storage/faidal-logo_11e2a37b.png" alt="Logo" className="h-20 mx-auto mb-1" />
                <p className="text-xs text-gray-500">للتخليص الجمركي والخدمات اللوجستية</p>
              </div>
              <div className="text-left flex-1">
                <p className="font-bold text-sm">FAIDAL AL-QADHI OFFICE</p>
                <p className="text-xs text-gray-600">- SANA'A MAIN OFFICE -</p>
                <p className="text-xs text-gray-600">REPUBLIC OF YEMEN</p>
              </div>
            </div>

            <div className="text-center mb-4">
              <h1 className="text-xl font-bold underline">
                {v.voucherType === "سند_قبض" ? "سند قبض" : "سند صرف"}
              </h1>
            </div>

            <div className="border border-gray-400 mb-4 flex">
              <div className="border-l border-gray-400 px-3 py-2 text-sm font-bold w-32 text-center">التفاصيل</div>
              <div className="flex-1 text-center py-2 text-sm">{v.description || (v.voucherType === "سند_قبض" ? "مبلغ مقبوض من العميل" : "مبلغ مدفوع للجهة")}</div>
            </div>

            <div className="border border-gray-400 mb-4">
              <div className="flex bg-[#4a6d7a] text-white text-sm font-bold">
                <div className="flex-1 text-center py-1.5 border-l border-gray-500">رقم السند</div>
                <div className="flex-1 text-center py-1.5 border-l border-gray-500">التاريخ</div>
                <div className="flex-1 text-center py-1.5">طريقة الدفع</div>
              </div>
              <div className="flex text-sm">
                <div className="flex-1 text-center py-1.5 border-l border-gray-300">#{v.number}</div>
                <div className="flex-1 text-center py-1.5 border-l border-gray-300">{voucherDate(v.date)}</div>
                <div className="flex-1 text-center py-1.5">{v.paymentMethod || "نقدي"}</div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-4 pb-3 border-b border-gray-400 text-sm">
              <div>
                <span className="text-gray-600">الاسم: </span>
                <span className="font-bold">{getClientName(v.clientId || null)}</span>
              </div>
              <div>
                <span className="text-gray-600">الصندوق: </span>
                <span className="font-bold">{v.cashBox || cashBoxes?.find(cb => cb.id === v.cashboxId)?.name || "-"}</span>
              </div>
            </div>

            <div className="border border-gray-400 mb-4">
              <div className="flex bg-[#4a6d7a] text-white text-sm font-bold">
                <div className="flex-1 text-center py-1.5 border-l border-gray-500">البيان</div>
                <div className="flex-1 text-center py-1.5 border-l border-gray-500">العملة</div>
                <div className="flex-1 text-center py-1.5">المبلغ</div>
              </div>
              <div className="flex text-sm border-b border-gray-200">
                <div className="flex-1 text-center py-2 border-l border-gray-300 font-medium">
                  {v.voucherType === "سند_قبض" ? "مبلغ مقبوض" : "مبلغ مدفوع"}
                </div>
                <div className="flex-1 text-center py-2 border-l border-gray-300">{v.currency || "ر.ي"}</div>
                <div className="flex-1 text-center py-2 font-bold">{Number(v.amount || 0).toLocaleString('en-US')}</div>
              </div>
            </div>

            <div className="border border-gray-400 max-w-[300px] ml-auto mb-4">
              <div className="flex text-sm bg-gray-100">
                <div className="flex-1 text-center py-2 border-l border-gray-300 font-bold">الإجمالي</div>
                <div className="flex-1 text-center py-2 font-bold">{Number(v.amount || 0).toLocaleString('en-US')}</div>
              </div>
            </div>

            <div className="border border-gray-400 bg-gray-50 px-4 py-2 mb-6 text-sm">
              <strong>المبلغ كتابةً:</strong> {numberToArabicWords(Number(v.amount || 0))} {v.currency === 'USD' ? 'دولار أمريكي' : v.currency === 'SAR' ? 'ريال سعودي' : 'ريال يمني'} فقط لا غير
            </div>

            <div className="flex justify-between mt-10 text-sm">
              <div>
                <span className="font-bold">المحاسب : </span>
                <span>............................</span>
              </div>
              <div>
                <span className="font-bold">المستلم : </span>
                <span>............................</span>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
