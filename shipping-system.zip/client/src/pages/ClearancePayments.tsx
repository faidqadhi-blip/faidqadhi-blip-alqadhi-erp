import { useState, useEffect } from "react";
import { getDefaultCurrency } from "@/lib/currency";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Download, Loader2, Receipt } from "lucide-react";
import { toast } from "sonner";
import { exportToExcel, exportToCSV, exportMultiSheetExcel } from "@/lib/export";

export default function ClearancePayments() {
  const utils = trpc.useUtils();
  const [selectedDeclId, setSelectedDeclId] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState("receipts");

  const [receiptForm, setReceiptForm] = useState({
    amount: "", currency: "YER", paymentDate: new Date().toISOString().split('T')[0], paymentMethod: "نقداً", paymentType: "نقداً", cashboxId: "", notes: ""
  });
  const [disburseForm, setDisburseForm] = useState({
    payee: "", amount: "", currency: "YER", expenseType: "", paymentDate: new Date().toISOString().split('T')[0], paymentMethod: "نقداً", paymentType: "نقداً", cashboxId: "", notes: ""
  });

  const { data: declarations } = trpc.declarations.list.useQuery();
  const { data: clients } = trpc.clients.list.useQuery();
  const { data: currencies } = trpc.currencies.list.useQuery();
  const { data: systemSettings } = trpc.settings.getAll.useQuery();
  const { data: cashboxes } = trpc.cashboxes.list.useQuery();

  useEffect(() => {
    if (systemSettings) {
      const defaultCurr = getDefaultCurrency(systemSettings);
      setReceiptForm(p => ({ ...p, currency: defaultCurr }));
      setDisburseForm(p => ({ ...p, currency: defaultCurr }));
    }
  }, [systemSettings]);

  const { data: receipts } = trpc.clearanceReceipts.list.useQuery(
    selectedDeclId ? { declarationId: selectedDeclId } : undefined,
    { enabled: !!selectedDeclId }
  );
  const { data: disbursements } = trpc.clearanceDisbursements.list.useQuery(
    selectedDeclId ? { declarationId: selectedDeclId } : undefined,
    { enabled: !!selectedDeclId }
  );

  const createReceiptMutation = trpc.clearanceReceipts.create.useMutation({
    onSuccess: () => {
      toast.success("تم تسجيل المقبوض بنجاح");
      utils.clearanceReceipts.list.invalidate();
      setReceiptForm({ ...receiptForm, amount: "", notes: "" });
    },
    onError: (e) => toast.error(e.message)
  });

  const deleteReceiptMutation = trpc.clearanceReceipts.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف المقبوض");
      utils.clearanceReceipts.list.invalidate();
    }
  });

  const createDisbursementMutation = trpc.clearanceDisbursements.create.useMutation({
    onSuccess: () => {
      toast.success("تم تسجيل المدفوع بنجاح");
      utils.clearanceDisbursements.list.invalidate();
      setDisburseForm({ ...disburseForm, amount: "", payee: "", notes: "" });
    },
    onError: (e) => toast.error(e.message)
  });

  const deleteDisbursementMutation = trpc.clearanceDisbursements.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف المدفوع");
      utils.clearanceDisbursements.list.invalidate();
    }
  });

  const selectedDecl = declarations?.find(d => d.id === selectedDeclId);

  const getClientName = (clientId: number | null) => {
    if (!clientId) return "-";
    return clients?.find(c => c.id === clientId)?.name || "-";
  };

  const handleExportReceiptsExcel = () => {
    if (!receipts || receipts.length === 0) return;
    const columns = [
      { key: "amount", label: "المبلغ" },
      { key: "currency", label: "العملة" },
      { key: "paymentDate", label: "التاريخ" },
      { key: "paymentMethod", label: "الطريقة" },
      { key: "notes", label: "ملاحظات" }
    ];
    exportToExcel(receipts, columns, `مقبوضات_بيان_${selectedDecl?.declarationNumber}`);
  };

  const handleExportReceiptsCSV = () => {
    if (!receipts || receipts.length === 0) return;
    const columns = [
      { key: "amount", label: "المبلغ" },
      { key: "currency", label: "العملة" },
      { key: "paymentDate", label: "التاريخ" },
      { key: "paymentMethod", label: "الطريقة" },
      { key: "notes", label: "ملاحظات" }
    ];
    exportToCSV(receipts, columns, `مقبوضات_بيان_${selectedDecl?.declarationNumber}`);
  };

  const handleExportDisbursementsExcel = () => {
    if (!disbursements || disbursements.length === 0) return;
    const columns = [
      { key: "payee", label: "الجهة" },
      { key: "amount", label: "المبلغ" },
      { key: "currency", label: "العملة" },
      { key: "expenseType", label: "النوع" },
      { key: "paymentDate", label: "التاريخ" },
      { key: "paymentMethod", label: "الطريقة" },
      { key: "notes", label: "ملاحظات" }
    ];
    exportToExcel(disbursements, columns, `مدفوعات_بيان_${selectedDecl?.declarationNumber}`);
  };

  const handleExportDisbursementsCSV = () => {
    if (!disbursements || disbursements.length === 0) return;
    const columns = [
      { key: "payee", label: "الجهة" },
      { key: "amount", label: "المبلغ" },
      { key: "currency", label: "العملة" },
      { key: "expenseType", label: "النوع" },
      { key: "paymentDate", label: "التاريخ" },
      { key: "paymentMethod", label: "الطريقة" },
      { key: "notes", label: "ملاحظات" }
    ];
    exportToCSV(disbursements, columns, `مدفوعات_بيان_${selectedDecl?.declarationNumber}`);
  };

  const handleExportComprehensive = () => {
    if (!selectedDecl) return;
    const sheets = [
      {
        sheetName: "المقبوضات",
        data: receipts || [],
        columns: [
          { key: "amount", label: "المبلغ" },
          { key: "currency", label: "العملة" },
          { key: "paymentDate", label: "التاريخ" },
          { key: "paymentMethod", label: "الطريقة" },
          { key: "paymentType", label: "النوع" },
          { key: "notes", label: "ملاحظات" }
        ]
      },
      {
        sheetName: "المدفوعات",
        data: disbursements || [],
        columns: [
          { key: "payee", label: "الجهة" },
          { key: "amount", label: "المبلغ" },
          { key: "currency", label: "العملة" },
          { key: "expenseType", label: "النوع" },
          { key: "paymentDate", label: "التاريخ" },
          { key: "paymentMethod", label: "الطريقة" },
          { key: "notes", label: "ملاحظات" }
        ]
      }
    ];
    exportMultiSheetExcel(sheets, `تقرير_مالي_شامل_بيان_${selectedDecl.declarationNumber}`);
  };

  const handleAddReceipt = () => {
    if (!selectedDeclId || !receiptForm.amount) {
      toast.error("يرجى اختيار البيان وإدخال المبلغ");
      return;
    }
    createReceiptMutation.mutate({
      declarationId: selectedDeclId,
      amount: receiptForm.amount,
      currency: receiptForm.currency,
      paymentDate: receiptForm.paymentDate,
      paymentMethod: receiptForm.paymentMethod,
      paymentType: receiptForm.paymentType as "نقداً" | "آجل" | "حوالة",
      cashboxId: receiptForm.cashboxId ? Number(receiptForm.cashboxId) : undefined,
      notes: receiptForm.notes,
    });
  };

  const handleAddDisbursement = () => {
    if (!selectedDeclId || !disburseForm.amount || !disburseForm.payee) {
      toast.error("يرجى اختيار البيان وإدخال الجهة والمبلغ");
      return;
    }
    createDisbursementMutation.mutate({
      declarationId: selectedDeclId,
      payee: disburseForm.payee,
      amount: disburseForm.amount,
      currency: disburseForm.currency,
      expenseType: disburseForm.expenseType,
      paymentDate: disburseForm.paymentDate,
      paymentMethod: disburseForm.paymentMethod,
      paymentType: disburseForm.paymentType as "نقداً" | "آجل" | "حوالة",
      cashboxId: disburseForm.cashboxId ? Number(disburseForm.cashboxId) : undefined,
      notes: disburseForm.notes,
    });
  };

  const currencyOptions = currencies?.map(c => ({ code: c.code, name: c.name, symbol: c.symbol })) || [{ code: "YER", name: "ريال يمني", symbol: "YER" }, { code: "SAR", name: "ريال سعودي", symbol: "SAR" }, { code: "USD", name: "دولار أمريكي", symbol: "USD" }];

  const expenseTypeOptions = [
    "رسوم تخليص", "نقل", "وقود", "سائق", "صيانة", "مصاريف أخرى",
  ];

  return (
    <div className="space-y-6 pb-20 md:pb-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">المقبوضات والمدفوعات</h2>
          <p className="text-sm text-muted-foreground mt-1">إدارة العمليات المالية للبيانات الجمركية</p>
        </div>
        <div className="flex gap-2 w-full md:w-auto">
          <Button variant="outline" onClick={handleExportComprehensive} className="flex-1 md:flex-none h-12 md:h-10 gap-2 font-bold">
            <Download className="h-4 w-4" /> تصدير شامل
          </Button>
        </div>
      </div>

      <Card className="shadow-sm border-gray-200">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-3 items-start md:items-center">
            <Label className="font-bold whitespace-nowrap">اختر البيان الجمركي:</Label>
            <Select value={selectedDeclId?.toString() || ""} onValueChange={v => setSelectedDeclId(v ? Number(v) : null)}>
              <SelectTrigger className="w-full md:max-w-md h-12">
                <SelectValue placeholder="ابحث عن رقم البيان..." />
              </SelectTrigger>
              <SelectContent>
                {declarations?.map(d => (
                  <SelectItem key={d.id} value={d.id.toString()}>
                    <div className="flex flex-col items-start">
                      <span className="font-bold">{d.declarationNumber}</span>
                      <span className="text-[10px] text-muted-foreground">{getClientName(d.clientId)} - {d.goodsType || "-"}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {selectedDecl ? (
        <>
          {/* Declaration Info Card */}
          <Card className="bg-primary/5 border-primary/20 overflow-hidden shadow-sm">
            <CardHeader className="p-4 bg-primary/10 border-b border-primary/10">
              <div className="flex justify-between items-center">
                <div className="font-black text-primary text-lg">تفاصيل البيان: {selectedDecl.declarationNumber}</div>
                <Badge variant="outline" className="bg-white/80 font-bold">{selectedDecl.customsPort || "-"}</Badge>
              </div>
            </CardHeader>
            <CardContent className="p-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div>
                  <div className="text-[10px] text-muted-foreground font-bold">العميل</div>
                  <div className="font-bold">{getClientName(selectedDecl.clientId)}</div>
                </div>
                <div>
                  <div className="text-[10px] text-muted-foreground font-bold">البضاعة</div>
                  <div className="font-bold">{selectedDecl.goodsType || "-"}</div>
                </div>
                <div>
                  <div className="text-[10px] text-muted-foreground font-bold">رقم اللوحة</div>
                  <div className="font-bold font-mono">{selectedDecl.plateNumber || "-"}</div>
                </div>
                <div>
                  <div className="text-[10px] text-muted-foreground font-bold">السائق</div>
                  <div className="font-bold">{selectedDecl.driverName || "-"}</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <TabsList className="grid grid-cols-2 w-full max-w-md bg-muted/50 p-1 h-12 rounded-xl">
              <TabsTrigger value="receipts" className="rounded-lg font-bold">المقبوضات</TabsTrigger>
              <TabsTrigger value="disbursements" className="rounded-lg font-bold">المدفوعات</TabsTrigger>
            </TabsList>

            {/* مقبوضات */}
            <TabsContent value="receipts" className="space-y-4">
              <Card className="shadow-sm border-gray-200">
                <CardHeader className="p-4 border-b border-gray-100">
                  <CardTitle className="text-lg font-bold">تسجيل مقبوض جديد</CardTitle>
                </CardHeader>
                <CardContent className="p-4 md:p-6">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <Label className="font-bold">المبلغ *</Label>
                      <Input type="number" value={receiptForm.amount} onChange={e => setReceiptForm({ ...receiptForm, amount: e.target.value })} placeholder="0.00" className="h-12 font-mono text-lg" />
                    </div>
                    <div className="space-y-2">
                      <Label className="font-bold">العملة</Label>
                      <Select value={receiptForm.currency} onValueChange={v => setReceiptForm({ ...receiptForm, currency: v })}>
                        <SelectTrigger className="h-12"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {currencyOptions.map(c => <SelectItem key={c.code} value={c.code}>{c.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="font-bold">التاريخ</Label>
                      <Input type="date" value={receiptForm.paymentDate} onChange={e => setReceiptForm({ ...receiptForm, paymentDate: e.target.value })} className="h-12" />
                    </div>
                    <div className="space-y-2">
                      <Label className="font-bold">الطريقة</Label>
                      <Select value={receiptForm.paymentMethod} onValueChange={v => setReceiptForm({ ...receiptForm, paymentMethod: v })}>
                        <SelectTrigger className="h-12"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="نقداً">نقداً</SelectItem>
                          <SelectItem value="تحويل بنكي">تحويل بنكي</SelectItem>
                          <SelectItem value="شيك">شيك</SelectItem>
                          <SelectItem value="بطاقة">بطاقة</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="font-bold">نوع الدفع</Label>
                      <Select value={receiptForm.paymentType} onValueChange={v => setReceiptForm({ ...receiptForm, paymentType: v })}>
                        <SelectTrigger className="h-12"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="نقداً">نقداً</SelectItem>
                          <SelectItem value="آجل">آجل</SelectItem>
                          <SelectItem value="حوالة">حوالة</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="font-bold">الصندوق/البنك</Label>
                      <Select value={receiptForm.cashboxId} onValueChange={v => setReceiptForm({ ...receiptForm, cashboxId: v })}>
                        <SelectTrigger className="h-12"><SelectValue placeholder="اختر" /></SelectTrigger>
                        <SelectContent>
                          {cashboxes?.map(cb => <SelectItem key={cb.id} value={cb.id.toString()}>{cb.name} ({cb.type === 'صندوق نقدي' ? 'صندوق' : 'بنك'})</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2 md:col-span-2">
                      <Label className="font-bold">ملاحظات</Label>
                      <Input value={receiptForm.notes} onChange={e => setReceiptForm({ ...receiptForm, notes: e.target.value })} className="h-12" />
                    </div>
                    <div className="flex items-end">
                      <Button onClick={handleAddReceipt} className="w-full h-12 font-bold text-lg" disabled={createReceiptMutation.isPending}>
                        {createReceiptMutation.isPending ? <Loader2 className="h-5 w-5 animate-spin" /> : "تسجيل المقبوض"}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-sm border-gray-200">
                <CardHeader className="flex flex-row items-center justify-between p-4 border-b border-gray-100">
                  <CardTitle className="text-lg font-bold">سجل المقبوضات</CardTitle>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={handleExportReceiptsExcel} className="h-9 md:h-8 gap-1">
                      <Download className="h-3.5 w-3.5" /> Excel
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="p-0">
                  {/* Desktop Table */}
                  <div className="hidden md:block overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>المبلغ</TableHead>
                          <TableHead>التاريخ</TableHead>
                          <TableHead>الطريقة</TableHead>
                          <TableHead>ملاحظات</TableHead>
                          <TableHead>إجراءات</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {receipts?.map(r => (
                          <TableRow key={r.id}>
                            <TableCell className="font-black font-mono">
                              {Number(r.amount).toLocaleString('en-US')} {r.currency}
                            </TableCell>
                            <TableCell>{r.paymentDate}</TableCell>
                            <TableCell>{r.paymentMethod}</TableCell>
                            <TableCell className="text-gray-500 max-w-[200px] truncate">{r.notes}</TableCell>
                            <TableCell>
                              <Button variant="ghost" size="sm" className="text-destructive" onClick={() => { if(confirm("حذف المقبوض؟")) deleteReceiptMutation.mutate({ id: r.id }); }}>حذف</Button>
                            </TableCell>
                          </TableRow>
                        ))}
                        {(!receipts || receipts.length === 0) && (
                          <TableRow><TableCell colSpan={5} className="py-12 text-center text-gray-400">لا توجد مقبوضات مسجلة</TableCell></TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>

                  {/* Mobile Card View */}
                  <div className="md:hidden divide-y divide-gray-100 bg-gray-50/30">
                    {receipts?.map(r => (
                      <div key={r.id} className="p-4 bg-white space-y-2">
                        <div className="flex justify-between items-center">
                          <div className="font-black font-mono text-lg text-green-600">
                            {Number(r.amount).toLocaleString('en-US')} <span className="text-xs text-muted-foreground">{r.currency}</span>
                          </div>
                          <div className="text-xs font-bold text-muted-foreground">{r.paymentDate}</div>
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <div className="font-medium text-gray-600">{r.paymentMethod}</div>
                          <Button variant="ghost" size="sm" className="text-destructive h-8 px-2" onClick={() => { if(confirm("حذف المقبوض؟")) deleteReceiptMutation.mutate({ id: r.id }); }}>حذف</Button>
                        </div>
                        {r.notes && <div className="text-xs text-muted-foreground bg-gray-50 p-2 rounded-lg">{r.notes}</div>}
                      </div>
                    ))}
                    {(!receipts || receipts.length === 0) && (
                      <div className="text-center py-12 text-muted-foreground">لا توجد مقبوضات مسجلة</div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* مدفوعات */}
            <TabsContent value="disbursements" className="space-y-4">
              <Card className="shadow-sm border-gray-200">
                <CardHeader className="p-4 border-b border-gray-100">
                  <CardTitle className="text-lg font-bold">تسجيل مدفوع جديد</CardTitle>
                </CardHeader>
                <CardContent className="p-4 md:p-6">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <Label className="font-bold">الجهة</Label>
                      <Input value={disburseForm.payee} onChange={e => setDisburseForm({ ...disburseForm, payee: e.target.value })} placeholder="اسم الجهة" className="h-12" />
                    </div>
                    <div className="space-y-2">
                      <Label className="font-bold">المبلغ *</Label>
                      <Input type="number" value={disburseForm.amount} onChange={e => setDisburseForm({ ...disburseForm, amount: e.target.value })} placeholder="0.00" className="h-12 font-mono text-lg" />
                    </div>
                    <div className="space-y-2">
                      <Label className="font-bold">العملة</Label>
                      <Select value={disburseForm.currency} onValueChange={v => setDisburseForm({ ...disburseForm, currency: v })}>
                        <SelectTrigger className="h-12"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {currencyOptions.map(c => <SelectItem key={c.code} value={c.code}>{c.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="font-bold">النوع</Label>
                      <Select value={disburseForm.expenseType} onValueChange={v => setDisburseForm({ ...disburseForm, expenseType: v })}>
                        <SelectTrigger className="h-12"><SelectValue placeholder="اختر" /></SelectTrigger>
                        <SelectContent>
                          {expenseTypeOptions.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="font-bold">التاريخ</Label>
                      <Input type="date" value={disburseForm.paymentDate} onChange={e => setDisburseForm({ ...disburseForm, paymentDate: e.target.value })} className="h-12" />
                    </div>
                    <div className="space-y-2">
                      <Label className="font-bold">الطريقة</Label>
                      <Select value={disburseForm.paymentMethod} onValueChange={v => setDisburseForm({ ...disburseForm, paymentMethod: v })}>
                        <SelectTrigger className="h-12"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="نقداً">نقداً</SelectItem>
                          <SelectItem value="تحويل بنكي">تحويل بنكي</SelectItem>
                          <SelectItem value="شيك">شيك</SelectItem>
                          <SelectItem value="بطاقة">بطاقة</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="font-bold">نوع الدفع</Label>
                      <Select value={disburseForm.paymentType} onValueChange={v => setDisburseForm({ ...disburseForm, paymentType: v })}>
                        <SelectTrigger className="h-12"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="نقداً">نقداً</SelectItem>
                          <SelectItem value="آجل">آجل</SelectItem>
                          <SelectItem value="حوالة">حوالة</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="font-bold">الصندوق/البنك</Label>
                      <Select value={disburseForm.cashboxId} onValueChange={v => setDisburseForm({ ...disburseForm, cashboxId: v })}>
                        <SelectTrigger className="h-12"><SelectValue placeholder="اختر" /></SelectTrigger>
                        <SelectContent>
                          {cashboxes?.map(cb => <SelectItem key={cb.id} value={cb.id.toString()}>{cb.name} ({cb.type === 'صندوق نقدي' ? 'صندوق' : 'بنك'})</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2 md:col-span-2">
                      <Label className="font-bold">ملاحظات</Label>
                      <Input value={disburseForm.notes} onChange={e => setDisburseForm({ ...disburseForm, notes: e.target.value })} className="h-12" />
                    </div>
                    <div className="flex items-end">
                      <Button onClick={handleAddDisbursement} className="w-full h-12 font-bold text-lg" disabled={createDisbursementMutation.isPending}>
                        {createDisbursementMutation.isPending ? <Loader2 className="h-5 w-5 animate-spin" /> : "تسجيل المدفوع"}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-sm border-gray-200">
                <CardHeader className="flex flex-row items-center justify-between p-4 border-b border-gray-100">
                  <CardTitle className="text-lg font-bold">سجل المدفوعات</CardTitle>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={handleExportDisbursementsExcel} className="h-9 md:h-8 gap-1">
                      <Download className="h-3.5 w-3.5" /> Excel
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="p-0">
                  {/* Desktop Table */}
                  <div className="hidden md:block overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>الجهة</TableHead>
                          <TableHead>المبلغ</TableHead>
                          <TableHead>النوع</TableHead>
                          <TableHead>التاريخ</TableHead>
                          <TableHead>إجراءات</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {disbursements?.map(d => (
                          <TableRow key={d.id}>
                            <TableCell className="font-bold">{d.payee}</TableCell>
                            <TableCell className="font-black font-mono text-red-600">{Number(d.amount).toLocaleString('en-US')} {d.currency}</TableCell>
                            <TableCell>{d.expenseType}</TableCell>
                            <TableCell>{d.paymentDate}</TableCell>
                            <TableCell>
                              <Button variant="ghost" size="sm" className="text-destructive" onClick={() => { if(confirm("حذف المدفوع؟")) deleteDisbursementMutation.mutate({ id: d.id }); }}>حذف</Button>
                            </TableCell>
                          </TableRow>
                        ))}
                        {(!disbursements || disbursements.length === 0) && (
                          <TableRow><TableCell colSpan={5} className="py-12 text-center text-gray-400">لا توجد مدفوعات مسجلة</TableCell></TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>

                  {/* Mobile Card View */}
                  <div className="md:hidden divide-y divide-gray-100 bg-gray-50/30">
                    {disbursements?.map(d => (
                      <div key={d.id} className="p-4 bg-white space-y-2">
                        <div className="flex justify-between items-center">
                          <div className="font-black font-mono text-lg text-red-600">
                            {Number(d.amount).toLocaleString('en-US')} <span className="text-xs text-muted-foreground">{d.currency}</span>
                          </div>
                          <div className="text-xs font-bold text-muted-foreground">{d.paymentDate}</div>
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <div>
                            <div className="font-bold text-primary">{d.payee}</div>
                            <div className="text-[10px] text-muted-foreground">{d.expenseType}</div>
                          </div>
                          <Button variant="ghost" size="sm" className="text-destructive h-8 px-2" onClick={() => { if(confirm("حذف المدفوع؟")) deleteDisbursementMutation.mutate({ id: d.id }); }}>حذف</Button>
                        </div>
                        {d.notes && <div className="text-xs text-muted-foreground bg-gray-50 p-2 rounded-lg">{d.notes}</div>}
                      </div>
                    ))}
                    {(!disbursements || disbursements.length === 0) && (
                      <div className="text-center py-12 text-muted-foreground">لا توجد مدفوعات مسجلة</div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      ) : (
        <Card className="h-[200px] md:h-[400px] flex flex-col items-center justify-center p-8 text-muted-foreground bg-gray-50/30 border-dashed border-2">
          <Receipt className="h-16 w-16 mb-4 opacity-10" />
          <p className="text-center font-medium">يرجى اختيار بيان جمركي من القائمة أعلاه للبدء في إدارة العمليات المالية</p>
        </Card>
      )}
    </div>
  );
}
