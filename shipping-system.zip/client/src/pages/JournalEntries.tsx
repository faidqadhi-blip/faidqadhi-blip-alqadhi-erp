import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Loader2, Plus, Trash2, FileSpreadsheet, CheckCircle2, X, Search, Calendar, Info, ArrowLeftRight, Trash } from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";

interface EntryItem {
  accountId: string;
  debit: string;
  credit: string;
  description: string;
}

interface EntryForm {
  date: string;
  description: string;
  entryType: string;
  items: EntryItem[];
}

export default function JournalEntries() {
  const utils = trpc.useUtils();
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const { data: entries, isLoading } = trpc.journalEntries.list.useQuery();
  const { data: accounts } = trpc.accounts.list.useQuery();
  const { data: nextNum } = trpc.journalEntries.nextNumber.useQuery();

  const [form, setForm] = useState<EntryForm>({
    date: new Date().toISOString().split("T")[0],
    description: "",
    entryType: "قيد_يومي",
    items: [
      { accountId: "", debit: "0", credit: "0", description: "" },
      { accountId: "", debit: "0", credit: "0", description: "" },
    ],
  });

  const filtered = useMemo(() => {
    if (!entries) return [];
    if (!search.trim()) return entries;
    const q = search.trim().toLowerCase();
    return entries.filter(e => 
      e.entryNumber.toString().includes(q) ||
      e.description?.toLowerCase().includes(q) ||
      e.entryType.toLowerCase().includes(q)
    );
  }, [entries, search]);

  const createMutation = trpc.journalEntries.create.useMutation({
    onSuccess: () => {
      utils.journalEntries.list.invalidate();
      setOpen(false);
      setForm({
        date: new Date().toISOString().split("T")[0],
        description: "",
        entryType: "قيد_يومي",
        items: [
          { accountId: "", debit: "0", credit: "0", description: "" },
          { accountId: "", debit: "0", credit: "0", description: "" },
        ],
      });
      toast.success("تم إنشاء القيد بنجاح");
    },
    onError: (e) => toast.error(e.message),
  });

  const postMutation = trpc.journalEntries.post.useMutation({
    onSuccess: () => {
      utils.journalEntries.list.invalidate();
      toast.success("تم ترحيل القيد");
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = trpc.journalEntries.delete.useMutation({
    onSuccess: () => {
      utils.journalEntries.list.invalidate();
      toast.success("تم حذف القيد");
    },
    onError: (e) => toast.error(e.message),
  });

  const addItem = () =>
    setForm(p => ({
      ...p,
      items: [...p.items, { accountId: "", debit: "0", credit: "0", description: "" }],
    }));

  const removeItem = (idx: number) =>
    setForm(p => ({ ...p, items: p.items.filter((_, i) => i !== idx) }));

  const updateItem = (idx: number, patch: Partial<EntryItem>) =>
    setForm(p => ({
      ...p,
      items: p.items.map((it, i) => (i === idx ? { ...it, ...patch } : it)),
    }));

  const handleSubmit = () => {
    if (form.items.some(it => !it.accountId)) {
      toast.error("يرجى اختيار الحساب في جميع البنود");
      return;
    }
    const totalDebit = form.items.reduce((s, it) => s + (parseFloat(it.debit) || 0), 0);
    const totalCredit = form.items.reduce((s, it) => s + (parseFloat(it.credit) || 0), 0);
    if (Math.abs(totalDebit - totalCredit) > 0.005) {
      toast.error(`القيد غير متوازن! مجموع المدين: ${totalDebit.toFixed(2)} - مجموع الدائن: ${totalCredit.toFixed(2)}`);
      return;
    }
    createMutation.mutate({
      entryNumber: nextNum ?? 1,
      date: form.date,
      description: form.description,
      entryType: form.entryType,
      items: form.items.map(it => ({
        accountId: parseInt(it.accountId),
        debit: it.debit,
        credit: it.credit,
        description: it.description || undefined,
      })),
    });
  };

  const typeLabels: Record<string, string> = {
    "قيد_يومي": "قيد يومي",
    "قيد_مزدوج": "قيد مزدوج",
    "تسوية": "تسوية",
  };

  return (
    <div className="space-y-4 pb-20 md:pb-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 px-1">
        <div>
          <h2 className="text-2xl font-bold text-foreground">القيود اليومية</h2>
          <p className="text-sm text-muted-foreground mt-1">إنشاء وترحيل القيود اليومية والمزدوجة</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="w-full md:w-auto h-12 md:h-10 font-bold text-base gap-2">
              <Plus className="h-5 w-5" /> قيد جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl p-0 gap-0 overflow-hidden">
            <DialogHeader className="p-6 pb-2">
              <DialogTitle className="text-xl">إنشاء قيد محاسبي جديد</DialogTitle>
            </DialogHeader>
            <div className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label className="font-bold">نوع القيد *</Label>
                  <Select value={form.entryType} onValueChange={(v) => setForm(p => ({ ...p, entryType: v }))}>
                    <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="قيد_يومي" className="text-right">قيد يومي</SelectItem>
                      <SelectItem value="قيد_مزدوج" className="text-right">قيد مزدوج</SelectItem>
                      <SelectItem value="تسوية" className="text-right">تسوية</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">التاريخ</Label>
                  <Input type="date" value={form.date} onChange={(e) => setForm(p => ({ ...p, date: e.target.value }))} className="h-12 md:h-10" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">الوصف العام</Label>
                  <Input value={form.description} onChange={(e) => setForm(p => ({ ...p, description: e.target.value }))} className="h-12 md:h-10" placeholder="وصف مختصر للقيد" />
                </div>
              </div>

              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <Label className="text-base font-bold">بنود القيد المحاسبي</Label>
                  <Button type="button" variant="outline" size="sm" onClick={addItem} className="h-9 gap-1 font-bold">
                    <Plus className="h-4 w-4" /> إضافة بند
                  </Button>
                </div>
                <div className="space-y-3">
                  {form.items.map((item, idx) => (
                    <div key={idx} className="relative border rounded-lg p-4 bg-gray-50/50 space-y-3">
                      <div className="flex justify-between items-center md:hidden mb-1">
                        <span className="text-xs font-bold text-muted-foreground">بند #{idx + 1}</span>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500" onClick={() => removeItem(idx)} disabled={form.items.length <= 2}>
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
                        <div className="md:col-span-5 space-y-1">
                          <Label className="text-xs font-bold">الحساب *</Label>
                          <Select value={item.accountId} onValueChange={(v) => updateItem(idx, { accountId: v })}>
                            <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue placeholder="اختر الحساب" /></SelectTrigger>
                            <SelectContent>
                              {accounts?.map(a => (
                                <SelectItem key={a.id} value={String(a.id)} className="text-right">{a.name}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="grid grid-cols-2 md:col-span-5 gap-2">
                          <div className="space-y-1">
                            <Label className="text-xs font-bold">مدين</Label>
                            <Input type="number" value={item.debit} onChange={(e) => updateItem(idx, { debit: e.target.value })} className="h-12 md:h-10 text-left font-mono" />
                          </div>
                          <div className="space-y-1">
                            <Label className="text-xs font-bold">دائن</Label>
                            <Input type="number" value={item.credit} onChange={(e) => updateItem(idx, { credit: e.target.value })} className="h-12 md:h-10 text-left font-mono" />
                          </div>
                        </div>
                        <div className="hidden md:block md:col-span-2 text-left">
                          <Button variant="ghost" size="icon" className="h-10 w-10 text-red-500" onClick={() => removeItem(idx)} disabled={form.items.length <= 2}>
                            <X className="h-5 w-5" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex flex-col md:flex-row justify-between items-center gap-4 pt-4 border-t">
                <div className="flex gap-4 text-sm font-bold">
                  <div className="flex flex-col items-center px-4 py-2 bg-blue-50 rounded-md border border-blue-100">
                    <span className="text-[10px] text-blue-600 uppercase">إجمالي المدين</span>
                    <span className="text-lg font-mono text-blue-900">{form.items.reduce((s, it) => s + (parseFloat(it.debit) || 0), 0).toFixed(2)}</span>
                  </div>
                  <div className="flex flex-col items-center px-4 py-2 bg-amber-50 rounded-md border border-amber-100">
                    <span className="text-[10px] text-amber-600 uppercase">إجمالي الدائن</span>
                    <span className="text-lg font-mono text-amber-900">{form.items.reduce((s, it) => s + (parseFloat(it.credit) || 0), 0).toFixed(2)}</span>
                  </div>
                </div>
                <Button onClick={handleSubmit} className="w-full md:w-auto h-12 md:h-10 font-bold text-base px-8" disabled={createMutation.isPending}>
                  {createMutation.isPending && <Loader2 className="h-4 w-4 animate-spin ml-2" />}
                  إنشاء القيد
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="shadow-sm border-gray-200">
        <CardHeader className="p-4 pb-2">
          <div className="relative">
            <Search className="absolute right-3 top-3 h-5 w-5 text-gray-400" />
            <Input
              placeholder="ابحث برقم القيد أو الوصف..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pr-10 h-12 md:h-10 w-full"
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex flex-col items-center py-12 gap-3">
              <Loader2 className="h-10 w-10 animate-spin text-primary" />
              <span className="text-muted-foreground">جاري تحميل القيود...</span>
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-12 flex flex-col items-center gap-3">
              <FileSpreadsheet className="h-16 w-16 text-gray-200" />
              <p className="text-muted-foreground">{search ? "لا توجد نتائج مطابقة" : "لا توجد قيود مسجلة"}</p>
            </div>
          ) : (
            <>
              {/* Desktop Table */}
              <div className="hidden md:block overflow-x-auto">
                <Table>
                  <TableHeader className="bg-gray-50">
                    <TableRow>
                      <TableHead className="text-right font-bold">رقم القيد</TableHead>
                      <TableHead className="text-right font-bold">النوع</TableHead>
                      <TableHead className="text-right font-bold">الوصف</TableHead>
                      <TableHead className="text-right font-bold">التاريخ</TableHead>
                      <TableHead className="text-right font-bold">الحالة</TableHead>
                      <TableHead className="text-left font-bold">الإجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filtered.map(e => (
                      <TableRow key={e.id} className="hover:bg-gray-50/50 transition-colors">
                        <TableCell className="font-bold text-primary">#{e.entryNumber}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="text-[10px] font-bold">
                            {typeLabels[e.entryType] || e.entryType}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm">{e.description || "-"}</TableCell>
                        <TableCell className="text-xs font-mono">{e.date || "-"}</TableCell>
                        <TableCell>
                          <Badge variant={e.status === "مرحل" ? "default" : "secondary"} className={`text-[10px] font-bold ${e.status === "مرحل" ? "bg-green-600" : ""}`}>
                            {e.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex justify-end gap-1">
                            {e.status === "مسودة" && (
                              <Button variant="ghost" size="icon" className="h-8 w-8 text-green-600" onClick={() => postMutation.mutate({ id: e.id })}>
                                <CheckCircle2 className="h-4 w-4" />
                              </Button>
                            )}
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500 hover:bg-red-50" onClick={() => { if (confirm("هل تريد حذف هذا القيد؟")) deleteMutation.mutate({ id: e.id }); }}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Mobile Card List */}
              <div className="md:hidden space-y-0 divide-y">
                {filtered.map(e => (
                  <div key={e.id} className="p-4 active:bg-gray-50 transition-colors">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex flex-col">
                        <h3 className="font-bold text-lg text-primary">قيد #{e.entryNumber}</h3>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-bold text-muted-foreground uppercase">{typeLabels[e.entryType] || e.entryType}</span>
                          <Badge variant={e.status === "مرحل" ? "default" : "secondary"} className={`text-[9px] py-0 h-4 font-bold ${e.status === "مرحل" ? "bg-green-600" : ""}`}>
                            {e.status}
                          </Badge>
                        </div>
                      </div>
                      <div className="flex gap-1">
                        {e.status === "مسودة" && (
                          <Button variant="ghost" size="icon" className="h-9 w-9 text-green-600" onClick={() => postMutation.mutate({ id: e.id })}>
                            <CheckCircle2 className="h-5 w-5" />
                          </Button>
                        )}
                        <Button variant="ghost" size="icon" className="h-9 w-9 text-red-500" onClick={() => { if (confirm("هل تريد حذف هذا القيد؟")) deleteMutation.mutate({ id: e.id }); }}>
                          <Trash2 className="h-5 w-5" />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3 mt-3">
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Calendar className="h-3.5 w-3.5 text-gray-400" />
                        <span className="font-mono text-xs">{e.date || "-"}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <ArrowLeftRight className="h-3.5 w-3.5 text-gray-400" />
                        <span className="text-xs">{e.entryType.replace('_', ' ')}</span>
                      </div>
                      <div className="flex items-start gap-2 text-sm text-gray-600 col-span-2">
                        <Info className="h-3.5 w-3.5 text-gray-400 mt-0.5" />
                        <span className="text-xs line-clamp-2">{e.description || "بدون وصف"}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
