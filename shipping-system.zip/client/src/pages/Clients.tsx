import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Plus, Search, Edit2, Trash2, User, Phone, MapPin, Hash } from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";

export default function Clients() {
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState({
    code: "", name: "", phone: "", address: "",
    nationalId: "", commercialReg: "", taxNumber: "", notes: "",
  });

  const { data: clients, isLoading, refetch } = trpc.clients.list.useQuery();
  const createMutation = trpc.clients.create.useMutation();
  const updateMutation = trpc.clients.update.useMutation();
  const deleteMutation = trpc.clients.delete.useMutation();

  const filtered = useMemo(() => {
    if (!clients) return [];
    if (!search) return clients;
    const s = search.toLowerCase();
    return clients.filter(c =>
      c.name.toLowerCase().includes(s) || c.code.toLowerCase().includes(s) || c.phone?.includes(s)
    );
  }, [clients, search]);

  const handleSubmit = async () => {
    if (!form.name || !form.code) {
      toast.error("يرجى ملء اسم العميل والرمز");
      return;
    }
    try {
      if (editId) {
        await updateMutation.mutateAsync({ id: editId, ...form });
        toast.success("تم تحديث بيانات العميل");
      } else {
        await createMutation.mutateAsync(form);
        toast.success("تم إضافة العميل بنجاح");
      }
      setForm({ code: "", name: "", phone: "", address: "", nationalId: "", commercialReg: "", taxNumber: "", notes: "" });
      setEditId(null);
      setOpen(false);
      refetch();
    } catch {
      toast.error("حدث خطأ");
    }
  };

  const handleEdit = (client: any) => {
    setForm({
      code: client.code, name: client.name, phone: client.phone || "",
      address: client.address || "", nationalId: client.nationalId || "",
      commercialReg: client.commercialReg || "", taxNumber: client.taxNumber || "",
      notes: client.notes || "",
    });
    setEditId(client.id);
    setOpen(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm("هل أنت متأكد من حذف هذا العميل؟")) return;
    try {
      await deleteMutation.mutateAsync({ id });
      toast.success("تم حذف العميل");
      refetch();
    } catch {
      toast.error("حدث خطأ");
    }
  };

  return (
    <div className="space-y-4 pb-20 md:pb-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 px-1">
        <div>
          <h1 className="text-2xl font-bold text-foreground">إدارة العملاء</h1>
          <p className="text-sm text-muted-foreground mt-1">إضافة وإدارة بيانات العملاء والشركات</p>
        </div>
        <Dialog open={open} onOpenChange={(v) => { if (!v) { setEditId(null); setForm({ code: "", name: "", phone: "", address: "", nationalId: "", commercialReg: "", taxNumber: "", notes: "" }); } setOpen(v); }}>
          <DialogTrigger asChild>
            <Button className="w-full md:w-auto h-12 md:h-10 font-bold text-base">
              <Plus className="h-5 w-5 ml-2" />
              إضافة عميل جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg p-0 gap-0 overflow-hidden">
            <DialogHeader className="p-6 pb-2">
              <DialogTitle className="text-xl">{editId ? "تعديل بيانات العميل" : "إضافة عميل جديد"}</DialogTitle>
            </DialogHeader>
            <div className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="font-bold">رمز العميل *</Label>
                  <Input 
                    value={form.code} 
                    onChange={e => setForm({ ...form, code: e.target.value })} 
                    className="h-12 md:h-10"
                    placeholder="مثال: C001"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">اسم العميل *</Label>
                  <Input 
                    value={form.name} 
                    onChange={e => setForm({ ...form, name: e.target.value })} 
                    className="h-12 md:h-10"
                    placeholder="الاسم الكامل"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">الهاتف</Label>
                  <Input 
                    value={form.phone} 
                    onChange={e => setForm({ ...form, phone: e.target.value })} 
                    className="h-12 md:h-10 text-left"
                    placeholder="000-000-000"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">الرقم الوطني</Label>
                  <Input value={form.nationalId} onChange={e => setForm({ ...form, nationalId: e.target.value })} className="h-12 md:h-10" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">السجل التجاري</Label>
                  <Input value={form.commercialReg} onChange={e => setForm({ ...form, commercialReg: e.target.value })} className="h-12 md:h-10" />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">الرقم الضريبي</Label>
                  <Input value={form.taxNumber} onChange={e => setForm({ ...form, taxNumber: e.target.value })} className="h-12 md:h-10" />
                </div>
                <div className="col-span-1 md:col-span-2 space-y-2">
                  <Label className="font-bold">العنوان</Label>
                  <Input value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} className="h-12 md:h-10" />
                </div>
                <div className="col-span-1 md:col-span-2 space-y-2">
                  <Label className="font-bold">ملاحظات</Label>
                  <Input value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} className="h-12 md:h-10" />
                </div>
              </div>
              <div className="flex flex-col md:flex-row justify-end gap-3 pt-4 border-t">
                <Button variant="outline" onClick={() => { setOpen(false); setEditId(null); }} className="h-12 md:h-10 font-bold">إلغاء</Button>
                <Button onClick={handleSubmit} className="h-12 md:h-10 font-bold text-base">{editId ? "تحديث البيانات" : "إضافة العميل"}</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="shadow-sm border-gray-200">
        <CardHeader className="p-4 pb-2">
          <div className="relative">
            <Search className="absolute right-3 top-3 h-5 w-5 text-gray-400" />
            <Input
              placeholder="ابحث بالاسم، الرمز، أو الهاتف..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pr-10 h-12 md:h-10 w-full"
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex flex-col items-center py-12 gap-3">
              <div className="h-10 w-10 animate-spin rounded-full border-4 border-primary border-t-transparent" />
              <span className="text-muted-foreground">جاري تحميل العملاء...</span>
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-12 flex flex-col items-center gap-3">
              <User className="h-16 w-16 text-gray-200" />
              <p className="text-muted-foreground">لا يوجد عملاء مطابقين للبحث</p>
            </div>
          ) : (
            <>
              {/* Desktop Table */}
              <div className="hidden md:block">
                <Table>
                  <TableHeader className="bg-gray-50">
                    <TableRow>
                      <TableHead className="text-right font-bold">الرمز</TableHead>
                      <TableHead className="text-right font-bold">الاسم</TableHead>
                      <TableHead className="text-right font-bold">الهاتف</TableHead>
                      <TableHead className="text-right font-bold">العنوان</TableHead>
                      <TableHead className="text-right font-bold">الرقم الضريبي</TableHead>
                      <TableHead className="text-left font-bold">الإجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filtered.map(client => (
                      <TableRow key={client.id} className="hover:bg-gray-50/50 transition-colors">
                        <TableCell className="font-mono font-bold text-xs">{client.code}</TableCell>
                        <TableCell className="font-bold text-primary">{client.name}</TableCell>
                        <TableCell className="text-sm">{client.phone || "-"}</TableCell>
                        <TableCell className="max-w-[200px] truncate text-xs">{client.address || "-"}</TableCell>
                        <TableCell className="text-sm font-mono">{client.taxNumber || "-"}</TableCell>
                        <TableCell>
                          <div className="flex justify-end gap-1">
                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => handleEdit(client)}>
                              <Edit2 className="h-3.5 w-3.5" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500 hover:bg-red-50" onClick={() => handleDelete(client.id)}>
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Mobile Card List */}
              <div className="md:hidden space-y-0 divide-y">
                {filtered.map(client => (
                  <div key={client.id} className="p-4 active:bg-gray-50 transition-colors">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex flex-col">
                        <span className="text-[10px] font-bold text-muted-foreground uppercase">{client.code}</span>
                        <h3 className="font-bold text-lg text-primary">{client.name}</h3>
                      </div>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" className="h-9 w-9 text-blue-600" onClick={() => handleEdit(client)}>
                          <Edit2 className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-9 w-9 text-red-500" onClick={() => handleDelete(client.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 gap-2 mt-3">
                      {client.phone && (
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Phone className="h-3.5 w-3.5 text-gray-400" />
                          <span>{client.phone}</span>
                        </div>
                      )}
                      {client.address && (
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <MapPin className="h-3.5 w-3.5 text-gray-400" />
                          <span className="truncate">{client.address}</span>
                        </div>
                      )}
                      {client.taxNumber && (
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Hash className="h-3.5 w-3.5 text-gray-400" />
                          <span className="text-xs">الرقم الضريبي: {client.taxNumber}</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
