import { useState, useEffect, useMemo } from "react";
import { getDefaultCurrency } from "@/lib/currency";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Search, Filter, RotateCcw, Calendar, Download, Upload, FileText, Image as ImageIcon, ExternalLink, X } from "lucide-react";
import { toast } from "sonner";
import { exportToExcel, exportToCSV, exportMultiSheetExcel } from "@/lib/export";

export default function CustomsDeclarations() {
  const utils = trpc.useUtils();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [selectedClientId, setSelectedClientId] = useState<number | null>(null);
  const [selectedShipmentId, setSelectedShipmentId] = useState<number | null>(null);

  const [releaseDialogOpen, setReleaseDialogOpen] = useState(false);
  const [selectedDeclForRelease, setSelectedDeclForRelease] = useState<number | null>(null);
  const [releaseForm, setReleaseForm] = useState({
    releaseDate: "",
    releasedBy: "",
    releaseNotes: "",
    releaseAttachmentUrl: "",
    releaseAttachmentKey: "",
  });
  const [form, setForm] = useState({
    entryNumber: "",
    customsEntryId: undefined as number | undefined,
    declarationNumber: "",
    declarationDate: "",
    goodsType: "",
    customsPort: "",
    plateNumber: "",
    driverName: "",
    declarationFee: "",
    currency: "YER",
    notes: "",
    attachmentUrl: "",
    attachmentKey: "",
    releaseAttachmentUrl: "",
    releaseAttachmentKey: "",
  });

  const [uploading, setUploading] = useState(false);

  const { data: allDeclarations, isLoading } = trpc.declarations.list.useQuery();
  const { data: nextNum } = trpc.declarations.nextNumber.useQuery();
  const { data: currencies } = trpc.currencies.list.useQuery();
  const { data: systemSettings } = trpc.settings.getAll.useQuery();

  // Set default currency from settings
  useEffect(() => {
    if (systemSettings) {
      const defaultCurr = getDefaultCurrency(systemSettings);
      setForm(p => ({ ...p, currency: defaultCurr }));
    }
  }, [systemSettings]);
  const { data: clients } = trpc.clients.list.useQuery();
  const { data: shipments } = trpc.shipments.list.useQuery();
  const { data: entries } = trpc.customsEntries.list.useQuery();

  // Auto-fetch entry data
  useEffect(() => {
    if (form.entryNumber && entries) {
      const entry = entries.find(e => e.entryNumber === form.entryNumber);
      if (entry) {
        setForm(prev => ({
          ...prev,
          customsEntryId: entry.id,
          goodsType: entry.goodsType || prev.goodsType,
          customsPort: entry.customsPort || prev.customsPort,
          plateNumber: entry.plateNumber || prev.plateNumber,
          driverName: entry.driverName || prev.driverName,
        }));
        if (entry.clientId) setSelectedClientId(entry.clientId);
      }
    }
  }, [form.entryNumber, entries]);

  const createMutation = trpc.declarations.create.useMutation({
    onSuccess: () => {
      utils.declarations.list.invalidate();
      toast.success("تم حفظ البيان بنجاح");
      setDialogOpen(false);
      resetForm();
    },
    onError: (e) => toast.error(e.message),
  });

  const updateMutation = trpc.declarations.update.useMutation({
    onSuccess: () => {
      utils.declarations.list.invalidate();
      toast.success("تم تحديث البيان بنجاح");
      setDialogOpen(false);
      resetForm();
    },
    onError: (e) => toast.error(e.message),
  });

  const releasePermitMutation = trpc.declarations.issueReleasePermit.useMutation({
    onSuccess: () => {
      utils.declarations.list.invalidate();
      toast.success("تم إصدار إذن الإفراج بنجاح");
      setReleaseDialogOpen(false);
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = trpc.declarations.delete.useMutation({
    onSuccess: () => {
      utils.declarations.list.invalidate();
      toast.success("تم حذف البيان");
    },
    onError: (e) => toast.error(e.message),
  });

  const openReleaseDialog = (decl: any) => {
    setSelectedDeclForRelease(decl.id);
    setReleaseForm({
      releaseDate: new Date().toISOString().split('T')[0],
      releasedBy: decl.releasedBy || "",
      releaseNotes: decl.releaseNotes || "",
      releaseAttachmentUrl: decl.releaseAttachmentUrl || "",
      releaseAttachmentKey: decl.releaseAttachmentKey || "",
    });
    setReleaseDialogOpen(true);
  };

  const uploadMutation = trpc.storage.upload.useMutation();

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, isRelease = false) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      toast.error("حجم الملف كبير جداً (الحد الأقصى 5 ميجابايت)");
      return;
    }

    setUploading(true);
    try {
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve, reject) => {
        reader.onload = () => {
          const base64String = (reader.result as string).split(',')[1];
          resolve(base64String);
        };
        reader.onerror = reject;
      });
      reader.readAsDataURL(file);
      
      const base64Data = await base64Promise;
      
      const result = await uploadMutation.mutateAsync({
        filename: file.name,
        contentType: file.type,
        base64Data: base64Data
      });

      if (isRelease) {
        setReleaseForm(prev => ({
          ...prev,
          releaseAttachmentUrl: result.url,
          releaseAttachmentKey: result.key
        }));
      } else {
        setForm(prev => ({
          ...prev,
          attachmentUrl: result.url,
          attachmentKey: result.key
        }));
      }
      
      toast.success("تم رفع الملف بنجاح");
    } catch (error) {
      console.error("Upload error:", error);
      toast.error("حدث خطأ أثناء رفع الملف");
    } finally {
      setUploading(false);
      e.target.value = "";
    }
  };

  const resetForm = () => {
    setEditId(null);
    setSelectedClientId(null);
    setSelectedShipmentId(null);
    setForm({
      entryNumber: "",
      customsEntryId: undefined,
      declarationNumber: "",
      declarationDate: "",
      goodsType: "",
      customsPort: "",
      plateNumber: "",
      driverName: "",
      declarationFee: "",
      currency: "YER",
      notes: "",
      attachmentUrl: "",
      attachmentKey: "",
      releaseAttachmentUrl: "",
      releaseAttachmentKey: "",
    });
  };

  const openEdit = (decl: any) => {
    setEditId(decl.id);
    setSelectedClientId(decl.clientId ?? null);
    setSelectedShipmentId(decl.shipmentId ?? null);
    setForm({
      entryNumber: decl.entryNumber || "",
      customsEntryId: decl.customsEntryId ?? undefined,
      declarationNumber: decl.declarationNumber || "",
      declarationDate: decl.declarationDate || "",
      goodsType: decl.goodsType || "",
      customsPort: decl.customsPort || "",
      plateNumber: decl.plateNumber || "",
      driverName: decl.driverName || "",
      declarationFee: String(decl.declarationFee || "0"),
      currency: decl.currency || "YER",
      notes: decl.notes || "",
      attachmentUrl: decl.attachmentUrl || "",
      attachmentKey: decl.attachmentKey || "",
      releaseAttachmentUrl: decl.releaseAttachmentUrl || "",
      releaseAttachmentKey: decl.releaseAttachmentKey || "",
    });
    setDialogOpen(true);
  };

  const handleSubmit = () => {
    if (!form.entryNumber || !form.declarationNumber || !selectedClientId) {
      toast.error("يرجى ملء الحقول الإجبارية (رقم القيد، رقم البيان، والعميل)");
      return;
    }
    const { ...formData } = form;
    const data = { ...formData, clientId: selectedClientId, shipmentId: selectedShipmentId ?? undefined };
    if (editId) {
      updateMutation.mutate({ id: editId, ...data });
    } else {
      createMutation.mutate(data);
    }
  };

  const getClientName = (clientId: number | null) => {
    if (!clientId) return "-";
    const client = clients?.find(c => c.id === clientId);
    return client?.name || "-";
  };

  const resetFilters = () => {
    setSearchQuery("");
    setStatusFilter("all");
    setDateFrom("");
    setDateTo("");
  };

  const filteredDeclarations = useMemo(() => {
    let result = allDeclarations || [];

    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      result = result.filter(decl => {
        const clientName = getClientName(decl.clientId).toLowerCase();
        return decl.declarationNumber?.toLowerCase().includes(q) ||
          clientName.includes(q) ||
          decl.goodsType?.toLowerCase().includes(q) ||
          decl.customsPort?.toLowerCase().includes(q) ||
          decl.entryNumber?.toLowerCase().includes(q) ||
          decl.plateNumber?.toLowerCase().includes(q);
      });
    }

    if (statusFilter !== "all") {
      result = result.filter(decl => decl.status === statusFilter);
    }

    if (dateFrom) {
      const fromDate = new Date(dateFrom).getTime();
      result = result.filter(decl => decl.declarationDate && new Date(decl.declarationDate).getTime() >= fromDate);
    }
    if (dateTo) {
      const toDate = new Date(dateTo).getTime() + 86400000;
      result = result.filter(decl => decl.declarationDate && new Date(decl.declarationDate).getTime() <= toDate);
    }

    return result;
  }, [allDeclarations, searchQuery, statusFilter, dateFrom, dateTo]);

  const hasActiveFilters = useMemo(() => {
    return searchQuery !== "" || statusFilter !== "all" || dateFrom !== "" || dateTo !== "";
  }, [searchQuery, statusFilter, dateFrom, dateTo]);

  const declExportColumns = [
    { key: "declarationNumber", label: "رقم البيان" },
    { key: "entryNumber", label: "رقم القيد" },
    { key: "clientName", label: "العميل" },
    { key: "goodsType", label: "البضاعة" },
    { key: "customsPort", label: "المنفذ" },
    { key: "plateNumber", label: "اللوحة" },
    { key: "driverName", label: "السائق" },
    { key: "declarationFee", label: "الرسوم" },
    { key: "currency", label: "العملة" },
    { key: "status", label: "الحالة" },
    { key: "declarationDate", label: "التاريخ" },
    { key: "releaseDate", label: "تاريخ الإفراج" },
    { key: "notes", label: "ملاحظات" },
  ];

  const getDeclExportData = () => {
    return filteredDeclarations.map(decl => ({
      declarationNumber: decl.declarationNumber || "-",
      entryNumber: decl.entryNumber || "-",
      clientName: getClientName(decl.clientId),
      goodsType: decl.goodsType || "-",
      customsPort: decl.customsPort || "-",
      plateNumber: decl.plateNumber || "-",
      driverName: decl.driverName || "-",
      declarationFee: String(decl.declarationFee || 0),
      currency: decl.currency || "YER",
      status: decl.status || "-",
      declarationDate: decl.declarationDate || "-",
      releaseDate: decl.releaseDate || "-",
      notes: decl.notes || "",
    }));
  };

  const handleExportDeclExcel = () => {
    if (filteredDeclarations.length === 0) {
      toast.warning("لا توجد نتائج للتصدير");
      return;
    }
    exportToExcel(getDeclExportData(), declExportColumns, `البيانات_الجمركية_${new Date().toISOString().split('T')[0]}`);
    toast.success(`تم تصدير ${filteredDeclarations.length} بيان إلى Excel`);
  };

  const handleExportDeclCSV = () => {
    if (filteredDeclarations.length === 0) {
      toast.warning("لا توجد نتائج للتصدير");
      return;
    }
    exportToCSV(getDeclExportData(), declExportColumns, `البيانات_الجمركية_${new Date().toISOString().split('T')[0]}`);
    toast.success(`تم تصدير ${filteredDeclarations.length} بيان إلى CSV`);
  };

  // Comprehensive multi-sheet export (Declarations + Costs + Receipts + Disbursements)
  const costExportColumns = [
    { key: "declarationNumber", label: "رقم البيان" },
    { key: "clientName", label: "العميل" },
    { key: "declarationFee", label: "رسوم البيان" },
    { key: "inspectionFee", label: "رسوم المعاينة" },
    { key: "penalties", label: "الغرامات" },
    { key: "weightDifferences", label: "فوارق الأوزان" },
    { key: "otherGovtFees", label: "رسوم حكومية" },
    { key: "transport", label: "نقل" },
    { key: "fuel", label: "وقود" },
    { key: "driverCost", label: "سائق" },
    { key: "maintenance", label: "صيانة" },
    { key: "otherExpenses", label: "مصاريف أخرى" },
    { key: "pettyCash", label: "نثريات" },
    { key: "totalCost", label: "إجمالي التكلفة" },
  ];

  const receiptExportColumns = [
    { key: "declarationNumber", label: "رقم البيان" },
    { key: "clientName", label: "العميل" },
    { key: "amount", label: "المبلغ" },
    { key: "currency", label: "العملة" },
    { key: "paymentDate", label: "التاريخ" },
    { key: "paymentMethod", label: "الطريقة" },
    { key: "notes", label: "ملاحظات" },
  ];

  const disburseExportColumns = [
    { key: "declarationNumber", label: "رقم البيان" },
    { key: "clientName", label: "العميل" },
    { key: "payee", label: "الجهة" },
    { key: "amount", label: "المبلغ" },
    { key: "currency", label: "العملة" },
    { key: "expenseType", label: "النوع" },
    { key: "paymentDate", label: "التاريخ" },
    { key: "paymentMethod", label: "الطريقة" },
    { key: "notes", label: "ملاحظات" },
  ];

  const getCurrencyName = (code: string | null) => {
    if (!code) return "-";
    const c = currencies?.find(c => c.code === code);
    return c?.name || code;
  };

  const handleExportComprehensive = async () => {
    try {
      const allDecls = await utils.declarations.list.fetch();
      const allCosts = await utils.clearanceCosts.list.fetch();
      const allReceipts = await utils.clearanceReceipts.list.fetch();
      const allDisbursements = await utils.clearanceDisbursements.list.fetch();
      const allClients = await utils.clients.list.fetch();

      const getClient = (clientId: number | null) => {
        if (!clientId) return "-";
        const c = allClients?.find(c => c.id === clientId);
        return c?.name || "-";
      };
      const getDecl = (declId: number | null) => {
        if (!declId) return null;
        return allDecls?.find(d => d.id === declId);
      };

      const sheets: {
        sheetName: string;
        data: Record<string, any>[];
        columns: { key: string; label: string }[];
      }[] = [];

      // Declarations sheet
      const declData = (allDecls || []).map(decl => ({
        declarationNumber: decl.declarationNumber || "-",
        entryNumber: decl.entryNumber || "-",
        clientName: getClient(decl.clientId),
        goodsType: decl.goodsType || "-",
        customsPort: decl.customsPort || "-",
        declarationDate: decl.declarationDate || "-",
        plateNumber: decl.plateNumber || "-",
        driverName: decl.driverName || "-",
        status: decl.status || "مسودة",
      }));
      if (declData.length > 0) {
        sheets.push({ sheetName: "البيانات الجمركية", data: declData, columns: declExportColumns });
      }

      // Costs sheet
      const costsData = (allCosts || []).map(c => {
        const decl = getDecl(c.declarationId ?? null);
        return {
          declarationNumber: decl?.declarationNumber || "-",
          clientName: getClient(decl?.clientId ?? null),
          declarationFee: Number(c.declarationFee || 0).toLocaleString('en-US'),
          inspectionFee: Number(c.inspectionFee || 0).toLocaleString('en-US'),
          penalties: Number(c.penalties || 0).toLocaleString('en-US'),
          weightDifferences: Number(c.weightDifferences || 0).toLocaleString('en-US'),
          otherGovtFees: Number(c.otherGovtFees || 0).toLocaleString('en-US'),
          transport: Number(c.transport || 0).toLocaleString('en-US'),
          fuel: Number(c.fuel || 0).toLocaleString('en-US'),
          driverCost: Number(c.driverCost || 0).toLocaleString('en-US'),
          maintenance: Number(c.maintenance || 0).toLocaleString('en-US'),
          otherExpenses: Number(c.otherExpenses || 0).toLocaleString('en-US'),
          pettyCash: Number(c.pettyCash || 0).toLocaleString('en-US'),
          totalCost: Number(c.totalCost || 0).toLocaleString('en-US'),
        };
      });
      if (costsData.length > 0) {
        sheets.push({ sheetName: "التكاليف", data: costsData, columns: costExportColumns });
      }

      // Receipts sheet
      const receiptsData = (allReceipts || []).map(r => {
        const decl = getDecl(r.declarationId ?? null);
        return {
          declarationNumber: decl?.declarationNumber || "-",
          clientName: getClient(decl?.clientId ?? null),
          amount: Number(r.amount || 0).toLocaleString('en-US'),
          currency: getCurrencyName(r.currency),
          paymentDate: r.paymentDate || "-",
          paymentMethod: r.paymentMethod || "-",
          notes: r.notes || "",
        };
      });
      if (receiptsData.length > 0) {
        sheets.push({ sheetName: "المقبوضات", data: receiptsData, columns: receiptExportColumns });
      }

      // Disbursements sheet
      const disburseData = (allDisbursements || []).map(d => {
        const decl = getDecl(d.declarationId ?? null);
        return {
          declarationNumber: decl?.declarationNumber || "-",
          clientName: getClient(decl?.clientId ?? null),
          payee: d.payee || "-",
          amount: Number(d.amount || 0).toLocaleString('en-US'),
          currency: getCurrencyName(d.currency),
          expenseType: d.expenseType || "-",
          paymentDate: d.paymentDate || "-",
          paymentMethod: d.paymentMethod || "-",
          notes: d.notes || "",
        };
      });
      if (disburseData.length > 0) {
        sheets.push({ sheetName: "المدفوعات", data: disburseData, columns: disburseExportColumns });
      }

      if (sheets.length === 0) {
        toast.warning("لا توجد بيانات للتصدير");
        return;
      }

      exportMultiSheetExcel(sheets, `تقرير_شامل_البيانات_الجمركية_${new Date().toISOString().split('T')[0]}`);
      toast.success(`تم تصدير التقرير الشامل (${sheets.length} ورقة)`);
    } catch (err) {
      toast.error("حدث خطأ أثناء التصدير الشامل");
    }
  };

  // قائمة المنافذ الجمركية الشائعة
  const ports = [
    "ذمار", "صنعاء", "عدن", "الحديدة", "المكلا", "سيئون",
    "الوديعـة", "الخضراء", "الشِّحـر", "بلحاف", "منفذ آخر",
  ];

  // قائمة السائقين من الشحنات السابقة
  const drivers = Array.from(new Set(
    (shipments || []).filter(s => s.driverName).map(s => s.driverName!)
  ));

  return (
    <div className="space-y-4 pb-20 md:pb-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 px-1">
        <div>
          <h2 className="text-2xl font-bold text-foreground">البيانات الجمركية</h2>
          <p className="text-sm text-muted-foreground mt-1">إدارة واعتماد البيانات الجمركية للمنافذ</p>
        </div>
        <Button onClick={() => { resetForm(); setDialogOpen(true); }} className="w-full md:w-auto h-12 md:h-10 font-bold text-base">
          + إنشاء بيان جديد
        </Button>
      </div>

      {/* Search & Filter Bar */}
      <Card className="shadow-sm border-gray-200">
        <CardContent className="p-4 space-y-4">
          <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-end">
            <div className="flex-1">
              <Label className="font-bold mb-1.5 block">بحث سريع</Label>
              <div className="relative">
                <Search className="absolute right-3 top-3 h-5 w-5 text-gray-400" />
                <Input
                  placeholder="رقم البيان، العميل، البضاعة..."
                  className="pr-10 h-12 md:h-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>

            <div className="flex gap-2">
              <div className="flex-1 md:w-40">
                <Label className="font-bold mb-1.5 block">الحالة</Label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="h-12 md:h-10">
                    <SelectValue placeholder="الكل" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">الكل</SelectItem>
                    <SelectItem value="جديد">جديد</SelectItem>
                    <SelectItem value="معتمد">معتمد</SelectItem>
                    <SelectItem value="مكتمل">مكتمل</SelectItem>
                    <SelectItem value="ملغي">ملغي</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button
                variant="outline"
                onClick={() => setShowFilters(!showFilters)}
                className={`h-12 md:h-10 px-3 ${showFilters ? "bg-primary/10 border-primary text-primary" : ""}`}
              >
                <Filter className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {showFilters && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-3 border-t border-gray-100 animate-in fade-in slide-in-from-top-2">
              <div className="col-span-1">
                <Label className="text-xs font-bold mb-1 block">من تاريخ</Label>
                <Input
                  type="date"
                  className="h-10 text-sm"
                  value={dateFrom}
                  onChange={(e) => setDateFrom(e.target.value)}
                />
              </div>
              <div className="col-span-1">
                <Label className="text-xs font-bold mb-1 block">إلى تاريخ</Label>
                <Input
                  type="date"
                  className="h-10 text-sm"
                  value={dateTo}
                  onChange={(e) => setDateTo(e.target.value)}
                />
              </div>
              <div className="col-span-2 md:col-span-2 flex items-end gap-2">
                <Button variant="outline" onClick={handleExportDeclExcel} className="flex-1 h-10 text-xs font-bold">
                  <Download className="h-3.5 w-3.5 ml-1" /> إكسل
                </Button>
                <Button variant="secondary" onClick={handleExportComprehensive} className="flex-1 h-10 text-xs font-bold">
                  تصدير شامل
                </Button>
                {hasActiveFilters && (
                  <Button variant="ghost" onClick={resetFilters} className="text-red-500 h-10 px-2">
                    <RotateCcw className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Desktop Table View */}
      <div className="hidden md:block">
        <Card className="shadow-sm border-gray-200 overflow-hidden">
          <Table>
            <TableHeader className="bg-gray-50">
              <TableRow>
                <TableHead className="font-bold">رقم البيان</TableHead>
                <TableHead className="font-bold">رقم القيد</TableHead>
                <TableHead className="font-bold">العميل</TableHead>
                <TableHead className="font-bold">البضاعة</TableHead>
                <TableHead className="font-bold">المنفذ</TableHead>
                <TableHead className="font-bold">الرسوم</TableHead>
                <TableHead className="font-bold">الحالة</TableHead>
                <TableHead className="font-bold">التاريخ</TableHead>
                <TableHead className="text-left font-bold">الإجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={9} className="text-center py-12">
                    <div className="flex flex-col items-center gap-2">
                      <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
                      <span className="text-muted-foreground">جاري تحميل البيانات...</span>
                    </div>
                  </TableCell>
                </TableRow>
              ) : filteredDeclarations.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} className="text-center py-12 text-muted-foreground italic">
                    لا توجد بيانات مطابقة للبحث
                  </TableCell>
                </TableRow>
              ) : (
                filteredDeclarations.map((decl) => (
                  <TableRow key={decl.id} className="hover:bg-gray-50/50 transition-colors">
                    <TableCell className="font-bold text-primary">{decl.declarationNumber}</TableCell>
                    <TableCell className="font-mono text-xs">{decl.entryNumber}</TableCell>
                    <TableCell className="max-w-[150px] truncate font-medium">{getClientName(decl.clientId)}</TableCell>
                    <TableCell className="text-xs">{decl.goodsType}</TableCell>
                    <TableCell className="text-xs">{decl.customsPort}</TableCell>
                    <TableCell className="font-mono font-bold">{Number(decl.declarationFee).toLocaleString()} <span className="text-[10px] text-muted-foreground">{decl.currency}</span></TableCell>
                    <TableCell>
                      <Badge variant={
                        decl.status === "معتمد" ? "default" :
                        decl.status === "مكتمل" ? "secondary" :
                        decl.status === "ملغي" ? "destructive" : "outline"
                      } className="rounded-md px-2 py-0.5 text-[10px]">
                        {decl.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-[10px] text-muted-foreground">{decl.declarationDate}</TableCell>
                    <TableCell>
                      <div className="flex justify-end gap-1">
                        {decl.attachmentUrl && (
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-600" asChild>
                            <a href={decl.attachmentUrl} target="_blank" rel="noreferrer">
                              <ImageIcon className="h-4 w-4" />
                            </a>
                          </Button>
                        )}
                        {!decl.releaseDate && (
                          <Button variant="outline" size="sm" className="h-8 px-2 text-xs font-bold text-green-700 border-green-200 bg-green-50 hover:bg-green-100" onClick={() => openReleaseDialog(decl)}>
                            إفراج
                          </Button>
                        )}
                        {decl.releaseDate && (
                          <div className="flex items-center gap-1">
                            <Badge variant="secondary" className="text-green-700 text-[10px]">مُفرج {decl.releaseDate}</Badge>
                            {decl.releaseAttachmentUrl && (
                              <Button variant="ghost" size="icon" className="h-8 w-8 text-green-600" asChild>
                                <a href={decl.releaseAttachmentUrl} target="_blank" rel="noreferrer">
                                  <ImageIcon className="h-4 w-4" />
                                </a>
                              </Button>
                            )}
                          </div>
                        )}
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(decl)}>
                          <FileText className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-red-500 hover:text-red-700 hover:bg-red-50"
                          onClick={() => {
                            if (confirm("هل أنت متأكد من حذف هذا البيان؟")) {
                              deleteMutation.mutate(decl.id);
                            }
                          }}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </Card>
      </div>

      {/* Mobile Card View */}
      <div className="md:hidden space-y-3">
        {isLoading ? (
          <div className="flex flex-col items-center py-12 gap-3">
            <div className="h-10 w-10 animate-spin rounded-full border-4 border-primary border-t-transparent" />
            <span className="text-muted-foreground">جاري التحميل...</span>
          </div>
        ) : filteredDeclarations.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl border border-dashed border-gray-300 text-muted-foreground">
            لا توجد بيانات مطابقة
          </div>
        ) : (
          filteredDeclarations.map((decl) => (
            <Card key={decl.id} className="shadow-sm border-gray-200 overflow-hidden active:scale-[0.98] transition-transform">
              <div className="bg-gray-50 px-4 py-2 border-b flex justify-between items-center">
                <span className="font-bold text-primary">{decl.declarationNumber}</span>
                <Badge variant={
                  decl.status === "معتمد" ? "default" :
                  decl.status === "مكتمل" ? "secondary" :
                  decl.status === "ملغي" ? "destructive" : "outline"
                } className="rounded-md">
                  {decl.status}
                </Badge>
              </div>
              <CardContent className="p-4 space-y-3">
                <div className="grid grid-cols-2 gap-y-3 gap-x-2 text-sm">
                  <div>
                    <p className="text-[10px] text-muted-foreground uppercase font-bold">العميل</p>
                    <p className="font-bold truncate">{getClientName(decl.clientId)}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-muted-foreground uppercase font-bold">رقم القيد</p>
                    <p className="font-mono">{decl.entryNumber}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-muted-foreground uppercase font-bold">البضاعة / المنفذ</p>
                    <p className="truncate">{decl.goodsType} - {decl.customsPort}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-muted-foreground uppercase font-bold">الرسوم</p>
                    <p className="font-bold text-green-700">{Number(decl.declarationFee).toLocaleString()} {decl.currency}</p>
                  </div>
                </div>

                <div className="pt-3 border-t flex justify-between items-center">
                  <span className="text-[10px] text-muted-foreground">{decl.declarationDate}</span>
                  <div className="flex gap-2">
                    {decl.attachmentUrl && (
                      <Button variant="outline" size="sm" className="h-9 w-9 p-0" asChild>
                        <a href={decl.attachmentUrl} target="_blank" rel="noreferrer">
                          <ImageIcon className="h-4 w-4" />
                        </a>
                      </Button>
                    )}
                    {!decl.releaseDate && (
                      <Button variant="outline" size="sm" className="h-9 px-3 font-bold text-green-700 border-green-200 bg-green-50" onClick={() => openReleaseDialog(decl)}>
                        إفراج
                      </Button>
                    )}
                    <Button variant="secondary" size="sm" className="h-9 px-3 font-bold" onClick={() => openEdit(decl)}>تعديل</Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-9 w-9 p-0 text-red-500"
                      onClick={() => {
                        if (confirm("هل أنت متأكد من حذف هذا البيان؟")) {
                          deleteMutation.mutate(decl.id);
                        }
                      }}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* نموذج إذن الإفراج */}
      <Dialog open={releaseDialogOpen} onOpenChange={setReleaseDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>إصدار إذن إفراج جمركي</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label>تاريخ الإفراج</Label>
              <Input 
                type="date" 
                value={releaseForm.releaseDate} 
                onChange={e => setReleaseForm({ ...releaseForm, releaseDate: e.target.value })} 
              />
            </div>
            <div className="space-y-2">
              <Label>المُفرِج (الموظف المسؤول)</Label>
              <Input 
                value={releaseForm.releasedBy} 
                onChange={e => setReleaseForm({ ...releaseForm, releasedBy: e.target.value })} 
                placeholder="اسم الموظف"
              />
            </div>
            <div className="space-y-2">
              <Label>مرفق الإفراج (صورة الإذن أو المحضر)</Label>
              <div className="flex items-center gap-4 p-3 border rounded-lg bg-gray-50/50">
                {releaseForm.releaseAttachmentUrl ? (
                  <div className="flex items-center justify-between w-full">
                    <div className="flex items-center gap-2">
                      <FileText className="w-5 h-5 text-green-600" />
                      <span className="text-sm font-medium truncate max-w-[150px]">تم إرفاق مستند الإفراج</span>
                      <Button variant="ghost" size="sm" asChild>
                        <a href={releaseForm.releaseAttachmentUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-xs text-green-600">
                          <ExternalLink className="w-3 h-3" /> عرض
                        </a>
                      </Button>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => setReleaseForm(p => ({ ...p, releaseAttachmentUrl: "", releaseAttachmentKey: "" }))}
                      className="text-red-500 hover:text-red-700"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center w-full py-2 border-2 border-dashed rounded-md border-gray-300 hover:border-green-400 transition-colors cursor-pointer relative">
                    <Upload className="w-6 h-6 text-gray-400 mb-1" />
                    <span className="text-xs text-gray-500">{uploading ? "جاري الرفع..." : "اضغط لرفع مستند الإفراج"}</span>
                    <input 
                      type="file" 
                      className="absolute inset-0 opacity-0 cursor-pointer" 
                      accept="image/*,.pdf" 
                      onChange={(e) => handleFileUpload(e, true)}
                      disabled={uploading}
                    />
                  </div>
                )}
              </div>
            </div>
            <div className="space-y-2">
              <Label>ملاحظات الإفراج</Label>
              <Textarea 
                value={releaseForm.releaseNotes} 
                onChange={e => setReleaseForm({ ...releaseForm, releaseNotes: e.target.value })} 
                rows={3} 
                placeholder="أي ملاحظات إضافية حول عملية الإفراج..."
              />
            </div>
          </div>
          <div className="flex gap-2 justify-end mt-4">
            <Button variant="outline" onClick={() => setReleaseDialogOpen(false)}>إلغاء</Button>
            <Button 
              className="bg-green-600 hover:bg-green-700"
              onClick={() => {
                if (!selectedDeclForRelease) return;
                releasePermitMutation.mutate({
                  id: selectedDeclForRelease,
                  ...releaseForm,
                  status: "مكتمل"
                });
              }}
              disabled={releasePermitMutation.isPending}
            >
              إعتماد الإفراج
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* نموذج إنشاء/تعديل البيان */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editId ? "تعديل بيان جمركي" : "إنشاء بيان جمركي جديد"}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>رقم القيد / الدخول *</Label>
              <div className="flex gap-2">
                <Select
                  value={form.entryNumber}
                  onValueChange={(v) => setForm({ ...form, entryNumber: v })}
                >
                  <SelectTrigger className="flex-1">
                    <SelectValue placeholder="اختر رقم القيد" />
                  </SelectTrigger>
                  <SelectContent>
                    {entries?.map((e) => (
                      <SelectItem key={e.id} value={e.entryNumber}>
                        {e.entryNumber} - {clients?.find(c => c.id === e.clientId)?.name || e.clientId}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Input
                  className="w-24"
                  value={form.entryNumber}
                  onChange={e => setForm({ ...form, entryNumber: e.target.value })}
                  placeholder="يدوي"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>تاريخ البيان</Label>
              <Input type="date" value={form.declarationDate} onChange={e => setForm({ ...form, declarationDate: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>رقم البيان الجمركي *</Label>
              <Input 
                value={form.declarationNumber} 
                onChange={e => setForm({ ...form, declarationNumber: e.target.value })} 
                placeholder="أدخل رقم البيان من المنفذ (مثال: CD-12345)" 
                required
              />
              <p className="text-[10px] text-muted-foreground">يجب إدخال الرقم الحقيقي كما هو في أوراق المنفذ</p>
            </div>
            <div className="space-y-2">
              <Label>اسم العميل *</Label>
              <Select value={selectedClientId ? String(selectedClientId) : "__pick__"} onValueChange={v => setSelectedClientId(v === "__pick__" ? null : Number(v))}>
                <SelectTrigger><SelectValue placeholder="اختر العميل" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="__pick__">اختر العميل *</SelectItem>
                  {clients?.map(c => <SelectItem key={c.id} value={String(c.id)}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>نوع البضاعة</Label>
              <Input value={form.goodsType} onChange={e => setForm({ ...form, goodsType: e.target.value })} placeholder="مثال: أحذية" />
            </div>
            <div className="space-y-2">
              <Label>المنفذ الجمركي</Label>
              <Select value={form.customsPort || "__none__"} onValueChange={v => setForm({ ...form, customsPort: v === "__none__" ? "" : v })}>
                <SelectTrigger><SelectValue placeholder="اختر المنفذ" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none__">بدون تحديد</SelectItem>
                  {ports.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>الشحنة المرتبطة</Label>
              <Select value={selectedShipmentId ? String(selectedShipmentId) : "none"} onValueChange={v => setSelectedShipmentId(v === "none" ? null : Number(v))}>
                <SelectTrigger><SelectValue placeholder="اختر الشحنة (اختياري)" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">بدون شحنة</SelectItem>
                  {shipments?.map(s => <SelectItem key={s.id} value={String(s.id)}>#{s.id} - {s.goodsType || "بدون"}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>رقم اللوحة</Label>
              <Input value={form.plateNumber} onChange={e => setForm({ ...form, plateNumber: e.target.value })} placeholder="مثال: ABC-123" />
            </div>
            <div className="space-y-2">
              <Label>اسم السائق</Label>
              <Select value={form.driverName || "__none__"} onValueChange={v => setForm({ ...form, driverName: v === "__none__" ? "" : v })}>
                <SelectTrigger><SelectValue placeholder="اختر السائق" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none__">بدون تحديد</SelectItem>
                  {drivers.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>رسوم البيان</Label>
              <div className="flex gap-2">
                <Input type="number" value={form.declarationFee} onChange={e => setForm({ ...form, declarationFee: e.target.value })} placeholder="0" className="flex-1" />
                <span className="flex items-center text-sm text-muted-foreground">ر.ي</span>
              </div>
            </div>
            <div className="space-y-2">
              <Label>العملة</Label>
              <Select value={form.currency} onValueChange={v => setForm({ ...form, currency: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {currencies?.map(c => <SelectItem key={c.id} value={c.code}>{c.name} ({c.code})</SelectItem>)}
                  {!currencies?.length && <SelectItem value="YER">ريال يمني (YER)</SelectItem>}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 col-span-2">
              <Label>المرفق (صورة أو PDF للبيان)</Label>
              <div className="flex items-center gap-4 p-3 border rounded-lg bg-gray-50/50">
                {form.attachmentUrl ? (
                  <div className="flex items-center justify-between w-full">
                    <div className="flex items-center gap-2">
                      <FileText className="w-5 h-5 text-blue-600" />
                      <span className="text-sm font-medium truncate max-w-[200px]">تم إرفاق ملف</span>
                      <Button variant="ghost" size="sm" asChild>
                        <a href={form.attachmentUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-xs text-blue-600">
                          <ExternalLink className="w-3 h-3" /> عرض
                        </a>
                      </Button>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => setForm(p => ({ ...p, attachmentUrl: "", attachmentKey: "" }))}
                      className="text-red-500 hover:text-red-700"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center w-full py-2 border-2 border-dashed rounded-md border-gray-300 hover:border-blue-400 transition-colors cursor-pointer relative">
                    <Upload className="w-6 h-6 text-gray-400 mb-1" />
                    <span className="text-xs text-gray-500">{uploading ? "جاري الرفع..." : "اضغط لرفع ملف البيان (صورة أو PDF)"}</span>
                    <input 
                      type="file" 
                      className="absolute inset-0 opacity-0 cursor-pointer" 
                      accept="image/*,.pdf" 
                      onChange={handleFileUpload}
                      disabled={uploading}
                    />
                  </div>
                )}
              </div>
            </div>
            <div className="space-y-2 col-span-2">
              <Label>ملاحظات</Label>
              <Textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} rows={3} />
            </div>
          </div>
          <div className="flex gap-2 justify-end mt-4">
            <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
            <Button onClick={handleSubmit} disabled={createMutation.isPending || updateMutation.isPending}>
              {editId ? "تحديث" : "حفظ البيان"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
