import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, CreditCard, Calendar, User, FileText, Wallet, MoreHorizontal } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useIsMobile } from "@/hooks/useMobile";

export default function Payments() {
  const isMobile = useIsMobile();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    invoiceId: "", clientId: "", amount: "", paymentDate: "", method: "", notes: "",
  });

  const { data: clients } = trpc.clients.list.useQuery();
  const { data: invoices } = trpc.invoices.list.useQuery();
  const { data: payments, isLoading, refetch } = trpc.payments.list.useQuery();
  const createMutation = trpc.payments.create.useMutation();

  const getClientName = (id: number) => clients?.find((c: any) => c.id === id)?.name || "-";
  const getInvoiceNumber = (id: number) => invoices?.find((i: any) => i.id === id)?.number || "-";

  const handleSubmit = async () => {
    if (!form.clientId || !form.amount || !form.invoiceId) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }
    try {
      await createMutation.mutateAsync({
        invoiceId: Number(form.invoiceId),
        clientId: Number(form.clientId),
        amount: form.amount,
        paymentDate: form.paymentDate,
        method: form.method || undefined,
        notes: form.notes || undefined,
      });
      toast.success("تم تسجيل الدفعة");
      setForm({ invoiceId: "", clientId: "", amount: "", paymentDate: "", method: "", notes: "" });
      setOpen(false);
      refetch();
    } catch { toast.error("حدث خطأ"); }
  };

  return (
    <div className="space-y-6 pb-20 md:pb-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 px-1">
        <div>
          <h1 className="text-2xl font-bold">المدفوعات والتحصيل</h1>
          <p className="text-sm text-muted-foreground mt-1">تسجيل ومتابعة المدفوعات الواردة من العملاء</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="h-12 md:h-10 font-bold w-full md:w-auto shadow-sm">
              <Plus className="h-5 w-5 ml-2" /> تسجيل دفعة جديدة
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg p-6">
            <DialogHeader>
              <DialogTitle className="text-xl font-bold">تسجيل دفعة جديدة</DialogTitle>
            </DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mt-4">
              <div className="space-y-2">
                <Label className="font-bold text-sm">العميل *</Label>
                <Select value={form.clientId} onValueChange={v => setForm({ ...form, clientId: v })}>
                  <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue placeholder="اختر العميل" /></SelectTrigger>
                  <SelectContent>
                    {clients?.map((c: any) => (
                      <SelectItem key={c.id} value={String(c.id)} className="text-right">{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="font-bold text-sm">الفاتورة *</Label>
                <Select value={form.invoiceId} onValueChange={v => setForm({ ...form, invoiceId: v })}>
                  <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue placeholder="اختر الفاتورة" /></SelectTrigger>
                  <SelectContent>
                    {invoices?.map((inv: any) => (
                      <SelectItem key={inv.id} value={String(inv.id)} className="text-right">#{inv.number} - {getClientName(inv.clientId)}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="font-bold text-sm">المبلغ *</Label>
                <div className="relative">
                  <Input value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} type="number" className="h-12 md:h-10 text-right pr-10" placeholder="0.00" />
                  <Wallet className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                </div>
              </div>
              <div className="space-y-2">
                <Label className="font-bold text-sm">التاريخ</Label>
                <div className="relative">
                  <Input value={form.paymentDate} onChange={e => setForm({ ...form, paymentDate: e.target.value })} type="date" className="h-12 md:h-10 text-right pr-10" />
                  <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                </div>
              </div>
              <div className="space-y-2">
                <Label className="font-bold text-sm">طريقة الدفع</Label>
                <Select value={form.method} onValueChange={v => setForm({ ...form, method: v })}>
                  <SelectTrigger className="h-12 md:h-10 text-right"><SelectValue placeholder="اختر الطريقة" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="نقداً" className="text-right">نقداً</SelectItem>
                    <SelectItem value="تحويل بنكي" className="text-right">تحويل بنكي</SelectItem>
                    <SelectItem value="شيك" className="text-right">شيك</SelectItem>
                    <SelectItem value="بطاقة" className="text-right">بطاقة</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="font-bold text-sm">ملاحظات</Label>
                <Input value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} className="h-12 md:h-10 text-right" placeholder="أدخل أي ملاحظات..." />
              </div>
            </div>
            <div className="flex gap-3 mt-8">
              <Button variant="outline" className="flex-1 h-12 md:h-10" onClick={() => setOpen(false)}>إلغاء</Button>
              <Button className="flex-1 h-12 md:h-10 font-bold" onClick={handleSubmit} disabled={createMutation.isPending}>حفظ الدفعة</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="border-gray-200 shadow-sm overflow-hidden">
        <CardHeader className="bg-gray-50/50 p-4 border-b">
          <CardTitle className="text-lg flex items-center gap-2">
            <CreditCard className="h-5 w-5 text-primary" /> سجل المدفوعات
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="text-center py-16 text-muted-foreground">جاري التحميل...</div>
          ) : !payments || payments.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground bg-white">
              <CreditCard className="h-16 w-16 mx-auto mb-4 opacity-20" />
              <p className="text-lg">لا توجد مدفوعات مسجلة</p>
            </div>
          ) : isMobile ? (
            <div className="divide-y divide-gray-100">
              {payments.map((p: any) => (
                <div key={p.id} className="p-4 bg-white active:bg-gray-50 transition-colors">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-green-50 flex items-center justify-center text-green-600">
                        <Wallet className="h-5 w-5" />
                      </div>
                      <div>
                        <div className="font-bold text-sm text-gray-900">{getClientName(p.clientId)}</div>
                        <div className="text-[10px] text-muted-foreground flex items-center gap-1">
                          <FileText className="h-3 w-3" /> فاتورة #{getInvoiceNumber(p.invoiceId)}
                        </div>
                      </div>
                    </div>
                    <div className="text-left">
                      <div className="text-base font-black text-green-600 leading-none mb-1">
                        {Number(p.amount || 0).toLocaleString('en-US')}
                      </div>
                      <Badge variant="outline" className="text-[9px] px-1.5 py-0 border-gray-200 text-gray-500 font-medium">
                        {p.method || "نقداً"}
                      </Badge>
                    </div>
                  </div>
                  <div className="flex justify-between items-center text-[10px] text-muted-foreground bg-gray-50 p-2 rounded-lg">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" /> {p.paymentDate || "-"}
                    </span>
                    <span className="flex items-center gap-1">
                      <User className="h-3 w-3" /> رقم الدفعة: {p.id}
                    </span>
                  </div>
                  {p.notes && (
                    <div className="mt-2 text-[10px] text-gray-500 italic px-2 border-r-2 border-gray-200">
                      {p.notes}
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-gray-50">
                  <TableRow>
                    <TableHead className="text-right font-bold">#</TableHead>
                    <TableHead className="text-right font-bold">الفاتورة</TableHead>
                    <TableHead className="text-right font-bold">العميل</TableHead>
                    <TableHead className="text-right font-bold">المبلغ</TableHead>
                    <TableHead className="text-right font-bold">الطريقة</TableHead>
                    <TableHead className="text-right font-bold">التاريخ</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {payments.map((p: any) => (
                    <TableRow key={p.id}>
                      <TableCell className="font-medium">{p.id}</TableCell>
                      <TableCell>{getInvoiceNumber(p.invoiceId)}</TableCell>
                      <TableCell>{getClientName(p.clientId)}</TableCell>
                      <TableCell className="font-black text-green-600">{Number(p.amount || 0).toLocaleString('en-US')} ر.س</TableCell>
                      <TableCell>{p.method || "-"}</TableCell>
                      <TableCell>{p.paymentDate || "-"}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
