import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, Filter, RotateCcw, Calendar, Truck, Download } from "lucide-react";
import { toast } from "sonner";
import { exportToExcel, exportToCSV, exportMultiSheetExcel } from "@/lib/export";

const transportStatuses = ["قيد_الانتظار", "تم_الانطلاق", "وصل", "تم_التسليم", "ملغي"];

export default function InternalTransport() {
  const utils = trpc.useUtils();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedJobOrderId, setSelectedJobOrderId] = useState<number | null>(null);
  const [podDialogOpen, setPodDialogOpen] = useState(false);
  const [selectedTransportId, setSelectedTransportId] = useState<number | null>(null);
  const [podForm, setPodForm] = useState({
    podNotes: "",
    receiverSignature: "",
    receiverName: "",
  });
  const [form, setForm] = useState({
    vehiclePlate: "",
    driverName: "",
    driverPhone: "",
    destination: "",
    notes: "",
  });

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [driverFilter, setDriverFilter] = useState("all");
  const [plateFilter, setPlateFilter] = useState("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  const { data: transportOrders, isLoading } = trpc.internalTransport.list.useQuery();
  const { data: jobOrders } = trpc.jobOrders.list.useQuery();
  const { data: declarations } = trpc.declarations.list.useQuery();
  const { data: clients } = trpc.clients.list.useQuery();

  const createMutation = trpc.internalTransport.create.useMutation({
    onSuccess: () => {
      utils.internalTransport.list.invalidate();
      toast.success("تم إنشاء أمر الحركة بنجاح");
      setDialogOpen(false);
      resetForm();
    },
    onError: (e) => toast.error(e.message),
  });

  const updateMutation = trpc.internalTransport.update.useMutation({
    onSuccess: () => {
      utils.internalTransport.list.invalidate();
      toast.success("تم تحديث أمر الحركة");
    },
    onError: (e) => toast.error(e.message),
  });

  const podMutation = trpc.internalTransport.update.useMutation({
    onSuccess: () => {
      utils.internalTransport.list.invalidate();
      toast.success("تم تسجيل محضر التسليم بنجاح");
      setPodDialogOpen(false);
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = trpc.internalTransport.delete.useMutation({
    onSuccess: () => {
      utils.internalTransport.list.invalidate();
      toast.success("تم حذف أمر الحركة");
    },
    onError: (e) => toast.error(e.message),
  });

  const openPodDialog = (to: any) => {
    setSelectedTransportId(to.id);
    setPodForm({
      podNotes: to.podNotes || "",
      receiverSignature: to.receiverSignature || "",
      receiverName: to.receiverName || "",
    });
    setPodDialogOpen(true);
  };

  const resetForm = () => {
    setSelectedJobOrderId(null);
    setForm({ vehiclePlate: "", driverName: "", driverPhone: "", destination: "", notes: "" });
  };

  const resetFilters = () => {
    setSearchQuery("");
    setStatusFilter("all");
    setDriverFilter("all");
    setPlateFilter("");
    setDateFrom("");
    setDateTo("");
  };

  const handleSubmit = () => {
    if (!selectedJobOrderId) {
      toast.error("يرجى اختيار أمر العمل");
      return;
    }
    createMutation.mutate({
      jobOrderId: selectedJobOrderId,
      ...form,
    });
  };

  const getJobOrderNumber = (joId: number | null) => {
    if (!joId) return "-";
    const jo = jobOrders?.find(j => j.id === joId);
    return jo?.jobNumber || "-";
  };

  // Get unique drivers for filter dropdown
  const uniqueDrivers = useMemo(() => {
    const drivers = new Set<string>();
    transportOrders?.forEach(to => {
      if (to.driverName) drivers.add(to.driverName);
    });
    return Array.from(drivers);
  }, [transportOrders]);

  // Get unique plates for filter dropdown
  const uniquePlates = useMemo(() => {
    const plates = new Set<string>();
    transportOrders?.forEach(to => {
      if (to.vehiclePlate) plates.add(to.vehiclePlate);
    });
    return Array.from(plates);
  }, [transportOrders]);

  const hasActiveFilters = useMemo(() => {
    return searchQuery !== "" || statusFilter !== "all" ||
      driverFilter !== "all" || plateFilter !== "" ||
      dateFrom !== "" || dateTo !== "";
  }, [searchQuery, statusFilter, driverFilter, plateFilter, dateFrom, dateTo]);

  const transportExportColumns = [
    { key: "jobNumber", label: "رقم أمر العمل" },
    { key: "vehiclePlate", label: "المركبة" },
    { key: "driverName", label: "السائق" },
    { key: "destination", label: "الوجهة" },
    { key: "statusLabel", label: "الحالة" },
    { key: "receiverName", label: "المستلم" },
    { key: "createdAtStr", label: "التاريخ" },
    { key: "podNotes", label: "ملاحظات التسليم" },
  ];

  const getTransportExportData = () => {
    return filteredOrders.map(to => ({
      jobNumber: getJobOrderNumber(to.jobOrderId),
      vehiclePlate: to.vehiclePlate || "-",
      driverName: to.driverName || "-",
      destination: to.destination || "-",
      statusLabel: getStatusLabel(to.status),
      receiverName: to.receiverName || "-",
      createdAtStr: to.createdAt ? new Date(to.createdAt).toLocaleDateString('en-US') : "-",
      podNotes: to.podNotes || "",
    }));
  };

  const handleExportTransportExcel = () => {
    if (filteredOrders.length === 0) {
      toast.warning("لا توجد نتائج للتصدير");
      return;
    }
    exportToExcel(getTransportExportData(), transportExportColumns, `أوامر_الحركة_${new Date().toISOString().split('T')[0]}`);
    toast.success(`تم تصدير ${filteredOrders.length} أمر حركة إلى Excel`);
  };

  const handleExportTransportCSV = () => {
    if (filteredOrders.length === 0) {
      toast.warning("لا توجد نتائج للتصدير");
      return;
    }
    exportToCSV(getTransportExportData(), transportExportColumns, `أوامر_الحركة_${new Date().toISOString().split('T')[0]}`);
    toast.success(`تم تصدير ${filteredOrders.length} أمر حركة إلى CSV`);
  };

  // Comprehensive multi-sheet export (Transport + Job Orders)
  const jobOrderExportColumns = [
    { key: "jobNumber", label: "رقم أمر العمل" },
    { key: "clientName", label: "العميل" },
    { key: "declarationNumber", label: "رقم البيان" },
    { key: "workTypeLabel", label: "نوع العمل" },
    { key: "statusLabel", label: "الحالة" },
    { key: "priorityLabel", label: "الأولوية" },
    { key: "createdAtStr", label: "التاريخ" },
  ];

  const getJobTypeLabel = (jt: string | null) => {
    const map: Record<string, string> = {
      "تخليص_جمركي": "تخليص جمركي",
      "شحن_داخلي": "شحن داخلي",
      "تعبئة_وتغليف": "تعبئة وتغليف",
      "استشارة": "استشارة",
    };
    return map[jt || ""] || "-";
  };

  const getJobPriorityLabel = (p: string | null) => {
    const map: Record<string, string> = {
      "منخفضة": "منخفضة", "متوسطة": "متوسطة", "عالية": "عالية", "عاجلة": "عاجلة",
    };
    return map[p || ""] || "-";
  };

  const handleExportComprehensive = async () => {
    try {
      const allTransport = await utils.internalTransport.list.fetch();
      const allJobOrders = await utils.jobOrders.list.fetch();
      const allDeclarations = await utils.declarations.list.fetch();
      const allClients = await utils.clients.list.fetch();

      const sheets: {
        sheetName: string;
        data: Record<string, any>[];
        columns: { key: string; label: string }[];
      }[] = [];

      const getDecl = (joId: number | null) => {
        if (!joId) return null;
        const jo = allJobOrders?.find(j => j.id === joId);
        if (!jo?.declarationId) return null;
        return allDeclarations?.find(d => d.id === jo.declarationId);
      };
      const getClient = (joId: number | null) => {
        if (!joId) return "-";
        const jo = allJobOrders?.find(j => j.id === joId);
        if (!jo?.clientId) return "-";
        const c = allClients?.find(c => c.id === jo.clientId);
        return c?.name || "-";
      };

      // Transport Orders sheet
      const transportData = (allTransport || []).map(to => ({
        jobNumber: getJobOrderNumber(to.jobOrderId),
        vehiclePlate: to.vehiclePlate || "-",
        driverName: to.driverName || "-",
        destination: to.destination || "-",
        statusLabel: getStatusLabel(to.status),
        receiverName: to.receiverName || "-",
        createdAtStr: to.createdAt ? new Date(to.createdAt).toLocaleDateString('en-US') : "-",
        podNotes: to.podNotes || "",
      }));
      if (transportData.length > 0) {
        sheets.push({ sheetName: "أوامر الحركة", data: transportData, columns: transportExportColumns });
      }

      // Job Orders sheet
      const jobData = (allJobOrders || []).map(jo => {
        const decl = getDecl(jo.id);
        return {
          jobNumber: jo.jobNumber || "-",
          clientName: getClient(jo.id),
          declarationNumber: decl?.declarationNumber || "-",
          workTypeLabel: getJobTypeLabel(jo.jobType),
          statusLabel: getStatusLabel(jo.status),
          priorityLabel: getJobPriorityLabel(jo.priority),
          createdAtStr: jo.createdAt ? new Date(jo.createdAt).toLocaleDateString('en-US') : "-",
        };
      });
      if (jobData.length > 0) {
        sheets.push({ sheetName: "أوامر العمل", data: jobData, columns: jobOrderExportColumns });
      }

      if (sheets.length === 0) {
        toast.warning("لا توجد بيانات للتصدير");
        return;
      }

      exportMultiSheetExcel(sheets, `تقرير_شامل_النقل_${new Date().toISOString().split('T')[0]}`);
      toast.success(`تم تصدير التقرير الشامل (${sheets.length} ورقة)`);
    } catch (err) {
      toast.error("حدث خطأ أثناء التصدير الشامل");
    }
  };

  const filteredOrders = useMemo(() => {
    let result = transportOrders || [];

    // Text search across job number, driver, destination, plate, receiver
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      result = result.filter(to => {
        const joNumber = getJobOrderNumber(to.jobOrderId).toLowerCase();
        return to.driverName?.toLowerCase().includes(q) ||
          to.destination?.toLowerCase().includes(q) ||
          to.vehiclePlate?.toLowerCase().includes(q) ||
          to.receiverName?.toLowerCase().includes(q) ||
          joNumber.includes(q);
      });
    }

    // Status filter
    if (statusFilter !== "all") {
      result = result.filter(to => to.status === statusFilter);
    }

    // Driver filter
    if (driverFilter !== "all") {
      result = result.filter(to => to.driverName === driverFilter);
    }

    // Plate filter
    if (plateFilter.trim()) {
      const q = plateFilter.trim().toLowerCase();
      result = result.filter(to => to.vehiclePlate?.toLowerCase().includes(q));
    }

    // Date range filter
    if (dateFrom) {
      const fromDate = new Date(dateFrom).getTime();
      result = result.filter(to => to.createdAt && to.createdAt.getTime() >= fromDate);
    }
    if (dateTo) {
      const toDate = new Date(dateTo).getTime() + 86400000;
      result = result.filter(to => to.createdAt && to.createdAt.getTime() <= toDate);
    }

    return result;
  }, [transportOrders, searchQuery, statusFilter, driverFilter, plateFilter, dateFrom, dateTo]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "تم_التسليم": return "bg-green-100 text-green-800 border-green-200";
      case "وصل": return "bg-blue-100 text-blue-800 border-blue-200";
      case "تم_الانطلاق": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "ملغي": return "bg-red-100 text-red-800 border-red-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "قيد_الانتظار": return "قيد الانتظار";
      case "تم_الانطلاق": return "تم الانطلاق";
      case "تم_التسليم": return "تم التسليم";
      default: return status || "قيد الانتظار";
    }
  };

  return (
    <div className="space-y-4 p-4 pb-20 md:pb-4" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h2 className="text-2xl font-bold">أوامر الحركة والتسليم</h2>
        <Button onClick={() => { resetForm(); setDialogOpen(true); }} className="h-12 md:h-10 w-full md:w-auto">
          + أمر حركة جديد
        </Button>
      </div>

      {/* Search & Filter Bar */}
      <Card className="shadow-sm border-gray-200">
        <CardContent className="p-3 md:p-4">
          <div className="flex flex-col md:flex-row gap-2 md:items-center">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="بحث بالسائق أو الوجهة أو اللوحة..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="pr-10 h-12 md:h-10"
              />
            </div>
            <div className="flex gap-2 w-full md:w-auto">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="flex-1 md:w-36 h-12 md:h-10">
                  <SelectValue placeholder="الحالة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الحالات</SelectItem>
                  {transportStatuses.map(s => (
                    <SelectItem key={s} value={s}>{getStatusLabel(s)}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                variant={showFilters ? "secondary" : "outline"}
                onClick={() => setShowFilters(!showFilters)}
                className="h-12 md:h-10 gap-2"
              >
                <Filter className="w-4 h-4" />
                <span className="hidden md:inline">تصفية</span>
                {hasActiveFilters && <Badge variant="destructive" className="h-2 w-2 p-0 rounded-full" />}
              </Button>
              <div className="flex gap-1 border-r pr-2 mr-2 md:mr-0">
                <Button variant="outline" size="icon" onClick={handleExportTransportExcel} title="تصدير Excel" className="h-12 w-12 md:h-10 md:w-10">
                  <Download className="w-4 h-4 text-green-600" />
                </Button>
                <Button variant="outline" size="icon" onClick={handleExportComprehensive} title="تصدير شامل" className="h-12 w-12 md:h-10 md:w-10">
                  <Download className="w-4 h-4 text-blue-600" />
                </Button>
              </div>
            </div>
          </div>

          {showFilters && (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-4 pt-4 border-t border-gray-100">
              <div className="space-y-2">
                <Label className="font-bold">السائق</Label>
                <Select value={driverFilter} onValueChange={setDriverFilter}>
                  <SelectTrigger className="h-12 md:h-10">
                    <SelectValue placeholder="اختر السائق" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع السائقين</SelectItem>
                    {uniqueDrivers.map(d => (
                      <SelectItem key={d} value={d}>{d}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="font-bold">رقم اللوحة</Label>
                <Input
                  placeholder="رقم اللوحة..."
                  value={plateFilter}
                  onChange={e => setPlateFilter(e.target.value)}
                  className="h-12 md:h-10"
                />
              </div>
              <div className="space-y-2">
                <Label className="font-bold">من تاريخ</Label>
                <Input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} className="h-12 md:h-10" />
              </div>
              <div className="space-y-2">
                <Label className="font-bold">إلى تاريخ</Label>
                <Input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} className="h-12 md:h-10" />
              </div>
              <div className="md:col-span-4 flex justify-end">
                <Button variant="ghost" onClick={resetFilters} className="gap-2 h-10">
                  <RotateCcw className="w-4 h-4" />
                  إعادة ضبط الفلاتر
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="overflow-hidden">
        <CardContent className="p-0">
          {/* Desktop Table */}
          <div className="hidden md:block">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>رقم العمل</TableHead>
                  <TableHead>المركبة</TableHead>
                  <TableHead>السائق</TableHead>
                  <TableHead>الوجهة</TableHead>
                  <TableHead>الحالة</TableHead>
                  <TableHead>المستلم</TableHead>
                  <TableHead>التاريخ</TableHead>
                  <TableHead>إجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow><TableCell colSpan={8} className="text-center py-8">جاري التحميل...</TableCell></TableRow>
                ) : filteredOrders.length === 0 ? (
                  <TableRow><TableCell colSpan={8} className="text-center py-8 text-muted-foreground">لا توجد أوامر حركة مطابقة للبحث</TableCell></TableRow>
                ) : (
                  filteredOrders.map((to) => (
                    <TableRow key={to.id}>
                      <TableCell className="font-bold">{getJobOrderNumber(to.jobOrderId)}</TableCell>
                      <TableCell>{to.vehiclePlate || "-"}</TableCell>
                      <TableCell>{to.driverName || "-"}</TableCell>
                      <TableCell>{to.destination || "-"}</TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(to.status)} variant="outline">
                          {getStatusLabel(to.status)}
                        </Badge>
                      </TableCell>
                      <TableCell>{to.receiverName || "-"}</TableCell>
                      <TableCell className="text-sm">
                        {to.createdAt ? new Date(to.createdAt).toLocaleDateString('en-US') : "-"}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Select onValueChange={v => {
                            if (v) updateMutation.mutate({ id: to.id, status: v });
                          }}>
                            <SelectTrigger className="w-28 h-8 text-xs">
                              <SelectValue placeholder="الحالة" />
                            </SelectTrigger>
                            <SelectContent>
                              {transportStatuses.map(s => (
                                <SelectItem key={s} value={s}>{getStatusLabel(s)}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <Button variant="outline" size="sm" onClick={() => openPodDialog(to)}>POD</Button>
                          <Button variant="destructive" size="sm" onClick={() => deleteMutation.mutate({ id: to.id })}>حذف</Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {/* Mobile List View */}
          <div className="md:hidden space-y-3 p-3 bg-gray-50/50">
            {isLoading ? (
              <div className="text-center py-12">جاري التحميل...</div>
            ) : filteredOrders.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">لا توجد بيانات</div>
            ) : (
              filteredOrders.map((to) => (
                <div key={to.id} className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="text-[10px] text-muted-foreground font-bold uppercase">رقم أمر العمل</div>
                      <div className="font-bold text-primary">{getJobOrderNumber(to.jobOrderId)}</div>
                    </div>
                    <Badge className={`${getStatusColor(to.status)} rounded-lg`} variant="outline">
                      {getStatusLabel(to.status)}
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <div className="text-[10px] text-muted-foreground">السائق</div>
                      <div className="font-medium">{to.driverName || "-"}</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-muted-foreground">المركبة</div>
                      <div className="font-medium">{to.vehiclePlate || "-"}</div>
                    </div>
                    <div className="col-span-2">
                      <div className="text-[10px] text-muted-foreground">الوجهة</div>
                      <div className="font-medium">{to.destination || "-"}</div>
                    </div>
                  </div>

                  <div className="flex flex-col gap-2 pt-3 border-t border-gray-100">
                    <div className="flex gap-2">
                      <Select
                        value={to.status}
                        onValueChange={(v) => updateMutation.mutate({ id: to.id, status: v })}
                      >
                        <SelectTrigger className="flex-1 h-10 text-sm">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {transportStatuses.map(s => (
                            <SelectItem key={s} value={s}>{getStatusLabel(s)}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Button variant="outline" size="sm" onClick={() => openPodDialog(to)} className="h-10 gap-2">
                        <Truck className="w-4 h-4" /> إثبات تسليم
                      </Button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* محضر التسليم (POD) Dialog */}
      <Dialog open={podDialogOpen} onOpenChange={setPodDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>محضر إثبات التسليم (POD)</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>اسم المستلم *</Label>
              <Input value={podForm.receiverName} onChange={e => setPodForm({ ...podForm, receiverName: e.target.value })} placeholder="اسم الشخص الذي استلم" />
            </div>
            <div className="space-y-2">
              <Label>التوقيع / الختم</Label>
              <Input value={podForm.receiverSignature} onChange={e => setPodForm({ ...podForm, receiverSignature: e.target.value })} placeholder="توقيع أو رقم الختم" />
            </div>
            <div className="space-y-2">
              <Label>ملاحظات سلامة الشحنة</Label>
              <Textarea value={podForm.podNotes} onChange={e => setPodForm({ ...podForm, podNotes: e.target.value })} rows={3} placeholder="مثال: تم التسليم بسلامة، لا يوجد تلف..." />
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setPodDialogOpen(false)}>إلغاء</Button>
              <Button onClick={() => {
                if (selectedTransportId && podForm.receiverName) {
                  podMutation.mutate({
                    id: selectedTransportId,
                    receiverName: podForm.receiverName,
                    receiverSignature: podForm.receiverSignature,
                    podNotes: podForm.podNotes,
                    status: "تم_التسليم",
                    arrivalTime: new Date().toISOString(),
                  });
                } else {
                  toast.error("يرجى إدخال اسم المستلم");
                }
              }} disabled={podMutation.isPending}>
                اعتماد التسليم
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>إنشاء أمر حركة جديد</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>أمر العمل *</Label>
              <Select value={selectedJobOrderId ? String(selectedJobOrderId) : ""} onValueChange={v => setSelectedJobOrderId(Number(v))}>
                <SelectTrigger><SelectValue placeholder="اختر أمر العمل" /></SelectTrigger>
                <SelectContent>
                  {jobOrders?.map(jo => (
                    <SelectItem key={jo.id} value={String(jo.id)}>
                      {jo.jobNumber} - {clients?.find(c => c.id === jo.clientId)?.name || "-"}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>رقم اللوحة</Label>
              <Input value={form.vehiclePlate} onChange={e => setForm({ ...form, vehiclePlate: e.target.value })} placeholder="ABC-123" />
            </div>
            <div className="space-y-2">
              <Label>اسم السائق</Label>
              <Input value={form.driverName} onChange={e => setForm({ ...form, driverName: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>هاتف السائق</Label>
              <Input value={form.driverPhone} onChange={e => setForm({ ...form, driverPhone: e.target.value })} />
            </div>
            <div className="space-y-2 col-span-2">
              <Label>الوجهة</Label>
              <Input value={form.destination} onChange={e => setForm({ ...form, destination: e.target.value })} placeholder="عنوان التسليم" />
            </div>
            <div className="space-y-2 col-span-2">
              <Label>ملاحظات</Label>
              <Textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} rows={2} />
            </div>
          </div>
          <div className="flex gap-2 justify-end mt-4">
            <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
            <Button onClick={handleSubmit} disabled={createMutation.isPending}>حفظ</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
