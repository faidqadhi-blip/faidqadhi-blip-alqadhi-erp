import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Search, Edit2, Trash2, ClipboardList, Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

export default function CustomsEntries() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<any>(null);

  const { data: entries, isLoading, refetch } = trpc.customsEntries.list.useQuery();
  const { data: clients } = trpc.clients.list.useQuery();
  const ports = ["منفذ شحن", "منفذ الوديعة", "ميناء عدن", "ميناء الحديدة", "منفذ صرفيت"];
  const drivers = ["أحمد علي", "محمد حسن", "سالم عبده", "خالد عبدالله"];

  const createMutation = trpc.customsEntries.create.useMutation({
    onSuccess: () => {
      toast.success("تم إنشاء القيد الجمركي بنجاح");
      setIsAddDialogOpen(false);
      refetch();
    },
  });

  const updateMutation = trpc.customsEntries.update.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث القيد الجمركي بنجاح");
      setEditingEntry(null);
      refetch();
    },
  });

  const deleteMutation = trpc.customsEntries.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف القيد الجمركي بنجاح");
      refetch();
    },
  });

  const [formData, setFormData] = useState({
    clientId: "",
    operationType: "استيراد",
    entryNumber: "",
    entryDate: new Date().toISOString().split('T')[0],
    goodsType: "",
    customsPort: "",
    plateNumber: "",
    driverName: "",
    notes: "",
  });

  const handleOpenAdd = () => {
    setFormData({
      clientId: "",
      operationType: "استيراد",
      entryNumber: "",
      entryDate: new Date().toISOString().split('T')[0],
      goodsType: "",
      customsPort: "",
      plateNumber: "",
      driverName: "",
      notes: "",
    });
    setIsAddDialogOpen(true);
  };

  const handleOpenEdit = (entry: any) => {
    setEditingEntry(entry);
    setFormData({
      clientId: entry.clientId?.toString() || "",
      operationType: entry.operationType || "استيراد",
      entryNumber: entry.entryNumber || "",
      entryDate: entry.entryDate || new Date().toISOString().split('T')[0],
      goodsType: entry.goodsType || "",
      customsPort: entry.customsPort || "",
      plateNumber: entry.plateNumber || "",
      driverName: entry.driverName || "",
      notes: entry.notes || "",
    });
  };

  const handleSubmit = () => {
    if (!formData.clientId || !formData.entryNumber || !formData.customsPort) {
      toast.error("يرجى إكمال الحقول المطلوبة (العميل، رقم القيد، المنفذ)");
      return;
    }

    const payload = {
      ...formData,
      clientId: parseInt(formData.clientId),
    };

    if (editingEntry) {
      updateMutation.mutate({ id: editingEntry.id, data: payload });
    } else {
      createMutation.mutate(payload);
    }
  };

  const filteredEntries = entries?.filter(entry =>
    entry.entryNumber?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    entry.goodsType?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    entry.customsPort?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <ClipboardList className="h-6 w-6 text-primary" />
            القيود الجمركية
          </h1>
          <p className="text-muted-foreground">إدارة وتتبع قيود دخول البضائع للمنافذ</p>
        </div>
        <Button onClick={handleOpenAdd} className="gap-2">
          <Plus className="h-4 w-4" />
          قيد جديد
        </Button>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="بحث برقم القيد، العميل، أو نوع البضاعة..."
              className="pr-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            <>
              {/* Desktop Table View */}
              <div className="hidden md:block rounded-md border overflow-hidden">
                <Table>
                  <TableHeader className="bg-muted/50">
                    <TableRow>
                      <TableHead className="text-right">رقم القيد</TableHead>
                      <TableHead className="text-right">العميل</TableHead>
                      <TableHead className="text-right">النوع</TableHead>
                      <TableHead className="text-right">التاريخ</TableHead>
                      <TableHead className="text-right">البضاعة</TableHead>
                      <TableHead className="text-right">المنفذ</TableHead>
                      <TableHead className="text-right">السائق/اللوحة</TableHead>
                      <TableHead className="text-left">الإجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredEntries?.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                          لا توجد قيود جمركية مسجلة
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredEntries?.map((entry) => (
                        <TableRow key={entry.id}>
                          <TableCell className="font-medium">{entry.entryNumber}</TableCell>
                          <TableCell>{clients?.find(c => c.id === entry.clientId)?.name || entry.clientId}</TableCell>
                          <TableCell>{entry.operationType}</TableCell>
                          <TableCell>{entry.entryDate}</TableCell>
                          <TableCell>{entry.goodsType}</TableCell>
                          <TableCell>{entry.customsPort}</TableCell>
                          <TableCell>
                            <div className="text-xs">
                              <div>{entry.driverName || "-"}</div>
                              <div className="text-muted-foreground">{entry.plateNumber || "-"}</div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Button variant="ghost" size="icon" onClick={() => handleOpenEdit(entry)}>
                                <Edit2 className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="text-destructive"
                                onClick={() => {
                                  if (confirm("هل أنت متأكد من حذف هذا القيد؟")) {
                                    deleteMutation.mutate(entry.id);
                                  }
                                }}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>

              {/* Mobile Card View */}
              <div className="md:hidden space-y-3">
                {filteredEntries?.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground bg-muted/20 rounded-lg">
                    لا توجد قيود جمركية مسجلة
                  </div>
                ) : (
                  filteredEntries?.map((entry) => (
                    <div key={entry.id} className="p-4 bg-card rounded-xl border shadow-sm space-y-3">
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="text-xs text-muted-foreground mb-1">رقم القيد</div>
                          <div className="font-bold text-lg">{entry.entryNumber}</div>
                        </div>
                        <Badge variant="outline" className="bg-primary/5">{entry.operationType}</Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-y-3 gap-x-2 text-sm">
                        <div>
                          <div className="text-[10px] text-muted-foreground">العميل</div>
                          <div className="font-medium truncate">{clients?.find(c => c.id === entry.clientId)?.name || entry.clientId}</div>
                        </div>
                        <div>
                          <div className="text-[10px] text-muted-foreground">التاريخ</div>
                          <div className="font-medium">{entry.entryDate}</div>
                        </div>
                        <div>
                          <div className="text-[10px] text-muted-foreground">المنفذ</div>
                          <div className="font-medium">{entry.customsPort}</div>
                        </div>
                        <div>
                          <div className="text-[10px] text-muted-foreground">البضاعة</div>
                          <div className="font-medium truncate">{entry.goodsType || "-"}</div>
                        </div>
                        <div className="col-span-2 pt-1 border-t flex justify-between items-center">
                          <div className="flex flex-col">
                            <span className="text-[10px] text-muted-foreground">السائق واللوحة</span>
                            <span className="text-xs font-medium">{entry.driverName || "-"} | {entry.plateNumber || "-"}</span>
                          </div>
                          <div className="flex gap-1">
                            <Button variant="outline" size="sm" onClick={() => handleOpenEdit(entry)} className="h-8 px-2">
                              تعديل
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="h-8 px-2 text-destructive border-destructive/20 hover:bg-destructive/10"
                              onClick={() => {
                                if (confirm("هل أنت متأكد من حذف هذا القيد؟")) {
                                  deleteMutation.mutate(entry.id);
                                }
                              }}
                            >
                              حذف
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </>
          )}
        </CardContent>
      </Card>

      <Dialog open={isAddDialogOpen || !!editingEntry} onOpenChange={(open) => {
        if (!open) {
          setIsAddDialogOpen(false);
          setEditingEntry(null);
        }
      }}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingEntry ? "تعديل قيد جمركي" : "إنشاء قيد جمركي جديد"}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 py-4">
            <div className="space-y-2">
              <Label className="text-sm font-bold">العميل *</Label>
              <Select
                value={formData.clientId}
                onValueChange={(v) => setFormData({ ...formData, clientId: v })}
              >
                <SelectTrigger className="h-12 md:h-10">
                  <SelectValue placeholder="اختر العميل" />
                </SelectTrigger>
                <SelectContent>
                  {clients?.map((c) => (
                    <SelectItem key={c.id} value={c.id.toString()}>{c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-bold">نوع العملية</Label>
              <Select
                value={formData.operationType}
                onValueChange={(v) => setFormData({ ...formData, operationType: v })}
              >
                <SelectTrigger className="h-12 md:h-10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="استيراد">استيراد</SelectItem>
                  <SelectItem value="تصدير">تصدير</SelectItem>
                  <SelectItem value="ترانزيت">ترانزيت</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-bold">رقم القيد *</Label>
              <Input
                value={formData.entryNumber}
                onChange={(e) => setFormData({ ...formData, entryNumber: e.target.value })}
                placeholder="أدخل رقم القيد/الدخول"
                className="h-12 md:h-10 text-lg md:text-base"
                inputMode="numeric"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-bold">تاريخ القيد</Label>
              <Input
                type="date"
                value={formData.entryDate}
                onChange={(e) => setFormData({ ...formData, entryDate: e.target.value })}
                className="h-12 md:h-10"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-bold">نوع البضاعة</Label>
              <Input
                value={formData.goodsType}
                onChange={(e) => setFormData({ ...formData, goodsType: e.target.value })}
                placeholder="مثال: مواد غذائية، قطع غيار..."
                className="h-12 md:h-10"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-bold">المنفذ الجمركي *</Label>
              <Select
                value={formData.customsPort}
                onValueChange={(v) => setFormData({ ...formData, customsPort: v })}
              >
                <SelectTrigger className="h-12 md:h-10">
                  <SelectValue placeholder="اختر المنفذ" />
                </SelectTrigger>
                <SelectContent>
                  {ports.map((p) => (
                    <SelectItem key={p} value={p}>{p}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-bold">رقم اللوحة</Label>
              <Input
                value={formData.plateNumber}
                onChange={(e) => setFormData({ ...formData, plateNumber: e.target.value })}
                placeholder="رقم لوحة الشاحنة"
                className="h-12 md:h-10"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-bold">اسم السائق</Label>
              <Select
                value={formData.driverName}
                onValueChange={(v) => setFormData({ ...formData, driverName: v })}
              >
                <SelectTrigger className="h-12 md:h-10">
                  <SelectValue placeholder="اختر السائق" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none__">بدون سائق محدد</SelectItem>
                  {drivers.map((d) => (
                    <SelectItem key={d} value={d}>{d}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="col-span-1 md:col-span-2 space-y-2">
              <Label className="text-sm font-bold">ملاحظات</Label>
              <Input
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="أي ملاحظات إضافية..."
                className="h-12 md:h-10"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setIsAddDialogOpen(false); setEditingEntry(null); }}>إلغاء</Button>
            <Button onClick={handleSubmit} disabled={createMutation.isPending || updateMutation.isPending}>
              {(createMutation.isPending || updateMutation.isPending) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              حفظ
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
