import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { Plus, Search, X, Building2, Pencil, Trash2, Phone, Mail, Tag, MapPin } from "lucide-react";

export default function Suppliers() {
  const utils = trpc.useUtils();
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState({
    name: "", phone: "", email: "", address: "", category: "", notes: "",
  });

  const { data: suppliers, isLoading } = trpc.suppliers.list.useQuery();

  const filtered = useMemo(() => {
    if (!suppliers) return [];
    if (!search.trim()) return suppliers;
    const q = search.trim().toLowerCase();
    return suppliers.filter(s =>
      s.name.toLowerCase().includes(q) ||
      (s.phone?.toLowerCase().includes(q)) ||
      (s.category?.toLowerCase().includes(q))
    );
  }, [suppliers, search]);

  const createMutation = trpc.suppliers.create.useMutation({
    onSuccess: () => {
      toast.success("تمت إضافة المورد بنجاح");
      utils.suppliers.list.invalidate();
      setDialogOpen(false);
      resetForm();
    },
    onError: (e) => toast.error(e.message),
  });

  const updateMutation = trpc.suppliers.update.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث بيانات المورد");
      utils.suppliers.list.invalidate();
      setDialogOpen(false);
      resetForm();
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = trpc.suppliers.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف المورد");
      utils.suppliers.list.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  const resetForm = () => {
    setForm({ name: "", phone: "", email: "", address: "", category: "", notes: "" });
    setEditingId(null);
  };

  const openEdit = (s: NonNullable<typeof suppliers>[number]) => {
    setForm({
      name: s.name, phone: s.phone || "", email: s.email || "",
      address: s.address || "", category: s.category || "",
      notes: s.notes || "",
    });
    setEditingId(s.id);
    setDialogOpen(true);
  };

  const handleSubmit = () => {
    if (!form.name.trim()) { toast.error("اسم المورد مطلوب"); return; }
    if (editingId) {
      updateMutation.mutate({ id: editingId, ...form });
    } else {
      createMutation.mutate(form);
    }
  };

  return (
    <div className="space-y-4 pb-20 md:pb-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 px-1">
        <div>
          <h1 className="text-2xl font-bold text-foreground">إدارة الموردين</h1>
          <p className="text-sm text-muted-foreground mt-1">إدارة بيانات الموردين وشركات الخدمات</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={(o) => { setDialogOpen(o); if (!o) resetForm(); }}>
          <DialogTrigger asChild>
            <Button className="w-full md:w-auto h-12 md:h-10 font-bold text-base">
              <Plus className="h-5 w-5 ml-2" /> إضافة مورد جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg p-0 gap-0 overflow-hidden">
            <DialogHeader className="p-6 pb-2">
              <DialogTitle className="text-xl">{editingId ? "تعديل بيانات المورد" : "إضافة مورد جديد"}</DialogTitle>
            </DialogHeader>
            <div className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="col-span-1 md:col-span-2 space-y-2">
                  <Label className="font-bold">اسم المورد *</Label>
                  <Input 
                    value={form.name} 
                    onChange={e => setForm(f => ({ ...f, name: e.target.value }))} 
                    className="h-12 md:h-10"
                    placeholder="اسم الشركة أو المورد" 
                  />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">الهاتف</Label>
                  <Input 
                    value={form.phone} 
                    onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} 
                    className="h-12 md:h-10 text-left"
                    placeholder="000-000-000" 
                  />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">البريد الإلكتروني</Label>
                  <Input 
                    value={form.email} 
                    onChange={e => setForm(f => ({ ...f, email: e.target.value }))} 
                    className="h-12 md:h-10 text-left"
                    placeholder="email@example.com" 
                  />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">التصنيف</Label>
                  <Input 
                    value={form.category} 
                    onChange={e => setForm(f => ({ ...f, category: e.target.value }))} 
                    className="h-12 md:h-10"
                    placeholder="نقل، وقود، صيانة، إلخ" 
                  />
                </div>
                <div className="col-span-1 md:col-span-2 space-y-2">
                  <Label className="font-bold">العنوان</Label>
                  <Textarea value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} placeholder="العنوان بالتفصيل" rows={2} />
                </div>
                <div className="col-span-1 md:col-span-2 space-y-2">
                  <Label className="font-bold">ملاحظات</Label>
                  <Textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} placeholder="أي ملاحظات إضافية" rows={2} />
                </div>
              </div>
              <div className="flex flex-col md:flex-row justify-end gap-3 pt-4 border-t">
                <Button variant="outline" onClick={() => { setDialogOpen(false); resetForm(); }} className="h-12 md:h-10 font-bold">إلغاء</Button>
                <Button onClick={handleSubmit} disabled={createMutation.isPending || updateMutation.isPending} className="h-12 md:h-10 font-bold text-base">
                  {editingId ? "تحديث البيانات" : "إضافة المورد"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="shadow-sm border-gray-200">
        <CardHeader className="p-4 pb-2">
          <div className="relative">
            <Search className="absolute right-3 top-3 h-5 w-5 text-gray-400" />
            <Input
              placeholder="ابحث بالاسم، الهاتف، أو التصنيف..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pr-10 h-12 md:h-10 w-full"
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex flex-col items-center py-12 gap-3">
              <div className="h-10 w-10 animate-spin rounded-full border-4 border-primary border-t-transparent" />
              <span className="text-muted-foreground">جاري تحميل الموردين...</span>
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-12 flex flex-col items-center gap-3">
              <Building2 className="h-16 w-16 text-gray-200" />
              <p className="text-muted-foreground">{search ? "لا توجد نتائج مطابقة للبحث" : "لا يوجد موردين بعد"}</p>
            </div>
          ) : (
            <>
              {/* Desktop Table */}
              <div className="hidden md:block">
                <Table>
                  <TableHeader className="bg-gray-50">
                    <TableRow>
                      <TableHead className="text-right font-bold">الاسم</TableHead>
                      <TableHead className="text-right font-bold">الهاتف</TableHead>
                      <TableHead className="text-right font-bold">البريد</TableHead>
                      <TableHead className="text-right font-bold">التصنيف</TableHead>
                      <TableHead className="text-right font-bold">العنوان</TableHead>
                      <TableHead className="text-left font-bold">الإجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filtered.map(s => (
                      <TableRow key={s.id} className="hover:bg-gray-50/50 transition-colors">
                        <TableCell className="font-bold text-primary">{s.name}</TableCell>
                        <TableCell className="text-sm" dir="ltr">{s.phone || "-"}</TableCell>
                        <TableCell className="text-sm" dir="ltr">{s.email || "-"}</TableCell>
                        <TableCell>
                          <span className="px-2 py-0.5 bg-gray-100 rounded text-[10px] font-bold">{s.category || "-"}</span>
                        </TableCell>
                        <TableCell className="max-w-[200px] truncate text-xs">{s.address || "-"}</TableCell>
                        <TableCell>
                          <div className="flex justify-end gap-1">
                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(s)}>
                              <Pencil className="h-3.5 w-3.5" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500 hover:bg-red-50" onClick={() => {
                              if (confirm(`هل تريد حذف المورد "${s.name}"؟`)) deleteMutation.mutate({ id: s.id });
                            }}>
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Mobile Card List */}
              <div className="md:hidden space-y-0 divide-y">
                {filtered.map(s => (
                  <div key={s.id} className="p-4 active:bg-gray-50 transition-colors">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex flex-col">
                        <h3 className="font-bold text-lg text-primary">{s.name}</h3>
                        {s.category && (
                          <span className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                            <Tag className="h-3 w-3" /> {s.category}
                          </span>
                        )}
                      </div>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" className="h-9 w-9 text-blue-600" onClick={() => openEdit(s)}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-9 w-9 text-red-500" onClick={() => {
                          if (confirm(`هل تريد حذف المورد "${s.name}"؟`)) deleteMutation.mutate({ id: s.id });
                        }}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 gap-2 mt-3">
                      {s.phone && (
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Phone className="h-3.5 w-3.5 text-gray-400" />
                          <span dir="ltr">{s.phone}</span>
                        </div>
                      )}
                      {s.email && (
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Mail className="h-3.5 w-3.5 text-gray-400" />
                          <span dir="ltr">{s.email}</span>
                        </div>
                      )}
                      {s.address && (
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <MapPin className="h-3.5 w-3.5 text-gray-400" />
                          <span className="truncate">{s.address}</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
