import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { BarChart3, Calendar, Filter, DollarSign, TrendingUp, Calculator, ChevronLeft } from "lucide-react";
import { useState } from "react";
import { useIsMobile } from "@/hooks/useMobile";
import { Badge } from "@/components/ui/badge";

export default function SalesReport() {
  const isMobile = useIsMobile();
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth() + 1);

  const { data: report, isLoading } = trpc.sales.monthlyReport.useQuery({ year, month });

  const totalAmount = report?.reduce((sum: number, r: any) => sum + Number(r.totalAmount || 0), 0) || 0;
  const totalCount = report?.length || 0;

  const monthNames = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];

  return (
    <div className="space-y-6 pb-20 md:pb-6" dir="rtl">
      <div className="px-1">
        <h1 className="text-2xl font-bold">تقرير المبيعات الشهري</h1>
        <p className="text-sm text-muted-foreground mt-1">عرض وتصفية المبيعات حسب الشهر والسنة</p>
      </div>

      <Card className="border-gray-200 shadow-sm overflow-hidden">
        <CardHeader className="bg-gray-50/50 p-4 border-b">
          <CardTitle className="text-lg flex items-center gap-2">
            <Filter className="h-5 w-5 text-primary" /> تصفية النتائج
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4 md:p-6">
          <div className="flex flex-col md:flex-row items-end gap-4">
            <div className="space-y-2 w-full md:w-40">
              <Label className="font-bold text-xs uppercase text-muted-foreground">السنة</Label>
              <Input type="number" value={year} onChange={e => setYear(Number(e.target.value))} className="h-12 md:h-10 text-center font-black" />
            </div>
            <div className="space-y-2 w-full md:w-48">
              <Label className="font-bold text-xs uppercase text-muted-foreground">الشهر</Label>
              <Select value={String(month)} onValueChange={v => setMonth(Number(v))}>
                <SelectTrigger className="h-12 md:h-10 text-right font-bold"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {monthNames.map((m, i) => (
                    <SelectItem key={i + 1} value={String(i + 1)} className="text-right font-bold">{m}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-gray-200 shadow-sm bg-gradient-to-br from-blue-50 to-white">
          <CardContent className="p-5 flex items-center gap-4">
            <div className="h-12 w-12 rounded-xl bg-blue-100 flex items-center justify-center shrink-0 shadow-sm">
              <DollarSign className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground mb-0.5 font-bold uppercase tracking-wider">إجمالي المبيعات</p>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-black text-gray-900">{totalAmount.toLocaleString('en-US')}</span>
                <span className="text-xs font-bold text-muted-foreground">ر.ي</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-gray-200 shadow-sm bg-gradient-to-br from-green-50 to-white">
          <CardContent className="p-5 flex items-center gap-4">
            <div className="h-12 w-12 rounded-xl bg-green-100 flex items-center justify-center shrink-0 shadow-sm">
              <TrendingUp className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground mb-0.5 font-bold uppercase tracking-wider">عدد العمليات</p>
              <span className="text-2xl font-black text-green-600">{totalCount.toLocaleString('en-US')}</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-gray-200 shadow-sm bg-gradient-to-br from-purple-50 to-white">
          <CardContent className="p-5 flex items-center gap-4">
            <div className="h-12 w-12 rounded-xl bg-purple-100 flex items-center justify-center shrink-0 shadow-sm">
              <Calculator className="h-6 w-6 text-purple-600" />
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground mb-0.5 font-bold uppercase tracking-wider">متوسط الفاتورة</p>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-black text-purple-600">{totalCount > 0 ? (totalAmount / totalCount).toLocaleString('en-US', { maximumFractionDigits: 0 }) : 0}</span>
                <span className="text-xs font-bold text-muted-foreground">ر.ي</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-gray-200 shadow-sm overflow-hidden">
        <CardHeader className="bg-gray-50/50 p-4 border-b">
          <CardTitle className="text-lg flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" /> تفاصيل مبيعات {monthNames[month-1]} {year}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="text-center py-16 text-muted-foreground">جاري التحميل...</div>
          ) : !report || report.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground bg-white">
              <BarChart3 className="h-16 w-16 mx-auto mb-4 opacity-20" />
              <p className="text-lg">لا توجد بيانات لهذا الشهر</p>
            </div>
          ) : isMobile ? (
            <div className="divide-y divide-gray-100">
              {report.map((r: any) => (
                <div key={r.id} className="p-4 bg-white active:bg-gray-50 transition-colors">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <span className="font-bold text-base block text-gray-900">فاتورة: {r.invoiceId}</span>
                      <Badge variant="outline" className="text-[10px] mt-1 bg-blue-50 text-blue-600 border-blue-100">
                        {r.invoiceType?.replace("_", " ")}
                      </Badge>
                    </div>
                    <div className="text-left">
                      <div className="font-black text-lg text-blue-600 leading-none mb-1">
                        {Number(r.totalAmount || 0).toLocaleString('en-US')}
                      </div>
                      <span className="text-[10px] text-muted-foreground font-bold uppercase">ر.ي</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center text-[10px] text-muted-foreground bg-gray-50 p-2 rounded-lg">
                    <div className="flex items-center gap-1 font-medium">
                      <Calendar className="h-3 w-3" />
                      <span>{new Date(r.transferredAt).toLocaleDateString('ar-SA')}</span>
                    </div>
                    <div className="flex items-center gap-1 font-medium">
                      <span className="bg-gray-200 text-gray-700 px-1.5 py-0.5 rounded uppercase tracking-tighter">
                        {r.customsPort || "-"}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-gray-50">
                  <TableRow>
                    <TableHead className="text-right font-bold text-gray-600">رقم الفاتورة</TableHead>
                    <TableHead className="text-right font-bold text-gray-600">النوع</TableHead>
                    <TableHead className="text-right font-bold text-gray-600">المبلغ</TableHead>
                    <TableHead className="text-right font-bold text-gray-600">المنفذ</TableHead>
                    <TableHead className="text-right font-bold text-gray-600">تاريخ الترحيل</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {report.map((r: any) => (
                    <TableRow key={r.id} className="hover:bg-gray-50 transition-colors">
                      <td className="p-4 font-bold text-gray-900">{r.invoiceId}</td>
                      <td className="p-4"><Badge variant="secondary" className="text-xs">{r.invoiceType?.replace("_", " ")}</Badge></td>
                      <td className="p-4 font-black text-blue-600">{Number(r.totalAmount || 0).toLocaleString('en-US')} ر.ي</td>
                      <td className="p-4 font-medium text-gray-600">{r.customsPort || "-"}</td>
                      <td className="p-4 text-muted-foreground">{new Date(r.transferredAt).toLocaleDateString('ar-SA')}</td>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
