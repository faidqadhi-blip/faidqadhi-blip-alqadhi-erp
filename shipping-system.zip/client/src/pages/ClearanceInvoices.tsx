import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { Printer, FileText, Search, FileDown, Loader2 } from "lucide-react";
import { useIsMobile } from "@/hooks/useMobile";

// تحويل الأرقام إلى كلمات عربية
function numberToArabicWords(num: number): string {
  if (num === 0) return "صفر";
  const ones = ["", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة"];
  const tens = ["", "عشرة", "عشرون", "ثلاثون", "أربعون", "خمسون", "ستون", "سبعون", "ثمانون", "تسعون"];
  const teens = ["عشرة", "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر", "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر"];
  let result = "";
  if (num >= 1000000) {
    const millions = Math.floor(num / 1000000);
    result += numberToArabicWords(millions) + " مليون ";
    num = num % 1000000;
  }
  if (num >= 1000) {
    const thousands = Math.floor(num / 1000);
    if (thousands === 1) result += "ألف ";
    else if (thousands === 2) result += "ألفين ";
    else result += numberToArabicWords(thousands) + " ألف ";
    num = num % 1000;
  }
  if (num >= 100) {
    const hundreds = Math.floor(num / 100);
    if (hundreds === 1) result += "مائة ";
    else if (hundreds === 2) result += "مائتان ";
    else if (hundreds >= 3) result += numberToArabicWords(hundreds).replace("ثمانية", "ثمان") + "مائة ";
    num = num % 100;
  }
  if (num > 0) {
    if (num < 10) result += ones[num];
    else if (num < 20) result += teens[num - 10];
    else {
      const t = Math.floor(num / 10);
      const o = num % 10;
      if (o > 0) result += ones[o] + " و" + tens[t];
      else result += tens[t];
    }
  }
  return result.trim();
}

function getCurrencyNameFn(code: string, currencies: any[]): string {
  const c = currencies?.find((c: any) => c.code === code);
  return c?.name || code;
}

export default function ClearanceInvoices() {
  const isMobile = useIsMobile();
  const utils = trpc.useUtils();
  const [selectedDeclId, setSelectedDeclId] = useState<number | null>(null);
  const [invoiceNumber, setInvoiceNumber] = useState("");
  const [isExporting, setIsExporting] = useState(false);

  const { data: declarations, isLoading: isDeclsLoading } = trpc.declarations.list.useQuery({ status: "معتمد" });
  const { data: costs } = trpc.clearanceCosts.list.useQuery(
    selectedDeclId ? { declarationId: selectedDeclId } : undefined,
    { enabled: !!selectedDeclId }
  );
  const { data: clients } = trpc.clients.list.useQuery();
  const { data: currencies } = trpc.currencies.list.useQuery();

  const selectedDecl = declarations?.find(d => d.id === selectedDeclId);
  const selectedCost = costs?.[0];
  const currencyCode = selectedDecl?.currency || "YER";
  const currencyName = getCurrencyNameFn(currencyCode, currencies || []);

  const getClientName = (clientId: number | null) => {
    if (!clientId) return "-";
    const client = clients?.find(c => c.id === clientId);
    return client?.name || "-";
  };

  const handleGenerateInvoice = () => {
    if (!selectedDeclId || !selectedCost) {
      toast.error("يرجى اختيار بيان معتمد له تكاليف");
      return;
    }
    const invNum = invoiceNumber || `INV-${String(selectedDeclId).padStart(6, "0")}`;
    setTimeout(() => printInvoice(invNum), 100);
  };

  const handleDownloadPDF = async () => {
    if (!selectedDeclId || !selectedCost) {
      toast.error("يرجى اختيار بيان معتمد له تكاليف");
      return;
    }
    setIsExporting(true);
    const invNum = invoiceNumber || `INV-${String(selectedDeclId).padStart(6, "0")}`;
    const element = document.getElementById(`invoice-print-${selectedDeclId}`);
    if (!element) { 
      toast.error("لم يتم العثور على الفاتورة"); 
      setIsExporting(false);
      return; 
    }
    
    try {
      const canvas = await html2canvas(element, { scale: 2, backgroundColor: '#ffffff', useCORS: true });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`فاتورة-${invNum}.pdf`);
      toast.success("تم تحميل الفاتورة PDF بنجاح");
    } catch (error) {
      console.error(error);
      toast.error("فشل تصدير PDF");
    } finally {
      setIsExporting(false);
    }
  };

  const printInvoice = (invNum: string) => {
    const element = document.getElementById(`invoice-print-${selectedDeclId}`);
    if (!element) return;
    const printWindow = window.open('', '_blank');
    if (!printWindow) { toast.error("يرجى السماح بالنوافذ المنبثقة"); return; }
    printWindow.document.write(`
      <!DOCTYPE html>
      <html dir="rtl">
      <head><meta charset="UTF-8"><title>فاتورة ${invNum}</title>
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Tajawal', Arial, sans-serif; }
        body { padding: 15mm; font-size: 13px; color: #333; }
        @media print { body { padding: 10mm; } }
      </style></head>
      <body>${element.innerHTML}</body></html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

  const totalCost = Number(selectedCost?.totalCost || 0);
  const discount = Number(selectedCost?.discount || 0);
  const netCost = totalCost - discount;

  const finalItems = [
    { detail: "رسوم البيان", type: "تخليص", count: "1", cost: Number(selectedCost?.declarationFee || 0) },
    { detail: "النقل", type: "تخليص", count: "1", cost: Number(selectedCost?.transport || 0) },
    { detail: "الوقود", type: "رسوم مستردة", count: "1", cost: Number(selectedCost?.fuel || 0) },
    { detail: "أتعاب السائق", type: "نقل", count: "1", cost: Number(selectedCost?.driverCost || 0) },
    { detail: "الصيانة", type: "صيانة", count: "1", cost: Number(selectedCost?.maintenance || 0) },
    { detail: "مصاريف أخرى", type: "أخرى", count: "1", cost: Number(selectedCost?.otherExpenses || 0) },
    { detail: "نثريات", type: "نثريات", count: "1", cost: Number(selectedCost?.pettyCash || 0) },
  ].filter(item => item.cost > 0);

  const invNum = invoiceNumber || `INV-${String(selectedDeclId).padStart(6, "0")}`;
  const invoiceDate = new Date().toLocaleDateString("ar-SA", { year: "numeric", month: "long", day: "numeric" });

  return (
    <div className="space-y-6 pb-24 md:pb-6" dir="rtl">
      <div className="px-1">
        <h2 className="text-2xl font-bold text-foreground">الفواتير والتكاليف</h2>
        <p className="text-sm text-muted-foreground mt-1">إنشاء وطباعة فواتير التخليص الجمركي</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Selection Sidebar */}
        <div className="lg:col-span-1 space-y-4">
          <Card className="shadow-sm border-gray-200">
            <CardHeader className="p-4 pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <Search className="h-4 w-4 text-primary" /> اختيار البيان
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4 space-y-4">
              <div className="space-y-2">
                <Label className="font-bold text-xs uppercase text-muted-foreground">البيان الجمركي المعتمد</Label>
                <Select value={selectedDeclId?.toString() || ""} onValueChange={v => setSelectedDeclId(v ? Number(v) : null)}>
                  <SelectTrigger className="w-full h-12">
                    <SelectValue placeholder="اختر البيان..." />
                  </SelectTrigger>
                  <SelectContent>
                    {isDeclsLoading ? (
                      <div className="p-2 text-center text-xs">جاري التحميل...</div>
                    ) : declarations?.length === 0 ? (
                      <div className="p-2 text-center text-xs">لا توجد بيانات معتمدة</div>
                    ) : declarations?.map(d => (
                      <SelectItem key={d.id} value={d.id.toString()}>
                        <div className="flex flex-col items-start">
                          <span className="font-bold text-xs">{d.declarationNumber}</span>
                          <span className="text-[10px] text-muted-foreground">{getClientName(d.clientId)}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedDecl && (
                <div className="space-y-2">
                  <Label className="font-bold text-xs uppercase text-muted-foreground">رقم الفاتورة (اختياري)</Label>
                  <Input 
                    value={invoiceNumber} 
                    onChange={e => setInvoiceNumber(e.target.value)} 
                    placeholder={invNum} 
                    className="h-12 font-mono text-sm" 
                  />
                </div>
              )}

              <div className="flex flex-col gap-2 pt-2">
                <Button 
                  onClick={handleGenerateInvoice} 
                  disabled={!selectedDecl || !selectedCost}
                  className="w-full h-12 font-bold gap-2"
                >
                  <Printer className="h-5 w-5" /> طباعة الفاتورة
                </Button>
                <Button 
                  variant="outline"
                  onClick={handleDownloadPDF} 
                  disabled={!selectedDecl || !selectedCost || isExporting}
                  className="w-full h-12 font-bold gap-2"
                >
                  {isExporting ? <Loader2 className="h-5 w-5 animate-spin" /> : <FileDown className="h-5 w-5" />}
                  تحميل PDF
                </Button>
              </div>
            </CardContent>
          </Card>
          
          {selectedDecl && selectedCost && (
            <Card className="shadow-sm border-gray-200 bg-blue-50/50">
              <CardContent className="p-4 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-xs text-muted-foreground">إجمالي التكاليف:</span>
                  <span className="font-bold">{totalCost.toLocaleString()} ر.ي</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-muted-foreground">الخصم:</span>
                  <span className="font-bold text-red-600">{discount.toLocaleString()} ر.ي</span>
                </div>
                <div className="pt-2 border-t border-blue-200 flex justify-between items-center">
                  <span className="font-bold text-sm">الصافي:</span>
                  <span className="font-black text-lg text-blue-700">{netCost.toLocaleString()} ر.ي</span>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Invoice Preview */}
        <div className="lg:col-span-3">
          {selectedDecl && selectedCost ? (
            <div className="overflow-x-auto bg-gray-200/50 p-4 md:p-8 rounded-xl border border-gray-200 shadow-inner min-h-[600px] flex items-start justify-center">
              <div 
                id={`invoice-print-${selectedDeclId}`} 
                className="bg-white shadow-2xl p-6 md:p-12 w-full max-w-[850px] min-w-[700px] md:min-w-0"
                style={{ direction: 'rtl', fontFamily: "'Tajawal', Arial, sans-serif" }}
              >
                {/* Header */}
                <div className="flex justify-between items-start mb-6 pb-4 border-b-2 border-gray-800">
                  <div className="text-right flex-1">
                    <p className="font-bold text-base text-gray-900">فيدل القاضي للتخليص الجمركي</p>
                    <p className="text-[11px] text-gray-600 font-bold">- مكتب صنعاء الرئيسي -</p>
                    <p className="text-[11px] text-gray-600">الجمهورية اليمنية</p>
                  </div>
                  <div className="text-center flex-1">
                    <img src="/manus-storage/faidal-logo_11e2a37b.png" alt="Logo" className="h-24 mx-auto mb-1 object-contain" />
                    <p className="text-[10px] text-gray-500 font-bold uppercase tracking-tighter">FAIDAL AL-QADHI LOGISTICS SERVICES</p>
                  </div>
                  <div className="text-left flex-1">
                    <p className="font-bold text-base text-gray-900">FAIDAL AL-QADHI OFFICE</p>
                    <p className="text-[11px] text-gray-600 font-bold">- SANA'A MAIN OFFICE -</p>
                    <p className="text-[11px] text-gray-600">REPUBLIC OF YEMEN</p>
                  </div>
                </div>

                {/* Title */}
                <div className="text-center mb-6">
                  <h1 className="text-2xl font-black underline decoration-2 underline-offset-8 text-gray-900">فاتورة خدمة التخليص الجمركي</h1>
                </div>

                {/* Details row */}
                <div className="border-2 border-gray-800 mb-6 flex overflow-hidden rounded-lg">
                  <div className="bg-gray-100 border-l-2 border-gray-800 px-4 py-3 text-sm font-black w-36 text-center text-gray-800 uppercase">البيان المالي</div>
                  <div className="flex-1 text-center py-3 text-sm font-bold text-gray-900">
                    أتعاب وتكاليف تخليص البيان الجمركي رقم ({selectedDecl.declarationNumber})
                  </div>
                </div>

                {/* Operation info table */}
                <div className="border-2 border-gray-800 mb-6 rounded-lg overflow-hidden">
                  <div className="flex bg-[#2c3e50] text-white text-xs font-black uppercase tracking-wider">
                    <div className="flex-1 text-center py-2 border-l-2 border-gray-700">رقم الفاتورة</div>
                    <div className="flex-1 text-center py-2 border-l-2 border-gray-700">تاريخ الإصدار</div>
                    <div className="flex-1 text-center py-2">طريقة السداد</div>
                  </div>
                  <div className="flex text-sm font-bold bg-white">
                    <div className="flex-1 text-center py-2.5 border-l-2 border-gray-200 font-mono text-blue-700">{invNum}</div>
                    <div className="flex-1 text-center py-2.5 border-l-2 border-gray-200">{invoiceDate}</div>
                    <div className="flex-1 text-center py-2.5 text-gray-700">حساب آجل</div>
                  </div>
                </div>

                {/* Customer info grid */}
                <div className="grid grid-cols-2 gap-y-4 gap-x-8 mb-6 p-4 bg-gray-50 rounded-xl border border-gray-200 text-sm font-bold">
                  <div className="flex justify-between border-b border-gray-200 pb-1">
                    <span className="text-gray-500 font-medium">اسم العميل:</span>
                    <span className="text-gray-900">{getClientName(selectedDecl.clientId)}</span>
                  </div>
                  <div className="flex justify-between border-b border-gray-200 pb-1">
                    <span className="text-gray-500 font-medium">نوع البضاعة:</span>
                    <span className="text-gray-900">{selectedDecl.goodsType || "-"}</span>
                  </div>
                  <div className="flex justify-between border-b border-gray-200 pb-1">
                    <span className="text-gray-500 font-medium">المنفذ الجمركي:</span>
                    <span className="text-gray-900">{selectedDecl.customsPort || "-"}</span>
                  </div>
                  <div className="flex justify-between border-b border-gray-200 pb-1">
                    <span className="text-gray-500 font-medium">رقم البيان:</span>
                    <span className="text-gray-900 font-mono">{selectedDecl.declarationNumber || "-"}</span>
                  </div>
                  <div className="flex justify-between border-b border-gray-200 pb-1">
                    <span className="text-gray-500 font-medium">تاريخ البيان:</span>
                    <span className="text-gray-900">{selectedDecl.declarationDate || "-"}</span>
                  </div>
                  <div className="flex justify-between border-b border-gray-200 pb-1">
                    <span className="text-gray-500 font-medium">رقم اللوحة/الحاوية:</span>
                    <span className="text-gray-900 font-mono">{selectedDecl.plateNumber || "-"}</span>
                  </div>
                </div>

                {/* Services table */}
                <div className="border-2 border-gray-800 mb-6 rounded-lg overflow-hidden">
                  <div className="flex bg-[#2c3e50] text-white text-xs font-black uppercase tracking-wider">
                    <div className="flex-[2.5] text-center py-2 border-l-2 border-gray-700">تفاصيل الخدمة</div>
                    <div className="flex-1 text-center py-2 border-l-2 border-gray-700">الكمية</div>
                    <div className="flex-1 text-center py-2 border-l-2 border-gray-700">السعر</div>
                    <div className="flex-1 text-center py-2">الإجمالي</div>
                  </div>
                  {finalItems.map((item, i) => (
                    <div key={i} className={`flex text-xs font-bold ${i % 2 === 0 ? 'bg-white' : 'bg-gray-50'} border-b border-gray-200`}>
                      <div className="flex-[2.5] text-right px-4 py-2.5 border-l-2 border-gray-200">{item.detail}</div>
                      <div className="flex-1 text-center py-2.5 border-l-2 border-gray-200 font-mono">{item.count}</div>
                      <div className="flex-1 text-center py-2.5 border-l-2 border-gray-200 font-mono">{item.cost.toLocaleString()}</div>
                      <div className="flex-1 text-center py-2.5 font-mono text-gray-900">{item.cost.toLocaleString()}</div>
                    </div>
                  ))}
                  {/* Summary Rows */}
                  <div className="flex bg-gray-100 border-t-2 border-gray-800 text-xs font-black">
                    <div className="flex-[4.5] text-left px-4 py-2 border-l-2 border-gray-200">إجمالي التكاليف</div>
                    <div className="flex-1 text-center py-2 font-mono">{totalCost.toLocaleString()}</div>
                  </div>
                  {discount > 0 && (
                    <div className="flex bg-white border-t border-gray-200 text-xs font-black text-red-600">
                      <div className="flex-[4.5] text-left px-4 py-2 border-l-2 border-gray-200">الخصم الممنوح</div>
                      <div className="flex-1 text-center py-2 font-mono">-{discount.toLocaleString()}</div>
                    </div>
                  )}
                  <div className="flex bg-[#2c3e50] text-white text-sm font-black">
                    <div className="flex-[4.5] text-left px-4 py-3 border-l-2 border-gray-700">الصافي المطلوب سداده</div>
                    <div className="flex-1 text-center py-3 font-mono text-lg">{netCost.toLocaleString()} ر.ي</div>
                  </div>
                </div>

                {/* Amount in words */}
                <div className="px-5 py-4 mb-8 bg-gray-50 border-2 border-gray-800 rounded-xl text-sm font-bold text-gray-900">
                  <span className="text-gray-500 font-medium">المبلغ كتابةً: </span>
                  <span>{numberToArabicWords(netCost)} ريال يمني فقط لا غير.</span>
                </div>

                {/* Signatures */}
                <div className="flex justify-between items-end mt-16 px-4">
                  <div className="text-center">
                    <p className="font-black text-sm text-gray-900 mb-12 underline underline-offset-4">توقيع المحاسب</p>
                    <div className="w-48 border-b-2 border-dotted border-gray-400"></div>
                  </div>
                  <div className="text-center">
                    <img src="/manus-storage/faidal-logo_11e2a37b.png" alt="Stamp" className="h-20 opacity-10 grayscale mb-2" />
                    <p className="text-[10px] text-gray-400 font-bold italic">الختم الرسمي للمكتب</p>
                  </div>
                  <div className="text-center">
                    <p className="font-black text-sm text-gray-900 mb-12 underline underline-offset-4">توقيع العميل / المستلم</p>
                    <div className="w-48 border-b-2 border-dotted border-gray-400"></div>
                  </div>
                </div>

                {/* Footer */}
                <div className="mt-16 pt-4 border-t border-gray-200 text-center text-[10px] text-gray-400 font-bold">
                  صنعاء - شارع الستين - جوار جسر السنينة | هاتف: 777777777 - 733333333 | البريد الإلكتروني: info@faidal.com
                </div>
              </div>
            </div>
          ) : (
            <Card className="shadow-sm border-dashed border-2 border-gray-200 bg-white/50 h-full flex flex-col items-center justify-center py-32">
              <div className="h-20 w-20 rounded-full bg-gray-100 flex items-center justify-center mb-4">
                <FileText className="h-10 w-10 text-gray-300" />
              </div>
              <p className="text-lg font-bold text-gray-400">يرجى اختيار بيان جمركي لعرض الفاتورة</p>
              <p className="text-sm text-gray-400 mt-1">يجب أن يكون البيان معتمداً وله تكاليف مسجلة</p>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
