import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import {
  Users, Truck, FileText, Package, Warehouse, Wrench,
  Briefcase, UserCheck, Banknote, ClipboardList,
  Scale, CalendarDays, ShieldCheck, Building2,
  Landmark, ScrollText, HandCoins, Calculator
} from "lucide-react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";

interface NavCard {
  title: string;
  desc: string;
  icon: typeof Users;
  path: string;
  color: string;
  bg: string;
  module?: string;
}

export default function Home() {
  const [, setLocation] = useLocation();
  const { data: stats, isLoading } = trpc.dashboard.stats.useQuery();
  const { user } = useAuth();
  const { data: permissions } = trpc.moduleAccess.myPermissions.useQuery(undefined, {
    enabled: !!user,
  });

  const hasAccess = (moduleId?: string) => {
    if (!moduleId) return true;
    if (!permissions) return true;
    const p = permissions?.modules?.find((p: { moduleId: string; canView: boolean }) => p.moduleId === moduleId);
    return !p || p.canView;
  };

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {Array.from({ length: 12 }).map((_, i) => (
          <Card key={i} className="animate-pulse border-0 shadow-sm">
            <CardContent className="p-6">
              <div className="h-10 w-10 bg-muted rounded-lg mb-3" />
              <div className="h-4 bg-muted rounded w-24 mb-2" />
              <div className="h-3 bg-muted rounded w-32" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const cards: NavCard[] = [
    {
      title: "التخليص الجمركي",
      desc: "البيانات الجمركية والبيانات والتكاليف",
      icon: Warehouse,
      path: "/customs-declarations",
      color: "text-blue-600",
      bg: "bg-blue-50",
    },
    {
      title: "أوامر العمل",
      desc: "إدارة أوامر العمل والمهام",
      icon: ClipboardList,
      path: "/job-orders",
      color: "text-indigo-600",
      bg: "bg-indigo-50",
    },
    {
      title: "العملاء",
      desc: "إدارة العملاء والشحنات",
      icon: Users,
      path: "/clients",
      color: "text-emerald-600",
      bg: "bg-emerald-50",
    },
    {
      title: "الموردين",
      desc: "إدارة بيانات الموردين",
      icon: Building2,
      path: "/suppliers",
      color: "text-teal-600",
      bg: "bg-teal-50",
      module: "suppliers",
    },
    {
      title: "النقل الداخلي",
      desc: "أوامر الحركة وإثبات التسليم",
      icon: Truck,
      path: "/internal-transport",
      color: "text-orange-600",
      bg: "bg-orange-50",
    },
    {
      title: "الموظفين",
      desc: "إدارة بيانات الموظفين",
      icon: UserCheck,
      path: "/employees",
      color: "text-purple-600",
      bg: "bg-purple-50",
      module: "employees",
    },
    {
      title: "العهد والسلف",
      desc: "السلف والعهد والمصروفات المقدمة",
      icon: HandCoins,
      path: "/petty-cash",
      color: "text-pink-600",
      bg: "bg-pink-50",
      module: "petty-cash",
    },
    {
      title: "الأصول الثابتة",
      desc: "إدارة الأصول والإهلاك",
      icon: Scale,
      path: "/fixed-assets",
      color: "text-cyan-600",
      bg: "bg-cyan-50",
    },
    {
      title: "الفواتير",
      desc: "فواتير التخليص والشحن",
      icon: FileText,
      path: "/clearance-invoices",
      color: "text-red-600",
      bg: "bg-red-50",
    },
    {
      title: "المصروفات",
      desc: "المصاريف والنثريات",
      icon: Wrench,
      path: "/clearance-expenses",
      color: "text-amber-600",
      bg: "bg-amber-50",
      module: "clearance-expenses",
    },
    {
      title: "المقبوضات والمدفوعات",
      desc: "سجل المقبوضات والمدفوعات",
      icon: Banknote,
      path: "/clearance-payments",
      color: "text-green-600",
      bg: "bg-green-50",
      module: "clearance-payments",
    },
    {
      title: "الصناديق والبنوك",
      desc: "إدارة الصناديق والبنوك",
      icon: Landmark,
      path: "/cashboxes",
      color: "text-sky-600",
      bg: "bg-sky-50",
      module: "cashboxes",
    },
    {
      title: "السندات",
      desc: "سندات القبض والصرف",
      icon: ScrollText,
      path: "/vouchers",
      color: "text-violet-600",
      bg: "bg-violet-50",
      module: "vouchers",
    },
    {
      title: "الأستاذ العام",
      desc: "دليل الحسابات والقيود",
      icon: Briefcase,
      path: "/general-ledger",
      color: "text-gray-600",
      bg: "bg-gray-50",
      module: "general-ledger",
    },
    {
      title: "إدارة التراخيص",
      desc: "تسجيل التراخيص وتخصيم كمياتها",
      icon: ScrollText,
      path: "/permits",
      color: "text-indigo-600",
      bg: "bg-indigo-50",
      module: "permits",
    },
    {
      title: "تخصيم الكميات",
      desc: "تسجيل المراجع وتخصيم الكميات",
      icon: Calculator,
      path: "/quantity-deductions",
      color: "text-emerald-600",
      bg: "bg-emerald-50",
      module: "quantity-deductions",
    },
    {
      title: "التقارير",
      desc: "تقارير التخليص والتقييمات",
      icon: Package,
      path: "/clearance-reports",
      color: "text-lime-600",
      bg: "bg-lime-50",
    },
    {
      title: "الإعدادات",
      desc: "إعدادات النظام والصلاحيات",
      icon: ShieldCheck,
      path: "/settings",
      color: "text-slate-600",
      bg: "bg-slate-50",
      module: "settings",
    },
  ];

  const visibleCards = cards.filter(c => hasAccess(c.module));

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-2">
        <div>
          <h1 className="text-xl font-bold text-foreground">لوحة التحكم</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Faidal Alqadhi للتخليص الجمركي والخدمات اللوجستية
          </p>
        </div>
        <div className="flex gap-3 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <CalendarDays className="h-3.5 w-3.5" />
            {new Date().toLocaleDateString('ar-SA', { year: 'numeric', month: 'long', day: 'numeric' })}
          </span>
        </div>
      </div>

      {/* Stats Strip */}
      {stats && (
        <div className="flex gap-2 overflow-x-auto pb-1 text-xs">
          <span className="bg-primary/10 text-primary px-3 py-1.5 rounded-lg whitespace-nowrap font-medium">
            العملاء: {stats.totalClients}
          </span>
          <span className="bg-emerald-50 text-emerald-700 px-3 py-1.5 rounded-lg whitespace-nowrap font-medium">
            الشحنات: {stats.totalShipments}
          </span>
          <span className="bg-purple-50 text-purple-700 px-3 py-1.5 rounded-lg whitespace-nowrap font-medium">
            الفواتير: {stats.totalInvoices}
          </span>
          <span className="bg-amber-50 text-amber-700 px-3 py-1.5 rounded-lg whitespace-nowrap font-medium">
            الإيرادات: {(stats.totalRevenue || 0).toLocaleString('en-US')}
          </span>
        </div>
      )}

      {/* Grid Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 pb-24 md:pb-0">
        {visibleCards.map((card) => (
          <Card
            key={card.title}
            className="card-hover cursor-pointer border border-gray-100 md:border-0 shadow-sm hover:shadow-md transition-all active:scale-95 touch-manipulation"
            onClick={() => setLocation(card.path)}
          >
            <CardContent className="p-3 md:p-4 flex flex-col items-center md:items-start text-center md:text-right">
              <div className={`p-3 md:p-2.5 rounded-2xl md:rounded-lg ${card.bg} mb-3 md:mb-2.5 w-fit`}>
                <card.icon className={`h-6 w-6 md:h-5 md:w-5 ${card.color}`} />
              </div>
              <h3 className="font-bold text-sm text-foreground mb-1 md:mb-0.5">{card.title}</h3>
              <p className="text-[10px] md:text-xs text-muted-foreground leading-tight md:leading-relaxed hidden md:block">{card.desc}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
