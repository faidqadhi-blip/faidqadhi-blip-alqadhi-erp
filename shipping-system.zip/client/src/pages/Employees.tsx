import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Plus, Search, X, UserCheck, Pencil, Trash2, Phone, Briefcase, Calendar, DollarSign } from "lucide-react";

export default function Employees() {
  const utils = trpc.useUtils();
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState({
    name: "", phone: "", email: "", jobTitle: "", department: "", salary: "0", joinDate: "", notes: "",
  });

  const { data: employees, isLoading } = trpc.employees.list.useQuery();

  const filtered = useMemo(() => {
    if (!employees) return [];
    if (!search.trim()) return employees;
    const q = search.trim().toLowerCase();
    return employees.filter(e =>
      e.name.toLowerCase().includes(q) ||
      (e.jobTitle?.toLowerCase().includes(q)) ||
      (e.phone?.toLowerCase().includes(q))
    );
  }, [employees, search]);

  const createMutation = trpc.employees.create.useMutation({
    onSuccess: () => {
      toast.success("تمت إضافة الموظف بنجاح");
      utils.employees.list.invalidate();
      setDialogOpen(false);
      resetForm();
    },
    onError: (e) => toast.error(e.message),
  });

  const updateMutation = trpc.employees.update.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث بيانات الموظف");
      utils.employees.list.invalidate();
      setDialogOpen(false);
      resetForm();
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = trpc.employees.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف الموظف");
      utils.employees.list.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  const resetForm = () => {
    setForm({ name: "", phone: "", email: "", jobTitle: "", department: "", salary: "0", joinDate: "", notes: "" });
    setEditingId(null);
  };

  const openEdit = (e: NonNullable<typeof employees>[number]) => {
    setForm({
      name: e.name, phone: e.phone || "", email: e.email || "",
      jobTitle: e.jobTitle || "", department: e.department || "",
      salary: e.salary?.toString() || "0",
      joinDate: e.joinDate ? new Date(e.joinDate).toISOString().split('T')[0] : "",
      notes: e.notes || "",
    });
    setEditingId(e.id);
    setDialogOpen(true);
  };

  const handleSubmit = () => {
    if (!form.name.trim()) { toast.error("اسم الموظف مطلوب"); return; }
    const data = { ...form, salary: parseFloat(form.salary) || 0, joinDate: form.joinDate ? new Date(form.joinDate) : undefined };
    if (editingId) {
      updateMutation.mutate({ id: editingId, ...data });
    } else {
      createMutation.mutate(data);
    }
  };

  return (
    <div className="space-y-4 pb-20 md:pb-6" dir="rtl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 px-1">
        <div>
          <h1 className="text-2xl font-bold text-foreground">إدارة الموظفين</h1>
          <p className="text-sm text-muted-foreground mt-1">إدارة بيانات الموظفين والرواتب والأقسام</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={(o) => { setDialogOpen(o); if (!o) resetForm(); }}>
          <DialogTrigger asChild>
            <Button className="w-full md:w-auto h-12 md:h-10 font-bold text-base">
              <Plus className="h-5 w-5 ml-2" /> إضافة موظف جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg p-0 gap-0 overflow-hidden">
            <DialogHeader className="p-6 pb-2">
              <DialogTitle className="text-xl">{editingId ? "تعديل بيانات الموظف" : "إضافة موظف جديد"}</DialogTitle>
            </DialogHeader>
            <div className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="col-span-1 md:col-span-2 space-y-2">
                  <Label className="font-bold">الاسم الكامل *</Label>
                  <Input 
                    value={form.name} 
                    onChange={e => setForm(f => ({ ...f, name: e.target.value }))} 
                    className="h-12 md:h-10"
                    placeholder="اسم الموظف الثلاثي" 
                  />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">الهاتف</Label>
                  <Input 
                    value={form.phone} 
                    onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} 
                    className="h-12 md:h-10 text-left"
                    placeholder="000-000-000" 
                  />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">المسمى الوظيفي</Label>
                  <Input 
                    value={form.jobTitle} 
                    onChange={e => setForm(f => ({ ...f, jobTitle: e.target.value }))} 
                    className="h-12 md:h-10"
                    placeholder="مثال: سائق، محاسب" 
                  />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">القسم</Label>
                  <Input 
                    value={form.department} 
                    onChange={e => setForm(f => ({ ...f, department: e.target.value }))} 
                    className="h-12 md:h-10"
                    placeholder="القسم التابع له" 
                  />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">الراتب</Label>
                  <Input 
                    type="number" 
                    value={form.salary} 
                    onChange={e => setForm(f => ({ ...f, salary: e.target.value }))} 
                    className="h-12 md:h-10 text-left font-mono"
                    placeholder="0" 
                  />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">تاريخ التعيين</Label>
                  <Input 
                    type="date" 
                    value={form.joinDate} 
                    onChange={e => setForm(f => ({ ...f, joinDate: e.target.value }))} 
                    className="h-12 md:h-10" 
                  />
                </div>
                <div className="col-span-1 md:col-span-2 space-y-2">
                  <Label className="font-bold">البريد الإلكتروني</Label>
                  <Input 
                    value={form.email} 
                    onChange={e => setForm(f => ({ ...f, email: e.target.value }))} 
                    className="h-12 md:h-10 text-left"
                    placeholder="email@example.com" 
                  />
                </div>
                <div className="col-span-1 md:col-span-2 space-y-2">
                  <Label className="font-bold">ملاحظات</Label>
                  <Input value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} className="h-12 md:h-10" placeholder="أي ملاحظات إضافية" />
                </div>
              </div>
              <div className="flex flex-col md:flex-row justify-end gap-3 pt-4 border-t">
                <Button variant="outline" onClick={() => { setDialogOpen(false); resetForm(); }} className="h-12 md:h-10 font-bold">إلغاء</Button>
                <Button onClick={handleSubmit} disabled={createMutation.isPending || updateMutation.isPending} className="h-12 md:h-10 font-bold text-base">
                  {editingId ? "تحديث البيانات" : "إضافة الموظف"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="shadow-sm border-gray-200">
        <CardHeader className="p-4 pb-2">
          <div className="relative">
            <Search className="absolute right-3 top-3 h-5 w-5 text-gray-400" />
            <Input
              placeholder="ابحث بالاسم، الوظيفة، أو الهاتف..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pr-10 h-12 md:h-10 w-full"
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex flex-col items-center py-12 gap-3">
              <div className="h-10 w-10 animate-spin rounded-full border-4 border-primary border-t-transparent" />
              <span className="text-muted-foreground">جاري تحميل الموظفين...</span>
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-12 flex flex-col items-center gap-3">
              <UserCheck className="h-16 w-16 text-gray-200" />
              <p className="text-muted-foreground">{search ? "لا توجد نتائج مطابقة" : "لا يوجد موظفين مسجلين"}</p>
            </div>
          ) : (
            <>
              {/* Desktop Table */}
              <div className="hidden md:block">
                <Table>
                  <TableHeader className="bg-gray-50">
                    <TableRow>
                      <TableHead className="text-right font-bold">الاسم</TableHead>
                      <TableHead className="text-right font-bold">الهاتف</TableHead>
                      <TableHead className="text-right font-bold">المسمى الوظيفي</TableHead>
                      <TableHead className="text-right font-bold">القسم</TableHead>
                      <TableHead className="text-right font-bold">الراتب</TableHead>
                      <TableHead className="text-right font-bold">تاريخ التعيين</TableHead>
                      <TableHead className="text-left font-bold">الإجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filtered.map(e => (
                      <TableRow key={e.id} className="hover:bg-gray-50/50 transition-colors">
                        <TableCell className="font-bold text-primary">{e.name}</TableCell>
                        <TableCell className="text-sm" dir="ltr">{e.phone || "-"}</TableCell>
                        <TableCell className="text-sm">{e.jobTitle || "-"}</TableCell>
                        <TableCell className="text-sm">{e.department || "-"}</TableCell>
                        <TableCell className="text-sm font-mono font-bold" dir="ltr">{parseFloat(e.salary || "0").toLocaleString('en-US')}</TableCell>
                        <TableCell className="text-xs">{e.joinDate ? new Date(e.joinDate).toLocaleDateString('en-GB') : "-"}</TableCell>
                        <TableCell>
                          <div className="flex justify-end gap-1">
                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(e)}>
                              <Pencil className="h-3.5 w-3.5" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500 hover:bg-red-50" onClick={() => {
                              if (confirm(`هل تريد حذف الموظف "${e.name}"؟`)) deleteMutation.mutate({ id: e.id });
                            }}>
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Mobile Card List */}
              <div className="md:hidden space-y-0 divide-y">
                {filtered.map(e => (
                  <div key={e.id} className="p-4 active:bg-gray-50 transition-colors">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex flex-col">
                        <h3 className="font-bold text-lg text-primary">{e.name}</h3>
                        <div className="flex items-center gap-1 text-[10px] font-bold text-muted-foreground uppercase">
                          <Briefcase className="h-3 w-3" />
                          <span>{e.jobTitle || "بدون مسمى"}</span>
                          {e.department && <span> • {e.department}</span>}
                        </div>
                      </div>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" className="h-9 w-9 text-blue-600" onClick={() => openEdit(e)}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-9 w-9 text-red-500" onClick={() => {
                          if (confirm(`هل تريد حذف الموظف "${e.name}"؟`)) deleteMutation.mutate({ id: e.id });
                        }}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3 mt-3">
                      {e.phone && (
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Phone className="h-3.5 w-3.5 text-gray-400" />
                          <span dir="ltr">{e.phone}</span>
                        </div>
                      )}
                      <div className="flex items-center gap-2 text-sm text-green-700 font-bold">
                        <DollarSign className="h-3.5 w-3.5 text-green-500" />
                        <span dir="ltr">{parseFloat(e.salary || "0").toLocaleString('en-US')}</span>
                      </div>
                      {e.joinDate && (
                        <div className="flex items-center gap-2 text-sm text-gray-600 col-span-2">
                          <Calendar className="h-3.5 w-3.5 text-gray-400" />
                          <span>تاريخ التعيين: {new Date(e.joinDate).toLocaleDateString('en-GB')}</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
