import * as XLSX from "xlsx";

/**
 * Export filtered data to Excel (.xlsx) file
 * The file will contain both an Arabic sheet and the full data
 */
export function exportToExcel(
  data: Record<string, any>[],
  columns: { key: string; label: string }[],
  filename: string
): void {
  // Create worksheet with Arabic headers
  const arabicData = data.map(row => {
    const obj: Record<string, string> = {};
    columns.forEach(col => {
      const val = row[col.key];
      obj[col.label] = val !== null && val !== undefined ? String(val) : "-";
    });
    return obj;
  });

  const ws = XLSX.utils.json_to_sheet(arabicData);

  // Set column widths based on header length
  const colWidths = columns.map(col => ({
    wch: Math.max(col.label.length, 12)
  }));
  ws["!cols"] = colWidths;

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "البيانات");

  // Export
  XLSX.writeFile(wb, `${filename}.xlsx`);
}

/**
 * Export multiple datasets into a single Excel file with multiple sheets (tabs)
 * Each entry in sheets defines a tab name and its data/columns
 */
export function exportMultiSheetExcel(
  sheets: {
    sheetName: string;
    data: Record<string, any>[];
    columns: { key: string; label: string }[];
  }[],
  filename: string
): void {
  const wb = XLSX.utils.book_new();

  sheets.forEach(({ sheetName, data, columns }) => {
    if (!data || data.length === 0) return; // Skip empty sheets

    const arabicData = data.map(row => {
      const obj: Record<string, string> = {};
      columns.forEach(col => {
        const val = row[col.key];
        obj[col.label] = val !== null && val !== undefined ? String(val) : "-";
      });
      return obj;
    });

    const ws = XLSX.utils.json_to_sheet(arabicData);
    const colWidths = columns.map(col => ({ wch: Math.max(col.label.length, 12) }));
    ws["!cols"] = colWidths;

    // XLSX sheet names max 31 chars, sanitize special chars
    const safeName = sheetName.replace(/[:\\/?*\[\]]/g, "").slice(0, 31);
    XLSX.utils.book_append_sheet(wb, ws, safeName);
  });

  if (wb.SheetNames.length === 0) return;
  XLSX.writeFile(wb, `${filename}.xlsx`);
}

/**
 * Export filtered data to CSV file with BOM for Arabic support
 */
export function exportToCSV(
  data: Record<string, any>[],
  columns: { key: string; label: string }[],
  filename: string
): void {
  const header = columns.map(col => col.label).join(",");
  const rows = data.map(row => {
    return columns.map(col => {
      const val = row[col.key];
      const str = val !== null && val !== undefined ? String(val).replace(/"/g, '""') : "-";
      return `"${str}"`;
    }).join(",");
  });

  const csvContent = "\uFEFF" + [header, ...rows].join("\n");
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `${filename}.csv`;
  link.click();
  URL.revokeObjectURL(url);
}
