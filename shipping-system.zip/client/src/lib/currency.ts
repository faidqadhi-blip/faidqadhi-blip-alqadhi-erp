/**
 * Get the default currency code from settings data
 * Falls back to "YER" if not found
 */
export function getDefaultCurrency(settingsData: { key: string; value: string | null }[] | undefined): string {
  const found = settingsData?.find(s => s.key === "defaultCurrency");
  return found?.value || "YER";
}

/**
 * Get the default currency name from currencies list and settings
 */
export function getDefaultCurrencyName(
  settingsData: { key: string; value: string | null }[] | undefined,
  currencies: { code: string; name: string; symbol: string }[] | undefined
): string {
  const code = getDefaultCurrency(settingsData);
  const found = currencies?.find(c => c.code === code);
  return found?.name || code;
}
