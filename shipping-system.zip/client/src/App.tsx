import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import DashboardLayout from "./components/DashboardLayout";
import Home from "./pages/Home";
import Clients from "./pages/Clients";
import Shipments from "./pages/Shipments";
import Transfers from "./pages/Transfers";
import SalesReport from "./pages/SalesReport";
import ClientStatement from "./pages/ClientStatement";
import Payments from "./pages/Payments";
import Revenue from "./pages/Revenue";
import Settings from "./pages/Settings";
import ServiceInvoices from "./pages/ServiceInvoices";
import Vouchers from "./pages/Vouchers";
import JournalEntries from "./pages/JournalEntries";
import GeneralLedger from "./pages/GeneralLedger";
import DailyMovementsPage from "./pages/DailyMovements";
import CustomsDeclarations from "./pages/CustomsDeclarations";
import CustomsEntries from "./pages/CustomsEntries";
import Permits from "./pages/Permits";
import QuantityDeductions from "./pages/QuantityDeductions";
import ClearanceCosts from "./pages/ClearanceCosts";
import ClearanceInvoices from "./pages/ClearanceInvoices";
import ClearancePayments from "./pages/ClearancePayments";
import ClearanceExpenses from "./pages/ClearanceExpenses";
import ClearanceReports from "./pages/ClearanceReports";
import JobOrders from "./pages/JobOrders";
import InternalTransport from "./pages/InternalTransport";
import FixedAssets from "./pages/FixedAssets";
import Evaluations from "./pages/Evaluations";
import Suppliers from "./pages/Suppliers";
import Employees from "./pages/Employees";
import PettyCash from "./pages/PettyCash";
import CashboxesPage from "./pages/CashboxesPage";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { FINANCIAL_MODULE_IDS } from "./pages/Settings";
import { ShieldX, ArrowRight } from "lucide-react";

// Module Guard: blocks access to financial pages for unauthorized users
function ModuleGuard({ moduleId, children }: { moduleId: string; children: React.ReactNode }) {
  const { user } = useAuth();
  const { data: perms, isLoading } = trpc.moduleAccess.myPermissions.useQuery();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  // Admin always has access
  if (perms?.isAdmin) return <>{children}</>;

  // Check if this module is in the financial list and user doesn't have permission
  const isFinancial = FINANCIAL_MODULE_IDS.includes(moduleId as any);
  if (isFinancial) {
    const hasAccess = perms?.modules?.find(p => p.moduleId === moduleId)?.canView ?? false;
    if (!hasAccess) {
      return (
        <div className="flex flex-col items-center justify-center h-64 gap-4">
          <ShieldX className="h-12 w-12 text-red-400" />
          <p className="text-lg font-medium text-muted-foreground">لا تملك صلاحية للوصول لهذه الصفحة</p>
          <p className="text-sm text-muted-foreground">يرجى مراجعة المدير للحصول على الصلاحية</p>
          <a
            href="/"
            className="flex items-center gap-2 text-sm text-primary hover:underline mt-2"
          >
            <ArrowRight className="h-4 w-4" />
            العودة للصفحة الرئيسية
          </a>
        </div>
      );
    }
  }

  return <>{children}</>;
}

function Router() {
  return (
    <DashboardLayout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/clients" component={Clients} />
        <Route path="/shipments" component={Shipments} />
        <Route path="/transfers" component={Transfers} />
        <Route path="/sales-report"><ModuleGuard moduleId="sales-report"><SalesReport /></ModuleGuard></Route>
        <Route path="/client-statement"><ModuleGuard moduleId="client-statement"><ClientStatement /></ModuleGuard></Route>
        <Route path="/payments"><ModuleGuard moduleId="payments"><Payments /></ModuleGuard></Route>
        <Route path="/revenue"><ModuleGuard moduleId="revenue"><Revenue /></ModuleGuard></Route>
        <Route path="/settings" component={Settings} />
        <Route path="/service-invoices"><ModuleGuard moduleId="service-invoices"><ServiceInvoices /></ModuleGuard></Route>
        <Route path="/vouchers"><ModuleGuard moduleId="vouchers"><Vouchers /></ModuleGuard></Route>
        <Route path="/journal-entries"><ModuleGuard moduleId="journal-entries"><JournalEntries /></ModuleGuard></Route>
        <Route path="/general-ledger"><ModuleGuard moduleId="general-ledger"><GeneralLedger /></ModuleGuard></Route>
        <Route path="/daily-movements"><ModuleGuard moduleId="daily-movements"><DailyMovementsPage /></ModuleGuard></Route>
        <Route path="/customs-entries" component={CustomsEntries} />
        <Route path="/permits" component={Permits} />
        <Route path="/quantity-deductions" component={QuantityDeductions} />
        <Route path="/customs-declarations" component={CustomsDeclarations} />
        <Route path="/clearance-costs"><ModuleGuard moduleId="clearance-costs"><ClearanceCosts /></ModuleGuard></Route>
        <Route path="/clearance-invoices" component={ClearanceInvoices} />
        <Route path="/clearance-payments"><ModuleGuard moduleId="clearance-payments"><ClearancePayments /></ModuleGuard></Route>
        <Route path="/clearance-expenses"><ModuleGuard moduleId="clearance-expenses"><ClearanceExpenses /></ModuleGuard></Route>
        <Route path="/clearance-reports"><ModuleGuard moduleId="clearance-reports"><ClearanceReports /></ModuleGuard></Route>
        <Route path="/job-orders" component={JobOrders} />
        <Route path="/internal-transport" component={InternalTransport} />
        <Route path="/fixed-assets" component={FixedAssets} />
        <Route path="/evaluations" component={Evaluations} />
        <Route path="/suppliers" component={Suppliers} />
        <Route path="/employees" component={Employees} />
        <Route path="/petty-cash" component={PettyCash} />
        <Route path="/cashboxes" component={CashboxesPage} />
        <Route path="/404" component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </DashboardLayout>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
