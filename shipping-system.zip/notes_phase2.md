# Phase 2 - Development Notes

## New Tables Created (DB)
- jobOrders: id, jobNumber (JO-0001), clientId, shipmentId, declarationId, jobType (تخليص_جمركي/شحن_داخلي/تعبئة_وتغليف/استشارة), status (استشارة/عرض_سعر/مفتوح/قيد_التخليص/مفروج/قيد_التسليم/مكتمل/ملغي), priority (عادي/عاجل/أولوية), notes, createdBy, completedAt
- internalTransportOrders: id, jobOrderId, declarationId, vehiclePlate, driverName, driverPhone, destination, departureTime, arrivalTime, podImage, podNotes, receiverName, receiverSignature, status (قيد_الانتظار/تم_الانطلاق/وصل/تم_التسليم/ملغي)
- fixedAssets: id, assetType (شاحنة/مقطورة/معدات/أجهزة/مبنى/أخرى), name, plateNumber, purchaseDate, purchaseValue, usefulLifeYears, monthlyDepreciation, accumulatedDepreciation, bookValue, status (نشط/صيانة/خارج_الخدمة/مباع), notes
- evaluations: id, jobOrderId, declarationId, clientId, rating, clearanceSpeed, cargoSafety, driverHandling, feedback

## New Columns Added
- clearanceCosts: inspectionFee, penalties, weightDifferences, otherGovtFees
- customsDeclarations: releaseDate, releasedBy, releaseNotes, jobOrderId, hsCode

## New DB Helpers (server/db.ts)
- listJobOrders, getJobOrderById, nextJobOrderNumber, createJobOrder, updateJobOrder, deleteJobOrder
- listInternalTransportOrders, createInternalTransportOrder, updateInternalTransportOrder, deleteInternalTransportOrder
- listFixedAssets, createFixedAsset, updateFixedAsset, deleteFixedAsset, runDepreciation
- listEvaluations, createEvaluation

## New tRPC Routers (server/routers.ts)
- jobOrders (list, create, update, delete)
- internalTransport (list, create, update, delete)
- fixedAssets (list, create, update, delete, depreciate)
- evaluations (list, create)

## Pages Created ✅
1. client/src/pages/JobOrders.tsx - ✅ Created
2. client/src/pages/InternalTransport.tsx - ✅ Created
3. client/src/pages/FixedAssets.tsx - ✅ Created
4. client/src/pages/Evaluations.tsx - ✅ Created

## Still Need To Do:
- Add routes in App.tsx
- Add sidebar items in DashboardLayout.tsx
- Update todo.md
- Save checkpoint

## Routes To Add (App.tsx)
- /job-orders → JobOrders
- /internal-transport → InternalTransport
- /fixed-assets → FixedAssets
- /evaluations → Evaluations

## Sidebar Items To Add (DashboardLayout.tsx)
In mainNav or a new section:
- { icon: ClipboardList, label: "أوامر العمل", path: "/job-orders" }
- { icon: Truck, label: "أمر الحركة", path: "/internal-transport" }
- { icon: Building2, label: "الأصول", path: "/fixed-assets" }
- { icon: Star, label: "التقييمات", path: "/evaluations" }

## Existing Page Patterns
- Pages use trpc hooks: trpc.xxx.useQuery/useMutation
- RTL Arabic UI with Tajawal font
- shadcn/ui components
- Currency: getDefaultCurrency() from client/src/lib/currency.ts
- Numbers: toLocaleString('en-US')
