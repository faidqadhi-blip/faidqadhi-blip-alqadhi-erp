# Project TODO

- [x] Database schema: users, clients, shipments, invoices, transfers, payments, settings
- [x] Backend procedures: CRUD for all entities
- [x] Dashboard layout with sidebar navigation (Arabic RTL)
- [x] Main dashboard page with statistics and charts
- [x] Clients management page (add/edit/view/delete)
- [x] Shipments registration page
- [x] Invoice creation and PDF export
- [x] Transfer system with operation log
- [x] Monthly sales report with filtering
- [x] Clients report with account statements
- [x] Shipments report with filtering
- [x] Payments report with balances
- [x] Revenue report with profit analysis
- [x] Settings page
- [x] Print functionality
- [x] RTL Arabic styling with professional design
- [x] Tests for backend procedures
- [x] Real PDF export for invoices (using jspdf + html2canvas)
- [x] Print support for reports
- [x] Better vitest tests with actual behavior
- [x] Fix transferLogs duplicate export in drizzle/schema.ts
- [x] ServiceInvoices page (الفواتير الخدمية)
- [x] Vouchers page (السندات)
- [x] JournalEntries page (القيود المحاسبية)
- [x] GeneralLedger page (الأستاذ العام)
- [x] DailyMovements page (الحركة اليومية)
- [x] Navigation links in DashboardLayout for all accounting pages
- [x] Update Settings page with currencies, languages, fonts, backups sections
- [x] All Vitest tests passing (21/21)
- [x] Fix currency addition in Settings (currencies tab)
- [x] Fix invoice forms (Invoices page) - added currency field from currencies table
- [x] Fix voucher forms (Vouchers page) - use currencies from database
- [x] Fix service invoice forms - use currencies from database
- [x] General UI enhancements
- [x] Update invoice display/print/PDF/export/list views to use each invoice's selected currency instead of hardcoded ر.س
- [x] Add better empty/loading/error states and form helper text to invoice/voucher/service-invoice forms
- [x] Customs Declaration schema: entryNumber, declarationNumber, date, clientName, goodsType, customsPort, plateNumber, driverName, declarationFee
- [x] Customs Declaration API (CRUD)
- [x] Clearance Costs schema: declarationId link, cost items (رسوم تخليص، نقل، تحميل، تفريغ، نثريات، أتعاب، رسوم أخرى)
- [x] Clearance Costs API (CRUD + calculate totals)
- [x] Receipts/Payments schema: declarationId, type (مقبوض/مدفوع), amount, method, date, notes
- [x] Receipts/Payments API (CRUD)
- [x] Expenses/Miscellaneous schema: declarationId, type, amount, description, date
- [x] Expenses/Miscellaneous API (CRUD)
- [x] Frontend: إنشاء بيان جمركي page
- [x] Frontend: تكاليف التخليص page (auto-fetch declaration data)
- [x] Frontend: المقبوضات والمدفوعات page
- [x] Frontend: المصاريف والنثريات page
- [x] Frontend: التقارير (5 reports)
- [x] Update navigation to replace "الفواتير" with "التخليص الجمركي"
- [x] Remove old Invoices page from routing
- [x] Link clearance payments to vouchers: auto-create receipt voucher when payment is created
- [x] Auto-create payment voucher when expense/misc is recorded

## Backend Restructure (Approved Schema)
- [x] Modify customsDeclarations: add shipmentId FK, remove clientName, update status enum
- [x] Restructure clearanceCosts: individual cost columns + totalCost + discount + netCost + isApproved
- [x] Split clearancePayments into clearanceReceipts and clearanceDisbursements
- [x] Add sourceDeclarationId to vouchers table
- [x] Update db.ts with new data functions
- [x] Update routers.ts with new API endpoints
- [x] Apply SQL migrations to database
- [x] Confirmed DB schema design with user and implemented all:
  - Added shipmentId to customsDeclarations (FK → shipments)
  - Added sourceDeclarationId to vouchers (FK → customsDeclarations)
  - Renamed clearancePayments to clearanceReceipts (مقبوضات فقط)
  - Renamed clearanceExpenses to clearanceDisbursements (مدفوعات فقط)
  - Restructured clearanceCosts fields (declarationFee, transport, fuel, driverCost, maintenance, otherExpenses, pettyCash, totalCost, discount, netCost, isApproved)
  - Added voucherId FK to receipts/disbursements
  - Updated db.ts and routers.ts accordingly
  - Updated all frontend pages accordingly
  - Add shipmentId to customs_declarations (FK → shipments)
  - Add sourceDeclarationId to vouchers (FK → customs_declarations)
  - Rename clearancePayments to clearance_receipts (مقبوضات فقط)
  - Rename clearanceExpenses to clearance_disbursements (مدفوعات فقط)
  - Restructure clearance_costs fields (transport, fuel, driverCost, maintenance, otherExpenses, pettyCash, totalCost, isApproved)
  - Add voucherId FK to receipts/disbursements
  - Update db.ts and routers.ts accordingly

## UI Vision (User's Detailed Design)
- [x] Sidebar: organize under "قسم التخليص الجمركي" section header with: البيانات الجمركية، تكاليف التخليص، الفواتير والتكاليف، المقبوضات، المدفوعات، السندات، التقارير
- [x] Declaration form: entryNumber, declarationNumber, date, clientId dropdown, goodsType, customsPort dropdown, plateNumber, driverName dropdown, declarationFee (ريال), notes
- [x] Declaration list: رقم البيان، العميل، البضاعة، المنفذ، التاريخ، الحالة
- [x] Costs page: select declaration → show declaration data card (readonly) + cost items + total + discount + net + approve button
- [x] Invoice generation after approval: A4 print/PDF with company name, invoice number (INV-000XXX), declaration info, items table, totals, amount in Arabic words, accountant/receiver signatures
- [x] Receipts page: table with voucher number, declaration, client, date, amount, method + daily total
- [x] Disbursements page: table with voucher, declaration, entity, expense type, amount
- [x] Reports: cards layout + financial report (period filter, revenue, costs, expenses, net) + print/PDF buttons

## Currencies & Numbers
- [x] Set default currencies: YER (ريال يمني), SAR (ريال سعودي), USD (دولار)
- [x] Change all number display to English numerals (123) instead of Arabic-Indic - replaced toLocaleString('ar-SA') with toLocaleString('en-US') across all pages

## Current Session Fixes
- [x] Fix duplicate transferLogs export in drizzle/schema.ts
- [x] Fix all imports: clearanceExpenses → clearanceDisbursements in server/db.ts and server/routers.ts
- [x] Fix TypeScript error in Settings.tsx (setNewCurrency reset - use symbol + exchangeRate)
- [x] Fix currency dropdown in ClearancePayments to use currencies from database (name display)
- [x] Fix currency display in receipts/disbursements tables to show names
- [x] Change default currency from SAR to YER in ClearancePayments forms
- [x] Update Vouchers.tsx currency dropdown to use currencies from database (YER default, name display)
- [x] Update ServiceInvoices.tsx currency dropdown to use currencies from database (YER default, name display)
- [x] Update Invoices.tsx currency dropdown to use currencies from database (YER default, name display)
- [x] Save checkpoint

## Default Currency from Settings
- [x] Add defaultCurrency setting key to system settings
- [x] Add defaultCurrency selector in Settings page (dropdown with currencies from DB)
- [x] Create shared utility to get default currency from settings (client/src/lib/currency.ts)
- [x] Update Vouchers.tsx to use dynamic default currency
- [x] Update ServiceInvoices.tsx to use dynamic default currency
- [x] Update Invoices.tsx to use dynamic default currency
- [x] Update ClearancePayments.tsx to use dynamic default currency
- [x] Update CustomsDeclarations.tsx and DailyMovements.tsx to use dynamic default currency
- [x] Save checkpoint

## Edit Currency in Settings
- [x] Check if currencies.update router exists in server/routers.ts (exists)
- [x] Add updateCurrency to db.ts if not exists (exists)
- [x] Add edit button to currencies table in Settings.tsx
- [x] Add edit dialog/form to update name and exchangeRate
- [x] Save checkpoint

## Invoice/Voucher PDF Design Matching Reference Image
- [x] Read ClearanceInvoices.tsx current PDF generation code
- [x] Update invoice PDF to match reference: header with logo, title, details table, customer info grid, services table, totals section, signatures
- [x] Update voucher PDF to match similar layout
- [x] Save checkpoint

## RTL Sidebar Fix
- [x] Fix content overlapping sidebar in RTL: rebuilt DashboardLayout with simple flex layout, sidebar fixed on right, content takes remaining space

## Phase 1: Job Order (أمر العمل)
- [x] Create jobOrders table in drizzle/schema.ts (jobNumber, clientId, shipmentId, declarationId, status, notes, createdAt)
- [x] Add db helpers: createJobOrder, listJobOrders, getJobOrderById, updateJobOrder
- [x] Add tRPC router: jobOrders.create, jobOrders.list, jobOrders.getById, jobOrders.update, jobOrders.delete
- [x] Create client page: client/src/pages/JobOrders.tsx
- [x] Add route /job-orders in App.tsx
- [x] Add sidebar menu item "أوامر العمل"
- [x] Link jobOrder to customsDeclaration (add jobOrderId column to customsDeclarations)

## Phase 2: Enhanced Customs (تعزيز التخليص)
- [x] Add columns to clearanceCosts: inspectionFee, penalties, weightDifferences, otherGovtFees
- [x] Add releasePermit fields to customsDeclarations (releaseDate, releasedBy, releaseNotes)
- [x] Update clearance costs UI
- [x] Add release permit button/form to CustomsDeclarations

## Phase 3: Internal Transport + POD
- [x] Create internalTransportOrders table
- [x] Add db helpers + tRPC routers
- [x] Create client page: InternalTransport.tsx
- [x] Add route + sidebar menu
- [x] Add POD dialog with receiver signature, safety notes, and status update

## Phase 4: Asset Management + Depreciation
- [x] Create fixedAssets table
- [x] Add db helpers + tRPC routers
- [x] Add depreciation auto-calculation
- [x] Create client page: FixedAssets.tsx
- [x] Add route + sidebar menu

## Phase 5: Enhanced Chart of Accounts
- [x] Update accounts table to support parent-child hierarchy
- [x] Add COA builder UI (tree view) in GeneralLedger
- [x] Add standard accounts (1000-6100 hierarchy, 28 accounts inserted, enums fixed)

## Phase 6: Post-Closure Evaluation (CSAT)
- [x] Create evaluations table
- [x] Add db helpers + tRPC routers
- [x] Add evaluation form in job closure flow (Evaluations.tsx)
- [x] Show ratings in ClearanceReports (new tab: تقييمات العملاء with avg rating + star breakdown)

## Phase 2 Updates
- [x] Add clearanceCosts router fields: inspectionFee, penalties, weightDifferences, otherGovtFees (create + update)
- [x] Add declarations.issueReleasePermit router
- [x] Update ClearanceCosts.tsx form + table with new fields
- [x] Update CustomsDeclarations.tsx with release permit button + dialog

## Phase 7: Advanced Search & Filtering (بحث وتصفية متقدم)
- [x] Add search + filters to JobOrders page (by status, client, jobNumber, date range)
- [x] Add search + filters to InternalTransport page (by status, driver, vehicle, date range, origin/destination)
- [x] Add search + filters to CustomsDeclarations page (by status, client, date range)

## Phase 8: Export Search Results to Excel/CSV (تصدير النتائج)
- [x] Add export to Excel/CSV for JobOrders filtered results
- [x] Add export to Excel/CSV for InternalTransport filtered results
- [x] Add export to Excel/CSV for CustomsDeclarations filtered results

## Phase 9: Export Excel/CSV for Clearance Pages (تصدير المقبوضات والمدفوعات والتكاليف)
- [x] Add export to Excel/CSV for ClearanceReceipts (المقبوضات)
- [x] Add export to Excel/CSV for ClearanceDisbursements (المدفوعات)
- [x] Add export to Excel/CSV for ClearanceCosts (تكاليف التخليص)

## Phase 10: Export Excel/CSV for Clearance Expenses (تصدير المصاريف والنثريات)
- [x] Add export to Excel/CSV for ClearanceExpenses (المصاريف والنثريات)

## Phase 11: Comprehensive Multi-Sheet Export (تصدير شامل متعدد الأوراق)
- [x] Add export function in client/src/lib/export.ts for multi-sheet Excel
- [x] Add export button in ClearancePayments page (gathers receipts + disbursements + costs into one Excel file with multiple sheets)

## Phase 12: Comprehensive Export for Internal Transport + Job Orders (تصدير شامل للنقل الداخلي وأوامر العمل)
- [x] Add comprehensive multi-sheet export button in InternalTransport page (transport orders + POD)
- [x] Add comprehensive multi-sheet export button in JobOrders page (job orders + linked data)

## Phase 13: Comprehensive Export for Customs Declarations (تصدير شامل للبيانات الجمركية)
- [x] Add comprehensive multi-sheet export button in CustomsDeclarations page (declaration data + costs + receipts + disbursements)

## Phase 14: Role-Based Access Control - Hide Financial Sections
- [x] Add modulePermissions table in DB (userId, moduleId, canView) + schema.ts
- [x] Define financial module IDs (13 financial + 11 operational modules) in Settings.tsx
- [x] Add db helpers (listAllUsers, listModulePermissions, upsertModulePermission)
- [x] Add tRPC routers: moduleAccess.myPermissions, listUsers, getUserPermissions, setPermission, setPermissions
- [x] ModuleGuard component in App.tsx wraps all financial routes (Access Denied page)
- [x] Sidebar filtering in DashboardLayout (hide financial items for unauthorized users)
- [x] Settings page permissions tab: user selector + checkboxes + select/deselect all buttons

## Phase 15: Home Grid + Payment Types + Cashboxes + Suppliers + Employees + Custody
- [x] Create suppliers table in DB
- [x] Create employees table in DB
- [x] Create custody/advances table in DB
- [x] Create cashboxes/banks table in DB
- [x] Add db helpers for all new tables
- [x] Add tRPC routers for suppliers, employees, custody, cashboxes
- [x] Redesign Home page as grid cards (Clearance, Clients, Suppliers, Expenses, Employees, Custody, Reports, etc.)
- [x] Create Suppliers page (CRUD + search)
- [x] Create Employees page (CRUD + search)
- [x] Create Custody/Advances page (CRUD + search)
- [x] Create Cashboxes/Banks settings page (add/edit/delete)
- [x] Add payment type field (نقداً/آجل/حوالة) to ServiceInvoices
- [x] Add payment type field to ClearanceReceipts/Disbursements
- [x] Add cashbox selection (from/to which cashbox/bank) to receipts and payments
- [x] Update sidebar with new sections

## Phase 16: Visual Indicator for User Financial Permissions
- [x] Add visual indicator next to username in sidebar showing whether user has financial permissions (badge: صلاحيات كاملة = green, صلاحيات مالية = blue, عمليات فقط = amber); live via trpc.moduleAccess.myPermissions so it updates when permissions change

## Phase 17: Enhanced User Profile Screen - Permissions Details & Change Log

- [x] Add permissionAuditLog table in drizzle/schema.ts (userId, moduleId, action, grantedBy, createdAt)
- [x] Add migration SQL and apply to database (table created via direct SQL)
- [x] Add db helpers: logPermissionChange, logPermissionChangeAsync, listPermissionAuditLogs
- [x] Add tRPC router: moduleAccess.auditLog (admin-only)
- [x] Instrument all permission mutations (setPermission, setPermissions) to write audit entries
- [x] Redesign Settings permissions tab: "تفاصيل صلاحيات المستخدم الحالي" summary card (stat boxes + module badges) + "سجل تغييرات الصلاحيات" table (module, action منح/سحب, grantedByName, Arabic date) with empty state; audit log refetched after each change
- [x] Vitest coverage for audit logging and admin-only auditLog access (6 tests passing, 27/27 full suite)
- [x] Save checkpoint and deliver (checkpoint 850e887d, auto-published)

## Bug Fix: Create Declaration Select.Item empty value

- [x] Find all Select.Item with empty string value="" in CustomsDeclarations "إنشاء بيان" dialog (shipment "بدون شحنة", customer, customs port, driver selects all used empty string values)
- [x] Fix by giving placeholder items a unique non-empty value ("none" for shipments, "__none__" for port/driver/client) and normalizing it in onValueChange
- [x] Verify with screenshot/vitest (27/27 passing) and checkpoint, then deliver

## Bug Fix: Permissions tab module lists not rendering

- [x] Diagnose root cause: settings.getAll batch failed with 500s from column mismatch in DB (cashBoxes lacked currency/updatedAt; languages/fonts lacked createdAt; fonts.family vs fontFamily) — crashing the settings page in production
- [x] Fix root cause: added missing columns via ALTER TABLE (cashBoxes.currency/updatedAt, languages.createdAt, fonts.createdAt, fonts.family→fontFamily); batch verified 200 with all 6 queries OK
- [x] UX hardening: auto-select current admin user in permissions tab via useEffect; hint text under user selector; empty-state card when no user selected
- [x] Verify vitest (27/27 passing); checkpoint 9e9fc7b9 auto-published

## Feature: Manual Declaration Number Entry
- [x] Ensure declarationNumber field in CustomsDeclarations "إنشاء بيان" dialog is a manual text input
- [x] Add placeholder/label clarifying it should match the real port declaration number
- [x] Checkpoint + deliver (checkpoint 01c8282f auto-published)

## Feature: Customs Declaration File Attachments
- [x] Add attachmentUrl/Key and releaseAttachmentUrl/Key columns to customsDeclarations table in schema.ts
- [x] Apply database migration for the new columns via direct SQL
- [x] Update tRPC router (declarations.create, declarations.update, declarations.issueReleasePermit) to handle attachments
- [x] Add real file upload via tRPC (getUploadUrl) in CustomsDeclarations create/edit and release dialogs
- [x] Add "عرض المرفق" (Declaration & Release) icons in the declarations table with direct links
- [x] Verify file upload and retrieval, then save checkpoint 276def48 and deliver

## Integrated Customs Workflow (Entry -> Declaration -> Voucher)

- [x] Create customsEntries table (entryNumber, clientId, type, date, goodsType, port, plateNumber, driverName)
- [x] Add db helpers and tRPC routers for customsEntries
- [x] Create CustomsEntries.tsx page and add to sidebar
- [x] Update CustomsDeclarations.tsx: auto-fetch entry data when entryNumber is entered
- [x] Update Vouchers.tsx: auto-fetch declaration data when declarationNumber is entered
- [x] Implement cost/expense addition within vouchers for declaration-linked entries
- [x] Add "Post" (ترحيل) functionality to vouchers to update General Ledger
- [x] Verify full workflow: Entry -> Declaration -> Voucher -> Ledger
- [x] Save checkpoint and deliver

## Licensing and Deduction System (التراخيص والتخصيم)
- [x] Create `permits` table and related schema
- [x] Create `quantityDeductions` table (independent from customs)
- [x] Add DB helpers for permits and quantity deductions
- [x] Add tRPC routers for permits and quantity deductions
- [x] Create `Permits.tsx` page (Management + Analytics)
- [x] Create `QuantityDeductions.tsx` page (Independent manual entry)
- [x] Update Sidebar and Routes alignment
- [x] Verify auto-calculation of remaining quantities
- [x] Add Analytical reports (Pie charts) for permits
- [x] Add Expiry alerts for permits
- [x] Add Excel export for all licensing modules
- [x] Fix module IDs and routing alignment (Home, Settings, DashboardLayout)
- [x] Hardening the 'Post to Ledger' logic with dynamic account mapping
- [x] Add Excel and CSV export for Receipts, Payments, and Clearance Costs
- [x] Add comprehensive Excel export combining all financial data in Clearance Reports
- [x] Verify the 'Quantity Deductions' UI to ensure all 'Reference Number' and 'Goods Type' fields are working as intended.
- [x] Final end-to-end test and cleanup
- [x] Save final checkpoint and deliver

## Mobile Responsiveness & Field Delegate UX (تحسين الموبايل وتجربة المندوبين)
- [x] Optimize `DashboardLayout.tsx` for mobile (Collapsible sidebar/drawer)
- [x] Improve `Home.tsx` grid layout for mobile screens
- [x] Implement responsive tables (scrollable or card-based) for all modules
- [x] Add "Quick Action" buttons for field delegates (Create Entry, Deduct Quantity)
- [x] Optimize forms for mobile input (larger touch targets, numeric keyboards)
- [x] Final mobile verification and checkpoint

## Final System Hardening
- [x] Integrated Customs Workflow (Entry -> Declaration -> Cost -> Invoice -> Voucher -> Ledger)
- [x] Independent Licensing & Deductions Module
- [x] Comprehensive Analytics & Multi-sheet Excel Export
- [x] Role-Based Access Control (RBAC) with Audit Logging
- [x] Full Mobile Responsiveness for Field Operations
