# PROJECT_NOTES.md - آخر تحديث: 2026-08-20

## الحالة: تم تطبيق قاعدة البيانات + db.ts + routers.ts
## المتبقي: إصلاح frontend pages (CustomsDeclarations ✅, ClearanceCosts, ClearanceReceipts, ClearanceDisbursements, ClearanceReports)

## ما تم:
1. ✅ قاعدة البيانات مطبقة (SQL)
2. ✅ schema.ts محدث
3. ✅ db.ts محدث (clearanceReceipts, clearanceDisbursements)
4. ✅ routers.ts محدث (declarations, clearanceCosts, clearanceReceipts, clearanceDisbursements)
5. ✅ CustomsDeclarations.tsx أعيد كتابتها

## المتبقي في frontend:
- ClearanceCosts.tsx: إعادة بناء (أعمدة فردية: declarationFee, transport, fuel, driverCost, maintenance, otherExpenses, pettyCash, totalCost, discount, netCost)
- ClearanceReceipts.tsx: إنشاء صفحة جديدة
- ClearanceDisbursements.tsx: إنشاء صفحة جديدة
- ClearancePayments.tsx: حذف (كان يستخدم clearancePayments القديم)
- ClearanceExpenses.tsx: حذف
- ClearanceReports.tsx: إعادة كتابة (5 تقارير)
- App.tsx: تحديث المسارات (receipts, disbursements بدل payments, expenses)
- DashboardLayout.tsx: تحديث القائمة الجانبية

## Routers API:
- trpc.declarations: list, get, nextNumber, create, update, delete
- trpc.clearanceCosts: list, create, update, delete, summary
- trpc.clearanceReceipts: list, create, delete
- trpc.clearanceDisbursements: list, create, delete
- trpc.currencies: list
- trpc.clients: list
- trpc.shipments: list

## Custom pages needed (App.tsx routes):
- /customs-declarations → CustomsDeclarations
- /clearance-costs → ClearanceCosts
- /clearance-receipts → ClearanceReceipts
- /clearance-disbursements → ClearanceDisbursements
- /clearance-reports → ClearanceReports

## DashboardLayout sidebar menu (customs section):
- البيانات الجمركية (/customs-declarations)
- تكاليف التخليص (/clearance-costs)
- المقبوضات (/clearance-receipts)
- المدفوعات (/clearance-disbursements)
- التقارير (/clearance-reports)
