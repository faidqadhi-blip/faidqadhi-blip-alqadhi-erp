# جرد قاعدة البيانات الحالية - نظام فيدل القاضي للتخليص الجمركي

## 1. الجداول الموجودة حالياً (28 جدول)

| # | الجدول | الحالة | الوصف |
|---|--------|--------|-------|
| 1 | `users` | أساسي | المستخدمون |
| 2 | `clients` | أساسي | العملاء |
| 3 | `shipments` | أساسي | الشحنات (مرتبطة بـ clientId) |
| 4 | `invoices` | يحتاج تعديل | فواتير الشحن (مرتبطة بـ clientId + shipmentId) |
| 5 | `entries` | موجود | ترحيل الشحنات |
| 6 | `salesTransfers` | موجود | ترحيل المبيعات |
| 7 | `payments` | موجود | مدفوعات الفواتير |
| 8 | `transferLogs` | موجود | سجل الترحيل |
| 9 | `settings` | موجود | إعدادات النظام |
| 10 | `serviceInvoices` | موجود | فواتير خدمية |
| 11 | `vouchers` | موجود | سندات (قبض/صرف) |
| 12 | `accounts` | موجود | دليل الحسابات |
| 13 | `journalEntries` | موجود | قيود اليومية |
| 14 | `journalEntryItems` | موجود | بنود القيود |
| 15 | `dailyMovements` | موجود | الحركة اليومية |
| 16 | `cashBoxes` | موجود | الصناديق |
| 17 | `currencies` | موجود | العملات |
| 18 | `languages` | موجود | اللغات |
| 19 | `fonts` | موجود | الخطوط |
| 20 | `templates` | موجود | النماذج |
| 21 | `permissions` | موجود | الصلاحيات |
| 22 | `backups` | موجود | النسخ الاحتياطي |
| 23 | `services` | موجود | الخدمات |
| 24 | `customsDeclarations` | **جديد - قيد التطوير** | البيانات الجمركية |
| 25 | `clearanceCosts` | **جديد - قيد التطوير** | تكاليف التخليص |
| 26 | `clearancePayments` | **جديد - قيد التطوير** | المقبوضات والمدفوعات |
| 27 | `clearanceExpenses` | **جديد - قيد التطوير** | المصاريف والنثريات |

---

## 2. تفاصيل الجداول المرتبطة بقسم التخليص

### `clients` (موجود ويعمل)
| الحقل | النوع |
|-------|------|
| id | INT PK |
| code | VARCHAR(20) |
| name | VARCHAR(200) |
| phone | VARCHAR(20) |
| address | TEXT |
| nationalId | VARCHAR(30) |
| commercialReg | VARCHAR(30) |
| taxNumber | VARCHAR(30) |
| notes | TEXT |

### `shipments` (موجود ويعمل)
| الحقل | النوع |
|-------|------|
| id | INT PK |
| clientId | INT FK → clients |
| invoiceType | ENUM(تخليص_جمركي، شحن_داخلي، تعبئة_وتغليف) |
| entryDate | VARCHAR(20) |
| releaseDate | VARCHAR(20) |
| driverName | VARCHAR(100) |
| routeFrom | VARCHAR(100) |
| routeTo | VARCHAR(100) |
| goodsType | VARCHAR(100) |
| customsPort | VARCHAR(100) |
| unit | VARCHAR(30) |
| quantity | VARCHAR(50) |
| quantityTons | DECIMAL(12,2) |
| invoiceNumber | INT |
| agriLicense | VARCHAR(50) |
| paymentLicense | VARCHAR(50) |
| status | ENUM(جديد، تم_الترحيل، مكتمل، ملغي) |

### `vouchers` (موجود ويعمل - سند قبض/صرف)
| الحقل | النوع |
|-------|------|
| id | INT PK |
| number | INT unique |
| voucherType | ENUM(سند_قبض، سند_صرف) |
| clientId | INT FK → clients |
| amount | DECIMAL(14,2) |
| currency | VARCHAR(10) |
| date | VARCHAR(20) |
| paymentMethod | VARCHAR(50) |
| cashBox | VARCHAR(100) |
| description | TEXT |
| status | ENUM(مسودة، معتمد، ملغي) |

### `customsDeclarations` (جديد - موجود جزئياً)
| الحقل | النوع |
|-------|------|
| id | INT PK |
| entryNumber | VARCHAR(50) - رقم القيد |
| declarationNumber | VARCHAR(50) - رقم البيان |
| declarationDate | VARCHAR(20) |
| clientId | INT - **موجود لكن بدون FK حقيقي** |
| clientName | VARCHAR(200) - **تكرار! يجب حذفه** |
| goodsType | VARCHAR(200) |
| customsPort | VARCHAR(200) |
| plateNumber | VARCHAR(50) |
| driverName | VARCHAR(200) |
| declarationFee | DECIMAL(14,2) |
| currency | VARCHAR(10) |
| status | ENUM(نشط، مكتمل، ملغي) |
| notes | TEXT |

### `clearanceCosts` (جديد - يحتاج إعادة هيكلة)
| الحقل | النوع | ملاحظة |
|-------|------|--------|
| id | INT PK | |
| declarationId | INT FK → customsDeclarations | ✅ صحيح |
| costType | ENUM(رسوم_تخليص، نقل، تحميل، تفريغ، نثريات، أتعاب، رسوم_أخرى) | ✅ موجود |
| amount | DECIMAL(14,2) | |
| description | TEXT | |
| **ناقص** | isApproved BOOLEAN | اعتماد التكلفة |
| **ناقص** | totalCost DECIMAL | الإجمالي المحسوب |

### `clearancePayments` (جديد - يحتاج فصل)
| الحقل | النوع | ملاحظة |
|-------|------|--------|
| id | INT PK | |
| declarationId | INT FK → customsDeclarations | ✅ |
| paymentType | ENUM(مقبوض، مدفوع) | ❌ يجب فصلها لجدولين |
| amount | DECIMAL(14,2) | |
| currency | VARCHAR(10) | |
| paymentMethod | VARCHAR(50) | |
| paymentDate | VARCHAR(20) | |
| notes | TEXT | |

### `clearanceExpenses` (جديد - يحتاج مراجعة)
| الحقل | النوع | ملاحظة |
|-------|------|--------|
| id | INT PK | |
| declarationId | INT FK → customsDeclarations | ✅ |
| expenseType | ENUM(نقل، تحميل، تفريغ، ضيافة، اتصالات، رسوم_صغيرة، مصاريف_أخرى) | |
| amount | DECIMAL(14,2) | |
| description | TEXT | |
| expenseDate | VARCHAR(20) | |

---

## 3. التصميم المقترح النهائي لقسم التخليص

### التعديلات المطلوبة:

#### أ) `customsDeclarations` - تعديل:
| الإجراء | الحقل | السبب |
|---------|-------|------|
| **إضافة** | `shipmentId` INT FK → shipments | ربط البيان بالشحنة الموجودة |
| **حذف** | `clientName` VARCHAR | تكرار - نستخدم clientId فقط |
| **تعديل** | `status` ENUM | إضافة: مسودة، معتمد، مكتمل، ملغي |
| **إضافة** | `approvedAt` TIMESTAMP NULLABLE | تاريخ الاعتماد |

#### ب) `clearanceCosts` - إعادة هيكلة:
| الإجراء | الحقل | السبب |
|---------|-------|------|
| **إبقاء** | `declarationId` | FK صحيح |
| **إضافة** | `declarationFee` DECIMAL | رسوم البيان |
| **إضافة** | `transport` DECIMAL | نقل |
| **إضافة** | `fuel` DECIMAL | وقود |
| **إضافة** | `driverCost` DECIMAL | سائق |
| **إضافة** | `maintenance` DECIMAL | صيانة |
| **إضافة** | `otherExpenses` DECIMAL | مصاريف أخرى |
| **إضافة** | `pettyCash` DECIMAL | نثريات |
| **إضافة** | `totalCost` DECIMAL | الإجمالي (محسوب) |
| **إضافة** | `discount` DECIMAL | خصم |
| **إضافة** | `netCost` DECIMAL | الصافي |
| **إضافة** | `isApproved` BOOLEAN | اعتماد التكلفة |
| **حذف** | `costType` ENUM | سيُستبدل بالأعمدة الفردية |

#### ج) `clearancePayments` - **فصل إلى جدولين**:
- `clearanceReceipts` (مقبوضات): declarationId, amount, currency, paymentDate, paymentMethod, clientId (FK), voucherId (FK → vouchers), notes
- `clearanceDisbursements` (مدفوعات): declarationId, payee VARCHAR, amount, currency, paymentDate, paymentMethod, expenseType, voucherId (FK → vouchers), notes

#### د) `vouchers` - إضافة:
| الإجراء | الحقل | السبب |
|---------|-------|------|
| **إضافة** | `sourceDeclarationId` INT FK → customsDeclarations | ربط السند بالبيان |

---

## 4. الهيكل النهائي المقترح:

```
clients
   │
   └── shipments
           │
           └── customsDeclarations ← (clientId + shipmentId FKs)
                   │
                   ├── clearanceCosts (أعمدة فردية للتكاليف)
                   ├── clearanceReceipts ←→ vouchers (سند قبض)
                   ├── clearanceDisbursements ←→ vouchers (سند صرف)
                   └── vouchers (linked via sourceDeclarationId)
```

---

## 5. ملخص الحالة:

| الحالة | الجداول |
|--------|---------|
| 🟢 موجود ويعمل بدون تعديل | clients, shipments, vouchers, users |
| 🟡 يحتاج تعديل طفيف | customsDeclarations (إضافة shipmentId، حذف clientName) |
| 🔴 يحتاج إعادة هيكلة | clearanceCosts |
| 🔴 يحتاج فصل لجدولين | clearancePayments → clearanceReceipts + clearanceDisbursements |
| 🔴 يحتاج حذف أو إعادة استخدام | clearanceExpenses (يدمج مع clearanceDisbursements) |
